<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1473594557704" ID="15kufd1au88is0qo3dleiiurk7" MODIFIED="1498398790798" TEXT="&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x7684;&#x7279;&#x5f81;">
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1473594557704" FOLDED="true" ID="6ml1tdso6cbq8mqa355glu755q" MODIFIED="1500283094618" POSITION="right" TEXT="&#x591a;&#x6001;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473594557704" ID="ID_1468377008" MODIFIED="1500272885823" TEXT="&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_479269167" MODIFIED="1473596636747" TEXT="&#x540c;&#x4e00;&#x79cd;&#x4e8b;&#x7269;&#x6216;&#x884c;&#x4e3a;&#x7684;&#x4e0d;&#x540c;&#x8868;&#x73b0;&#x5f62;&#x5f0f;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1280507562" MODIFIED="1473594682137" TEXT="&#x4e13;&#x4e1a;&#x7684;&#x8bf4;&#x6cd5;&#x662f;:&#x540c;&#x4e00;&#x4e2a;&#x5b9e;&#x73b0;&#x63a5;&#x53e3;,&#x4f7f;&#x7528;&#x4e0d;&#x540c;&#x7684;&#x5b9e;&#x4f8b;&#x800c;&#x6267;&#x884c;&#x4e0d;&#x540c;&#x7684;&#x64cd;&#x4f5c;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594557704" ID="ID_450984794" MODIFIED="1500272885838" TEXT="&#x591a;&#x6001;&#x7684;&#x4e09;&#x4e2a;&#x6761;&#x4ef6;:">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1105972674" MODIFIED="1473594682137" TEXT="   &#x7ee7;&#x627f;&#x7684;&#x5b58;&#x5728;(&#x7ee7;&#x627f;&#x662f;&#x591a;&#x6001;&#x7684;&#x57fa;&#x7840;,&#x6ca1;&#x6709;&#x7ee7;&#x627f;&#x5c31;&#x6ca1;&#x6709;&#x591a;&#x6001;).">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_423874104" MODIFIED="1473594682137" TEXT=" &#x5b50;&#x7c7b;&#x91cd;&#x5199;&#x7236;&#x7c7b;&#x7684;&#x65b9;&#x6cd5;(&#x591a;&#x6001;&#x4e0b;&#x8c03;&#x7528;&#x5b50;&#x7c7b;&#x91cd;&#x5199;&#x7684;&#x65b9;&#x6cd5;).">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_400190760" MODIFIED="1473597749922" TEXT=" &#x7236;&#x7c7b;&#x7684;&#x5f15;&#x7528;&#x6307;&#x5411;&#x5b50;&#x7c7b;&#x5bf9;&#x8c61;(&#x5b50;&#x7c7b;&#x5230;&#x7236;&#x7c7b;&#x7684;&#x7c7b;&#x578b;&#x8f6c;&#x6362;).">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594801436" FOLDED="true" ID="ID_1890559757" MODIFIED="1500272934305" TEXT="&#x4f5c;&#x7528;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473595094633" ID="ID_1862579766" MODIFIED="1473595094633" TEXT="&#x5206;&#x79bb;&#x505a;&#x4ec0;&#x4e48;&#x548c;&#x600e;&#x4e48;&#x505a;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473595103890" ID="ID_445388730" MODIFIED="1473595113486" TEXT="&#x6d88;&#x9664;&#x7c7b;&#x578b;&#x95f4;&#x7684;&#x8026;&#x5408;&#x5173;&#x7cfb;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473597807463" ID="ID_1829510560" MODIFIED="1500272885917" TEXT="&#x597d;&#x5904;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473597810565" ID="ID_1695556147" MODIFIED="1473597810565" TEXT="1.&#x53ef;&#x66ff;&#x6362;&#x6027;&#xff08;substitutability&#xff09;&#x3002;&#x591a;&#x6001;&#x5bf9;&#x5df2;&#x5b58;&#x5728;&#x4ee3;&#x7801;&#x5177;&#x6709;&#x53ef;&#x66ff;&#x6362;&#x6027;&#x3002;&#x4f8b;&#x5982;&#xff0c;&#x591a;&#x6001;&#x5bf9;&#x5706;Circle&#x7c7b;&#x5de5;&#x4f5c;&#xff0c;&#x5bf9;&#x5176;&#x4ed6;&#x4efb;&#x4f55;&#x5706;&#x5f62;&#x51e0;&#x4f55;&#x4f53;&#xff0c;&#x5982;&#x5706;&#x73af;&#xff0c;&#x4e5f;&#x540c;&#x6837;&#x5de5;&#x4f5c;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473597810575" ID="ID_1092953297" MODIFIED="1473597810575" TEXT="2.&#x53ef;&#x6269;&#x5145;&#x6027;&#xff08;extensibility&#xff09;&#x3002;&#x591a;&#x6001;&#x5bf9;&#x4ee3;&#x7801;&#x5177;&#x6709;&#x53ef;&#x6269;&#x5145;&#x6027;&#x3002;&#x589e;&#x52a0;&#x65b0;&#x7684;&#x5b50;&#x7c7b;&#x4e0d;&#x5f71;&#x54cd;&#x5df2;&#x5b58;&#x5728;&#x7c7b;&#x7684;&#x591a;&#x6001;&#x6027;&#x3001;&#x7ee7;&#x627f;&#x6027;&#xff0c;&#x4ee5;&#x53ca;&#x5176;&#x4ed6;&#x7279;&#x6027;&#x7684;&#x8fd0;&#x884c;&#x548c;&#x64cd;&#x4f5c;&#x3002;&#x5b9e;&#x9645;&#x4e0a;&#x65b0;&#x52a0;&#x5b50;&#x7c7b;&#x66f4;&#x5bb9;&#x6613;&#x83b7;&#x5f97;&#x591a;&#x6001;&#x529f;&#x80fd;&#x3002;&#x4f8b;&#x5982;&#xff0c;&#x5728;&#x5b9e;&#x73b0;&#x4e86;&#x5706;&#x9525;&#x3001;&#x534a;&#x5706;&#x9525;&#x4ee5;&#x53ca;&#x534a;&#x7403;&#x4f53;&#x7684;&#x591a;&#x6001;&#x57fa;&#x7840;&#x4e0a;&#xff0c;&#x5f88;&#x5bb9;&#x6613;&#x589e;&#x6dfb;&#x7403;&#x4f53;&#x7c7b;&#x7684;&#x591a;&#x6001;&#x6027;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473597810585" ID="ID_1399905529" MODIFIED="1473597810585" TEXT="3.&#x63a5;&#x53e3;&#x6027;&#xff08;interface-ability&#xff09;&#x3002;&#x591a;&#x6001;&#x662f;&#x8d85;&#x7c7b;&#x901a;&#x8fc7;&#x65b9;&#x6cd5;&#x7b7e;&#x540d;&#xff0c;&#x5411;&#x5b50;&#x7c7b;&#x63d0;&#x4f9b;&#x4e86;&#x4e00;&#x4e2a;&#x5171;&#x540c;&#x63a5;&#x53e3;&#xff0c;&#x7531;&#x5b50;&#x7c7b;&#x6765;&#x5b8c;&#x5584;&#x6216;&#x8005;&#x8986;&#x76d6;&#x5b83;&#x800c;&#x5b9e;&#x73b0;&#x7684;&#x3002;&#x5982;&#x56fe;8.3 &#x6240;&#x793a;&#x3002;&#x56fe;&#x4e2d;&#x8d85;&#x7c7b;Shape&#x89c4;&#x5b9a;&#x4e86;&#x4e24;&#x4e2a;&#x5b9e;&#x73b0;&#x591a;&#x6001;&#x7684;&#x63a5;&#x53e3;&#x65b9;&#x6cd5;&#xff0c;computeArea()&#x4ee5;&#x53ca;computeVolume()&#x3002;&#x5b50;&#x7c7b;&#xff0c;&#x5982;Circle&#x548c;Sphere&#x4e3a;&#x4e86;&#x5b9e;&#x73b0;&#x591a;&#x6001;&#xff0c;&#x5b8c;&#x5584;&#x6216;&#x8005;&#x8986;&#x76d6;&#x8fd9;&#x4e24;&#x4e2a;&#x63a5;&#x53e3;&#x65b9;&#x6cd5;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473597810595" ID="ID_89695657" MODIFIED="1473597810595" TEXT="4.&#x7075;&#x6d3b;&#x6027;&#xff08;flexibility&#xff09;&#x3002;&#x5b83;&#x5728;&#x5e94;&#x7528;&#x4e2d;&#x4f53;&#x73b0;&#x4e86;&#x7075;&#x6d3b;&#x591a;&#x6837;&#x7684;&#x64cd;&#x4f5c;&#xff0c;&#x63d0;&#x9ad8;&#x4e86;&#x4f7f;&#x7528;&#x6548;&#x7387;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473597810595" ID="ID_44282645" MODIFIED="1473597810595" TEXT="5.&#x7b80;&#x5316;&#x6027;&#xff08;simplicity&#xff09;&#x3002;&#x591a;&#x6001;&#x7b80;&#x5316;&#x5bf9;&#x5e94;&#x7528;&#x8f6f;&#x4ef6;&#x7684;&#x4ee3;&#x7801;&#x7f16;&#x5199;&#x548c;&#x4fee;&#x6539;&#x8fc7;&#x7a0b;&#xff0c;&#x5c24;&#x5176;&#x5728;&#x5904;&#x7406;&#x5927;&#x91cf;&#x5bf9;&#x8c61;&#x7684;&#x8fd0;&#x7b97;&#x548c;&#x64cd;&#x4f5c;&#x65f6;&#xff0c;&#x8fd9;&#x4e2a;&#x7279;&#x70b9;&#x5c24;&#x4e3a;&#x7a81;&#x51fa;&#x548c;&#x91cd;&#x8981;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473597838503" ID="ID_1193474795" MODIFIED="1500272885917" TEXT="&#x8868;&#x73b0;&#x65b9;&#x5f0f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473597843145" ID="ID_191296960" MODIFIED="1473597849305" TEXT="&#x63a5;&#x53e3;&#x5b9e;&#x73b0;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473597850323" ID="ID_1940271679" MODIFIED="1473597864195" TEXT="&#x7ee7;&#x627f;&#x7236;&#x7c7b;&#x8fdb;&#x884c;&#x65b9;&#x6cd5;&#x91cd;&#x5199;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473597857323" ID="ID_769671708" MODIFIED="1473597871115" TEXT="&#x540c;&#x4e00;&#x4e2a;&#x7c7b;&#x4e2d;&#x8fdb;&#x884c;&#x65b9;&#x6cd5;&#x91cd;&#x8f7d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473596111501" ID="ID_447929610" MODIFIED="1500272885932" TEXT="&#x591a;&#x6001;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473596118606" ID="ID_414760960" MODIFIED="1500272885932" TEXT="&#x6784;&#x9020;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473596134042" ID="ID_1181395281" MODIFIED="1473596172452" TEXT="&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x5b9e;&#x9645;&#x4e0a;&#x662f;static&#x7684;&#xff0c;&#x53ea;&#x4e0d;&#x8fc7;&#x662f;&#x8be5;static&#x7684;&#x58f0;&#x660e;&#x662f;&#x9690;&#x5f0f;&#x7684;&#xff08;&#x7cfb;&#x7edf;&#x52a0;&#x4e0a;&#x7684;&#xff09;"/>
<node COLOR="#111111" CREATED="1473596173471" ID="ID_85309" MODIFIED="1473596190805" TEXT="&#x6240;&#x4ee5;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x4e0d;&#x5177;&#x5907;&#x591a;&#x6001;&#x6027;"/>
</node>
<node COLOR="#990000" CREATED="1473596195662" ID="ID_324868214" MODIFIED="1500272885932" TEXT="&#x666e;&#x901a;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473596207651" ID="ID_1676002941" MODIFIED="1473596216576" TEXT="private&#x65b9;&#x6cd5;&#x4e0d;&#x5177;&#x5907;&#x591a;&#x6001;&#x6027;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473595730629" ID="ID_672222329" MODIFIED="1500272885932" TEXT="&#x7ed1;&#x5b9a;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473595829322" ID="ID_1054271173" MODIFIED="1500272885932" TEXT="&#x5206;&#x7c7b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473595739872" ID="ID_590781324" MODIFIED="1500272885932" TEXT="&#x524d;&#x671f;&#x7ed1;&#x5b9a;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473595779426" ID="ID_1122537805" MODIFIED="1473595791221" TEXT="&#x6307;&#x7684;&#x662f;&#x7f16;&#x8bd1;&#x65f6;&#x5c31;&#x53ef;&#x4ee5;&#x786e;&#x5b9a;"/>
</node>
<node COLOR="#111111" CREATED="1473595744732" ID="ID_95647036" MODIFIED="1500272885932" TEXT="&#x540e;&#x671f;&#x7ed1;&#x5b9a;/&#x52a8;&#x6001;&#x7ed1;&#x5b9a;/&#x8fd0;&#x884c;&#x65f6;&#x7ed1;&#x5b9a;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473595794487" ID="ID_34395726" MODIFIED="1473595817500" TEXT="&#x6307;&#xff1a;&#x5230;&#x7a0b;&#x5e8f;&#x8fd0;&#x884c;&#x65f6;&#x624d;&#x786e;&#x5b9a;&#x6570;&#x636e;&#x7c7b;&#x578b;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473595837162" ID="ID_1901780339" MODIFIED="1473595888313" TEXT="&#x9664;&#x4e86;static&#x548c;final&#x65b9;&#x6cd5;&#x5916;&#xff08;private&#x65b9;&#x6cd5;&#x5176;&#x5b9e;&#x662f;final&#x65b9;&#x6cd5;&#xff09;&#xff0c;&#x5176;&#x4ed6;&#x6240;&#x6709;&#x975e;&#x65b9;&#x6cd5;&#x90fd;&#x662f;&#x540e;&#x671f;&#x7ed1;&#x5b9a;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473594557704" FOLDED="true" ID="1dis4k22pkae2jt0h1jqb2g137" MODIFIED="1498398790798" POSITION="left" TEXT="&#x5c01;&#x88c5;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473594557704" FOLDED="true" ID="ID_1107517208" MODIFIED="1498398790798" TEXT="&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1044289036" MODIFIED="1473594681950" TEXT="&#x5c06;&#x7c7b;&#x7684;&#x72b6;&#x6001;&#x4fe1;&#x606f;&#x9690;&#x85cf;&#x5728;&#x7c7b;&#x5185;&#x90e8;,&#x4e0d;&#x5141;&#x8bb8;&#x5916;&#x90e8;&#x7a0b;&#x5e8f;&#x76f4;&#x63a5;&#x8bbf;&#x95ee;,&#x800c;&#x662f;&#x901a;&#x8fc7;&#x8be5;&#x7c7b;&#x63d0;&#x4f9b;&#x7684;&#x65b9;&#x6cd5;&#x6765;&#x5b9e;&#x73b0;&#x5bf9;&#x9690;&#x85cf;&#x4fe1;&#x606f;&#x7684;&#x64cd;&#x4f5c;&#x548c;&#x8bbf;&#x95ee;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598230386" ID="ID_689379235" MODIFIED="1473598230386" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x4fdd;&#x62a4;&#x5c4f;&#x969c;&#xff0c;&#x9632;&#x6b62;&#x8be5;&#x7c7b;&#x7684;&#x4ee3;&#x7801;&#x548c;&#x6570;&#x636e;&#x88ab;&#x5916;&#x90e8;&#x7c7b;&#x5b9a;&#x4e49;&#x7684;&#x4ee3;&#x7801;&#x968f;&#x673a;&#x8bbf;&#x95ee;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598244556" ID="ID_845466634" MODIFIED="1473598244556" TEXT="&#x8981;&#x8bbf;&#x95ee;&#x8be5;&#x7c7b;&#x7684;&#x4ee3;&#x7801;&#x548c;&#x6570;&#x636e;&#xff0c;&#x5fc5;&#x987b;&#x901a;&#x8fc7;&#x4e25;&#x683c;&#x7684;&#x63a5;&#x53e3;&#x63a7;&#x5236;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594557704" FOLDED="true" ID="ID_669061872" MODIFIED="1498398790798" TEXT="&#x4f7f;&#x7528;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_328237237" MODIFIED="1473594681981" TEXT="&#x4fee;&#x6539;&#x5c5e;&#x6027;&#x7684;&#x53ef;&#x89c1;&#x6027;&#x6765;&#x9650;&#x5236;&#x5bf9;&#x5c5e;&#x6027;&#x7684;&#x8bbf;&#x95ee;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_389822560" MODIFIED="1473594681981" TEXT="&#x4e3a;&#x6bcf;&#x4e2a;&#x5c5e;&#x6027;&#x521b;&#x5efa;&#x4e00;&#x5bf9;&#x8d4b;&#x503c;(setter)&#x65b9;&#x6cd5;&#x548c;&#x53d6;&#x503c;(getter)&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594557704" FOLDED="true" ID="ID_1027367832" MODIFIED="1498398790798" TEXT="&#x4f5c;&#x7528;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_351416304" MODIFIED="1473594681981" TEXT="&#x9690;&#x85cf;&#x7c7b;&#x7684;&#x5b9e;&#x73b0;&#x7ec6;&#x8282;;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1123382943" MODIFIED="1473594681981" TEXT="&#x9650;&#x5236;&#x4e0d;&#x5408;&#x7406;&#x64cd;&#x4f5c;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_73857364" MODIFIED="1473594681981" TEXT="&#x53ef;&#x4ee5;&#x65b9;&#x4fbf;&#x7684;&#x52a0;&#x5165;&#x5b58;&#x53d6;&#x63a7;&#x5236;&#x8bed;&#x53e5;,">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1177054872" MODIFIED="1473594681981" TEXT="&#x8ba9;&#x4f7f;&#x7528;&#x8005;&#x53ea;&#x80fd;&#x901a;&#x8fc7;&#x7a0b;&#x5e8f;&#x5458;&#x89c4;&#x5b9a;&#x7684;&#x65b9;&#x6cd5;&#x6765;&#x8bbf;&#x95ee;&#x6570;&#x636e;;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473594557704" FOLDED="true" ID="0jk8sb0m9gaoptvafs8qod8s5b" MODIFIED="1498398790798" POSITION="left" TEXT="&#x7ee7;&#x627f;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473594557704" FOLDED="true" ID="ID_780628640" MODIFIED="1498398790798" TEXT="&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_36004904" MODIFIED="1473594681981" TEXT="&#x662f;java&#x4e2d;&#x5b9e;&#x73b0;&#x4ee3;&#x7801;&#x91cd;&#x7528;&#x7684;&#x91cd;&#x8981;&#x624b;&#x6bb5;&#x4e4b;&#x4e00;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_84956036" MODIFIED="1473594681981" TEXT="java&#x4e2d;&#x53ea;&#x652f;&#x6301;&#x5355;&#x7ee7;&#x627f;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1450021453" MODIFIED="1473594681981" TEXT="&#x7ee7;&#x627f;&#x8868;&#x8fbe;&#x7684;&#x662f;is-a&#x7684;&#x5173;&#x7cfb;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594557704" FOLDED="true" ID="ID_1959096168" MODIFIED="1498398790798" TEXT="&#x5b50;&#x7c7b;&#x53ef;&#x4ee5;&#x7ee7;&#x627f;&#x7236;&#x7c7b;&#x7684;&#x4ec0;&#x4e48;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1032041908" MODIFIED="1473594681997" TEXT="&#x7ee7;&#x627f;public&#x548c;protected&#x4fee;&#x9970;&#x7684;&#x5c5e;&#x6027;&#x548c;&#x65b9;&#x6cd5;,&#x4e0d;&#x7ba1;&#x5b50;&#x7c7b;&#x548c;&#x7236;&#x7c7b;&#x662f;&#x5426;&#x5728;&#x540c;&#x4e00;&#x4e2a;&#x5305;&#x91cc;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1682112511" MODIFIED="1473594681997" TEXT=" &#x7ee7;&#x627f;&#x9ed8;&#x8ba4;&#x6743;&#x9650;&#x4fee;&#x9970;&#x7b26;&#x4fee;&#x9970;&#x7684;&#x5c5e;&#x6027;&#x548c;&#x65b9;&#x6cd5;,&#x4f46;&#x5b50;&#x7c7b;&#x548c;&#x7236;&#x7c7b;&#x5fc5;&#x987b;&#x5728;&#x540c;&#x4e00;&#x4e2a;&#x5305;&#x91cc;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594557704" FOLDED="true" ID="ID_160896896" MODIFIED="1498398790798" TEXT="&#x90a3;&#x4e9b;&#x65e0;&#x6cd5;&#x7ee7;&#x627f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1735736182" MODIFIED="1473594681997" TEXT="&#x65e0;&#x6cd5;&#x7ee7;&#x627f;private&#x4fee;&#x9970;&#x7684;&#x5c5e;&#x6027;&#x548c;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1905302899" MODIFIED="1473594681997" TEXT="&#x65e0;&#x6cd5;&#x7ee7;&#x627f;&#x7236;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594557704" FOLDED="true" ID="ID_21624769" MODIFIED="1498398790798" TEXT="&#x7ee7;&#x627f;&#x6761;&#x4ef6;&#x4e0b;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x8c03;&#x7528;&#x89c4;&#x5219;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1050674678" MODIFIED="1473594682044" TEXT="&#x5982;&#x679c;&#x5b50;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x4e2d;&#x6ca1;&#x6709;&#x901a;&#x8fc7;super&#x663e;&#x793a;&#x8c03;&#x7528;&#x7236;&#x7c7b;&#x7684;&#x6709;&#x53c2;&#x6784;&#x9020;&#x65b9;&#x6cd5;,&#x4e5f;&#x6ca1;&#x6709;&#x901a;&#x8fc7;this&#x663e;&#x793a;&#x8c03;&#x7528;&#x81ea;&#x8eab;&#x7684;&#x5176;&#x4ed6;&#x6784;&#x9020;&#x65b9;&#x6cd5;,&#x5219;&#x7cfb;&#x7edf;&#x4f1a;&#x9ed8;&#x8ba4;&#x5148;&#x8c03;&#x7528;&#x7236;&#x7c7b;&#x7684;&#x65e0;&#x53c2;&#x6784;&#x9020; &#x65b9;&#x6cd5;.&#x5728;&#x8fd9;&#x79cd;&#x60c5;&#x51b5;&#x4e0b;&#x5199;&#x4e0d;&#x5199;super()&#x8bed;&#x53e5;&#x6548;&#x679c;&#x90fd;&#x662f;&#x4e00;&#x6837;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_629407074" MODIFIED="1473594682059" TEXT="&#x5982;&#x679c;&#x5b50;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x4e2d;&#x901a;&#x8fc7;super&#x663e;&#x793a;&#x8c03;&#x7528;&#x7236;&#x7c7b;&#x7684;&#x6709;&#x53c2;&#x6784;&#x9020;&#x65b9;&#x6cd5;,&#x90a3;&#x5c06;&#x6267;&#x884c;&#x7236;&#x7c7b;&#x76f8;&#x5e94;&#x6784;&#x9020;&#x65b9;&#x6cd5;,&#x800c;&#x4e0d;&#x6267;&#x884c;&#x7236;&#x7c7b;&#x65e0;&#x53c2;&#x6784;&#x9020;&#x65b9;&#x6cd5;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_769815116" MODIFIED="1473594682075" TEXT="&#x5982;&#x679c;&#x5b50;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x4e2d;&#x901a;&#x8fc7;this&#x663e;&#x793a;&#x8c03;&#x7528;&#x81ea;&#x8eab;&#x7684;&#x5176;&#x4ed6;&#x6784;&#x9020;&#x65b9;&#x6cd5;,&#x5728;&#x76f8;&#x5e94; &#x6784;&#x9020;&#x65b9;&#x6cd5;&#x4e2d;&#x5e94;&#x7528;&#x4ee5;&#x4e0a;&#x4e24;&#x6761;&#x89c4;&#x5219;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473594557704" ID="ID_1773961410" MODIFIED="1473594682090" TEXT="  &#x7279;&#x522b;&#x6ce8;&#x610f;&#x7684;&#x662f;,&#x5982;&#x679c;&#x5b58;&#x5728;&#x591a;&#x7ea7;&#x7ee7;&#x627f;&#x5173;&#x7cfb;,&#x5728;&#x521b;&#x5efa;&#x4e00;&#x4e2a;&#x5b50;&#x7c7b;&#x5bf9;&#x8c61;&#x65f6;,&#x4ee5;&#x4e0a;&#x89c4;&#x5219;&#x4f1a;&#x591a;&#x6b21;&#x5411;&#x66f4;&#x9ad8;&#x4e00;&#x7ea7;&#x7236;&#x7c7b;&#x5e94;&#x7528;,&#x4e00;&#x76f4;&#x5230;&#x6267;&#x884c;&#x9876;&#x7ea7;&#x7236;&#x7c7b;Object&#x7c7b;&#x7684;&#x65e0;&#x53c2;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x4e3a;&#x6b62;.">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473594702246" ID="ID_1803222223" MODIFIED="1473594794535" TEXT="&#x7ee7;&#x627f;&#x5141;&#x8bb8;&#x5c06;&#x591a;&#x79cd;&#x7c7b;&#x578b;&#xff08;&#x4ece;&#x540c;&#x4e00;&#x57fa;&#x7c7b;&#x5bfc;&#x51fa;&#x7684;&#xff09;&#x89c6;&#x4e3a;&#x540c;&#x4e00;&#x79cd;&#x7c7b;&#x578b;&#x5904;&#x7406;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473594557704" ID="ID_1016526475" MODIFIED="1473594698073" TEXT="&#x6ce8;&#x610f;&#xff1a; &#x5982;&#x679c;&#x4ece;&#x7236;&#x7c7b;&#x7ee7;&#x627f;&#x7684;&#x65b9;&#x6cd5;&#x4e0d;&#x80fd;&#x6ee1;&#x8db3;&#x5b50;&#x7c7b;&#x7684;&#x9700;&#x6c42;,&#x5728;&#x5b50;&#x7c7b;&#x4e2d;&#x53ef;&#x4ee5;&#x5bf9;&#x7236;&#x7c7b;&#x7684;&#x540c;&#x540d;&#x65b9;&#x6cd5;&#x8fdb;&#x884c;&#x91cd;&#x5199;(&#x8986;&#x76d6;),&#x4ee5;&#x7b26;&#x5408;&#x8981;&#x6c42;.">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473595394542" FOLDED="true" ID="ID_680173234" MODIFIED="1498398790798" TEXT="&#x5411;&#x4e0a;&#x8f6c;&#x578b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473595450282" ID="ID_666202475" MODIFIED="1473595460079" TEXT="&#x5b50;&#x7c7b;&#x8f6c;&#x6362;&#x4e3a;&#x7236;&#x7c7b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473595467870" FOLDED="true" ID="ID_1826958772" MODIFIED="1498398790798" TEXT="&#x4f4e;&#x7ea7;&#x522b;&#x7684;&#x8f6c;&#x6362;&#x4e3a;&#x9ad8;&#x7ea7;&#x522b;&#x7684;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473595556696" ID="ID_1647160455" MODIFIED="1473595562938" TEXT="int &#x8f6c;&#x6362;&#x4e3a;long"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473595438372" FOLDED="true" ID="ID_1189640279" MODIFIED="1498398790798" TEXT="&#x5411;&#x4e0b;&#x8f6c;&#x578b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473595517517" ID="ID_1925725418" MODIFIED="1473595533119" TEXT="&#x7236;&#x7c7b;&#x8f6c;&#x6362;&#x4e3a;&#x5b50;&#x7c7b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473595533920" FOLDED="true" ID="ID_1914514429" MODIFIED="1498398790798" TEXT="&#x9ad8;&#x7ea7;&#x522b;&#x7684;&#x8f6c;&#x6362;&#x4e3a;&#x4f4e;&#x7ea7;&#x522b;&#x7684;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473595567281" ID="ID_955922322" MODIFIED="1473595573382" TEXT="long &#x8f6c;&#x6362;&#x4e3a;int"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473597281011" FOLDED="true" ID="ID_437270214" MODIFIED="1498398790798" TEXT="&#x5b50;&#x7c7b;&#x548c;&#x7236;&#x7c7b;&#x90fd;&#x6709;&#x4e00;&#x4e2a;&#x5b8c;&#x5168;&#x76f8;&#x540c;&#x7684;private&#x7684;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473597298756" ID="ID_1036795562" MODIFIED="1473597313094" TEXT="&#x5b50;&#x7c7b;&#x7684;&#x65b9;&#x6cd5;&#x5e76;&#x6ca1;&#x6709;&#x590d;&#x5199;&#x7236;&#x7c7b;&#x7684;&#x65b9;&#x6cd5;&#xff0c;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473597313490" ID="ID_917798864" MODIFIED="1473597340652" TEXT="&#x6b64;&#x65f6;&#xff0c;&#x5b50;&#x7c7b;&#x7684;&#x8be5;&#x65b9;&#x6cd5;&#x662f;&#x4e00;&#x4e2a;&#x5168;&#x65b0;&#x7684;&#x65b9;&#x6cd5;&#xff0c;&#x548c;&#x7236;&#x7c7b;&#x540c;&#x540d;&#x7684;&#x65b9;&#x6cd5;&#x6ca1;&#x6709;&#x8054;&#x7cfb;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
