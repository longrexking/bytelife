package org.lc;

/**
 * project:PrepareCourseProject
 * author: long wh
 * date: 2018/3/28-12:38
 * desc:
 */
public class BankSyschonizedBlock {
    private int total;

    private void addMoney(int money) {
        synchronized (this) {
            total += money;
            System.out.println("存了:\t"+money+"\t余额为:\t"+total);
        }
    }
    private  void spendMoney(int money) {
        synchronized (this) {
            if ( total-money < 0) {
                System.out.println("余额不足,余额为: "+total);
                return;
            }
            total -= money;
            System.out.println("花了:\t"+money+"\t余额为:\t"+total);
        }

    }

}
