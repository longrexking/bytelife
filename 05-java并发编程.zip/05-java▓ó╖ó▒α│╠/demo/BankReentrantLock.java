package org.lc;

import java.util.concurrent.locks.ReentrantLock;

/**
 * project:PrepareCourseProject
 * author: long wh
 * date: 2018/3/28-12:59
 * desc:
 */
public class BankReentrantLock {
    private ReentrantLock lock = new ReentrantLock();
    private int total;

    public void addMoney(int money) {
        try {
            lock.lock();
            total += money;
            System.out.println("存了:\t" + money + "\t余额为:\t" + total);
        } finally {
            lock.unlock();

        }
    }

    public void spendMoney(int money) {
        try {
            lock.lock();
            if (total - money < 0) {
                System.out.println("余额不足,余额为: " + total);
                return;
            }
            total -= money;
            System.out.println("花了:\t" + money + "\t余额为:\t" + total);
        } finally {
            lock.unlock();
        }
    }
}
