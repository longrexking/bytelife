package org.lc;

/**
 * project:PrepareCourseProject
 * author: long wh
 * date: 2018/3/28-13:00
 * desc:
 */
public class Test {
    public static void main(String[] args) {
//        BankSyschonizedBlock bank = new BankSyschonizedBlock();
//        BankReentrantLock bank = new BankReentrantLock();
        BankSemaphore bank = new BankSemaphore();
        Thread tAdd = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    bank.addMoney(100);
                }

            }
        });

        Thread tSpend = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    bank.spendMoney(100);
                }
            }
        });

        tAdd.start();
        tSpend.start();
    }
}
