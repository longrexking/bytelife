package org.lc;

import java.util.concurrent.Semaphore;

/**
 * project:PrepareCourseProject
 * author: long wh
 * date: 2018/3/28-13:06
 * desc:
 */
public class BankSemaphore {
    Semaphore semaphore = new Semaphore(10);
    private int total;

    public void addMoney(int money) {
        try {
            semaphore.acquire();
            total += money;
            System.out.println("存了:\t" + money + "\t余额为:\t" + total);
            semaphore.release();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void spendMoney(int money) {
        try {
            semaphore.acquire();
            if (total - money < 0) {
                System.out.println("余额不足,余额为: " + total);
                return;
            }
            total -= money;
            System.out.println("花了:\t" + money + "\t余额为:\t" + total);
            semaphore.release();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
