<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1490159880700" ID="ID_1715882576" MODIFIED="1501123546985" TEXT="Java&#x5e76;&#x53d1;&#x7f16;&#x7a0b;">
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1490159922497" FOLDED="true" ID="ID_921453667" MODIFIED="1501123546938" POSITION="right" TEXT="&#x9501;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1500550849333" FOLDED="true" ID="ID_1337429726" MODIFIED="1501123546907" TEXT="&#x7279;&#x70b9;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500550859452" ID="ID_114388115" MODIFIED="1500550859452" TEXT="&#x53ea;&#x80fd;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#xff0c;&#x800c;&#x4e0d;&#x80fd;&#x540c;&#x6b65;&#x53d8;&#x91cf;&#x548c;&#x7c7b;&#xff1b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550872082" ID="ID_785811544" MODIFIED="1500550872082" TEXT="&#x6bcf;&#x4e2a;&#x5bf9;&#x8c61;&#x53ea;&#x6709;&#x4e00;&#x4e2a;&#x9501;&#xff1b;&#x5f53;&#x63d0;&#x5230;&#x540c;&#x6b65;&#x65f6;&#xff0c;&#x5e94;&#x8be5;&#x6e05;&#x695a;&#x5728;&#x4ec0;&#x4e48;&#x4e0a;&#x540c;&#x6b65;&#xff0c;&#x4e5f;&#x5c31;&#x662f;&#x8bf4;&#xff0c;&#x5728;&#x54ea;&#x4e2a;&#x5bf9;&#x8c61;&#x4e0a;&#x540c;&#x6b65;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550877956" ID="ID_1140265767" MODIFIED="1500550877956" TEXT="&#x4e0d;&#x5fc5;&#x540c;&#x6b65;&#x7c7b;&#x4e2d;&#x6240;&#x6709;&#x7684;&#x65b9;&#x6cd5;&#xff0c;&#x7c7b;&#x53ef;&#x4ee5;&#x540c;&#x65f6;&#x62e5;&#x6709;&#x540c;&#x6b65;&#x548c;&#x975e;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550895250" ID="ID_868837120" MODIFIED="1500550895250" TEXT="&#x5982;&#x679c;&#x4e24;&#x4e2a;&#x7ebf;&#x7a0b;&#x8981;&#x6267;&#x884c;&#x4e00;&#x4e2a;&#x7c7b;&#x4e2d;&#x7684;synchronized&#x65b9;&#x6cd5;&#xff0c;&#x5e76;&#x4e14;&#x4e24;&#x4e2a;&#x7ebf;&#x7a0b;&#x4f7f;&#x7528;&#x76f8;&#x540c;&#x7684;&#x5b9e;&#x4f8b;&#x6765;&#x8c03;&#x7528;&#x65b9;&#x6cd5;&#xff0c;&#x90a3;&#x4e48;&#x4e00;&#x6b21;&#x53ea;&#x80fd;&#x6709;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x80fd;&#x591f;&#x6267;&#x884c;&#x65b9;&#x6cd5;&#xff0c;&#x53e6;&#x4e00;&#x4e2a;&#x9700;&#x8981;&#x7b49;&#x5f85;&#xff0c;&#x76f4;&#x5230;&#x9501;&#x88ab;&#x91ca;&#x653e;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550905693" ID="ID_925220280" MODIFIED="1500550905693" TEXT="&#x5982;&#x679c;&#x7ebf;&#x7a0b;&#x62e5;&#x6709;&#x540c;&#x6b65;&#x548c;&#x975e;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#xff0c;&#x5219;&#x975e;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x53ef;&#x4ee5;&#x88ab;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x81ea;&#x7531;&#x8bbf;&#x95ee;&#x800c;&#x4e0d;&#x53d7;&#x9501;&#x7684;&#x9650;&#x5236;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550910592" ID="ID_1906253524" MODIFIED="1500550910592" TEXT="&#x7ebf;&#x7a0b;&#x7761;&#x7720;&#x65f6;&#xff0c;&#x5b83;&#x6240;&#x6301;&#x7684;&#x4efb;&#x4f55;&#x9501;&#x90fd;&#x4e0d;&#x4f1a;&#x91ca;&#x653e;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550931009" ID="ID_1567042604" MODIFIED="1500550931009" TEXT="&#x7ebf;&#x7a0b;&#x53ef;&#x4ee5;&#x83b7;&#x5f97;&#x591a;&#x4e2a;&#x9501;&#x3002;&#x6bd4;&#x5982;&#xff0c;&#x5728;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x91cc;&#x9762;&#x8c03;&#x7528;&#x53e6;&#x5916;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#xff0c;&#x5219;&#x83b7;&#x53d6;&#x4e86;&#x4e24;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;&#x540c;&#x6b65;&#x9501;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550938745" ID="ID_1898301921" MODIFIED="1500550938745" TEXT="&#x540c;&#x6b65;&#x635f;&#x5bb3;&#x5e76;&#x53d1;&#x6027;&#xff0c;&#x5e94;&#x8be5;&#x5c3d;&#x53ef;&#x80fd;&#x7f29;&#x5c0f;&#x540c;&#x6b65;&#x8303;&#x56f4;&#x3002;&#x540c;&#x6b65;&#x4e0d;&#x4f46;&#x53ef;&#x4ee5;&#x540c;&#x6b65;&#x6574;&#x4e2a;&#x65b9;&#x6cd5;&#xff0c;&#x8fd8;&#x53ef;&#x4ee5;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x4e2d;&#x4e00;&#x90e8;&#x5206;&#x4ee3;&#x7801;&#x5757;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550947742" ID="ID_1962044134" MODIFIED="1500550947742" TEXT="&#x5728;&#x4f7f;&#x7528;&#x540c;&#x6b65;&#x4ee3;&#x7801;&#x5757;&#x65f6;&#x5019;&#xff0c;&#x5e94;&#x8be5;&#x6307;&#x5b9a;&#x5728;&#x54ea;&#x4e2a;&#x5bf9;&#x8c61;&#x4e0a;&#x540c;&#x6b65;&#xff0c;&#x4e5f;&#x5c31;&#x662f;&#x8bf4;&#x8981;&#x83b7;&#x53d6;&#x54ea;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;&#x9501;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500550952043" ID="ID_549168117" MODIFIED="1500550952043" TEXT="&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x7684;&#x540c;&#x6b65;&#x9700;&#x8981;&#x83b7;&#x53d6;&#x7c7b;&#x9501;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1501083610624" FOLDED="true" ID="ID_1250326466" MODIFIED="1501123546922" TEXT="&#x5206;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1501083615272" FOLDED="true" ID="ID_610887336" MODIFIED="1501123546907">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21487;&#37325;&#20837;&#38145;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1501083739395" FOLDED="true" ID="ID_945403151" MODIFIED="1501123546907" TEXT="?">
<node COLOR="#111111" CREATED="1501083740953" ID="ID_1927737242" MODIFIED="1501083939308" TEXT="&#x53ef;&#x91cd;&#x5165;&#x9501;&#x53c8;&#x540d;&#x9012;&#x5f52;&#x9501;&#xff0c;&#x662f;&#x6307;&#x5728;&#x540c;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x5728;&#x5916;&#x5c42;&#xa;&#x65b9;&#x6cd5;&#x83b7;&#x53d6;&#x9501;&#x7684;&#x65f6;&#x5019;&#xff0c;&#x5728;&#x8fdb;&#x5165;&#x5185;&#x5c42;&#x65b9;&#x6cd5;&#x4f1a;&#x81ea;&#x52a8;&#x83b7;&#xa;&#x53d6;&#x9501;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1501083725851" ID="ID_1482035026" MODIFIED="1501083725852" TEXT="&#x53ef;&#x91cd;&#x5165;&#x9501;&#x6700;&#x5927;&#x7684;&#x4f5c;&#x7528;&#x662f;&#x907f;&#x514d;&#x6b7b;&#x9501;"/>
</node>
<node COLOR="#990000" CREATED="1501084029063" FOLDED="true" ID="ID_1172857520" MODIFIED="1501123546922" TEXT="&#x516c;&#x5e73;&#x9501;/&#x975e;&#x516c;&#x5e73;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1501084076902" FOLDED="true" ID="ID_1067787643" MODIFIED="1501123546922" TEXT="&#x516c;&#x5e73;&#x9501;">
<node COLOR="#111111" CREATED="1501084080818" ID="ID_1994743152" MODIFIED="1501084080818" TEXT="&#x516c;&#x5e73;&#x9501;&#x662f;&#x6307;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x6309;&#x7167;&#x7533;&#x8bf7;&#x9501;&#x7684;&#x987a;&#x5e8f;&#x6765;&#x83b7;&#x53d6;&#x9501;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1501084083971" FOLDED="true" ID="ID_421710027" MODIFIED="1501123546922" TEXT="&#x975e;&#x516c;&#x5e73;&#x9501;">
<node COLOR="#111111" CREATED="1501084107376" ID="ID_856555117" MODIFIED="1501084107377" TEXT="&#x975e;&#x516c;&#x5e73;&#x9501;&#x662f;&#x6307;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x83b7;&#x53d6;&#x9501;&#x7684;&#x987a;&#x5e8f;&#x5e76;&#x4e0d;&#x662f;&#x6309;&#x7167;&#x7533;&#x8bf7;&#x9501;&#x7684;&#x987a;&#x5e8f;&#xff0c;&#x6709;&#x53ef;&#x80fd;&#x540e;&#x7533;&#x8bf7;&#x7684;&#x7ebf;&#x7a0b;&#x6bd4;&#x5148;&#x7533;&#x8bf7;&#x7684;&#x7ebf;&#x7a0b;&#x4f18;&#x5148;&#x83b7;&#x53d6;&#x9501;&#x3002;&#x6709;&#x53ef;&#x80fd;&#xff0c;&#x4f1a;&#x9020;&#x6210;&#x4f18;&#x5148;&#x7ea7;&#x53cd;&#x8f6c;&#x6216;&#x8005;&#x9965;&#x997f;&#x73b0;&#x8c61;&#x3002;"/>
<node COLOR="#111111" CREATED="1501084140633" ID="ID_797210482" MODIFIED="1501084140633" TEXT="&#x975e;&#x516c;&#x5e73;&#x9501;&#x7684;&#x4f18;&#x70b9;&#x5728;&#x4e8e;&#x541e;&#x5410;&#x91cf;&#x6bd4;&#x516c;&#x5e73;&#x9501;&#x5927;&#x3002;"/>
<node COLOR="#111111" CREATED="1501084152326" ID="ID_1165233755" MODIFIED="1501084152326" TEXT="&#x5bf9;&#x4e8e;Synchronized&#x800c;&#x8a00;&#xff0c;&#x4e5f;&#x662f;&#x4e00;&#x79cd;&#x975e;&#x516c;&#x5e73;&#x9501;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1501084029064" FOLDED="true" ID="ID_939905953" MODIFIED="1501123546922" TEXT="&#x72ec;&#x4eab;&#x9501;/&#x5171;&#x4eab;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1501084171963" FOLDED="true" ID="ID_982055658" MODIFIED="1501123546922" TEXT="&#x72ec;&#x4eab;&#x9501;">
<node COLOR="#111111" CREATED="1501084176330" ID="ID_1475992661" MODIFIED="1501084176330" TEXT="&#x662f;&#x6307;&#x8be5;&#x9501;&#x4e00;&#x6b21;&#x53ea;&#x80fd;&#x88ab;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x6240;&#x6301;&#x6709;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1501084171964" FOLDED="true" ID="ID_222047391" MODIFIED="1501123546922" TEXT="&#x5171;&#x4eab;&#x9501;">
<node COLOR="#111111" CREATED="1501084180021" ID="ID_346154428" MODIFIED="1501084180021" TEXT="&#x662f;&#x6307;&#x8be5;&#x9501;&#x53ef;&#x88ab;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x6240;&#x6301;&#x6709;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1501084229960" FOLDED="true" ID="ID_510770867" MODIFIED="1501123546922">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23454;&#29616;&#31867;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1501084222007" ID="ID_1077013615" MODIFIED="1501084222007" TEXT="&#x4f46;&#x662f;&#x5bf9;&#x4e8e;Lock&#x7684;&#x53e6;&#x4e00;&#x4e2a;&#x5b9e;&#x73b0;&#x7c7b;ReadWriteLock&#xff0c;&#x5176;&#x8bfb;&#x9501;&#x662f;&#x5171;&#x4eab;&#x9501;&#xff0c;&#x5176;&#x5199;&#x9501;&#x662f;&#x72ec;&#x4eab;&#x9501;"/>
<node COLOR="#111111" CREATED="1501084205354" ID="ID_898599422" MODIFIED="1501084205354" TEXT="&#x5bf9;&#x4e8e;Java ReentrantLock&#x800c;&#x8a00;&#xff0c;&#x5176;&#x662f;&#x72ec;&#x4eab;&#x9501;"/>
</node>
<node COLOR="#111111" CREATED="1501084263648" FOLDED="true" ID="ID_1381070012" MODIFIED="1501123546922" TEXT="&#x5176;&#x4ed6;">
<node COLOR="#111111" CREATED="1501084266965" ID="ID_1453830928" MODIFIED="1501084291039">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35835;&#38145;&#30340;&#20849;&#20139;&#38145;&#21487;&#20445;&#35777;&#24182;&#21457;&#35835;&#26159;&#38750;&#24120;&#39640;
    </p>
    <p>
      &#25928;&#30340;&#65292;&#35835;&#20889;&#65292;&#20889;&#35835; &#65292;&#20889;&#20889;&#30340;&#36807;&#31243;&#26159;&#20114;&#26021;&#30340;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1501084029064" ID="ID_1451170940" MODIFIED="1501084029064" TEXT="&#x4e92;&#x65a5;&#x9501;/&#x8bfb;&#x5199;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1501084029065" ID="ID_1496945069" MODIFIED="1501084029065" TEXT="&#x4e50;&#x89c2;&#x9501;/&#x60b2;&#x89c2;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1501084029065" ID="ID_1308489554" MODIFIED="1501084029065" TEXT="&#x5206;&#x6bb5;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1501084029066" ID="ID_580568292" MODIFIED="1501084029066" TEXT="&#x504f;&#x5411;&#x9501;/&#x8f7b;&#x91cf;&#x7ea7;&#x9501;/&#x91cd;&#x91cf;&#x7ea7;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1501084029066" ID="ID_1996419763" MODIFIED="1501084029067" TEXT="&#x81ea;&#x65cb;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473484599590" FOLDED="true" ID="ID_321239760" MODIFIED="1501123546954" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#30456;&#20851;&#30340;&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473493110062" FOLDED="true" ID="ID_1525932394" MODIFIED="1501123546938" TEXT="Lock  &#x4e0e; Condition">
<edge STYLE="bezier" WIDTH="thin"/>
<font BOLD="true" NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473493882732" ID="ID_869569526" MODIFIED="1491784224503" TEXT="&#x5904;&#x7406;&#x590d;&#x6742;&#x7684;&#x5e76;&#x53d1;&#x65f6;&#x4f7f;&#x7528;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473493129732" ID="ID_645125990" MODIFIED="1491784224503" TEXT="BlockingQueue">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473493145762" ID="ID_1714945255" MODIFIED="1491784224503" TEXT="CountDownLatch">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473493155242" FOLDED="true" ID="ID_1876197608" MODIFIED="1501123546938" TEXT="CycliBarrier">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473494357009" FOLDED="true" ID="ID_842330396" MODIFIED="1501123546938" TEXT="&#xff1f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473494363212" ID="ID_398676255" MODIFIED="1473494363212" TEXT="&#x4e00;&#x4e2a;&#x540c;&#x6b65;&#x8f85;&#x52a9;&#x7c7b;&#xff0c;&#x5b83;&#x5141;&#x8bb8;&#x4e00;&#x7ec4;&#x7ebf;&#x7a0b;&#x4e92;&#x76f8;&#x7b49;&#x5f85;&#xff0c;&#x76f4;&#x5230;&#x5230;&#x8fbe;&#x67d0;&#x4e2a;&#x516c;&#x5171;&#x5c4f;&#x969c;&#x70b9; (common barrier point)&#x3002;&#x5728;&#x6d89;&#x53ca;&#x4e00;&#x7ec4;&#x56fa;&#x5b9a;&#x5927;&#x5c0f;&#x7684;&#x7ebf;&#x7a0b;&#x7684;&#x7a0b;&#x5e8f;&#x4e2d;&#xff0c;&#x8fd9;&#x4e9b;&#x7ebf;&#x7a0b;&#x5fc5;&#x987b;&#x4e0d;&#x65f6;&#x5730;&#x4e92;&#x76f8;&#x7b49;&#x5f85;&#xff0c;&#x6b64;&#x65f6; CyclicBarrier &#x5f88;&#x6709;&#x7528;&#x3002;&#x56e0;&#x4e3a;&#x8be5; barrier &#x5728;&#x91ca;&#x653e;&#x7b49;&#x5f85;&#x7ebf;&#x7a0b;&#x540e;&#x53ef;&#x4ee5;&#x91cd;&#x7528;&#xff0c;&#x6240;&#x4ee5;&#x79f0;&#x5b83;&#x4e3a;&#x5faa;&#x73af; &#x7684; barrier&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1473494368995" FOLDED="true" ID="ID_417092580" MODIFIED="1501123546938" TEXT="&#x4f7f;&#x7528;&#x573a;&#x666f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473494375734" ID="ID_307380988" MODIFIED="1473494375734" TEXT="&#x9700;&#x8981;&#x6240;&#x6709;&#x7684;&#x5b50;&#x4efb;&#x52a1;&#x90fd;&#x5b8c;&#x6210;&#x65f6;&#xff0c;&#x624d;&#x6267;&#x884c;&#x4e3b;&#x4efb;&#x52a1;&#xff0c;&#x8fd9;&#x4e2a;&#x65f6;&#x5019;&#x5c31;&#x53ef;&#x4ee5;&#x9009;&#x62e9;&#x4f7f;&#x7528;CyclicBarrier&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1473494384782" FOLDED="true" ID="ID_436635149" MODIFIED="1501123546938" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473494386184" ID="ID_78669267" MODIFIED="1473494386184" TEXT="public int await()"/>
</node>
<node COLOR="#990000" CREATED="1473494556068" ID="ID_665540883" LINK="&#x7ebf;&#x7a0b;/&#x5e76;&#x53d1;&#x76f8;&#x5173;&#x7684;&#x7c7b;/CyclicBarrier.txt" MODIFIED="1491784224504" TEXT="&#x9644;&#x4ef6;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473493163712" FOLDED="true" ID="ID_1007886215" MODIFIED="1501123546938" TEXT="Semaphore &#x4fe1;&#x53f7;&#x91cf;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473494313216" ID="ID_1819720978" MODIFIED="1491784224504" TEXT="&#x7528;&#x6765;&#x63a7;&#x5236;&#x540c;&#x65f6;&#x8bbf;&#x95ee;&#x7279;&#x5b9a;&#x8d44;&#x6e90;&#x7684;&#x7ebf;&#x7a0b;&#x6570;&#x91cf;&#xff0c;&#x5b83;&#x901a;&#x8fc7;&#x534f;&#x8c03;&#x5404;&#x4e2a;&#x7ebf;&#x7a0b;&#xff0c;&#x4ee5;&#x4fdd;&#x8bc1;&#x5408;&#x7406;&#x7684;&#x4f7f;&#x7528;&#x516c;&#x5171;&#x8d44;&#x6e90;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473493172613" ID="ID_504526339" MODIFIED="1491784224504" TEXT="Exchanger">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473493183532" FOLDED="true" ID="ID_1786668994" MODIFIED="1501123546938" TEXT="&#x514d;&#x9501;&#x5bb9;&#x5668;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473493211212" ID="ID_1879663018" MODIFIED="1491784224504" TEXT="CopyOnWriteArrayList&lt;E&gt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473493251883" ID="ID_1237337593" MODIFIED="1491784224504" TEXT="CopyOnWriteArraySet&lt;E&gt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473493263793" ID="ID_1262181548" MODIFIED="1491784224504" TEXT="ConcurrentHashMap&lt;K,V&gt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473493289520" ID="ID_828548449" MODIFIED="1491784224504" TEXT="ConcurrentLinkedQueue&lt;E&gt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495711799703" FOLDED="true" ID="ID_152902073" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Timer
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495719702705" FOLDED="true" ID="ID_269207388" MODIFIED="1501123546938" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495719705460" ID="ID_834073463" MODIFIED="1495719705460" TEXT="public Timer()"/>
<node COLOR="#111111" CREATED="1495719715637" FOLDED="true" ID="ID_1742835940" MODIFIED="1501123546938" TEXT="public Timer(String name)">
<node COLOR="#111111" CREATED="1495720918302" FOLDED="true" ID="ID_5744676" MODIFIED="1501123546938" TEXT="name">
<node COLOR="#111111" CREATED="1495720921457" ID="ID_1701668369" MODIFIED="1495720931126" TEXT="&#x5b9a;&#x65f6;&#x5668;&#x7684;&#x540d;&#x5b57;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720360023" FOLDED="true" ID="ID_586306859" MODIFIED="1501123546938" TEXT="public Timer(String name, boolean isDaemon)">
<node COLOR="#111111" CREATED="1495720934368" FOLDED="true" ID="ID_1967642518" MODIFIED="1501123546938" TEXT="isDaemon">
<node COLOR="#111111" CREATED="1495720941292" ID="ID_382396859" MODIFIED="1495720954214" TEXT="&#x662f;&#x5426;&#x8bbe;&#x7f6e;&#x4e3a;&#x540e;&#x53f0;&#x7ebf;&#x7a0b;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495720374673" FOLDED="true" ID="ID_605618299" MODIFIED="1501123546954" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495720376582" FOLDED="true" ID="ID_666047092" MODIFIED="1501123546954" TEXT="public void schedule(TimerTask task, long delay)">
<node COLOR="#111111" CREATED="1495720957657" FOLDED="true" ID="ID_598719033" MODIFIED="1501123546938" TEXT="?">
<node COLOR="#111111" CREATED="1495720964679" ID="ID_1550802319" MODIFIED="1495720973184" TEXT="&#x5b9a;&#x65f6;&#x6267;&#x884c;&#x4efb;&#x52a1;"/>
</node>
<node COLOR="#111111" CREATED="1495720974545" FOLDED="true" ID="ID_1017288220" MODIFIED="1501123546954" TEXT="TimerTask">
<arrowlink DESTINATION="ID_1650574484" ENDARROW="Default" ENDINCLINATION="448;0;" ID="Arrow_ID_835366314" STARTARROW="None" STARTINCLINATION="448;0;"/>
<node COLOR="#111111" CREATED="1495720983452" ID="ID_328988391" MODIFIED="1495720994055" TEXT="&#x4e00;&#x4e2a;&#x5b9a;&#x65f6;&#x4efb;&#x52a1;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_1363799868" MODIFIED="1501123546954" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_915183348" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720390342" FOLDED="true" ID="ID_300547047" MODIFIED="1501123546954" TEXT="public void schedule(TimerTask task, Date time)">
<node COLOR="#111111" CREATED="1495721069628" ID="ID_342960082" MODIFIED="1495721087940" TEXT="&#x5728;&#x672a;&#x6765;&#x7684;&#x67d0;&#x4e2a;&#x65f6;&#x95f4; time&#x6267;&#x884c;"/>
<node COLOR="#111111" CREATED="1495721088453" ID="ID_1990036126" MODIFIED="1495721102118" TEXT="time:&#x672a;&#x6765;&#x67d0;&#x4e2a;&#x65e5;&#x671f;"/>
</node>
<node COLOR="#111111" CREATED="1495720424345" FOLDED="true" ID="ID_1494274988" MODIFIED="1501123546954" TEXT="public void schedule(TimerTask task, long delay, long period)">
<node COLOR="#111111" CREATED="1495721106799" ID="ID_185295240" MODIFIED="1495721133859" TEXT="&#x4efb;&#x52a1;&#x6bcf;&#x9694; period&#x6267;&#x884c;&#x4e00;&#x6b21;"/>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_1773164714" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_1409090879" MODIFIED="1501123546954" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_1061308242" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720410305" FOLDED="true" ID="ID_1789051404" MODIFIED="1501123546954" TEXT="public void schedule(TimerTask task, Date firstTime, long period)">
<node COLOR="#111111" CREATED="1495721137538" ID="ID_237587403" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721882093" ID="ID_285571300" MODIFIED="1495721914513">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      firstTime : &#39318;&#27425;&#25191;&#34892;&#30340;&#26102;&#38388;,&#29992;Date&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495720444767" FOLDED="true" ID="ID_253357917" MODIFIED="1501123546954" TEXT="public void scheduleAtFixedRate(TimerTask task, long delay, long period)">
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_764304382" MODIFIED="1501123546954" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_1609057719" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_989185369" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
</node>
<node COLOR="#111111" CREATED="1495720460358" FOLDED="true" ID="ID_605233019" MODIFIED="1501123546954" TEXT="public void scheduleAtFixedRate(TimerTask task, Date firstTime,     long period)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_1926199847" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721882093" ID="ID_424558010" MODIFIED="1495721914513">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      firstTime : &#39318;&#27425;&#25191;&#34892;&#30340;&#26102;&#38388;,&#29992;Date&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495720490697" FOLDED="true" ID="ID_1020148639" MODIFIED="1501123546954" TEXT="public void cancel()">
<node COLOR="#111111" CREATED="1495722025551" ID="ID_1841405845" MODIFIED="1495722033537" TEXT="&#x53d6;&#x6d88;&#x4efb;&#x52a1;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1495721015686" FOLDED="true" ID="ID_1650574484" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      TimerTask&#25277;&#35937;&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495722213466" FOLDED="true" ID="ID_1678365498" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495722194538" ID="ID_985057047" MODIFIED="1495722213472" TEXT="&#x548c;Timer&#x5171;&#x540c;&#x4f7f;&#x7528;&#x6765;&#x5b9a;&#x65f6;&#x4e00;&#x4e2a;&#x4efb;&#x52a1;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495722074591" ID="ID_351274268" MODIFIED="1495722074592" TEXT="public abstract void run()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495722151326" ID="ID_934257226" MODIFIED="1495722151327" TEXT="public boolean cancel()">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1500550826187" FOLDED="true" ID="ID_249120769" MODIFIED="1501123546954" POSITION="right" TEXT="&#x540c;&#x6b65;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1500550962092" FOLDED="true" ID="ID_1135135854" MODIFIED="1501123546954" TEXT="&#x540c;&#x6b65;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500553519372" FOLDED="true" ID="ID_110703255" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38750;&#38745;&#24577;&#21516;&#27493;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500551372031" ID="ID_579281998" MODIFIED="1500553559686" TEXT="&#x5373;&#x7528;synchronized&#x5173;&#x952e;&#x5b57;&#x4fee;&#x9970;&#x7684;&#x975e;&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1500551470446" ID="ID_406065154" MODIFIED="1500553519379" TEXT="&#x7531;&#x4e8e;java&#x7684;&#x6bcf;&#x4e2a;&#x5bf9;&#x8c61;&#x90fd;&#x6709;&#x4e00;&#x4e2a;&#x5185;&#x7f6e;&#x9501;&#xff0c;&#x5f53;&#x7528;&#x6b64;&#x5173;&#x952e;&#x5b57;&#x4fee;&#x9970;&#x65b9;&#x6cd5;&#x65f6;&#xff0c;&#x5185;&#x7f6e;&#x9501;&#x4f1a;&#x4fdd;&#x62a4;&#x6574;&#x4e2a;&#x65b9;&#x6cd5;&#x3002;&#x5728;&#x8c03;&#x7528;&#x8be5;&#x65b9;&#x6cd5;&#x524d;&#xff0c;&#x9700;&#x8981;&#x83b7;&#x5f97;&#x5185;&#x7f6e;&#x9501;&#xff0c;&#x5426;&#x5219;&#x5c31;&#x5904;&#x4e8e;&#x963b;&#x585e;&#x72b6;&#x6001;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1500553570747" ID="ID_1168570873" MODIFIED="1500553571484" TEXT="&#x9501;&#x7684;&#x662f;&#x5f53;&#x524d;&#x65b9;&#x6cd5;&#x6240;&#x5c5e;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#990000" CREATED="1500553480898" FOLDED="true" ID="ID_373157078" MODIFIED="1501123546954" TEXT="&#x9759;&#x6001;&#x540c;&#x6b65;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500553487169" ID="ID_1995153001" MODIFIED="1500553504549">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24403;&#25105;&#20204;&#23545;&#19968;&#20010;&#38745;&#24577;&#26041;&#27861;&#21152;&#38145;&#65292;&#22914;&#65306;public sychronized static void smethod(){&#8230;}&#160;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1500553487170" ID="ID_871739157" MODIFIED="1500553487170" TEXT="&#x90a3;&#x4e48;&#x8be5;&#x65b9;&#x6cd5;&#x9501;&#x7684;&#x5bf9;&#x8c61;&#x662f;&#x7c7b;&#x5bf9;&#x8c61;&#xff0c;&#x6bcf;&#x4e2a;&#x7c7b;&#x90fd;&#x6709;&#x552f;&#x4e00;&#x7684;&#x4e00;&#x4e2a;&#x7c7b;&#x5bf9;&#x8c61;&#xff0c;&#x83b7;&#x53d6;&#x7c7b;&#x5bf9;&#x8c61;&#x7684;&#x65b9;&#x5f0f;&#x662f;:&#x7c7b;&#x540d;.class"/>
</node>
<node COLOR="#990000" CREATED="1500553588749" FOLDED="true" ID="ID_1703582745" MODIFIED="1501123546954" TEXT="&#x6ce8;&#x610f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500553592778" ID="ID_746152851" MODIFIED="1500553592778" TEXT="&#x5728;&#x4e00;&#x4e2a;&#x7c7b;&#x91cc;&#x9762;&#x9759;&#x6001;&#x7684;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x548c;&#x975e;&#x9759;&#x6001;&#x7684;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x4e4b;&#x95f4;&#x4e0d;&#x4f1a;&#x76f8;&#x4e92;&#x963b;&#x585e;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1500550967293" FOLDED="true" ID="ID_10751279" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21516;&#27493;&#20195;&#30721;&#22359;synchronize
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500551294368" ID="ID_1751596268" MODIFIED="1500551294384" TEXT="&#x88ab;&#x8be5;&#x5173;&#x952e;&#x5b57;&#x4fee;&#x9970;&#x7684;&#x8bed;&#x53e5;&#x5757;&#x4f1a;&#x81ea;&#x52a8;&#x88ab;&#x52a0;&#x4e0a;&#x5185;&#x7f6e;&#x9501;&#xff0c;&#x4ece;&#x800c;&#x5b9e;&#x73b0;&#x540c;&#x6b65;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551339785" FOLDED="true" ID="ID_1053462513" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27880;&#65306;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500551349906" ID="ID_1582065502" MODIFIED="1500551352742">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21516;&#27493;&#26159;&#19968;&#31181;&#39640;&#24320;&#38144;&#30340;&#25805;&#20316;&#65292;&#22240;&#27492;&#24212;&#35813;&#23613;&#37327;&#20943;&#23569;&#21516;&#27493;&#30340;&#20869;&#23481;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1500551339785" ID="ID_721682270" MODIFIED="1500551343952" TEXT="&#x901a;&#x5e38;&#x6ca1;&#x6709;&#x5fc5;&#x8981;&#x540c;&#x6b65;&#x6574;&#x4e2a;&#x65b9;&#x6cd5;&#xff0c;&#x4f7f;&#x7528;synchronized&#x4ee3;&#x7801;&#x5757;&#x540c;&#x6b65;&#x5173;&#x952e;&#x4ee3;&#x7801;&#x5373;&#x53ef;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1500551311374" FOLDED="true" ID="ID_1389144081" MODIFIED="1501123546954" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500551314342" ID="ID_767260341" MODIFIED="1500551329418">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p class="MsoNormal">
      synchronized(object){
    </p>
    <p class="MsoNormal">
      //&#20195;&#30721;...
    </p>
    <p class="MsoNormal">
      }
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1500550978498" FOLDED="true" ID="ID_630411687" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      volatile&#30340;&#20351;&#29992;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500551231644" ID="ID_258819187" MODIFIED="1500551231644" TEXT="volatile&#x5173;&#x952e;&#x5b57;&#x4e3a;&#x57df;&#x53d8;&#x91cf;&#x7684;&#x8bbf;&#x95ee;&#x63d0;&#x4f9b;&#x4e86;&#x4e00;&#x79cd;&#x514d;&#x9501;&#x673a;&#x5236;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551231644" ID="ID_1825713802" MODIFIED="1500551231644" TEXT="&#x4f7f;&#x7528;volatile&#x4fee;&#x9970;&#x57df;&#x76f8;&#x5f53;&#x4e8e;&#x544a;&#x8bc9;&#x865a;&#x62df;&#x673a;&#x8be5;&#x57df;&#x53ef;&#x80fd;&#x4f1a;&#x88ab;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x66f4;&#x65b0;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551231644" ID="ID_1242608210" MODIFIED="1500551231644" TEXT="&#x56e0;&#x6b64;&#x6bcf;&#x6b21;&#x4f7f;&#x7528;&#x8be5;&#x57df;&#x5c31;&#x8981;&#x91cd;&#x65b0;&#x8ba1;&#x7b97;&#xff0c;&#x800c;&#x4e0d;&#x662f;&#x4f7f;&#x7528;&#x5bc4;&#x5b58;&#x5668;&#x4e2d;&#x7684;&#x503c;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551231644" ID="ID_1890292512" MODIFIED="1500551236387" TEXT="volatile&#x4e0d;&#x4f1a;&#x63d0;&#x4f9b;&#x4efb;&#x4f55;&#x539f;&#x5b50;&#x64cd;&#x4f5c;&#xff0c;&#x5b83;&#x4e5f;&#x4e0d;&#x80fd;&#x7528;&#x6765;&#x4fee;&#x9970;final&#x7c7b;&#x578b;&#x7684;&#x53d8;&#x91cf;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1500550985160" FOLDED="true" ID="ID_65506270" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ReentrantLock
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500551076650" ID="ID_1929180224" MODIFIED="1500551080219">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20351;&#29992;&#37325;&#20837;&#38145;&#23454;&#29616;&#32447;&#31243;&#21516;&#27493;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551067465" ID="ID_1080028206" MODIFIED="1500551067465" TEXT="ReentrantLock&#x7c7b;&#x662f;&#x53ef;&#x91cd;&#x5165;&#x3001;&#x4e92;&#x65a5;&#x3001;&#x5b9e;&#x73b0;&#x4e86;Lock&#x63a5;&#x53e3;&#x7684;&#x9501;&#xff0c;&#x5b83;&#x4e0e;&#x4f7f;&#x7528;synchronized&#x65b9;&#x6cd5;&#x548c;&#x5feb;&#x5177;&#x6709;&#x76f8;&#x540c;&#x7684;&#x57fa;&#x672c;&#x884c;&#x4e3a;&#x548c;&#x8bed;&#x4e49;&#xff0c;&#x5e76;&#x4e14;&#x6269;&#x5c55;&#x4e86;&#x5176;&#x80fd;&#x529b;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1500551000022" FOLDED="true" ID="ID_552394601" MODIFIED="1501123546954" TEXT="ThreadLocal  ">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500551011603" ID="ID_160769593" MODIFIED="1500551011603" TEXT="&#x4f7f;&#x7528;&#x5c40;&#x90e8;&#x53d8;&#x91cf;&#x5b9e;&#x73b0;&#x7ebf;&#x7a0b;&#x540c;&#x6b65;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551017093" ID="ID_394010313" MODIFIED="1500551017093" TEXT="&#x5982;&#x679c;&#x4f7f;&#x7528;ThreadLocal&#x7ba1;&#x7406;&#x53d8;&#x91cf;&#xff0c;&#x5219;&#x6bcf;&#x4e00;&#x4e2a;&#x4f7f;&#x7528;&#x8be5;&#x53d8;&#x91cf;&#x7684;&#x7ebf;&#x7a0b;&#x90fd;&#x83b7;&#x5f97;&#x8be5;&#x53d8;&#x91cf;&#x7684;&#x526f;&#x672c;&#xff0c;&#x526f;&#x672c;&#x4e4b;&#x95f4;&#x76f8;&#x4e92;&#x72ec;&#x7acb;&#xff0c;&#x8fd9;&#x6837;&#x6bcf;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x90fd;&#x53ef;&#x4ee5;&#x968f;&#x610f;&#x4fee;&#x6539;&#x81ea;&#x5df1;&#x7684;&#x53d8;&#x91cf;&#x526f;&#x672c;&#xff0c;&#x800c;&#x4e0d;&#x4f1a;&#x5bf9;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x4ea7;&#x751f;&#x5f71;&#x54cd;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1500551173742" FOLDED="true" ID="ID_1243515025" MODIFIED="1501123546954" TEXT="Lock&#x548c;synchronize&#x7684;&#x9009;&#x62e9;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500551188028" ID="ID_960744446" MODIFIED="1500551188028" TEXT="a.&#x6700;&#x597d;&#x4e24;&#x4e2a;&#x90fd;&#x4e0d;&#x7528;&#xff0c;&#x4f7f;&#x7528;&#x4e00;&#x79cd;java.util.concurrent&#x5305;&#x63d0;&#x4f9b;&#x7684;&#x673a;&#x5236;&#xff0c;&#x80fd;&#x591f;&#x5e2e;&#x52a9;&#x7528;&#x6237;&#x5904;&#x7406;&#x6240;&#x6709;&#x4e0e;&#x9501;&#x76f8;&#x5173;&#x7684;&#x4ee3;&#x7801;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551188028" ID="ID_1836721786" MODIFIED="1500551196438" TEXT="b.&#x5982;&#x679c;synchronized&#x5173;&#x952e;&#x5b57;&#x80fd;&#x6ee1;&#x8db3;&#x7528;&#x6237;&#x7684;&#x9700;&#x6c42;&#xff0c;&#x5c31;&#x7528;synchronized&#xff0c;&#x56e0;&#x4e3a;&#x5b83;&#x80fd;&#x7b80;&#x5316;&#x4ee3;&#x7801;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500551188028" ID="ID_97858176" MODIFIED="1500551196438" TEXT="c.&#x5982;&#x679c;&#x9700;&#x8981;&#x66f4;&#x9ad8;&#x7ea7;&#x7684;&#x529f;&#x80fd;&#xff0c;&#x5c31;&#x7528;ReentrantLock&#x7c7b;&#xff0c;&#x6b64;&#x65f6;&#x8981;&#x6ce8;&#x610f;&#x53ca;&#x65f6;&#x91ca;&#x653e;&#x9501;&#xff0c;&#x5426;&#x5219;&#x4f1a;&#x51fa;&#x73b0;&#x6b7b;&#x9501;&#xff0c;&#x901a;&#x5e38;&#x5728;finally&#x4ee3;&#x7801;&#x91ca;&#x653e;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1472795637653" FOLDED="true" ID="ID_67626560" MODIFIED="1501123546954" POSITION="left" TEXT="&#x8fdb;&#x7a0b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472796014682" FOLDED="true" ID="ID_14338707" MODIFIED="1501123546954" TEXT="&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472796020327" ID="ID_1939598211" MODIFIED="1491784224476" TEXT="&#x72ed;&#x4e49;&#x5b9a;&#x4e49;&#xff1a;&#x8fdb;&#x7a0b;&#x662f;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7a0b;&#x5e8f;&#x7684;&#x5b9e;&#x4f8b;&#xff08;an instance of a computer program that is being executed&#xff09;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796038195" ID="ID_1748021106" MODIFIED="1491784224477" TEXT="&#x5e7f;&#x4e49;&#x5b9a;&#x4e49;&#xff1a;&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x5177;&#x6709;&#x4e00;&#x5b9a;&#x72ec;&#x7acb;&#x529f;&#x80fd;&#x7684;&#x7a0b;&#x5e8f;&#x5173;&#x4e8e;&#x67d0;&#x4e2a;&#x6570;&#x636e;&#x96c6;&#x5408;&#x7684;&#x4e00;&#x6b21;&#x8fd0;&#x884c;&#x6d3b;&#x52a8;&#x3002;&#x5b83;&#x662f;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x52a8;&#x6001;&#x6267;&#x884c;&#x7684;&#x57fa;&#x672c;&#x5355;&#x5143;&#xff0c;&#x5728;&#x4f20;&#x7edf;&#x7684;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x4e2d;&#xff0c;&#x8fdb;&#x7a0b;&#x65e2;&#x662f;&#x57fa;&#x672c;&#x7684;&#x5206;&#x914d;&#x5355;&#x5143;&#xff0c;&#x4e5f;&#x662f;&#x57fa;&#x672c;&#x7684;&#x6267;&#x884c;&#x5355;&#x5143;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796078155" ID="ID_1227673007" MODIFIED="1491784224477" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x5b9e;&#x4f53;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796095934" FOLDED="true" ID="ID_1138667061" MODIFIED="1501123546954" TEXT="&#x6bcf;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x90fd;&#x6709;&#x5b83;&#x81ea;&#x5df1;&#x7684;&#x5730;&#x5740;&#x7a7a;&#x95f4;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472796111013" FOLDED="true" ID="ID_298845286" MODIFIED="1501123546954" TEXT="&#x6587;&#x672c;&#x533a;&#x57df;&#xff08;text region&#xff09;">
<node COLOR="#111111" CREATED="1472796135773" ID="ID_1464966615" MODIFIED="1472796135774" TEXT="&#x5b58;&#x50a8;&#x5904;&#x7406;&#x5668;&#x6267;&#x884c;&#x7684;&#x4ee3;&#x7801;"/>
</node>
<node COLOR="#111111" CREATED="1472796117878" FOLDED="true" ID="ID_50657624" MODIFIED="1501123546954" TEXT="&#x6570;&#x636e;&#x533a;&#x57df;&#xff08;data region&#xff09;">
<node COLOR="#111111" CREATED="1472796148312" ID="ID_699963265" MODIFIED="1472796148313" TEXT="&#x5b58;&#x50a8;&#x53d8;&#x91cf;&#x548c;&#x8fdb;&#x7a0b;&#x6267;&#x884c;&#x671f;&#x95f4;&#x4f7f;&#x7528;&#x7684;&#x52a8;&#x6001;&#x5206;&#x914d;&#x7684;&#x5185;&#x5b58;"/>
</node>
<node COLOR="#111111" CREATED="1472796123061" FOLDED="true" ID="ID_915236333" MODIFIED="1501123546954" TEXT="&#x5806;&#x6808;&#xff08;stack region&#xff09;">
<node COLOR="#111111" CREATED="1472796159161" ID="ID_287813478" MODIFIED="1472796159161" TEXT="&#x5b58;&#x50a8;&#x7740;&#x6d3b;&#x52a8;&#x8fc7;&#x7a0b;&#x8c03;&#x7528;&#x7684;&#x6307;&#x4ee4;&#x548c;&#x672c;&#x5730;&#x53d8;&#x91cf;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472796169629" FOLDED="true" ID="ID_341526900" MODIFIED="1501123546954" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x201c;&#x6267;&#x884c;&#x4e2d;&#x7684;&#x7a0b;&#x5e8f;&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472796180766" ID="ID_1348062430" MODIFIED="1472796180766" TEXT="&#x7a0b;&#x5e8f;&#x662f;&#x4e00;&#x4e2a;&#x6ca1;&#x6709;&#x751f;&#x547d;&#x7684;&#x5b9e;&#x4f53;&#xff0c;&#x53ea;&#x6709;&#x5904;&#x7406;&#x5668;&#x8d4b;&#x4e88;&#x7a0b;&#x5e8f;&#x751f;&#x547d;&#x65f6;&#xff08;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x6267;&#x884c;&#x4e4b;&#xff09;&#xff0c;&#x5b83;&#x624d;&#x80fd;&#x6210;&#x4e3a;&#x4e00;&#x4e2a;&#x6d3b;&#x52a8;&#x7684;&#x5b9e;&#x4f53;&#xff0c;&#x6211;&#x4eec;&#x79f0;&#x5176;&#x4e3a;&#x8fdb;&#x7a0b;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472796227321" ID="ID_1135440213" MODIFIED="1491784224477" TEXT="&#x4ece;&#x5b9e;&#x73b0;&#x89d2;&#x5ea6;&#x770b;&#xff0c;&#x662f;&#x4e00;&#x79cd;&#x6570;&#x636e;&#x7ed3;&#x6784;&#xff0c;&#x76ee;&#x7684;&#x5728;&#x4e8e;&#x6e05;&#x6670;&#x5730;&#x523b;&#x753b;&#x52a8;&#x6001;&#x7cfb;&#x7edf;&#x7684;&#x5185;&#x5728;&#x89c4;&#x5f8b;&#xff0c;&#x6709;&#x6548;&#x7ba1;&#x7406;&#x548c;&#x8c03;&#x5ea6;&#x8fdb;&#x5165;&#x8ba1;&#x7b97;&#x673a;&#x7cfb;&#x7edf;&#x4e3b;&#x5b58;&#x50a8;&#x5668;&#x8fd0;&#x884c;&#x7684;&#x7a0b;&#x5e8f;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796232532" ID="ID_760002487" MODIFIED="1491784224477" TEXT="&#x4ece;&#x7406;&#x8bba;&#x89d2;&#x5ea6;&#x770b;&#xff0c;&#x662f;&#x5bf9;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7a0b;&#x5e8f;&#x8fc7;&#x7a0b;&#x7684;&#x62bd;&#x8c61;&#xff1b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472796253382" FOLDED="true" ID="ID_758810201" MODIFIED="1501123546954" TEXT="&#x7279;&#x5f81;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472796263257" ID="ID_1588195834" MODIFIED="1491784224478" TEXT="&#x52a8;&#x6001;&#x6027;&#xff1a;&#x8fdb;&#x7a0b;&#x7684;&#x5b9e;&#x8d28;&#x662f;&#x7a0b;&#x5e8f;&#x5728;&#x591a;&#x9053;&#x7a0b;&#x5e8f;&#x7cfb;&#x7edf;&#x4e2d;&#x7684;&#x4e00;&#x6b21;&#x6267;&#x884c;&#x8fc7;&#x7a0b;&#xff0c;&#x8fdb;&#x7a0b;&#x662f;&#x52a8;&#x6001;&#x4ea7;&#x751f;&#xff0c;&#x52a8;&#x6001;&#x6d88;&#x4ea1;&#x7684;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796263259" ID="ID_1849592678" MODIFIED="1491784224478" TEXT="&#x5e76;&#x53d1;&#x6027;&#xff1a;&#x4efb;&#x4f55;&#x8fdb;&#x7a0b;&#x90fd;&#x53ef;&#x4ee5;&#x540c;&#x5176;&#x4ed6;&#x8fdb;&#x7a0b;&#x4e00;&#x8d77;&#x5e76;&#x53d1;&#x6267;&#x884c;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796263263" ID="ID_147073474" MODIFIED="1491784224478" TEXT="&#x72ec;&#x7acb;&#x6027;&#xff1a;&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x80fd;&#x72ec;&#x7acb;&#x8fd0;&#x884c;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;&#xff0c;&#x540c;&#x65f6;&#x4e5f;&#x662f;&#x7cfb;&#x7edf;&#x5206;&#x914d;&#x8d44;&#x6e90;&#x548c;&#x8c03;&#x5ea6;&#x7684;&#x72ec;&#x7acb;&#x5355;&#x4f4d;&#xff1b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796263265" ID="ID_240054971" MODIFIED="1491784224478" TEXT="&#x5f02;&#x6b65;&#x6027;&#xff1a;&#x7531;&#x4e8e;&#x8fdb;&#x7a0b;&#x95f4;&#x7684;&#x76f8;&#x4e92;&#x5236;&#x7ea6;&#xff0c;&#x4f7f;&#x8fdb;&#x7a0b;&#x5177;&#x6709;&#x6267;&#x884c;&#x7684;&#x95f4;&#x65ad;&#x6027;&#xff0c;&#x5373;&#x8fdb;&#x7a0b;&#x6309;&#x5404;&#x81ea;&#x72ec;&#x7acb;&#x7684;&#x3001;&#x4e0d;&#x53ef;&#x9884;&#x77e5;&#x7684;&#x901f;&#x5ea6;&#x5411;&#x524d;&#x63a8;&#x8fdb;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796263266" ID="ID_263943523" MODIFIED="1491784224478" TEXT="&#x7ed3;&#x6784;&#x7279;&#x5f81;&#xff1a;&#x8fdb;&#x7a0b;&#x7531;&#x7a0b;&#x5e8f;&#x3001;&#x6570;&#x636e;&#x548c;&#x8fdb;&#x7a0b;&#x63a7;&#x5236;&#x5757;&#x4e09;&#x90e8;&#x5206;&#x7ec4;&#x6210;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472796336141" FOLDED="true" ID="ID_448919417" MODIFIED="1501123546954" TEXT="&#x5207;&#x6362;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472796347720" ID="ID_1129788930" MODIFIED="1491784224478" TEXT="&#x4ece;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x8fdb;&#x7a0b;&#x4e2d;&#x6536;&#x56de;&#x5904;&#x7406;&#x5668;&#xff0c;&#x7136;&#x540e;&#x518d;&#x4f7f;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x6765;&#x5360;&#x7528;&#x5904;&#x7406;&#x5668;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796370848" ID="ID_1066424303" MODIFIED="1491784224479" TEXT="&#x5b9e;&#x8d28;&#x4e0a;&#x5c31;&#x662f;&#x628a;&#x8fdb;&#x7a0b;&#x5b58;&#x653e;&#x5728;&#x5904;&#x7406;&#x5668;&#x7684;&#x5bc4;&#x5b58;&#x5668;&#x4e2d;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#x627e;&#x4e2a;&#x5730;&#x65b9;&#x5b58;&#x8d77;&#x6765;&#xff0c;&#x4ece;&#x800c;&#x628a;&#x5904;&#x7406;&#x5668;&#x7684;&#x5bc4;&#x5b58;&#x5668;&#x817e;&#x51fa;&#x6765;&#x8ba9;&#x5176;&#x4ed6;&#x8fdb;&#x7a0b;&#x4f7f;&#x7528;&#x3002;&#x90a3;&#x4e48;&#x88ab;&#x4e2d;&#x6b62;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#x5b58;&#x5728;&#x8fdb;&#x7a0b;&#x7684;&#x79c1;&#x6709;&#x5806;&#x6808;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796515244" ID="ID_1701056137" MODIFIED="1491784224479" TEXT="&#x7136;&#x540e;&#x628a;&#x67d0;&#x4e2a;&#x8fdb;&#x7a0b;&#x5b58;&#x653e;&#x5728;&#x79c1;&#x6709;&#x5806;&#x6808;&#x4e2d;&#x5bc4;&#x5b58;&#x5668;&#x7684;&#x6570;&#x636e;&#xff08;&#x524d;&#x4e00;&#x6b21;&#x672c;&#x8fdb;&#x7a0b;&#x88ab;&#x4e2d;&#x6b62;&#x65f6;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#xff09;&#x518d;&#x6062;&#x590d;&#x5230;&#x5904;&#x7406;&#x5668;&#x7684;&#x5bc4;&#x5b58;&#x5668;&#x4e2d;&#x53bb;&#xff0c;&#x5e76;&#x628a;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x7684;&#x65ad;&#x70b9;&#x9001;&#x5165;&#x5904;&#x7406;&#x5668;&#x7684;&#x7a0b;&#x5e8f;&#x6307;&#x9488;PC&#xff0c;&#x4e8e;&#x662f;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x5c31;&#x5f00;&#x59cb;&#x88ab;&#x5904;&#x7406;&#x5668;&#x8fd0;&#x884c;&#x4e86;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472796428511" FOLDED="true" ID="ID_700299022" MODIFIED="1501123546954" TEXT="&#x4e0a;&#x4e0b;&#x6587;context">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472796420096" ID="ID_1650019774" MODIFIED="1473812568683" TEXT="&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x5b58;&#x50a8;&#x5728;&#x5904;&#x7406;&#x5668;&#x5404;&#x5bc4;&#x5b58;&#x5668;&#x4e2d;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#x53eb;&#x505a;&#x8fdb;&#x7a0b;&#x7684;&#x4e0a;&#x4e0b;&#x6587;&#xff0c;&#x6240;&#x4ee5;&#x8fdb;&#x7a0b;&#x7684;&#x5207;&#x6362;&#x5b9e;&#x8d28;&#x4e0a;&#x5c31;&#x662f;&#x88ab;&#x4e2d;&#x6b62;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x4e0e;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x4e0a;&#x4e0b;&#x6587;&#x7684;&#x5207;&#x6362;&#x3002;&#x5728;&#x8fdb;&#x7a0b;&#x672a;&#x5360;&#x7528;&#x5904;&#x7406;&#x5668;&#x65f6;&#xff0c;&#x8fdb;&#x7a0b; &#x7684;&#x4e0a;&#x4e0b;&#x6587;&#x662f;&#x5b58;&#x50a8;&#x5728;&#x8fdb;&#x7a0b;&#x7684;&#x79c1;&#x6709;&#x5806;&#x6808;&#x4e2d;&#x7684;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472805038307" FOLDED="true" ID="ID_571604798" MODIFIED="1501123546954" TEXT="&#x72b6;&#x6001;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472805043812" FOLDED="true" ID="ID_1705223157" MODIFIED="1501123546954" TEXT="&#x5c31;&#x7eea;&#x72b6;&#x6001;&#xff08;Ready&#xff09;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805058055" ID="ID_138147909" MODIFIED="1472805058055" TEXT="&#x8fdb;&#x7a0b;&#x5df2;&#x83b7;&#x5f97;&#x9664;&#x5904;&#x7406;&#x5668;&#x5916;&#x7684;&#x6240;&#x9700;&#x8d44;&#x6e90;&#xff0c;&#x7b49;&#x5f85;&#x5206;&#x914d;&#x5904;&#x7406;&#x5668;&#x8d44;&#x6e90;&#xff1b;&#x53ea;&#x8981;&#x5206;&#x914d;&#x4e86;&#x5904;&#x7406;&#x5668;&#x8fdb;&#x7a0b;&#x5c31;&#x53ef;&#x6267;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1472805065018" ID="ID_1853496199" MODIFIED="1472805065019" TEXT="&#x5c31;&#x7eea;&#x8fdb;&#x7a0b;&#x53ef;&#x4ee5;&#x6309;&#x591a;&#x4e2a;&#x4f18;&#x5148;&#x7ea7;&#x6765;&#x5212;&#x5206;&#x961f;&#x5217;"/>
</node>
<node COLOR="#990000" CREATED="1472805072010" FOLDED="true" ID="ID_1080492199" MODIFIED="1501123546954" TEXT="&#x8fd0;&#x884c;&#x72b6;&#x6001;(Running)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805099236" ID="ID_1199566397" MODIFIED="1472805099237" TEXT="&#x8fdb;&#x7a0b;&#x5360;&#x7528;&#x5904;&#x7406;&#x5668;&#x8d44;&#x6e90;&#xff1b;&#x5904;&#x4e8e;&#x6b64;&#x72b6;&#x6001;&#x7684;&#x8fdb;&#x7a0b;&#x7684;&#x6570;&#x76ee;&#x5c0f;&#x4e8e;&#x7b49;&#x4e8e;&#x5904;&#x7406;&#x5668;&#x7684;&#x6570;&#x76ee;&#x3002;&#x5728;&#x6ca1;&#x6709;&#x5176;&#x4ed6;&#x8fdb;&#x7a0b;&#x53ef;&#x4ee5;&#x6267;&#x884c;&#x65f6;(&#x5982;&#x6240;&#x6709;&#x8fdb;&#x7a0b;&#x90fd;&#x5728;&#x963b;&#x585e;&#x72b6;&#x6001;)&#xff0c;&#x901a;&#x5e38;&#x4f1a;&#x81ea;&#x52a8;&#x6267;&#x884c;&#x7cfb;&#x7edf;&#x7684;&#x7a7a;&#x95f2;&#x8fdb;&#x7a0b;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472805105665" FOLDED="true" ID="ID_972215001" MODIFIED="1501123546954" TEXT="&#x963b;&#x585e;&#x72b6;&#x6001;(Blocked)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805156130" ID="ID_795584703" MODIFIED="1472805173493" TEXT="&#x7531;&#x4e8e;&#x8fdb;&#x7a0b;&#x7b49;&#x5f85;&#x67d0;&#x79cd;&#x6761;&#x4ef6;&#xff08;&#x5982;I/O&#x64cd;&#x4f5c;&#x6216;&#x8fdb;&#x7a0b;&#x540c;&#x6b65;&#xff09;&#xff0c;&#x5728;&#x6761;&#x4ef6;&#x6ee1;&#x8db3;&#x4e4b;&#x524d;&#x65e0;&#x6cd5;&#x7ee7;&#x7eed;&#x6267;&#x884c;&#x3002;&#x5373;&#x4f7f;&#x628a;&#x5904;&#x7406;&#x5668;&#x8d44;&#x6e90;&#x5206;&#x914d;&#x7ed9;&#x8be5;&#x8fdb;&#x7a0b;&#xff0c;&#x4e5f;&#x65e0;&#x6cd5;&#x8fd0;&#x884c;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472805209668" FOLDED="true" ID="ID_456147498" MODIFIED="1501123546954" TEXT="&#x7a0b;&#x5e8f;&#x548c;&#x8fdb;&#x7a0b;&#x7684;&#x533a;&#x522b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472805225439" ID="ID_819681470" MODIFIED="1491784224480" TEXT="&#x7a0b;&#x5e8f;&#x662f;&#x6307;&#x4ee4;&#x548c;&#x6570;&#x636e;&#x7684;&#x6709;&#x5e8f;&#x96c6;&#x5408;&#xff0c;&#x5176;&#x672c;&#x8eab;&#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x8fd0;&#x884c;&#x7684;&#x542b;&#x4e49;&#xff0c;&#x662f;&#x4e00;&#x4e2a;&#x9759;&#x6001;&#x7684;&#x6982;&#x5ff5;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472805235106" ID="ID_1434915288" MODIFIED="1491784224480" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x7a0b;&#x5e8f;&#x5728;&#x5904;&#x7406;&#x673a;&#x4e0a;&#x7684;&#x4e00;&#x6b21;&#x6267;&#x884c;&#x8fc7;&#x7a0b;&#xff0c;&#x5b83;&#x662f;&#x4e00;&#x4e2a;&#x52a8;&#x6001;&#x7684;&#x6982;&#x5ff5;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472805249977" ID="ID_346715766" MODIFIED="1491784224480" TEXT="&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#x4f5c;&#x4e3a;&#x4e00;&#x79cd;&#x8f6f;&#x4ef6;&#x8d44;&#x6599;&#x957f;&#x671f;&#x5b58;&#x5728;&#xff0c;&#x800c;&#x8fdb;&#x7a0b;&#x662f;&#x6709;&#x4e00;&#x5b9a;&#x751f;&#x547d;&#x671f;&#x7684;&#x3002;&#x7a0b;&#x5e8f;&#x662f;&#x6c38;&#x4e45;&#x7684;&#xff0c;&#x8fdb;&#x7a0b;&#x662f;&#x6682;&#x65f6;&#x7684;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472805290368" ID="ID_1611370192" MODIFIED="1491784224480" TEXT="&#x540c;&#x4e00;&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#x5bf9;&#x5e94;&#x591a;&#x4e2a;&#x8fdb;&#x7a0b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1472805880007" FOLDED="true" ID="ID_1409834258" MODIFIED="1501123546954" POSITION="left" TEXT="&#x4e8c;&#x8005;&#x533a;&#x522b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472805958580" ID="ID_1570889795" MODIFIED="1491784224499" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x8d44;&#x6e90;&#x5206;&#x914d;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1472805988654" ID="ID_833847488" MODIFIED="1491784224499" TEXT="&#x7ebf;&#x7a0b;&#x4e0e;&#x8d44;&#x6e90;&#x5206;&#x914d;&#x65e0;&#x5173;&#xff0c;&#x5b83;&#x5c5e;&#x4e8e;&#x67d0;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#xff0c;&#x5e76;&#x4e0e;&#x8fdb;&#x7a0b;&#x5185;&#x7684;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x4e00;&#x8d77;&#x5171;&#x4eab;&#x8fdb;&#x7a0b;&#x7684;&#x8d44;&#x6e90;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1472806022641" ID="ID_1474120852" MODIFIED="1491784224499" TEXT="&#x901a;&#x5e38;&#x5728;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x4e2d;&#x53ef;&#x4ee5;&#x5305;&#x542b;&#x82e5;&#x5e72;&#x4e2a;&#x7ebf;&#x7a0b;&#xff0c;&#x5b83;&#x4eec;&#x53ef;&#x4ee5;&#x5229;&#x7528;&#x8fdb;&#x7a0b;&#x6240;&#x62e5;&#x6709;&#x7684;&#x8d44;&#x6e90;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1472806088135" ID="ID_968659290" MODIFIED="1491784224499" TEXT="&#x7ebf;&#x7a0b;&#x4e0a;&#x4e0b;&#x6587;&#x5207;&#x6362;&#x6bd4;&#x8fdb;&#x7a0b;&#x4e0a;&#x4e0b;&#x6587;&#x5207;&#x6362;&#x8981;&#x5feb;&#x5f97;&#x591a;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1472806094600" ID="ID_174596136" MODIFIED="1491784224499" TEXT="&#x8fdb;&#x7a0b;&#x95f4;&#x901a;&#x4fe1;IPC&#xff0c;&#x7ebf;&#x7a0b;&#x95f4;&#x53ef;&#x4ee5;&#x76f4;&#x63a5;&#x8bfb;&#x5199;&#x8fdb;&#x7a0b;&#x6570;&#x636e;&#x6bb5;&#xff08;&#x5982;&#x5168;&#x5c40;&#x53d8;&#x91cf;&#xff09;&#x6765;&#x8fdb;&#x884c;&#x901a;&#x4fe1;&#x2014;&#x2014;&#x9700;&#x8981;&#x8fdb;&#x7a0b;&#x540c;&#x6b65;&#x548c;&#x4e92;&#x65a5;&#x624b;&#x6bb5;&#x7684;&#x8f85;&#x52a9;&#xff0c;&#x4ee5;&#x4fdd;&#x8bc1;&#x6570;&#x636e;&#x7684;&#x4e00;&#x81f4;&#x6027;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1472795640669" FOLDED="true" ID="ID_767373056" MODIFIED="1522220316460" POSITION="right" TEXT="&#x7ebf;&#x7a0b;Thread">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472805328449" ID="ID_1746759886" MODIFIED="1522215192741" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472805330280" ID="ID_1717688026" MODIFIED="1491784224484" TEXT="&#x6709;&#x65f6;&#x88ab;&#x79f0;&#x4e3a;&#x8f7b;&#x91cf;&#x7ea7;&#x8fdb;&#x7a0b;(Lightweight Process&#xff0c;LWP&#xff09;&#xff0c;&#x662f;&#x7a0b;&#x5e8f;&#x6267;&#x884c;&#x6d41;&#x7684;&#x6700;&#x5c0f;&#x5355;&#x5143;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472805345589" ID="ID_357931339" MODIFIED="1491784224484" TEXT="&#x4e00;&#x4e2a;&#x6807;&#x51c6;&#x7684;&#x7ebf;&#x7a0b;&#x7531;&#x7ebf;&#x7a0b;ID&#xff0c;&#x5f53;&#x524d;&#x6307;&#x4ee4;&#x6307;&#x9488;(PC&#xff09;&#xff0c;&#x5bc4;&#x5b58;&#x5668;&#x96c6;&#x5408;&#x548c;&#x5806;&#x6808;&#x7ec4;&#x6210;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472805366679" ID="ID_1747772647" MODIFIED="1491784224484" TEXT="&#x7ebf;&#x7a0b;&#x662f;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x4e00;&#x4e2a;&#x5b9e;&#x4f53;&#xff0c;&#x662f;&#x88ab;&#x7cfb;&#x7edf;&#x72ec;&#x7acb;&#x8c03;&#x5ea6;&#x548c;&#x5206;&#x6d3e;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;&#xff0c;&#x7ebf;&#x7a0b;&#x81ea;&#x5df1;&#x4e0d;&#x62e5;&#x6709;&#x7cfb;&#x7edf;&#x8d44;&#x6e90;&#xff0c;&#x53ea;&#x62e5;&#x6709;&#x4e00;&#x70b9;&#x513f;&#x5728;&#x8fd0;&#x884c;&#x4e2d;&#x5fc5;&#x4e0d;&#x53ef;&#x5c11;&#x7684;&#x8d44;&#x6e90;&#xff0c;&#x4f46;&#x5b83;&#x53ef;&#x4e0e;&#x540c;&#x5c5e;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x7684;&#x5176;&#x5b83;&#x7ebf;&#x7a0b;&#x5171;&#x4eab;&#x8fdb;&#x7a0b;&#x6240;&#x62e5;&#x6709;&#x7684;&#x5168;&#x90e8;&#x8d44;&#x6e90;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472805734159" FOLDED="true" ID="ID_1870314786" MODIFIED="1522215563270" TEXT="&#x7279;&#x5f81;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472805764986" ID="ID_625217622" MODIFIED="1522215409549" TEXT="&#x8f7b;&#x578b;&#x5b9e;&#x4f53;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805741580" ID="ID_423827264" MODIFIED="1472805741581" TEXT="&#x7ebf;&#x7a0b;&#x662f;&#x80fd;&#x72ec;&#x7acb;&#x8fd0;&#x884c;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;&#xff0c;&#x56e0;&#x800c;&#x4e5f;&#x662f;&#x72ec;&#x7acb;&#x8c03;&#x5ea6;&#x548c;&#x5206;&#x6d3e;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;"/>
<node COLOR="#111111" CREATED="1472805750749" ID="ID_360758305" MODIFIED="1472805750749" TEXT="&#x7ebf;&#x7a0b;&#x5f88;&#x201c;&#x8f7b;&#x201d;&#xff0c;&#x6545;&#x7ebf;&#x7a0b;&#x7684;&#x5207;&#x6362;&#x975e;&#x5e38;&#x8fc5;&#x901f;&#x4e14;&#x5f00;&#x9500;&#x5c0f;&#xff08;&#x5728;&#x540c;&#x4e00;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#xff09;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472805777307" ID="ID_819273161" MODIFIED="1491784224485" TEXT="&#x72ec;&#x7acb;&#x8c03;&#x5ea6;&#x548c;&#x5206;&#x6d3e;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472805802387" ID="ID_219352292" MODIFIED="1522215463804" TEXT="&#x53ef;&#x5e76;&#x53d1;&#x6267;&#x884c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805817637" ID="ID_655260545" MODIFIED="1501051114396" TEXT="&#x5728;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x4e4b;&#x95f4;&#xff0c;&#x53ef;&#x4ee5;&#x5e76;&#x53d1;&#x6267;&#x884c;&#xff0c;&#xa;&#x751a;&#x81f3;&#x5141;&#x8bb8;&#x5728;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x4e2d;&#x6240;&#x6709;&#x7ebf;&#x7a0b;&#x90fd;&#x80fd;&#x5e76;&#x53d1;&#x6267;&#x884c;&#xff1b;&#xa;&#x540c;&#x6837;&#xff0c;&#x4e0d;&#x540c;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x7ebf;&#x7a0b;&#x4e5f;&#x80fd;&#x5e76;&#x53d1;&#x6267;&#x884c;&#xff0c;&#xa;&#x5145;&#x5206;&#x5229;&#x7528;&#x548c;&#x53d1;&#x6325;&#x4e86;&#x5904;&#x7406;&#x673a;&#x4e0e;&#x5916;&#x56f4;&#x8bbe;&#x5907;&#x5e76;&#x884c;&#x5de5;&#x4f5c;&#x7684;&#x80fd;&#x529b;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472805823433" FOLDED="true" ID="ID_595192257" MODIFIED="1501123546954" TEXT="&#x5171;&#x4eab;&#x8fdb;&#x7a0b;&#x8d44;&#x6e90;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805851470" ID="ID_1236863241" MODIFIED="1472805851470" TEXT="&#x5728;&#x540c;&#x4e00;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x5404;&#x4e2a;&#x7ebf;&#x7a0b;&#xff0c;&#x90fd;&#x53ef;&#x4ee5;&#x5171;&#x4eab;&#x8be5;&#x8fdb;&#x7a0b;&#x6240;&#x62e5;&#x6709;&#x7684;&#x8d44;&#x6e90;&#xff0c;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472806295705" FOLDED="true" ID="ID_571289423" LINK="&#x7ebf;&#x7a0b;&#x751f;&#x547d;&#x5468;&#x671f;.png" MODIFIED="1522215672210" TEXT="&#x7ebf;&#x7a0b;&#x7684;&#x751f;&#x547d;&#x5468;&#x671f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472806321131" FOLDED="true" ID="ID_559817739" MODIFIED="1522215611639" TEXT="&#x65b0;&#x7ebf;&#x7a0b;&#x6001;&#xff08;New Thread)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472806346386" ID="ID_157715108" MODIFIED="1472806346386" TEXT="&#x5f53;&#x7ebf;&#x7a0b;&#x5904;&#x4e8e;&quot;&#x65b0;&#x7ebf;&#x7a0b;&quot;&#x72b6;&#x6001;&#x65f6;&#xff0c;&#x4ec5;&#x4ec5;&#x662f;&#x4e00;&#x4e2a;&#x7a7a;&#x7ebf;&#x7a0b;&#x5bf9;&#x8c61;&#xff0c;&#x5b83;&#x8fd8;&#x6ca1;&#x6709;&#x5206;&#x914d;&#x5230;&#x7cfb;&#x7edf;&#x8d44;&#x6e90;&#x3002;&#x56e0;&#x6b64;&#x53ea;&#x80fd;&#x542f;&#x52a8;&#x6216;&#x7ec8;&#x6b62;&#x5b83;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472806352825" ID="ID_1636062473" MODIFIED="1522215631929" TEXT="&#x5c31;&#x7eea;&#x72b6;&#x6001;:">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472806444316" ID="ID_465637973" MODIFIED="1472806444317" TEXT="&#x5f53;&#x7ebf;&#x7a0b;&#x5bf9;&#x8c61;&#x8c03;&#x7528;&#x4e86;start()&#x65b9;&#x6cd5;&#x4e4b;&#x540e;&#xff0c;&#x8be5;&#x7ebf;&#x7a0b;&#x5c31;&#x8fdb;&#x5165;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x3002;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x5904;&#x4e8e;&#x5c31;&#x7eea;&#x961f;&#x5217;&#x4e2d;&#xff0c;&#x8981;&#x7b49;&#x5f85;JVM&#x91cc;&#x7ebf;&#x7a0b;&#x8c03;&#x5ea6;&#x5668;&#x7684;&#x8c03;&#x5ea6;"/>
</node>
<node COLOR="#990000" CREATED="1472806455381" ID="ID_797854994" MODIFIED="1522215590696" TEXT="&#x8fd0;&#x884c;&#x72b6;&#x6001;:">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472806461273" ID="ID_192190175" MODIFIED="1472806461273" TEXT="&#x5982;&#x679c;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x83b7;&#x53d6; CPU &#x8d44;&#x6e90;&#xff0c;&#x5c31;&#x53ef;&#x4ee5;&#x6267;&#x884c; run()&#xff0c;&#x6b64;&#x65f6;&#x7ebf;&#x7a0b;&#x4fbf;&#x5904;&#x4e8e;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x3002;&#x5904;&#x4e8e;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x6700;&#x4e3a;&#x590d;&#x6742;&#xff0c;&#x5b83;&#x53ef;&#x4ee5;&#x53d8;&#x4e3a;&#x963b;&#x585e;&#x72b6;&#x6001;&#x3001;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x548c;&#x6b7b;&#x4ea1;&#x72b6;&#x6001;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472806467339" ID="ID_744194040" MODIFIED="1522215601879" TEXT="&#x963b;&#x585e;&#x72b6;&#x6001;:">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472806483557" ID="ID_1174511687" MODIFIED="1472806483558" TEXT="&#x5982;&#x679c;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x6267;&#x884c;&#x4e86;sleep&#xff08;&#x7761;&#x7720;&#xff09;&#x3001;suspend&#xff08;&#x6302;&#x8d77;&#xff09;&#x7b49;&#x65b9;&#x6cd5;&#xff0c;&#x5931;&#x53bb;&#x6240;&#x5360;&#x7528;&#x8d44;&#x6e90;&#x4e4b;&#x540e;&#xff0c;&#x8be5;&#x7ebf;&#x7a0b;&#x5c31;&#x4ece;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x8fdb;&#x5165;&#x963b;&#x585e;&#x72b6;&#x6001;&#x3002;&#x5728;&#x7761;&#x7720;&#x65f6;&#x95f4;&#x5df2;&#x5230;&#x6216;&#x83b7;&#x5f97;&#x8bbe;&#x5907;&#x8d44;&#x6e90;&#x540e;&#x53ef;&#x4ee5;&#x91cd;&#x65b0;&#x8fdb;&#x5165;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1500551987575" FOLDED="true" ID="ID_1872295178" MODIFIED="1501123546954">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27515;&#20129;&#29366;&#24577;:
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500552007266" ID="ID_1260088438" MODIFIED="1500552007266" TEXT="&#x5f53;&#x7ebf;&#x7a0b;&#x7684;run()&#x65b9;&#x6cd5;&#x6267;&#x884c;&#x7ed3;&#x675f;&#x540e;&#xff0c;&#x8be5;&#x7ebf;&#x7a0b;&#x81ea;&#x7136;&#x6d88;&#x4ea1;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472807114713" FOLDED="true" ID="ID_203557211" MODIFIED="1522216011662" TEXT="&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472807131292" FOLDED="true" ID="ID_760187430" MODIFIED="1501123546969" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472807135252" FOLDED="true" ID="ID_703787508" MODIFIED="1501123546969" TEXT="&#x6307;&#x7684;&#x662f;&#x7ebf;&#x7a0b;&#x88ab;&#x8c03;&#x5ea6;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x987a;&#x5e8f;">
<node COLOR="#111111" CREATED="1472806489522" FOLDED="true" ID="ID_1390281345" MODIFIED="1501123546969" TEXT="&#x6b7b;&#x4ea1;&#x72b6;&#x6001;:">
<node COLOR="#111111" CREATED="1472806497027" ID="ID_1082832717" MODIFIED="1472806497027" TEXT="&#x4e00;&#x4e2a;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x5b8c;&#x6210;&#x4efb;&#x52a1;&#x6216;&#x8005;&#x5176;&#x4ed6;&#x7ec8;&#x6b62;&#x6761;&#x4ef6;&#x53d1;&#x751f;&#x65f6;&#xff0c;&#x8be5;&#x7ebf;&#x7a0b;&#x5c31;&#x5207;&#x6362;&#x5230;&#x7ec8;&#x6b62;&#x72b6;&#x6001;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472807160482" ID="ID_479089772" MODIFIED="1472807161554" TEXT="&#x6bcf;&#x4e00;&#x4e2a;Java&#x7ebf;&#x7a0b;&#x90fd;&#x6709;&#x4e00;&#x4e2a;&#x4f18;&#x5148;&#x7ea7;&#xff0c;&#x8fd9;&#x6837;&#x6709;&#x52a9;&#x4e8e;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x786e;&#x5b9a;&#x7ebf;&#x7a0b;&#x7684;&#x8c03;&#x5ea6;&#x987a;&#x5e8f;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472807182262" ID="ID_98657040" MODIFIED="1522215700993" TEXT="&#x53d6;&#x503c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472807185104" ID="ID_510850275" MODIFIED="1500552094664" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x6574;&#x6570;&#xff0c;&#x5176;&#x53d6;&#x503c;&#x8303;&#x56f4;&#x662f;1 &#xff08;Thread.MIN_PRIORITY &#xff09; &#x2014; &gt;  10 &#xff08;Thread.MAX_PRIORITY &#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1500552045637" ID="ID_180593393" MODIFIED="1500552058549" TEXT="Thread.MIN_PRIORITY"/>
<node COLOR="#111111" CREATED="1500552069302" FOLDED="true" ID="ID_1792774935" MODIFIED="1501123546969" TEXT="Thread.NORM_PRIORITY">
<node COLOR="#111111" CREATED="1472807225204" FOLDED="true" ID="ID_1584847077" MODIFIED="1501123546969" TEXT="&#x9ed8;&#x8ba4;&#x4f18;&#x5148;&#x7ea7;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472807238113" ID="ID_1337791247" MODIFIED="1472807241904" TEXT="&#x6bcf;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x90fd;&#x4f1a;&#x5206;&#x914d;&#x4e00;&#x4e2a;&#x4f18;&#x5148;&#x7ea7;NORM_PRIORITY&#xff08;5&#xff09;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1500552064057" ID="ID_550752781" MODIFIED="1500552065103" TEXT="Thread.MAX_PRIORITY"/>
</node>
<node COLOR="#990000" CREATED="1473485973385" FOLDED="true" ID="ID_582801784" MODIFIED="1501123546969" TEXT="&#x8be6;&#x60c5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473485976427" ID="ID_833400174" MODIFIED="1473485984667" TEXT="&#x5f53;&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x6ca1;&#x6709;&#x6307;&#x5b9a;&#x65f6;&#xff0c;&#x6240;&#x6709;&#x7ebf;&#x7a0b;&#x90fd;&#x643a;&#x5e26;&#x666e;&#x901a;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976427" ID="ID_486900033" MODIFIED="1473485976427" TEXT="&#x4f18;&#x5148;&#x7ea7;&#x53ef;&#x4ee5;&#x7528;&#x4ece;1&#x5230;10&#x7684;&#x8303;&#x56f4;&#x6307;&#x5b9a;&#x3002;10&#x8868;&#x793a;&#x6700;&#x9ad8;&#x4f18;&#x5148;&#x7ea7;&#xff0c;1&#x8868;&#x793a;&#x6700;&#x4f4e;&#x4f18;&#x5148;&#x7ea7;&#xff0c;5&#x662f;&#x666e;&#x901a;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_286156164" MODIFIED="1473812688366" TEXT="&#x4f18;&#x5148;&#x7ea7;&#x6700;&#x9ad8;&#x7684;&#x7ebf;&#x7a0b;&#x5728;&#x6267;&#x884c;&#x65f6;&#x88ab;&#x7ed9;&#x4e88;&#x4f18;&#x5148;&#x3002;&#x4f46;&#x662f;&#x4e0d;&#x80fd;&#x4fdd;&#x8bc1;&#x7ebf;&#x7a0b;&#x5728;&#x542f;&#x52a8;&#x65f6;&#x5c31;&#x8fdb;&#x5165;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_1476552177" MODIFIED="1473485976437" TEXT="&#x4e0e;&#x5728;&#x7ebf;&#x7a0b;&#x6c60;&#x4e2d;&#x7b49;&#x5f85;&#x8fd0;&#x884c;&#x673a;&#x4f1a;&#x7684;&#x7ebf;&#x7a0b;&#x76f8;&#x6bd4;&#xff0c;&#x5f53;&#x524d;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7ebf;&#x7a0b;&#x53ef;&#x80fd;&#x603b;&#x662f;&#x62e5;&#x6709;&#x66f4;&#x9ad8;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_592871160" MODIFIED="1473485976437" TEXT="&#x7531;&#x8c03;&#x5ea6;&#x7a0b;&#x5e8f;&#x51b3;&#x5b9a;&#x54ea;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x88ab;&#x6267;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_863706984" MODIFIED="1473822146268" TEXT="t.setPriority(int)&#x7528;&#x6765;&#x8bbe;&#x5b9a;&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_1533690697" MODIFIED="1473812762069" TEXT="&#x6ce8;&#x610f;&#xff1a; &#x5728;&#x7ebf;&#x7a0b;&#x5f00;&#x59cb;&#x65b9;&#x6cd5;&#x88ab;&#x8c03;&#x7528;&#x4e4b;&#x524d;&#xff0c;&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x5e94;&#x8be5;&#x88ab;&#x8bbe;&#x5b9a;&#x3002;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473485992445" FOLDED="true" ID="ID_1685883036" MODIFIED="1522216544488" TEXT="&#x7ebf;&#x7a0b;&#x7684;&#x8c03;&#x5ea6;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473486013430" FOLDED="true" ID="ID_1965563465" MODIFIED="1522216528553" TEXT="yield()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473486023623" ID="ID_1260982073" MODIFIED="1522216109274" TEXT="?">
<node COLOR="#111111" CREATED="1473486026025" ID="ID_809305015" MODIFIED="1473486031805" TEXT="&#x653e;&#x624b;&#xff0c;&#x653e;&#x5f03;&#xff0c;&#x6295;&#x964d;&#x7684;&#x610f;&#x601d;"/>
<node COLOR="#111111" CREATED="1473486046989" ID="ID_1866990005" MODIFIED="1473486046989" TEXT="&#x4e00;&#x4e2a;&#x8c03;&#x7528;yield()&#x65b9;&#x6cd5;&#x7684;&#x7ebf;&#x7a0b;&#x544a;&#x8bc9;&#x865a;&#x62df;&#x673a;&#x5b83;&#x4e50;&#x610f;&#x8ba9;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x5360;&#x7528;&#x81ea;&#x5df1;&#x7684;&#x4f4d;&#x7f6e;"/>
<node COLOR="#111111" CREATED="1473486060461" ID="ID_228230856" MODIFIED="1473486060461" TEXT="&#x8fd9;&#x8868;&#x660e;&#x8be5;&#x7ebf;&#x7a0b;&#x6ca1;&#x6709;&#x5728;&#x505a;&#x4e00;&#x4e9b;&#x7d27;&#x6025;&#x7684;&#x4e8b;&#x60c5;"/>
<node COLOR="#111111" CREATED="1473486095277" ID="ID_482034817" MODIFIED="1500713215581" TEXT="yield() &#x662f;&#x4e00;&#x4e2a;&#x9759;&#x6001;&#x7684;&#x539f;&#x751f;(native)&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1473486095277" ID="ID_1166039108" MODIFIED="1500713223203" TEXT="yield()&#x544a;&#x8bc9;&#x5f53;&#x524d;&#x6b63;&#x5728;&#x6267;&#x884c;&#x7684;&#x7ebf;&#x7a0b;&#x628a;&#x8fd0;&#x884c;&#x673a;&#x4f1a;&#x4ea4;&#x7ed9;&#x7ebf;&#x7a0b;&#x6c60;&#x4e2d;&#x62e5;&#x6709;&#x76f8;&#x540c;&#x4f18;&#x5148;&#x7ea7;&#x7684;&#x7ebf;&#x7a0b;&#x3002;"/>
<node COLOR="#111111" CREATED="1473486095277" ID="ID_61590422" MODIFIED="1500713230970" TEXT="yield() &#x4e0d;&#x80fd;&#x4fdd;&#x8bc1;&#x4f7f;&#x5f97;&#x5f53;&#x524d;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7ebf;&#x7a0b;&#x8fc5;&#x901f;&#x8f6c;&#x6362;&#x5230;&#x53ef;&#x8fd0;&#x884c;&#x7684;&#x72b6;&#x6001;"/>
<node COLOR="#111111" CREATED="1473486095287" ID="ID_1605364582" MODIFIED="1473486095287" TEXT="&#x5b83;&#x4ec5;&#x80fd;&#x4f7f;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x4ece;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x8f6c;&#x5230;&#x53ef;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#xff0c;&#x800c;&#x4e0d;&#x662f;&#x7b49;&#x5f85;&#x6216;&#x963b;&#x585e;&#x72b6;&#x6001;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473486150596" FOLDED="true" ID="ID_1301119843" MODIFIED="1522216530543" TEXT="join()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473486154174" FOLDED="true" ID="ID_1720034569" MODIFIED="1501123546969" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473486179566" ID="ID_141609932" MODIFIED="1473487621239" TEXT="&#x8c03;&#x7528;&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x7ebf;&#x7a0b;&#x4f1a;&#x7b49;&#x5f85;"/>
</node>
<node COLOR="#111111" CREATED="1473487627997" FOLDED="true" ID="ID_1273994790" MODIFIED="1501123546969" TEXT="&#x91cd;&#x8f7d;&#x7684;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473487658527" ID="ID_360353686" MODIFIED="1473487658527" TEXT="public final synchronized void join(long millis)"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473487718572" FOLDED="true" ID="ID_1707608035" MODIFIED="1522216531880">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      sleep(time&#27627;&#31186;)
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500713246442" ID="ID_900350642" MODIFIED="1500713256512" TEXT="&#x8ba9;&#x7ebf;&#x7a0b;&#x4f11;&#x7720;"/>
</node>
<node COLOR="#990000" CREATED="1473487675712" ID="ID_1625509813" MODIFIED="1522216215837">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      wait()
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473487887238" FOLDED="true" ID="ID_1186927610" MODIFIED="1501123546969" TEXT="?">
<node COLOR="#111111" CREATED="1473487888850" ID="ID_673717514" MODIFIED="1473487888850" TEXT="&#x8ba9;&#x5f53;&#x524d;&#x7ebf;&#x7a0b;&#x963b;&#x585e;&#xff0c;&#x5e76;&#x4e14;&#x5f53;&#x524d;&#x7ebf;&#x7a0b;&#x5fc5;&#x987b;&#x62e5;&#x6709;&#x6b64;&#x5bf9;&#x8c61;&#x7684;monitor&#xff08;&#x5373;&#x9501;&#xff09;"/>
<node COLOR="#111111" CREATED="1473488038420" ID="ID_217215283" MODIFIED="1473488038420" TEXT="&#x8c03;&#x7528;wait()&#x65b9;&#x6cd5;&#x5fc5;&#x987b;&#x5728;&#x540c;&#x6b65;&#x5757;&#x6216;&#x8005;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x4e2d;&#x8fdb;&#x884c;&#xff08;synchronized&#x5757;&#x6216;&#x8005;synchronized&#x65b9;&#x6cd5;&#xff09;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473487680492" FOLDED="true" ID="ID_1206978712" MODIFIED="1501123546969" TEXT="notify()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473487913650" ID="ID_1462612599" MODIFIED="1473487913650" TEXT="&#x5524;&#x9192;&#x4e00;&#x4e2a;&#x6b63;&#x5728;&#x7b49;&#x5f85;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;monitor&#x7684;&#x7ebf;&#x7a0b;&#xff0c;&#x5982;&#x679c;&#x6709;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x90fd;&#x5728;&#x7b49;&#x5f85;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;monitor&#xff0c;&#x5219;&#x53ea;&#x80fd;&#x5524;&#x9192;&#x5176;&#x4e2d;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#990000" CREATED="1473487685402" FOLDED="true" ID="ID_637678687" MODIFIED="1501123546969" TEXT="notifyAll()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473487924610" ID="ID_1997070514" MODIFIED="1473487924610" TEXT="&#x5524;&#x9192;&#x6240;&#x6709;&#x6b63;&#x5728;&#x7b49;&#x5f85;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;monitor&#x7684;&#x7ebf;&#x7a0b;&#xff1b;"/>
</node>
<node COLOR="#990000" CREATED="1473488118878" ID="ID_1461290613" MODIFIED="1491784224488" TEXT="&#x6ce8;&#x610f;&#xff1a; notify()&#x548c;notifyAll()&#x65b9;&#x6cd5;&#x53ea;&#x662f;&#x5524;&#x9192;&#x7b49;&#x5f85;&#x8be5;&#x5bf9;&#x8c61;&#x7684;monitor&#x7684;&#x7ebf;&#x7a0b;&#xff0c;&#x5e76;&#x4e0d;&#x51b3;&#x5b9a;&#x54ea;&#x4e2a;&#x7ebf;&#x7a0b;&#x80fd;&#x591f;&#x83b7;&#x53d6;&#x5230;monitor">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473487954148" FOLDED="true" ID="ID_1400179769" LINK="&#x7ebf;&#x7a0b;/&#x751f;&#x4ea7;&#x6d88;&#x8d39;&#x8005;.txt" MODIFIED="1522216519687" TEXT="monitor &#x9501;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473489366009" FOLDED="true" ID="ID_987194426" MODIFIED="1501147092747" TEXT="&#x6b7b;&#x9501;">
<node COLOR="#111111" CREATED="1473489371409" FOLDED="true" ID="ID_1753339500" MODIFIED="1501123546969" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473489412109" ID="ID_1951843246" MODIFIED="1500713361564" TEXT="&#x6240;&#x8c13;&#x6b7b;&#x9501;&#xff1a; &#x662f;&#x6307;&#x4e24;&#x4e2a;&#x6216;&#x4e24;&#x4e2a;&#x4ee5;&#x4e0a;&#x7684;&#x8fdb;&#x7a0b;&#x5728;&#x6267;&#x884c;&#x8fc7;&#x7a0b;&#x4e2d;&#xff0c;&#xa;&#x7531;&#x4e8e;&#x7ade;&#x4e89;&#x8d44;&#x6e90;&#x6216;&#x8005;&#x7531;&#x4e8e;&#x5f7c;&#x6b64;&#x901a;&#x4fe1;&#x4e0d;&#x7545;&#x800c;&#x9020;&#x6210;&#x7684;&#x4e00;&#x79cd;&#x963b;&#x585e;&#x7684;&#x73b0;&#x8c61;&#xff0c;&#xa;&#x82e5;&#x65e0;&#x5916;&#x529b;&#x4f5c;&#x7528;&#xff0c;&#x5b83;&#x4eec;&#x90fd;&#x5c06;&#x65e0;&#x6cd5;&#x63a8;&#x8fdb;&#x4e0b;&#x53bb;&#x3002;&#xa;&#x6b64;&#x65f6;&#x79f0;&#x7cfb;&#x7edf;&#x5904;&#x4e8e;&#x6b7b;&#x9501;&#x72b6;&#x6001;&#x6216;&#x7cfb;&#x7edf;&#x4ea7;&#x751f;&#x4e86;&#x6b7b;&#x9501;&#xff0c;&#xa;&#x8fd9;&#x4e9b;&#x6c38;&#x8fdc;&#x5728;&#x4e92;&#x76f8;&#x7b49;&#x5f85;&#x7684;&#x8fdb;&#x7a0b;&#x79f0;&#x4e3a;&#x6b7b;&#x9501;&#x8fdb;&#x7a0b;&#x3002;"/>
<node COLOR="#111111" CREATED="1500713374154" ID="ID_569816423" MODIFIED="1500713392617" TEXT="&#x6bd4;&#x5982;&quot;&#x72ed;&#x8def;&#x76f8;&#x9022;&quot;"/>
</node>
<node COLOR="#111111" CREATED="1473489425720" FOLDED="true" ID="ID_839797092" MODIFIED="1501123546969" TEXT="&#x4ea7;&#x751f;&#x6b7b;&#x9501;&#x7684;&#x6761;&#x4ef6;">
<node COLOR="#111111" CREATED="1473489445703" FOLDED="true" ID="ID_1693991678" MODIFIED="1501123546969" TEXT="1&#xff09;&#x4e92;&#x65a5;&#x6761;&#x4ef6;&#xff1a;">
<node COLOR="#111111" CREATED="1500713810632" ID="ID_981388463" MODIFIED="1500713820650" TEXT="&#x6307;&#x8fdb;&#x7a0b;&#x5bf9;&#x6240;&#x5206;&#x914d;&#x5230;&#x7684;&#x8d44;&#x6e90;&#x8fdb;&#x884c;&#x6392;&#x5b83;&#x6027;&#x4f7f;&#x7528;&#xff0c;&#xa; &#x5373;&#x5728;&#x4e00;&#x6bb5;&#x65f6;&#x95f4;&#x5185;&#x67d0;&#x8d44;&#x6e90;&#x53ea;&#x7531;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x5360;&#x7528;&#x3002;&#xa;&#x5982;&#x679c;&#x6b64;&#x65f6;&#x8fd8; &#x6709;&#x5176;&#x5b83;&#x8fdb;&#x7a0b;&#x8bf7;&#x6c42;&#x8d44;&#x6e90;&#xff0c;&#x5219;&#x8bf7;&#x6c42;&#x8005;&#xa;&#x53ea;&#x80fd;&#x7b49;&#x5f85;&#xff0c;&#x76f4;&#x81f3;&#x5360;&#x6709;&#x8d44; &#x6e90;&#x7684;&#x8fdb;&#x7a0b;&#x7528;&#x6bd5;&#x91ca;&#x653e;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473489445713" FOLDED="true" ID="ID_1860615704" MODIFIED="1501123546969" TEXT="2&#xff09;&#x8bf7;&#x6c42;&#x548c;&#x4fdd;&#x6301;&#x6761;&#x4ef6;&#xff1a;">
<node COLOR="#111111" CREATED="1500713830365" ID="ID_1312054460" MODIFIED="1500713835105">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25351;&#36827;&#31243;&#24050;&#32463;&#20445;&#25345;&#33267;&#23569;&#19968;&#20010;&#36164;&#28304;&#65292;
    </p>
    <p>
      &#20294;&#21448;&#25552;&#20986;&#20102;&#26032;&#30340;&#36164;&#28304;&#35831;&#27714;&#65292;&#32780;&#35813;&#36164;&#28304;&#24050;&#34987;&#20854;&#23427;&#36827;&#31243;&#21344;&#26377;&#65292;
    </p>
    <p>
      &#27492;&#26102;&#35831;&#27714;&#36827;&#31243;&#38459;&#22622;&#65292;&#20294;&#21448;&#23545;&#33258;&#24049;&#24050;&#33719;&#24471;&#30340;&#20854;&#23427;&#36164;&#28304;&#20445;&#25345;&#19981;&#25918;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1473489445731" FOLDED="true" ID="ID_1845911600" MODIFIED="1501123546969">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      3&#65289;&#19981;&#21093;&#22842;&#26465;&#20214;&#65306;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1500713855651" ID="ID_411798175" MODIFIED="1500713865490">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25351;&#36827;&#31243;&#24050;&#33719;&#24471;&#30340;&#36164;&#28304;&#65292;&#22312;&#26410;&#20351;&#29992;&#23436;&#20043;&#21069;&#65292;<br />&#19981;&#33021;&#34987;&#21093;&#22842;&#65292;&#21482;&#33021;&#22312;&#20351;&#29992;&#23436;&#26102;&#30001;&#33258;&#24049;&#37322;&#25918;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1473489445736" FOLDED="true" ID="ID_1572762333" MODIFIED="1501123546969" TEXT="4&#xff09;&#x73af;&#x8def;&#x7b49;&#x5f85;&#x6761;&#x4ef6;&#xff1a;">
<node COLOR="#111111" CREATED="1500713872071" ID="ID_1179056692" MODIFIED="1500713874379">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25351;&#22312;&#21457;&#29983;&#27515;&#38145;&#26102;&#65292;&#24517;&#28982;&#23384;&#22312;&#19968;&#20010;&#36827;&#31243;&#8212;&#8212;&#36164;&#28304;
    </p>
    <p>
      &#30340;&#29615;&#24418;&#38142;&#65292;&#21363;&#36827;&#31243;&#38598;&#21512;{P0&#65292;P1&#65292;P2&#65292;&#183;&#183;&#183;&#65292;Pn}&#20013;&#30340;P0&#27491;&#22312;&#31561;&#24453;&#19968;
    </p>
    <p>
      &#20010;P1&#21344;&#29992;&#30340;&#36164;&#28304;&#65307;P1&#27491;&#22312;&#31561;&#24453;P2&#21344;&#29992;&#30340;&#36164;&#28304;&#65292;&#8230;&#8230;&#65292;Pn&#27491;&#22312;&#31561;&#24453;
    </p>
    <p>
      &#24050;&#34987;P0&#21344;&#29992;&#30340;&#36164;&#28304;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473489505754" FOLDED="true" ID="ID_1036442539" MODIFIED="1501123546969" TEXT="&#x5904;&#x7406;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473489513889" FOLDED="true" ID="ID_1298396228" MODIFIED="1501123546969" TEXT="&#x9884;&#x9632;&#x6b7b;&#x9501;">
<node COLOR="#111111" CREATED="1473489534141" ID="ID_1815269723" MODIFIED="1473489534141" TEXT="&#x7834;&#x574f;&#x4ea7;&#x751f;&#x6b7b;&#x9501;&#x7684;&#x56db;&#x4e2a;&#x5fc5;&#x8981;&#x6761;&#x4ef6;&#x4e2d;&#x7684;&#x4e00;&#x4e2a;&#x6216;&#x8005;&#x51e0;&#x4e2a;&#xff0c;&#x6765;&#x9884;&#x9632;&#x53d1;&#x751f;&#x6b7b;&#x9501;"/>
</node>
<node COLOR="#111111" CREATED="1473489525427" FOLDED="true" ID="ID_293555308" MODIFIED="1501123546969" TEXT="&#x68c0;&#x6d4b;&#x548c;&#x89e3;&#x9664;&#x6b7b;&#x9501;">
<node COLOR="#111111" CREATED="1473489569181" FOLDED="true" ID="ID_1035111209" MODIFIED="1501123546969" TEXT="&#x68c0;&#x67e5;">
<node COLOR="#111111" CREATED="1473489571698" ID="ID_1222234796" MODIFIED="1473489571698" TEXT="&#x68c0;&#x6d4b;&#x65b9;&#x6cd5;&#x5305;&#x62ec;&#x5b9a;&#x65f6;&#x68c0;&#x6d4b;&#x3001;&#x6548;&#x7387;&#x4f4e;&#x65f6;&#x68c0;&#x6d4b;&#x3001;&#x8fdb;&#x7a0b;&#x7b49;&#x5f85;&#x65f6;&#x68c0;&#x6d4b;&#x7b49;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473489580246" FOLDED="true" ID="ID_116234665" MODIFIED="1501123546969" TEXT="&#x89e3;&#x9664;">
<node COLOR="#111111" CREATED="1473489582484" ID="ID_4815160" MODIFIED="1473489582484" TEXT="&#x91c7;&#x53d6;&#x9002;&#x5f53;&#x63aa;&#x65bd;&#xff0c;&#x4ece;&#x7cfb;&#x7edf;&#x4e2d;&#x5c06;&#x5df2;&#x53d1;&#x751f;&#x7684;&#x6b7b;&#x9501;&#x6e05;&#x9664;&#x6389;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473489710065" FOLDED="true" ID="ID_696889424" MODIFIED="1501147092747" TEXT="&#x7ecf;&#x5178;&#x6848;&#x4f8b;">
<node COLOR="#111111" CREATED="1473489720894" FOLDED="true" ID="ID_301916946" LINK="&#x7ebf;&#x7a0b;/&#x54f2;&#x5b66;&#x5bb6;.txt" MODIFIED="1501123546969" TEXT="&#x54f2;&#x5b66;&#x5bb6;&#x5c31;&#x9910;">
<node COLOR="#111111" CREATED="1473489731595" ID="ID_1620526119" MODIFIED="1473489748316" TEXT="&#x5047;&#x8bbe;&#x6709;&#x51e0;&#x4f4d;&#x54f2;&#x5b66;&#x5bb6;&#x56f4;&#x5750;&#x5728;&#x4e00;&#x5f20;&#x9910;&#x684c;&#x65c1;&#xff0c;&#x684c;&#x4e0a;&#x6709;&#x5403;&#x4e0d;&#x5c3d;&#x7684;&#x98df;&#x54c1;&#xff0c;&#x6bcf;&#x4e24;&#x4f4d;&#x54f2;&#x5b66;&#x5bb6;&#x4e4b;&#x95f4;&#x6446;&#x653e;&#x7740;&#x4e00;&#x6839;&#x7b77;&#x5b50;&#xff0c;&#x7b77;&#x5b50;&#x7684;&#x4e2a;&#x6570;&#x4e0e;&#x54f2;&#x5b66;&#x5bb6;&#x7684;&#x6570;&#x91cf;&#x76f8;&#x7b49;&#xff0c;&#x6bcf;&#x4e00;&#x4f4d;&#x54f2;&#x5b66;&#x5bb6;&#x8981;&#x4e48;&#x601d;&#x8003;&#xff0c;&#x8981;&#x4e48;&#x7b49;&#x5f85;&#xff0c;&#x8981;&#x4e48;&#x62ff;&#x8d77;&#x5de6;&#x53f3;&#x4e24;&#x6839;&#x7b77;&#x5b50;&#x8fdb;&#x9910;"/>
</node>
<node COLOR="#111111" CREATED="1473493009811" ID="ID_1959393810" LINK="../Java&#x8fdb;&#x9636;&#x6280;&#x672f;/&#x7ebf;&#x7a0b;/TestConsumerProducer&#x4f7f;&#x7528;Wait&#x548c;notify.java" MODIFIED="1500904879318" TEXT="&#x751f;&#x4ea7;&#x8005;&#x6d88;&#x8d39;&#x8005;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473489873075" ID="ID_1440242016" MODIFIED="1473489891011" TEXT="&#x706b;&#x8f66;&#x4e0a;&#x5395;&#x6240;&#x4f8b;&#x5b50;"/>
</node>
<node COLOR="#990000" CREATED="1473489945051" FOLDED="true" ID="ID_568011647" MODIFIED="1501123546969" TEXT="sychronized">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473489953722" FOLDED="true" ID="ID_1452708315" MODIFIED="1501123546969" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473489956722" ID="ID_1943991521" MODIFIED="1473489985215" TEXT="&#x540c;&#x6b65;"/>
<node COLOR="#111111" CREATED="1473489985753" ID="ID_565309641" MODIFIED="1473490003466" TEXT="&#x6307;&#x7684;&#x662f;&#x4e8b;&#x60c5;&#x6309;&#x7ebf;&#x6027;&#x987a;&#x5e8f;&#x8fdb;&#x884c;"/>
</node>
<node COLOR="#111111" CREATED="1473490005644" ID="ID_1002188865" MODIFIED="1473490008573" TEXT="&#x540c;&#x6b65;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1473490008861" ID="ID_1456180759" MODIFIED="1473490012063" TEXT="&#x540c;&#x6b65;&#x4ee3;&#x7801;&#x5757;"/>
<node COLOR="#111111" CREATED="1501029613764" ID="ID_544264553" MODIFIED="1501029613764" TEXT="wait/notify&#x5fc5;&#x987b;&#x5b58;&#x5728;&#x4e8e;synchronized&#x5757;&#x4e2d;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1500552452090" ID="ID_1412380181" MODIFIED="1522216722421" TEXT="&#x5b88;&#x62a4;&#x7ebf;&#x7a0b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1500552471099" ID="ID_1859510238" MODIFIED="1500552482667" TEXT="&#x53ef;&#x4ee5;&#x901a;&#x8fc7;&#x7ebf;&#x7a0b;&#x5bf9;&#x8c61;.setDeamon(true)&#x6765;&#x8bb2;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x8bbe;&#x7f6e;&#x4e3a;&#x5b88;&#x62a4;&#x7ebf;&#x7a0b;&#x3002;&#x5b88;&#x62a4;&#x7ebf;&#x7a0b;&#x5c06;&#x4f5c;&#x4e3a;&#x670d;&#x52a1;&#x7ebf;&#x7a0b;&#x4e3a;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x63d0;&#x4f9b;&#x670d;&#x52a1;&#xff0c;&#x5f53;&#x7cfb;&#x7edf;&#x4e2d;&#x53ea;&#x5269;&#x4e0b;&#x5b88;&#x62a4;&#x7ebf;&#x7a0b;&#x7684;&#x65f6;&#x5019;&#xff0c;&#x865a;&#x62df;&#x673a;&#x5c31;&#x9000;&#x51fa;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473485459276" ID="ID_1423639057" MODIFIED="1522216746918">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Thread&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473485497891" FOLDED="true" ID="ID_1715388857" MODIFIED="1501123546969" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473485501523" ID="ID_1221186590" MODIFIED="1473485501523" TEXT="public Thread()"/>
<node COLOR="#111111" CREATED="1473485509975" ID="ID_967414152" MODIFIED="1473485509975" TEXT="public Thread(Runnable target)"/>
<node COLOR="#111111" CREATED="1473485523765" ID="ID_530453515" MODIFIED="1473485523765" TEXT="public Thread(String name)"/>
<node COLOR="#111111" CREATED="1473485533367" ID="ID_120640770" MODIFIED="1473485533367" TEXT="public Thread(Runnable target, String name)"/>
</node>
<node COLOR="#990000" CREATED="1473485562398" FOLDED="true" ID="ID_679944786" MODIFIED="1501144677834" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473485554499" ID="ID_1291459442" MODIFIED="1473485554499" TEXT="public static native Thread currentThread()"/>
<node COLOR="#111111" CREATED="1473485578554" ID="ID_1155485405" MODIFIED="1473485578554" TEXT="public static native void yield()"/>
<node COLOR="#111111" CREATED="1473485588071" ID="ID_696536498" MODIFIED="1473485588071" TEXT="public static native void sleep(long millis) throws InterruptedException"/>
<node COLOR="#111111" CREATED="1473485612753" ID="ID_1514989222" MODIFIED="1473485612753" TEXT="public synchronized void start()"/>
<node COLOR="#111111" CREATED="1473485648135" ID="ID_410047121" MODIFIED="1473485648135" TEXT="public void interrupt()"/>
<node COLOR="#111111" CREATED="1473485655247" ID="ID_1534664583" MODIFIED="1473485655247" TEXT="public static boolean interrupted()"/>
<node COLOR="#111111" CREATED="1473485660851" ID="ID_606684539" MODIFIED="1473485660851" TEXT="public boolean isInterrupted()"/>
<node COLOR="#111111" CREATED="1473485670243" ID="ID_1778526885" MODIFIED="1473485670243" TEXT="public final native boolean isAlive()"/>
<node COLOR="#111111" CREATED="1473485687074" ID="ID_329325914" MODIFIED="1473485687074" TEXT="public final native boolean isAlive()"/>
<node COLOR="#111111" CREATED="1473485696176" ID="ID_96450558" MODIFIED="1473485696176" TEXT="public final void setPriority(int newPriority)"/>
<node COLOR="#111111" CREATED="1473485704617" ID="ID_1648505284" MODIFIED="1473485704617" TEXT="public final int getPriority()"/>
<node COLOR="#111111" CREATED="1473485711388" ID="ID_943445392" MODIFIED="1473485711388" TEXT="public final synchronized void setName(String name)"/>
<node COLOR="#111111" CREATED="1473485720099" ID="ID_1638856128" MODIFIED="1473485720099" TEXT="public final String getName()"/>
<node COLOR="#111111" CREATED="1473485733341" ID="ID_1867226733" MODIFIED="1473485733341" TEXT="public final synchronized void join(long millis)"/>
<node COLOR="#111111" CREATED="1473485745631" ID="ID_624815743" MODIFIED="1473485745631" TEXT="public final void join() throws InterruptedException"/>
<node COLOR="#111111" CREATED="1473485758840" FOLDED="true" ID="ID_1019752592" MODIFIED="1501123546969" TEXT="public final void setDaemon(boolean on)">
<node COLOR="#111111" CREATED="1473485869859" ID="ID_995139976" MODIFIED="1473485881821" TEXT="&#x8bbe;&#x7f6e;&#x662f;&#x5426;&#x662f;&#x540e;&#x53f0;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#111111" CREATED="1473485765099" FOLDED="true" ID="ID_636120044" MODIFIED="1501123546969" TEXT="public final boolean isDaemon()">
<node COLOR="#111111" CREATED="1473485860159" ID="ID_40918030" MODIFIED="1473485867511" TEXT="&#x662f;&#x5426;&#x662f;&#x540e;&#x53f0;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#111111" CREATED="1473485818111" ID="ID_415549650" MODIFIED="1473485818111" TEXT="public long getId()"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472807281253" FOLDED="true" ID="ID_853659816" MODIFIED="1522220314593">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22914;&#20309;&#20351;&#29992;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472807296683" FOLDED="true" ID="ID_1861773574" MODIFIED="1501123546969" TEXT="&#x65b9;&#x6cd5;&#x4e00;&#xff1a;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472807317075" ID="ID_1624491713" MODIFIED="1472808147345" TEXT="&#x521b;&#x5efa;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#xff1a; Thread thread = new Thread()"/>
<node COLOR="#111111" CREATED="1472808127203" ID="ID_247097545" MODIFIED="1472808161355" TEXT="&#x7136;&#x540e;&#x8c03;&#x7528;: thread.start()"/>
</node>
<node COLOR="#990000" CREATED="1472807336163" FOLDED="true" ID="ID_40907470" MODIFIED="1501123546969" TEXT="&#x65b9;&#x6cd5;&#x4e8c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472807340365" ID="ID_1133865260" MODIFIED="1472807340365" TEXT="&#x5b9e;&#x73b0;Runnable&#x63a5;&#x53e3;&#x6765;&#x521b;&#x5efa;&#x7ebf;&#x7a0b;"/>
<node COLOR="#111111" CREATED="1472807490977" ID="ID_172014820" MODIFIED="1472807548919" TEXT="Runnable"/>
</node>
<node COLOR="#990000" CREATED="1473226957513" FOLDED="true" ID="ID_1484239031" MODIFIED="1501123546969">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="color: #990000; font-size: 116%; font-family: SansSerif, sans-serif"><font color="#990000" size="116%" face="SansSerif, sans-serif">&#26041;&#27861;&#19977;&#65306; &#32447;&#31243;&#27744;</font></span>
    </p>
    <p>
      ExecutorService
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473483668987" FOLDED="true" ID="ID_483230458" MODIFIED="1501123546969" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473483696174" ID="ID_1551202407" MODIFIED="1473483696175" TEXT="Executor&#x5c31;&#x662f;Runnable&#x548c;Callable&#x7684;&#x8c03;&#x5ea6;&#x5bb9;&#x5668;"/>
</node>
<node COLOR="#111111" CREATED="1473468171805" FOLDED="true" ID="ID_1872303005" MODIFIED="1501123546969" TEXT="&#x9759;&#x6001;&#x83b7;&#x53d6;&#x7ebf;&#x7a0b;&#x6c60;&#x7684;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473226977847" ID="ID_396630302" MODIFIED="1473226977847" TEXT="public static ExecutorService newFixedThreadPool(int nThreads)"/>
<node COLOR="#111111" CREATED="1473226993620" ID="ID_568825299" MODIFIED="1473226993620" TEXT="public static ExecutorService newCachedThreadPool()"/>
<node COLOR="#111111" CREATED="1473227002968" ID="ID_211908029" MODIFIED="1473227002968" TEXT="public static ExecutorService newSingleThreadExecutor()"/>
</node>
<node COLOR="#111111" CREATED="1473484080898" FOLDED="true" ID="ID_37279876" MODIFIED="1501123546969" TEXT="&#x76f8;&#x5173;&#x7c7b;">
<node COLOR="#111111" CREATED="1473483610186" FOLDED="true" ID="ID_525141141" MODIFIED="1501123546969" TEXT="Runnable">
<node COLOR="#111111" CREATED="1473483728210" ID="ID_1956555489" MODIFIED="1473483741330" TEXT="&#x6267;&#x884c;&#x5b8c;&#x6bd5;&#x53ea;&#x6709;&#x6ca1;&#x6709;&#x7ed3;&#x679c;&#x53ef;&#x4ee5;&#x8fd4;&#x56de;"/>
</node>
<node COLOR="#111111" CREATED="1473483622696" FOLDED="true" ID="ID_1088602324" MODIFIED="1501123546969" TEXT="Callable">
<node COLOR="#111111" CREATED="1473483747598" ID="ID_1627345105" MODIFIED="1501029254315" TEXT="&#x6267;&#x884c;&#x5b8c;&#x6bd5;&#x540e;&#x6709;&#x7ed3;&#x679c;&#x8fd4;&#x56de;"/>
</node>
<node COLOR="#111111" CREATED="1473483628796" FOLDED="true" ID="ID_38251575" MODIFIED="1501123546969" TEXT="Future">
<node COLOR="#111111" CREATED="1473484847974" FOLDED="true" ID="ID_317913004" MODIFIED="1501123546969" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473483716650" ID="ID_280729571" MODIFIED="1473484857246" TEXT=" &#x662f;&#x5bf9;&#x4e8e;&#x5177;&#x4f53;&#x7684;&#x8c03;&#x5ea6;&#x4efb;&#x52a1;&#x7684;&#x6267;&#x884c;&#x7ed3;&#x679c;&#x8fdb;&#x884c;&#x67e5;&#x770b;&#xff0c;&#x6700;&#x4e3a;&#x5173;&#x952e;&#x7684;&#x662f;Future&#x53ef;&#x4ee5;&#x68c0;&#x67e5;&#x5bf9;&#x5e94;&#x7684;&#x4efb;&#x52a1;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x5b8c;&#x6210;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x963b;&#x585e;&#x5728;get&#x65b9;&#x6cd5;&#x4e0a;&#x4e00;&#x76f4;&#x7b49;&#x5f85;&#x4efb;&#x52a1;&#x8fd4;&#x56de;&#x7ed3;&#x679c;"/>
</node>
<node COLOR="#111111" CREATED="1473484861694" FOLDED="true" ID="ID_741851673" MODIFIED="1501123546969" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473484871271" ID="ID_678143110" MODIFIED="1473484871271" TEXT="boolean cancel(boolean mayInterruptIfRunning)"/>
<node COLOR="#111111" CREATED="1473484883437" ID="ID_1803638655" MODIFIED="1473484883437" TEXT="boolean isCancelled()"/>
<node COLOR="#111111" CREATED="1473484889301" ID="ID_1882032675" MODIFIED="1473484889301" TEXT="boolean isDone()"/>
<node COLOR="#111111" CREATED="1473484897292" FOLDED="true" ID="ID_1094226942" MODIFIED="1501123546969" TEXT="V get() throws InterruptedException, ExecutionException">
<node COLOR="#111111" CREATED="1473484900590" ID="ID_1503884956" MODIFIED="1473484911982" TEXT="&#x83b7;&#x53d6;&#x6267;&#x884c;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x4f1a;&#x963b;&#x585e;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#111111" CREATED="1473484925258" FOLDED="true" ID="ID_1054029327" MODIFIED="1501123546969" TEXT="V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException">
<node COLOR="#111111" CREATED="1473484942657" ID="ID_793178000" MODIFIED="1473484953698" TEXT="&#x8bbe;&#x7f6e;&#x8d85;&#x65f6;&#x65f6;&#x95f4;&#xff0c;&#x4f1a;&#x963b;&#x585e;&#x7ebf;&#x7a0b;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473483634266" FOLDED="true" ID="ID_842161352" MODIFIED="1501123546969" TEXT="&#x5b50;&#x7c7b;FutureTask">
<node COLOR="#111111" CREATED="1473485067311" FOLDED="true" ID="ID_6428434" MODIFIED="1501123546969" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473483794650" ID="ID_665618983" MODIFIED="1473483813820" TEXT="&#x4e00;&#x4e2a;RunnableFuture&lt;V&gt;&#xff0c;&#x5373;&#x5b9e;&#x73b0;&#x4e86;Runnbale&#x53c8;&#x5b9e;&#x73b0;&#x4e86;Futrue&lt;V&gt;&#x8fd9;&#x4e24;&#x4e2a;&#x63a5;&#x53e3;&#xff0c;&#x53e6;&#x5916;&#x5b83;&#x8fd8;&#x53ef;&#x4ee5;&#x5305;&#x88c5;Runnable&#x548c;Callable&lt;V&gt;&#xff0c;&#x6240;&#x4ee5;&#x662f;&#x4e00;&#x4e2a;&#x590d;&#x5408;&#x4f53;&#xff0c;&#x5b83;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;Thread&#x5305;&#x88c5;&#x6765;&#x76f4;&#x63a5;&#x6267;&#x884c;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x63d0;&#x4ea4;&#x7ed9;ExecuteService&#x6765;&#x6267;&#x884c;"/>
</node>
<node COLOR="#111111" CREATED="1473485062191" FOLDED="true" ID="ID_393122239" MODIFIED="1501123546969" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1473485064983" ID="ID_1287768208" MODIFIED="1473485064983" TEXT="public FutureTask(Callable&lt;V&gt; callable)"/>
<node COLOR="#111111" CREATED="1473485079714" ID="ID_260454927" MODIFIED="1473485079714" TEXT="public FutureTask(Runnable runnable, V result)"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473484095578" FOLDED="true" ID="ID_773009448" MODIFIED="1501123546969" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473484111052" ID="ID_321129554" MODIFIED="1473484111052" TEXT="shutdown()"/>
<node COLOR="#111111" CREATED="1473484140240" ID="ID_1857868909" MODIFIED="1473484140240" TEXT="List&lt;Runnable&gt; shutdownNow();"/>
<node COLOR="#111111" CREATED="1473484245477" ID="ID_1689629876" MODIFIED="1473484245477" TEXT="boolean isShutdown()"/>
<node COLOR="#111111" CREATED="1473484252576" FOLDED="true" ID="ID_446529950" MODIFIED="1501123546969" TEXT="boolean isTerminated()">
<node COLOR="#111111" CREATED="1474332167276" ID="ID_1516752661" MODIFIED="1474332176838" TEXT="&#x4efb;&#x52a1;&#x5b8c;&#x6210;"/>
</node>
<node COLOR="#111111" CREATED="1473484339767" ID="ID_640857987" MODIFIED="1473484339767" TEXT="boolean awaitTermination(long timeout, TimeUnit unit)"/>
<node COLOR="#111111" CREATED="1473484384398" ID="ID_573238715" MODIFIED="1473484384398" TEXT="&lt;T&gt; Future&lt;T&gt; submit(Callable&lt;T&gt; task)"/>
<node COLOR="#111111" CREATED="1473484390793" ID="ID_1994304972" MODIFIED="1473484423688" TEXT="&lt;T&gt; Future&lt;T&gt; submit(Runnable task, T result)"/>
<node COLOR="#111111" CREATED="1473484417088" ID="ID_237540357" MODIFIED="1473484498427" TEXT="Future&lt;?&gt; submit(Runnable task)">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1473491489652" ID="ID_1330248771" MODIFIED="1473491611336" TEXT="void execute(Runnable task)">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1501077722986" ID="ID_469896466" MODIFIED="1522213547384" TEXT="&#x7ebf;&#x7a0b;&#x540c;&#x6b65;&#x7684;&#x4e09;&#x79cd;&#x65b9;&#x5f0f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1501077733576" ID="ID_363251625" MODIFIED="1522213552741" TEXT="synchronized">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1501077763680" ID="ID_361861635" MODIFIED="1501077769058" TEXT="&#x540c;&#x6b65;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1501077769376" ID="ID_1673859542" LINK="demo/BankSyschonizedBlock.java" MODIFIED="1522213575169" TEXT="&#x540c;&#x6b65;&#x4ee3;&#x7801;&#x5757;"/>
</node>
<node COLOR="#990000" CREATED="1501077774058" ID="ID_1216808487" MODIFIED="1522213550186" TEXT="&#x9501;Lock">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1501077787898" ID="ID_204567938" LINK="demo/BankReentrantLock.java" MODIFIED="1522213584330">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ReentrantLock&#37325;&#20837;&#38145;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1501077792053" ID="ID_1288994290" LINK="demo/BankSemaphore.java" MODIFIED="1522214146204" TEXT="&#x4fe1;&#x53f7;&#x91cf;Semaphore">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
