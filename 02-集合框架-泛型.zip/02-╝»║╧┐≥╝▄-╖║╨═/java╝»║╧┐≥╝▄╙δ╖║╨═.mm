<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1473598684756" ID="294fem0ichl6ofjb1vh7l4nkk3" LINK="http://www.cnblogs.com/xiohao/p/4309462.html" MODIFIED="1497582684797" TEXT="&#x96c6;&#x5408;&#x6846;&#x67b6;&#x4e0e;&#x6cdb;&#x578b;">
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1473598684779" FOLDED="true" ID="6ap52joickh92jrgjfn4rhkkqq" MODIFIED="1497582684765" POSITION="left" TEXT="Iterator">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684780" FOLDED="true" ID="4vgu21igsnnqgavu5tbr1g0a37" MODIFIED="1497582684765" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684780" ID="6gorklv13k03b3c4dov28p92h9" MODIFIED="1473598715062" TEXT="&#x8fed;&#x4ee3;&#x5668;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684780" ID="3u12ch0eu460u4lj8sfuqduq27" MODIFIED="1473598715062" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x63a5;&#x53e3;&#x7c7b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684780" ID="7ovmvv8lqku2k3ugrsf6o2ehfv" MODIFIED="1473598715062" TEXT="&#x7528;&#x6765;&#x8bbf;&#x95ee;&#x96c6;&#x5408;&#x4e2d;&#x7684;&#x5143;&#x7d20;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684780" ID="643j9f0g429ajb81p1l95fsg8s" MODIFIED="1473598715063" TEXT="&#x76f8;&#x5f53;&#x4e8e;&#x6570;&#x636e;&#x5e93;&#x4e2d;&#x7684;&#x6e38;&#x6807;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684780" ID="0ckj4v23rgul1au4jt2dj7820a" MODIFIED="1473598715063" TEXT="&#x901a;&#x5e38;&#x548c;foreach&#x3001;while&#x5faa;&#x73af;&#x8bed;&#x53e5;&#x4f7f;&#x7528;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684780" ID="2bi8ro6q0jds5nupc48j5gof42" MODIFIED="1473598715064" TEXT="&#x4efb;&#x4f55;&#x5b9e;&#x73b0;&#x4e86;Iterable&#x63a5;&#x53e3;&#x7684;&#x7c7b;&#x90fd;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;foreach     p241">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684780" FOLDED="true" ID="5bcfup40vobibdg4v8k633g563" MODIFIED="1497582684765" TEXT="&#x5b50;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684780" FOLDED="true" ID="66blbv6f5nopojhn2p2aefjg79" MODIFIED="1497582684765" TEXT="ListIterator">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684780" FOLDED="true" ID="7cqca1esevngv518fgovufiolk" MODIFIED="1497582684765" TEXT="?">
<node COLOR="#111111" CREATED="1473598684780" ID="35k439tevm79267d8q0q9bkjn4" MODIFIED="1473598715065" TEXT="&#x7ee7;&#x627f;&#x81ea;Iterator"/>
<node COLOR="#111111" CREATED="1473598684780" ID="72jv1dbakobg9otitq0t5igc0k" MODIFIED="1473598715065" TEXT="&#x53ef;&#x4ee5;&#x53cc;&#x5411;&#x8bbf;&#x95ee;&#x96c6;&#x5408;&#x4e2d;&#x7684;&#x6570;&#x636e;"/>
</node>
<node COLOR="#111111" CREATED="1473598684780" FOLDED="true" ID="5hrrd2gqlfd1shl93l13b76o1c" MODIFIED="1497582684765" TEXT="&#x5e38;&#x7528;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473598684780" ID="1cj7qae8cruh515ahtc2ni2mp9" MODIFIED="1473598715065" TEXT="boolean hasNext()"/>
<node COLOR="#111111" CREATED="1473598684780" ID="3ik2pv36vb0sn1alk211c9c9an" MODIFIED="1473598715066" TEXT="E next()"/>
<node COLOR="#111111" CREATED="1473598684780" ID="2p5i3coacghtm6qqjiibkq5r37" MODIFIED="1473598715070" TEXT="void remove()"/>
<node COLOR="#111111" CREATED="1473598684781" ID="528uk5bhd1v7hlun0tmn5tajve" MODIFIED="1473598715070" TEXT="boolean hasPrevious()"/>
<node COLOR="#111111" CREATED="1473598684781" ID="3e9dqikuhbo4sc8vhh9b0962jd" MODIFIED="1473598715071" TEXT="E previous()"/>
<node COLOR="#111111" CREATED="1473598684781" FOLDED="true" ID="7h3m8oe0kl8c7thgepokijq9qa" MODIFIED="1497582684765" TEXT="void set(E e)">
<node COLOR="#111111" CREATED="1473598684781" ID="3553d1nc4jlua5270nvdtu7q7j" MODIFIED="1473598715071" TEXT="&#x66ff;&#x6362;&#x96c6;&#x5408;&#x4e2d;&#x7684;&#x67d0;&#x4e2a;&#x5143;&#x7d20;"/>
</node>
<node COLOR="#111111" CREATED="1473598684781" FOLDED="true" ID="2072o8d465euir7s8ulshl6n4t" MODIFIED="1497582684765" TEXT="void add(E e);">
<node COLOR="#111111" CREATED="1473598684781" ID="58nslujj2qm54e42891lk7aib0" MODIFIED="1473598715071" TEXT="&#x5411;&#x96c6;&#x5408;&#x4e2d;&#x6dfb;&#x52a0;&#x4e00;&#x4e2a;&#x5143;&#x7d20;"/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684781" FOLDED="true" ID="1656i0mkbhd6dvhrdc7j1ksim6" MODIFIED="1497582684765" TEXT="&#x5e38;&#x7528;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684781" ID="4q6ads7c86g8d5hfhn1lchqndr" MODIFIED="1473598715072" TEXT="boolean hasNext()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684781" ID="3egc71qil4a4bg7lg0vf45n6rt" MODIFIED="1473598715072" TEXT="E next()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684781" ID="0eua7lpa199s4iljtkj4hao5o8" MODIFIED="1473598715072" TEXT="void remove()">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684781" FOLDED="true" ID="4n5ic009qponvg7faj5ksuv066" MODIFIED="1497582684765" POSITION="left" TEXT="Entry">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684781" ID="6en272vn8a40sdvbnokoe0oid4" MODIFIED="1473598715077" TEXT="A map entry (key-value pair). &#x4e5f;&#x5c31;&#x662f;key - value&#x5bf9;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473598684781" ID="2jfsumhdh93tt7pk1d9fh2nsgo" MODIFIED="1473598715079" TEXT="&#x662f;&#x6811;&#x7ed3;&#x6784;&#x7684;&#x8282;&#x70b9;Node">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473598684781" FOLDED="true" ID="0laoaj7nuub5gpfevhhuimq384" MODIFIED="1497582684765" TEXT="&#x5e38;&#x7528;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684781" ID="087o60upsf7resdjm7kn8ld8kq" MODIFIED="1473598715079" TEXT="K getKey();">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684781" ID="0l90quo94gca2877bm3af86pjl" MODIFIED="1473598715080" TEXT="V getValue();">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684782" FOLDED="true" ID="64tkp60b19nb567uf5vgh0gddm" LINK="http://blog.csdn.net/tjcyjd/article/details/11111401" MODIFIED="1497582684765" POSITION="left" TEXT="&#x96c6;&#x5408;&#x7684;&#x904d;&#x5386;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684782" FOLDED="true" ID="3irsrp825871n97g7nkbocmn06" MODIFIED="1497582684765" TEXT="map">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684799" ID="5b2chc6d8i2u4r7f9p2eom31mh" MODIFIED="1473598715084" TEXT="for (Map.Entry&lt;Integer, Integer&gt; entry : map.entrySet()) {  }">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="full-1"/>
</node>
<node COLOR="#990000" CREATED="1473598684799" ID="1aft8hahjiba5hpoghn6fjnpo8" MODIFIED="1473598715098" TEXT="Iterator&lt;Map.Entry&lt;Integer, Integer&gt;&gt; it = map.entrySet().iterator();   &#xd;&#xa;        while (entries.hasNext()) {  &#xd;&#xa;    Map.Entry&lt;Integer, Integer&gt; entry = it.next();  &#xd;&#xa;  System.out.println(&quot;Key = &quot; + entry.getKey() + &quot;, Value = &quot; + entry.getValue());  &#xd;&#xa;  }  ">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="full-3"/>
</node>
<node COLOR="#990000" CREATED="1473598684799" ID="161g6s5jv1gbhtbgrk42elv5r0" MODIFIED="1473598715112" TEXT="for (Integer key : map.keySet()) {  }">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="full-2"/>
</node>
<node COLOR="#990000" CREATED="1473598684799" ID="34gu8uhamlol9r8ibo3kt6pgq3" MODIFIED="1473598715123" TEXT="Iterator&lt;Integer&gt; iterator = keySet.iterator();&#xd;&#xa;        while (iterator.hasNext()) {&#xd;&#xa;            int key = iterator.next();&#xd;&#xa;            System.out.println(&quot;key= &quot;+key+&quot;  value=&quot;+mMap.get(key));&#xd;&#xa;        }">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="full-4"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684799" FOLDED="true" ID="7rfirt2a1q654g47sf8ql376n9" MODIFIED="1497582684765" TEXT="set">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684799" ID="71pfgf3l5394fhpane054nip57" MODIFIED="1473598715175" TEXT=" for (Integer in: set) {&#xd;&#xa;            System.out.println(in);&#xd;&#xa;        }">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684799" ID="3cbfnipa7uch8nn6gfa8q5b2fb" MODIFIED="1473598715223" TEXT=" while (iterator.hasNext()) {&#xd;&#xa;            System.out.println(iterator.next());&#xd;&#xa;        }">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684799" FOLDED="true" ID="14bc8mjj6cpbeeukbul8n35v2d" MODIFIED="1497582684765" TEXT="list">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684800" ID="6uh0seo5vls8jt4qg38r2ai03o" MODIFIED="1473598715240" TEXT="      Iterator it = list.iterator();&#xd;&#xa;        while (it.hasNext()) {&#xd;&#xa;            System.out.println(it.next());&#xd;&#xa;        }">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684800" ID="098hrinlblkiao1r8h4qo7s3e9" MODIFIED="1473598715262" TEXT="for (Integer in : list&#xd;&#xa;             ) {&#xd;&#xa;            System.out.println(in);&#xd;&#xa;        }">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684800" ID="4n9cr702dq1d9pk3078rllf0g3" MODIFIED="1473598715275" TEXT=" Iterator it = list.iterator();    &#xd;&#xa;while (iterator.hasNext()) {&#xd;&#xa;            System.out.println(iterator.next());&#xd;&#xa;        }">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684800" FOLDED="true" ID="270b5nhinvuksgdqeu1a15jug9" MODIFIED="1497582684765" TEXT="&#x6ce8;&#x610f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684800" ID="1vv5088ttt9on1gosdj5u2menk" MODIFIED="1473598715283" TEXT="&#x904d;&#x5386;&#x8fc7;&#x7a0b;&#x4e2d;&#x79fb;&#x9664;&#x67d0;&#x4e2a;&#x5143;&#x7d20;&#x53ea;&#x80fd;&#x4f7f;&#x7528; iterator&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1495165508238" ID="ID_1166150563" MODIFIED="1517311609254" POSITION="right" TEXT="&#x5de5;&#x5177;&#x7c7b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1495165514509" FOLDED="true" ID="ID_732655617" MODIFIED="1497582684781" TEXT="Arrays">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495198763428" FOLDED="true" ID="ID_1618263577" MODIFIED="1497582684765" TEXT="&#x53cc;&#x8f74;&#x5feb;&#x901f;&#x6392;&#x5e8f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495198767270" ID="ID_612595910" MODIFIED="1495198767270" TEXT="public static void sort(int[] a)"/>
<node COLOR="#111111" CREATED="1495198767270" ID="ID_1726183418" MODIFIED="1495198767271" TEXT="public static void sort(int[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198767271" ID="ID_1717018524" MODIFIED="1495198767271" TEXT="public static void sort(long[] a)"/>
<node COLOR="#111111" CREATED="1495198767272" ID="ID_266775301" MODIFIED="1495198767272" TEXT="public static void sort(long[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198767272" ID="ID_1034222910" MODIFIED="1495198767272" TEXT="public static void sort(short[] a)"/>
<node COLOR="#111111" CREATED="1495198767273" ID="ID_1275296900" MODIFIED="1495198767273" TEXT="public static void sort(short[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198767273" ID="ID_1975695011" MODIFIED="1495198767273" TEXT="public static void sort(char[] a)"/>
<node COLOR="#111111" CREATED="1495198767274" ID="ID_575429923" MODIFIED="1495198767274" TEXT="public static void sort(char[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198767274" ID="ID_29564124" MODIFIED="1495198767274" TEXT="public static void sort(byte[] a)"/>
<node COLOR="#111111" CREATED="1495198767275" ID="ID_1429375114" MODIFIED="1495198767275" TEXT="public static void sort(byte[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198767276" ID="ID_1029548477" MODIFIED="1495198767276" TEXT="public static void sort(float[] a)"/>
<node COLOR="#111111" CREATED="1495198767277" ID="ID_632832869" MODIFIED="1495198767277" TEXT="public static void sort(float[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198767278" ID="ID_1932993034" MODIFIED="1495198767278" TEXT="public static void sort(double[] a)"/>
<node COLOR="#111111" CREATED="1495198767279" ID="ID_1956391333" MODIFIED="1495198767279" TEXT="public static void sort(double[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495199236994" FOLDED="true" ID="ID_937711951" MODIFIED="1497582684765">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21407;&#29702;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495199241439" FOLDED="true" ID="ID_785887321" LINK="http://blog.csdn.net/u010786672/article/details/42580899" MODIFIED="1497582684765" TEXT="&#x4ee5;&#x4e0a;&#x90fd;&#x662f;&#x53cc;&#x652f;&#x70b9;&#x5feb;&#x901f;&#x6392;&#x5e8f;&#x7b97;&#x6cd5;">
<node COLOR="#111111" CREATED="1495199292580" ID="ID_1386438847" MODIFIED="1495199292581" TEXT="&#x5e38;&#x7528;&#x7684;&#x5feb;&#x6392;&#x7b97;&#x6cd5;&#x662f;&#x4ece;&#x6570;&#x7ec4;&#x7684;left&#x3001;right&#x4ee5;&#x53ca;center&#x4e09;&#x4e2a;&#x6570;&#x4e2d;&#x9009;&#x62e9;&#x4e00;&#x4e2a;pivot&#xff0c;&#x7136;&#x540e;&#x5728;&#x5feb;&#x6392;&#x3002;&#x800c;DualPivotQuicksort&#x4f7f;&#x7528;&#x4e86;&#x4e24;&#x4e2a;pivot&#x52a0;&#x901f;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199306043" FOLDED="true" ID="ID_1313382490" MODIFIED="1497582684765" TEXT="&#x7b97;&#x6cd5;&#x6b65;&#x9aa4;">
<node COLOR="#111111" CREATED="1495199311616" ID="ID_1975682281" MODIFIED="1495199311616" TEXT="1) &#x9009;&#x62e9;&#x4e24;&#x4e2a;&#x70b9;&#x4f5c;&#x4e3a;&#x8f74;&#x5fc3;,P1,P2&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311618" FOLDED="true" ID="ID_991758989" MODIFIED="1497582684765" TEXT="2)P1&#x5fc5;&#x987b;&#x6bd4;P2&#x8981;&#x5c0f;&#xff0c;&#x73b0;&#x5728;&#x5c06;&#x6574;&#x4e2a;&#x6570;&#x7ec4;&#x5206;&#x4e3a;&#x56db;&#x90e8;&#x5206;&#xff1a;">
<node COLOR="#111111" CREATED="1495199311619" ID="ID_147623954" MODIFIED="1495199311619" TEXT="&#xff08;1&#xff09;&#x7b2c;&#x4e00;&#x90e8;&#x5206;&#xff1a;&#x6bd4;P1&#x5c0f;&#x7684;&#x5143;&#x7d20;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311620" ID="ID_1197779291" MODIFIED="1495199311620" TEXT="&#xff08;2&#xff09;&#x7b2c;&#x4e8c;&#x90e8;&#x5206;&#xff1a;&#x6bd4;P1&#x5927;&#x4f46;&#x662f;&#x6bd4;P2&#x5c0f;&#x7684;&#x5143;&#x7d20;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311623" ID="ID_649771691" MODIFIED="1495199311623" TEXT="&#xff08;3&#xff09;&#x7b2c;&#x4e09;&#x90e8;&#x5206;&#xff1a;&#x6bd4;P2&#x5927;&#x7684;&#x5143;&#x7d20;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311626" FOLDED="true" ID="ID_1570945827" MODIFIED="1497582684765" TEXT="&#xff08;4&#xff09;&#x7b2c;&#x56db;&#x90e8;&#x5206;&#xff1a;&#x5f85;&#x6bd4;&#x8f83;&#x7684;&#x90e8;&#x5206;&#x3002;">
<node COLOR="#111111" CREATED="1495199311627" ID="ID_790929509" MODIFIED="1495199311627" TEXT="&#x5728;&#x5f00;&#x59cb;&#x6bd4;&#x8f83;&#x524d;&#xff0c;&#x9664;&#x4e86;&#x8f74;&#x70b9;&#xff0c;&#x5176;&#x4f59;&#x5143;&#x7d20;&#x51e0;&#x4e4e;&#x90fd;&#x5728;&#x7b2c;&#x56db;&#x90e8;&#x5206;&#xff0c;&#x76f4;&#x5230;&#x6bd4;&#x8f83;&#x5b8c;&#x4e4b;&#x540e;&#x7b2c;&#x56db;&#x90e8;&#x5206;&#x6ca1;&#x6709;&#x5143;&#x7d20;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495199311628" ID="ID_1804174366" MODIFIED="1495199311629" TEXT="3&#xff09;.&#x4ece;&#x7b2c;&#x56db;&#x90e8;&#x5206;&#x9009;&#x51fa;&#x4e00;&#x4e2a;&#x5143;&#x7d20;a[K]&#xff0c;&#x4e0e;&#x4e24;&#x4e2a;&#x8f74;&#x5fc3;&#x6bd4;&#x8f83;&#xff0c;&#x7136;&#x540e;&#x653e;&#x5230;&#x7b2c;&#x4e00;&#x4e8c;&#x4e09;&#x90e8;&#x5206;&#x4e2d;&#x7684;&#x4e00;&#x4e2a;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311631" ID="ID_978271301" MODIFIED="1495199311631" TEXT="4&#xff09;.&#x79fb;&#x52a8;L&#xff0c;K&#xff0c;G&#x6307;&#x5411;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311634" ID="ID_67120707" MODIFIED="1495199311634" TEXT="5&#xff09;.&#x91cd;&#x590d; 3&#xff09;&#x548c;4&#xff09; &#x6b65;&#xff0c;&#x76f4;&#x5230;&#x7b2c;&#x56db;&#x90e8;&#x5206;&#x4e3a;&#x7a7a;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311640" ID="ID_576159821" MODIFIED="1495199311641" TEXT="6&#xff09;.&#x5c06;P1&#x4e0e;&#x7b2c;&#x4e00;&#x90e8;&#x5206;&#x7684;&#x6700;&#x540e;&#x4e00;&#x4e2a;&#x5143;&#x7d20;&#x4ea4;&#x6362;&#x3002;&#x5c06;P2&#x4e0e;&#x7b2c;&#x4e09;&#x90e8;&#x5206;&#x7684;&#x7b2c;&#x4e00;&#x4e2a;&#x5143;&#x7d20;&#x4ea4;&#x6362;&#x3002;"/>
<node COLOR="#111111" CREATED="1495199311641" ID="ID_312020384" MODIFIED="1495199311641" TEXT="7&#xff09;.&#x9012;&#x5f52;&#x7684;&#x5c06;&#x7b2c;&#x4e00;&#x4e8c;&#x4e09;&#x90e8;&#x5206;&#x6392;&#x5e8f;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495199694248" ID="ID_1396020713" MODIFIED="1495199698815" TEXT="&#x90fd;&#x662f;&#x5347;&#x5e8f;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495198818323" FOLDED="true" ID="ID_1602103158" MODIFIED="1497582684765">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;parallelSort&#24182;&#34892;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495198847970" ID="ID_1960432742" MODIFIED="1495198847970" TEXT="public static void parallelSort(byte[] a)"/>
<node COLOR="#111111" CREATED="1495198847971" ID="ID_1057704249" MODIFIED="1495198847971" TEXT="public static void parallelSort(byte[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198847972" ID="ID_122496200" MODIFIED="1495198847973" TEXT="public static void parallelSort(char[] a)"/>
<node COLOR="#111111" CREATED="1495198847974" ID="ID_539927349" MODIFIED="1495198847974" TEXT="public static void parallelSort(char[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198847975" ID="ID_1666330020" MODIFIED="1495198847975" TEXT="public static void parallelSort(short[] a)"/>
<node COLOR="#111111" CREATED="1495198847976" ID="ID_267543966" MODIFIED="1495198847976" TEXT="public static void parallelSort(short[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198847979" ID="ID_1662242569" MODIFIED="1495198847979" TEXT="public static void parallelSort(int[] a)"/>
<node COLOR="#111111" CREATED="1495198847985" ID="ID_884623116" MODIFIED="1495198847985" TEXT="public static void parallelSort(int[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198847986" ID="ID_1795666223" MODIFIED="1495198847986" TEXT="public static void parallelSort(long[] a)"/>
<node COLOR="#111111" CREATED="1495198847987" ID="ID_1115755578" MODIFIED="1495198847987" TEXT="public static void parallelSort(long[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198847988" ID="ID_1330983055" MODIFIED="1495198847988" TEXT="public static void parallelSort(float[] a)"/>
<node COLOR="#111111" CREATED="1495198847989" ID="ID_1380908591" MODIFIED="1495198847989" TEXT="public static void parallelSort(float[] a, int fromIndex, int toIndex)"/>
<node COLOR="#111111" CREATED="1495198847990" ID="ID_192457558" MODIFIED="1495198847990" TEXT="public static void parallelSort(double[] a)"/>
<node COLOR="#111111" CREATED="1495198847991" ID="ID_1221448358" MODIFIED="1495198847991" TEXT="public static void parallelSort(double[] a, int fromIndex, int toIndex)"/>
</node>
<node COLOR="#990000" CREATED="1495200194460" FOLDED="true" ID="ID_1232413587" MODIFIED="1497582684765" TEXT="&#x4e8c;&#x5206;&#x67e5;&#x627e;&#x7b97;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200205119" ID="ID_1292368449" MODIFIED="1495200205119" TEXT="public static int binarySearch(long[] a, long key)"/>
<node COLOR="#111111" CREATED="1495200205121" ID="ID_1080256353" MODIFIED="1495200205121" TEXT="public static int binarySearch(int[] a, int key)"/>
<node COLOR="#111111" CREATED="1495200205122" ID="ID_1938944591" MODIFIED="1495200205122" TEXT="public static int binarySearch(short[] a, short key)"/>
<node COLOR="#111111" CREATED="1495200205128" ID="ID_855351338" MODIFIED="1495200205128" TEXT="public static int binarySearch(char[] a, char key)"/>
<node COLOR="#111111" CREATED="1495200205129" ID="ID_1900648881" MODIFIED="1495200205129" TEXT="public static int binarySearch(byte[] a, byte key)"/>
<node COLOR="#111111" CREATED="1495200205130" ID="ID_1793111604" MODIFIED="1495200205131" TEXT="public static int binarySearch(double[] a, double key)"/>
<node COLOR="#111111" CREATED="1495200205132" ID="ID_1118770989" MODIFIED="1495200205132" TEXT="public static int binarySearch(float[] a, float key)"/>
<node COLOR="#111111" CREATED="1495200205133" ID="ID_1612861554" MODIFIED="1495200205133" TEXT="public static int binarySearch(Object[] a, Object key)"/>
<node COLOR="#111111" CREATED="1495200217826" ID="ID_1635118911" MODIFIED="1495200217827" TEXT="public static &lt;T&gt; int binarySearch(T[] a, T key, Comparator&lt;? super T&gt; c)"/>
</node>
<node COLOR="#990000" CREATED="1495200234137" FOLDED="true" ID="ID_1984677404" MODIFIED="1497582684765" TEXT="&#x5224;&#x65ad;&#x4e24;&#x4e2a;&#x6570;&#x7ec4;&#x4e2d;&#x7684;&#x503c;&#x662f;&#x5426;&#x76f8;&#x540c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200253216" ID="ID_431118938" MODIFIED="1495200253216" TEXT="public static boolean equals(long[] a, long[] a2)"/>
<node COLOR="#111111" CREATED="1495200253218" ID="ID_193166323" MODIFIED="1495200253218" TEXT="public static boolean equals(int[] a, int[] a2)"/>
<node COLOR="#111111" CREATED="1495200253225" ID="ID_100167199" MODIFIED="1495200253225" TEXT="public static boolean equals(short[] a, short a2[])"/>
<node COLOR="#111111" CREATED="1495200253226" ID="ID_595112591" MODIFIED="1495200253226" TEXT="public static boolean equals(char[] a, char[] a2)"/>
<node COLOR="#111111" CREATED="1495200253226" ID="ID_536507711" MODIFIED="1495200253227" TEXT="public static boolean equals(byte[] a, byte[] a2)"/>
<node COLOR="#111111" CREATED="1495200253235" ID="ID_684919579" MODIFIED="1495200253235" TEXT="public static boolean equals(boolean[] a, boolean[] a2)"/>
<node COLOR="#111111" CREATED="1495200253236" ID="ID_1481322464" MODIFIED="1495200253236" TEXT="public static boolean equals(double[] a, double[] a2)"/>
<node COLOR="#111111" CREATED="1495200253237" ID="ID_1542726656" MODIFIED="1495200253237" TEXT="public static boolean equals(float[] a, float[] a2)"/>
<node COLOR="#111111" CREATED="1495200253238" ID="ID_445270314" MODIFIED="1495200253238" TEXT="public static boolean equals(Object[] a, Object[] a2)"/>
</node>
<node COLOR="#990000" CREATED="1495200326514" FOLDED="true" ID="ID_1980381222" MODIFIED="1497582684765" TEXT="&#x66ff;&#x6362;&#x6570;&#x7ec4;&#x4e2d;&#x7684;&#x503c;(&#x5168;&#x90e8;&#x6216;&#x90e8;&#x5206;)&#x4e3a;&#x67d0;&#x4e2a;&#x503c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200334120" FOLDED="true" ID="ID_681834649" MODIFIED="1497582684765" TEXT="public static void fill(long[] a, long val)">
<node COLOR="#111111" CREATED="1495200390222" ID="ID_628252841" MODIFIED="1495200393190" TEXT="&#x5168;&#x90e8;&#x66ff;&#x6362;"/>
</node>
<node COLOR="#111111" CREATED="1495200334121" FOLDED="true" ID="ID_1420704682" MODIFIED="1497582684765" TEXT="public static void fill(long[] a, int fromIndex, int toIndex, long val)">
<node COLOR="#111111" CREATED="1495200383086" ID="ID_570763463" MODIFIED="1495200387902" TEXT="&#x90e8;&#x5206;&#x66ff;&#x6362;"/>
<node COLOR="#111111" CREATED="1495200400428" FOLDED="true" ID="ID_741081432" MODIFIED="1497582684765" TEXT="fromIndex">
<node COLOR="#111111" CREATED="1495200413542" ID="ID_1434014347" MODIFIED="1495200415811" TEXT="&#x5f00;&#x59cb;&#x4f4d;&#x7f6e;"/>
</node>
<node COLOR="#111111" CREATED="1495200404031" FOLDED="true" ID="ID_1414968625" MODIFIED="1497582684765" TEXT="toIndex">
<node COLOR="#111111" CREATED="1495200407397" ID="ID_1645804135" MODIFIED="1495200411725" TEXT="&#x7ed3;&#x675f;&#x4f4d;&#x7f6e;"/>
</node>
<node COLOR="#111111" CREATED="1495200418706" FOLDED="true" ID="ID_1338928844" MODIFIED="1497582684765" TEXT="val">
<node COLOR="#111111" CREATED="1495200420984" ID="ID_879399188" MODIFIED="1495200424496" TEXT="&#x65b0;&#x7684;&#x503c;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495200334122" ID="ID_1991067358" MODIFIED="1495200334123" TEXT="public static void fill(int[] a, int val)"/>
<node COLOR="#111111" CREATED="1495200334124" ID="ID_204411306" MODIFIED="1495200334124" TEXT="public static void fill(int[] a, int fromIndex, int toIndex, int val)"/>
<node COLOR="#111111" CREATED="1495200334125" ID="ID_1460616956" MODIFIED="1495200334125" TEXT="public static void fill(short[] a, short val)"/>
<node COLOR="#111111" CREATED="1495200334132" ID="ID_700958671" MODIFIED="1495200334132" TEXT="public static void fill(short[] a, int fromIndex, int toIndex, short val)"/>
<node COLOR="#111111" CREATED="1495200334134" ID="ID_655047993" MODIFIED="1495200334134" TEXT="public static void fill(char[] a, char val)"/>
<node COLOR="#111111" CREATED="1495200334137" ID="ID_458242079" MODIFIED="1495200334137" TEXT="public static void fill(char[] a, int fromIndex, int toIndex, char val)"/>
<node COLOR="#111111" CREATED="1495200334138" ID="ID_1472041837" MODIFIED="1495200334138" TEXT="public static void fill(byte[] a, byte val)"/>
<node COLOR="#111111" CREATED="1495200334139" ID="ID_962169650" MODIFIED="1495200334139" TEXT="public static void fill(byte[] a, int fromIndex, int toIndex, byte val)"/>
<node COLOR="#111111" CREATED="1495200334140" ID="ID_1344514680" MODIFIED="1495200334140" TEXT="public static void fill(boolean[] a, boolean val)"/>
<node COLOR="#111111" CREATED="1495200334141" ID="ID_825377028" MODIFIED="1495200334141" TEXT="public static void fill(double[] a, double val)"/>
<node COLOR="#111111" CREATED="1495200334142" ID="ID_1145874815" MODIFIED="1495200334142" TEXT="public static void fill(double[] a, int fromIndex, int toIndex,double val)"/>
<node COLOR="#111111" CREATED="1495200334143" ID="ID_140339268" MODIFIED="1495200334143" TEXT="public static void fill(float[] a, float val)"/>
<node COLOR="#111111" CREATED="1495200334144" ID="ID_1976540648" MODIFIED="1495200334144" TEXT="public static void fill(float[] a, int fromIndex, int toIndex, float val)"/>
<node COLOR="#111111" CREATED="1495200334145" ID="ID_803025970" MODIFIED="1495200334145" TEXT="public static void fill(Object[] a, Object val)"/>
<node COLOR="#111111" CREATED="1495200334146" ID="ID_1371509139" MODIFIED="1495200334146" TEXT="public static void fill(Object[] a, int fromIndex, int toIndex, Object val)"/>
</node>
<node COLOR="#990000" CREATED="1495200562695" FOLDED="true" ID="ID_1648850362" MODIFIED="1497582684781" TEXT="&#x62f7;&#x8d1d;&#x67d0;&#x4e2a;&#x957f;&#x5ea6;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200583587" FOLDED="true" ID="ID_1121190907" MODIFIED="1497582684765" TEXT="public static &lt;T&gt; T[] copyOf(T[] original, int newLength)">
<node COLOR="#111111" CREATED="1495200657932" FOLDED="true" ID="ID_305292829" MODIFIED="1497582684765">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495200620792" ID="ID_1167017881" MODIFIED="1495200656680" TEXT="&#x628a;&#x539f;&#x6570;&#x7ec4;&#x4e2d;&#x7684;&#x5143;&#x7d20;&#x4ece; 0&#x4e0b;&#x6807;&#x5f00;&#x59cb;,&#x62f7;&#x8d1d;newLength&#x4e2a;&#x5230;&#x65b0;&#x7684;&#x6570;&#x7ec4;&#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1495200592583" FOLDED="true" ID="ID_169695663" MODIFIED="1497582684765" TEXT="orginal">
<node COLOR="#111111" CREATED="1495200596372" ID="ID_1286469042" MODIFIED="1495200600359" TEXT="&#x539f;&#x59cb;&#x7684;&#x6570;&#x7ec4;"/>
</node>
<node COLOR="#111111" CREATED="1495200602084" FOLDED="true" ID="ID_1061888290" MODIFIED="1497582684765" TEXT="newLength">
<node COLOR="#111111" CREATED="1495200606027" ID="ID_1837909323" MODIFIED="1495200620333" TEXT="&#x65b0;&#x6570;&#x7ec4;&#x7684;&#x957f;&#x5ea6;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495200583597" ID="ID_993483335" MODIFIED="1495200583597" TEXT="public static &lt;T,U&gt; T[] copyOf(U[] original, int newLength, Class&lt;? extends T[]&gt; newType)"/>
<node COLOR="#111111" CREATED="1495200583597" ID="ID_602794095" MODIFIED="1495200583598" TEXT="public static byte[] copyOf(byte[] original, int newLength)"/>
<node COLOR="#111111" CREATED="1495200583598" ID="ID_150736469" MODIFIED="1495200583598" TEXT="public static short[] copyOf(short[] original, int newLength)"/>
<node COLOR="#111111" CREATED="1495200583599" ID="ID_1177446619" MODIFIED="1495200583599" TEXT="public static int[] copyOf(int[] original, int newLength)"/>
<node COLOR="#111111" CREATED="1495200583600" ID="ID_1696113544" MODIFIED="1495200583600" TEXT="public static long[] copyOf(long[] original, int newLength)"/>
<node COLOR="#111111" CREATED="1495200583600" ID="ID_1220737622" MODIFIED="1495200583600" TEXT="public static char[] copyOf(char[] original, int newLength)"/>
<node COLOR="#111111" CREATED="1495200583601" ID="ID_88598070" MODIFIED="1495200583601" TEXT="public static float[] copyOf(float[] original, int newLength)"/>
<node COLOR="#111111" CREATED="1495200583601" ID="ID_1757920740" MODIFIED="1495200583602" TEXT="public static double[] copyOf(double[] original, int newLength)"/>
<node COLOR="#111111" CREATED="1495200583603" ID="ID_513268343" MODIFIED="1495200583603" TEXT="public static boolean[] copyOf(boolean[] original, int newLength)"/>
</node>
<node COLOR="#990000" CREATED="1495200690983" FOLDED="true" ID="ID_590917870" MODIFIED="1497582684781" TEXT="&#x62f7;&#x8d1d;&#x67d0;&#x90e8;&#x5206;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200702209" FOLDED="true" ID="ID_1598171147" MODIFIED="1497582684781" TEXT="public static &lt;T&gt; T[] copyOfRange(T[] original, int from, int to)">
<node COLOR="#111111" CREATED="1495200764150" FOLDED="true" ID="ID_57497893" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495200716448" ID="ID_764691306" MODIFIED="1495200762008" TEXT="&#x628a;&#x5143;&#x7d20;&#x4e2d;&#x4ece;&#x4e0b;&#x6807;&#x4e3a;from &#x5230; &#x4e0b;&#x6807;&#x4e3a;to &#x7684;&#x5143;&#x7d20;&#x62f7;&#x8d1d;&#x5230;&#x65b0;&#x7684;&#x6570;&#x7ec4;&#x4e2d;,&#x5e76;&#x4e14;&#x8fd4;&#x56de;"/>
</node>
<node COLOR="#111111" CREATED="1495200771478" FOLDED="true" ID="ID_935244091" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21442;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495200706334" FOLDED="true" ID="ID_1331678072" MODIFIED="1497582684781" TEXT="orginal">
<node COLOR="#111111" CREATED="1495200783010" ID="ID_78770824" MODIFIED="1495200790099" TEXT="&#x539f;&#x6570;&#x7ec4;"/>
</node>
<node COLOR="#111111" CREATED="1495200709599" FOLDED="true" ID="ID_1569636167" MODIFIED="1497582684781" TEXT="from">
<node COLOR="#111111" CREATED="1495200792272" ID="ID_831808084" MODIFIED="1495200800569" TEXT="&#x8d77;&#x59cb;&#x4e0b;&#x6807;"/>
</node>
<node COLOR="#111111" CREATED="1495200711403" FOLDED="true" ID="ID_1208957374" MODIFIED="1497582684781" TEXT="to">
<node COLOR="#111111" CREATED="1495200801816" ID="ID_648383882" MODIFIED="1495200813938" TEXT="&#x7ed3;&#x675f;&#x4f4d;&#x7f6e;&#x4e0b;&#x6807;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495200702217" ID="ID_1957146947" MODIFIED="1495200702217" TEXT="public static &lt;T,U&gt; T[] copyOfRange(U[] original, int from, int to, Class&lt;? extends T[]&gt; newType)"/>
<node COLOR="#111111" CREATED="1495200702218" ID="ID_1119113003" MODIFIED="1495200702218" TEXT="public static byte[] copyOfRange(byte[] original, int from, int to)"/>
<node COLOR="#111111" CREATED="1495200702218" ID="ID_1714908999" MODIFIED="1495200702218" TEXT="public static short[] copyOfRange(short[] original, int from, int to)"/>
<node COLOR="#111111" CREATED="1495200702219" ID="ID_1063340368" MODIFIED="1495200702219" TEXT="public static int[] copyOfRange(int[] original, int from, int to)"/>
<node COLOR="#111111" CREATED="1495200702220" ID="ID_617288563" MODIFIED="1495200702220" TEXT="public static long[] copyOfRange(long[] original, int from, int to)"/>
<node COLOR="#111111" CREATED="1495200702220" ID="ID_1457452305" MODIFIED="1495200702221" TEXT="public static char[] copyOfRange(char[] original, int from, int to)"/>
<node COLOR="#111111" CREATED="1495200702221" ID="ID_589139823" MODIFIED="1495200702221" TEXT="public static float[] copyOfRange(float[] original, int from, int to)"/>
<node COLOR="#111111" CREATED="1495200702222" ID="ID_1632294295" MODIFIED="1495200702222" TEXT="public static double[] copyOfRange(double[] original, int from, int to)"/>
<node COLOR="#111111" CREATED="1495200702222" ID="ID_814964447" MODIFIED="1495200702222" TEXT="public static boolean[] copyOfRange(boolean[] original, int from, int to)"/>
</node>
<node COLOR="#990000" CREATED="1495200828992" FOLDED="true" ID="ID_552685166" MODIFIED="1497582684781" TEXT="public static &lt;T&gt; List&lt;T&gt; asList(T... a)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200833386" ID="ID_1648173265" MODIFIED="1495200878539" TEXT="&#x628a;&#x53c2;&#x6570;&#x5b58;&#x50a8;&#x5230;List&#x96c6;&#x5408;&#x4e2d;&#x5e76;&#x4e14;&#x8fd4;&#x56de;&#x96c6;&#x5408;"/>
</node>
<node COLOR="#990000" CREATED="1495200888961" FOLDED="true" ID="ID_1166557519" MODIFIED="1497582684781" TEXT="&#x54c8;&#x5e0c;&#x7801;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200893698" ID="ID_1758071287" MODIFIED="1495200893698" TEXT="public static int hashCode(long a[])"/>
<node COLOR="#111111" CREATED="1495200893699" ID="ID_468716494" MODIFIED="1495200893699" TEXT="public static int hashCode(int a[])"/>
<node COLOR="#111111" CREATED="1495200893699" ID="ID_494715543" MODIFIED="1495200893699" TEXT="public static int hashCode(short a[])"/>
<node COLOR="#111111" CREATED="1495200893699" ID="ID_1377878157" MODIFIED="1495200893699" TEXT="public static int hashCode(char a[])"/>
<node COLOR="#111111" CREATED="1495200893699" ID="ID_1453754336" MODIFIED="1495200893699" TEXT="public static int hashCode(byte a[])"/>
<node COLOR="#111111" CREATED="1495200893700" ID="ID_1983311256" MODIFIED="1495200893700" TEXT="public static int hashCode(boolean a[])"/>
<node COLOR="#111111" CREATED="1495200893700" ID="ID_234352266" MODIFIED="1495200893700" TEXT="public static int hashCode(float a[])"/>
<node COLOR="#111111" CREATED="1495200893700" ID="ID_1299132468" MODIFIED="1495200893700" TEXT="public static int hashCode(double a[])"/>
<node COLOR="#111111" CREATED="1495200893700" ID="ID_1777178674" MODIFIED="1495200893700" TEXT="public static int hashCode(Object a[])"/>
<node COLOR="#111111" CREATED="1495200902416" ID="ID_970626807" MODIFIED="1495200902417" TEXT="public static int deepHashCode(Object a[])"/>
</node>
<node COLOR="#990000" CREATED="1495200913967" ID="ID_713674662" MODIFIED="1495200913967" TEXT="public static boolean deepEquals(Object[] a1, Object[] a2)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495200927773" FOLDED="true" ID="ID_557379674" MODIFIED="1497582684781" TEXT="toString&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200933216" ID="ID_15649061" MODIFIED="1495200933216" TEXT="public static String toString(long[] a)"/>
<node COLOR="#111111" CREATED="1495200933223" ID="ID_696530396" MODIFIED="1495200933223" TEXT="public static String toString(int[] a)"/>
<node COLOR="#111111" CREATED="1495200933224" ID="ID_466508462" MODIFIED="1495200933224" TEXT="public static String toString(short[] a)"/>
<node COLOR="#111111" CREATED="1495200933225" ID="ID_1867610196" MODIFIED="1495200933225" TEXT="public static String toString(char[] a)"/>
<node COLOR="#111111" CREATED="1495200933226" ID="ID_923325016" MODIFIED="1495200933226" TEXT="public static String toString(byte[] a)"/>
<node COLOR="#111111" CREATED="1495200933227" ID="ID_768113067" MODIFIED="1495200933227" TEXT="public static String toString(boolean[] a)"/>
<node COLOR="#111111" CREATED="1495200933234" ID="ID_275901249" MODIFIED="1495200933234" TEXT="public static String toString(float[] a)"/>
<node COLOR="#111111" CREATED="1495200933235" ID="ID_1914445041" MODIFIED="1495200933235" TEXT="public static String toString(double[] a)"/>
<node COLOR="#111111" CREATED="1495200933236" ID="ID_307510318" MODIFIED="1495200933236" TEXT="public static String toString(Object[] a)"/>
<node COLOR="#111111" CREATED="1495200933237" ID="ID_543101004" MODIFIED="1495200933237" TEXT="public static String deepToString(Object[] a)"/>
</node>
<node COLOR="#990000" CREATED="1495200964332" FOLDED="true" ID="ID_485199123" MODIFIED="1497582684781" TEXT="&#x5176;&#x4ed6;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495200966491" ID="ID_1672357391" MODIFIED="1495200966491" TEXT="public static &lt;T&gt; void setAll(T[] array, IntFunction&lt;? extends T&gt; generator)"/>
<node COLOR="#111111" CREATED="1495200966492" ID="ID_1108801231" MODIFIED="1495200966492" TEXT="public static &lt;T&gt; void parallelSetAll(T[] array, IntFunction&lt;? extends T&gt; generator)"/>
<node COLOR="#111111" CREATED="1495200966493" ID="ID_1179313090" MODIFIED="1495200966493" TEXT="public static void setAll(int[] array, IntUnaryOperator generator)"/>
<node COLOR="#111111" CREATED="1495200966494" ID="ID_1325053948" MODIFIED="1495200966494" TEXT="public static void parallelSetAll(int[] array, IntUnaryOperator generator)"/>
<node COLOR="#111111" CREATED="1495200966496" ID="ID_643634262" MODIFIED="1495200966496" TEXT="public static void setAll(long[] array, IntToLongFunction generator)"/>
<node COLOR="#111111" CREATED="1495200966497" ID="ID_1733079233" MODIFIED="1495200966497" TEXT="public static void parallelSetAll(long[] array, IntToLongFunction generator)"/>
<node COLOR="#111111" CREATED="1495200966497" ID="ID_224833578" MODIFIED="1495200966499" TEXT="public static void setAll(double[] array, IntToDoubleFunction generator)"/>
<node COLOR="#111111" CREATED="1495200966500" ID="ID_897802669" MODIFIED="1495200966500" TEXT="public static void parallelSetAll(double[] array, IntToDoubleFunction generator)"/>
<node COLOR="#111111" CREATED="1495200995922" FOLDED="true" ID="ID_1226617404" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36845;&#20195;&#22120;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495200966508" ID="ID_1188649107" MODIFIED="1495200966508" TEXT="public static &lt;T&gt; Spliterator&lt;T&gt; spliterator(T[] array)"/>
<node COLOR="#111111" CREATED="1495200966512" ID="ID_1686335868" MODIFIED="1495200966513" TEXT="public static &lt;T&gt; Spliterator&lt;T&gt; spliterator(T[] array, int startInclusive, int endExclusive)"/>
<node COLOR="#111111" CREATED="1495200966517" ID="ID_1249505140" MODIFIED="1495200966518" TEXT="public static Spliterator.OfInt spliterator(int[] array)"/>
<node COLOR="#111111" CREATED="1495200966519" ID="ID_1386449120" MODIFIED="1495200966519" TEXT="public static Spliterator.OfInt spliterator(int[] array, int startInclusive, int endExclusive)"/>
<node COLOR="#111111" CREATED="1495200966520" ID="ID_341982551" MODIFIED="1495200966520" TEXT="public static Spliterator.OfLong spliterator(long[] array)"/>
<node COLOR="#111111" CREATED="1495200966521" ID="ID_1076022604" MODIFIED="1495200966521" TEXT="public static Spliterator.OfLong spliterator(long[] array, int startInclusive, int endExclusive)"/>
<node COLOR="#111111" CREATED="1495200966522" ID="ID_467258851" MODIFIED="1495200966522" TEXT="public static Spliterator.OfDouble spliterator(double[] array)"/>
<node COLOR="#111111" CREATED="1495200966523" ID="ID_1835027282" MODIFIED="1495200966523" TEXT="public static Spliterator.OfDouble spliterator(double[] array, int startInclusive, int endExclusive)"/>
</node>
<node COLOR="#111111" CREATED="1495201007957" FOLDED="true" ID="ID_620391418" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27969;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495200966524" ID="ID_870580912" MODIFIED="1495200966524" TEXT="public static &lt;T&gt; Stream&lt;T&gt; stream(T[] array)"/>
<node COLOR="#111111" CREATED="1495200966526" ID="ID_1352605610" MODIFIED="1495200966526" TEXT="public static &lt;T&gt; Stream&lt;T&gt; stream(T[] array, int startInclusive, int endExclusive)"/>
<node COLOR="#111111" CREATED="1495200966527" ID="ID_649035384" MODIFIED="1495200966527" TEXT="public static IntStream stream(int[] array)"/>
<node COLOR="#111111" CREATED="1495200966528" ID="ID_1360475400" MODIFIED="1495200966528" TEXT="public static IntStream stream(int[] array, int startInclusive, int endExclusive)"/>
<node COLOR="#111111" CREATED="1495200966529" ID="ID_587141909" MODIFIED="1495200966529" TEXT="public static LongStream stream(long[] array)"/>
<node COLOR="#111111" CREATED="1495200966538" ID="ID_604637056" MODIFIED="1495200966538" TEXT="public static LongStream stream(long[] array, int startInclusive, int endExclusive)"/>
<node COLOR="#111111" CREATED="1495200966539" ID="ID_171627960" MODIFIED="1495200966539" TEXT="public static DoubleStream stream(double[] array)"/>
<node COLOR="#111111" CREATED="1495200966539" ID="ID_1298094714" MODIFIED="1495200966540" TEXT="public static DoubleStream stream(double[] array, int startInclusive, int endExclusive)"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1495165518125" FOLDED="true" ID="ID_194906729" MODIFIED="1517311613947" TEXT="Collections">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495201104483" FOLDED="true" ID="ID_1666239620" MODIFIED="1497582684781" TEXT="&#x6392;&#x5e8f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201106894" ID="ID_542760168" MODIFIED="1495201106894" TEXT="public static &lt;T extends Comparable&lt;? super T&gt;&gt; void sort(List&lt;T&gt; list)"/>
<node COLOR="#111111" CREATED="1495201106895" ID="ID_57963554" MODIFIED="1495201106895" TEXT="public static &lt;T&gt; void sort(List&lt;T&gt; list, Comparator&lt;? super T&gt; c)"/>
</node>
<node COLOR="#990000" CREATED="1495201116399" FOLDED="true" ID="ID_182539354" MODIFIED="1497582684781" TEXT="&#x67e5;&#x627e;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201118616" ID="ID_922473012" MODIFIED="1495201118616" TEXT="public static &lt;T&gt; int binarySearch(List&lt;? extends T&gt; list, T key, Comparator&lt;? super T&gt; c)"/>
</node>
<node COLOR="#990000" CREATED="1495201154192" FOLDED="true" ID="ID_315491916" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#39072;&#20498;&#20803;&#32032;&#39034;&#24207;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201142066" ID="ID_1300883176" MODIFIED="1495201154197" TEXT="public static void reverse(List&lt;?&gt; list)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495201172083" FOLDED="true" ID="ID_253165219" MODIFIED="1497582684781" TEXT="&#x6253;&#x4e71;&#x5143;&#x7d20;&#x987a;&#x5e8f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201177629" ID="ID_538213452" MODIFIED="1495201177629" TEXT="public static void shuffle(List&lt;?&gt; list)"/>
<node COLOR="#111111" CREATED="1495201177630" ID="ID_1898747024" MODIFIED="1495201177630" TEXT="public static void shuffle(List&lt;?&gt; list, Random rnd)"/>
</node>
<node COLOR="#990000" CREATED="1495201195290" ID="ID_1973288788" MODIFIED="1495201195290" TEXT="public static void swap(List&lt;?&gt; list, int i, int j)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495201200866" FOLDED="true" ID="ID_1805659567" MODIFIED="1497582684781" TEXT="public static &lt;T&gt; void fill(List&lt;? super T&gt; list, T obj)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201204395" ID="ID_181234203" MODIFIED="1495201234155" TEXT="&#x66ff;&#x6362;&#x96c6;&#x5408;&#x4e2d;&#x7684;&#x6240;&#x6709;&#x5143;&#x7d20; &#x4e3a; obj&#x7684;&#x503c;"/>
</node>
<node COLOR="#990000" CREATED="1495201276163" FOLDED="true" ID="ID_1516228476" MODIFIED="1497582684781" TEXT="public static &lt;T&gt; void copy(List&lt;? super T&gt; dest, List&lt;? extends T&gt; src)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201290391" ID="ID_1196485336" MODIFIED="1495201454485" TEXT="&#x62f7;&#x8d1d;&#x539f;&#x59cb;&#x96c6;&#x5408;src&#x4e2d;&#x6240;&#x6709;&#x7684;&#x5143;&#x7d20;&#x5230;&#x76ee;&#x7684;&#x96c6;&#x5408;destination&#x4e2d;"/>
<node COLOR="#111111" CREATED="1495201488053" ID="ID_134449017" MODIFIED="1495201510288" TEXT="&#x76ee;&#x7684;&#x96c6;&#x5408;&#x7684;&#x957f;&#x5ea6;&#x4e0d;&#x80fd;&#x5c0f;&#x4e8e;&#x539f;&#x59cb;&#x96c6;&#x5408;&#x7684;&#x957f;&#x5ea6;"/>
</node>
<node COLOR="#990000" CREATED="1495201276164" FOLDED="true" ID="ID_1065756658" MODIFIED="1497582684781" TEXT="public static &lt;T extends Object &amp; Comparable&lt;? super T&gt;&gt; T   min(Collection&lt;? extends T&gt; coll)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201528137" ID="ID_199350098" MODIFIED="1495201537504" TEXT="&#x67e5;&#x627e;&#x6700;&#x5c0f;&#x5143;&#x7d20;"/>
<node COLOR="#111111" CREATED="1495201662307" ID="ID_301374359" MODIFIED="1495201705858" TEXT="&#x53c2;&#x6570;&#x96c6;&#x5408;&#x7684;&#x6cdb;&#x578b; &#x5fc5;&#x987b;&#x662f; &#x8fd4;&#x56de;&#x503c;&#x6cdb;&#x578b;&#x7684;&#x5b50;&#x7c7b;"/>
<node COLOR="#111111" CREATED="1495201713440" ID="ID_1304378336" MODIFIED="1495201735098" TEXT="&#x4e14;&#x6cdb;&#x578b;&#x5fc5;&#x987b;&#x53ef;&#x6bd4;"/>
</node>
<node COLOR="#990000" CREATED="1495201276172" ID="ID_1876135507" MODIFIED="1495201572248" TEXT="public static &lt;T&gt; T     min(Collection&lt;? extends T&gt; coll, Comparator&lt;? super T&gt; comp)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495201276175" ID="ID_856054914" MODIFIED="1495201580694" TEXT="public static &lt;T extends Object &amp; Comparable&lt;? super T&gt;&gt; T    max(Collection&lt;? extends T&gt; coll)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495201276178" ID="ID_609547959" MODIFIED="1495201276178" TEXT="public static &lt;T&gt; T max(Collection&lt;? extends T&gt; coll, Comparator&lt;? super T&gt; comp)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495201276179" FOLDED="true" ID="ID_567878633" MODIFIED="1497582684781" TEXT="public static void rotate(List&lt;?&gt; list, int distance)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495202529551" ID="ID_1318998940" MODIFIED="1495202555206" TEXT="&#x5143;&#x7d20;&#x50cf;&#x4e00;&#x4e2a;&#x73af;&#x5f62;&#x4e00;&#x6837;&#x6eda;&#x52a8;"/>
<node COLOR="#111111" CREATED="1495202469401" FOLDED="true" ID="ID_998868618" MODIFIED="1497582684781" TEXT="&#x4e3e;&#x4f8b;">
<node COLOR="#111111" CREATED="1495202472339" ID="ID_1583466353" MODIFIED="1495202472339" TEXT="[t, a, n, k, s]"/>
<node COLOR="#111111" CREATED="1495202477652" ID="ID_267816744" MODIFIED="1495202501110" TEXT="distance &#x4e3a; 2 &#x6216; -4"/>
<node COLOR="#111111" CREATED="1495202502562" ID="ID_1674624912" MODIFIED="1495202505932" TEXT="&#x7ed3;&#x679c;: [s, t, a, n, k]"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495201276180" ID="ID_1871820786" MODIFIED="1495201276180" TEXT="public static &lt;T&gt; boolean replaceAll(List&lt;T&gt; list, T oldVal, T newVal)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495201276181" ID="ID_1740115329" MODIFIED="1495201276181" TEXT="public static int indexOfSubList(List&lt;?&gt; source, List&lt;?&gt; target)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495201276182" ID="ID_202135498" MODIFIED="1495201276182" TEXT="public static int lastIndexOfSubList(List&lt;?&gt; source, List&lt;?&gt; target)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495202749765" FOLDED="true" ID="ID_1264782672" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36820;&#22238;&#21407;&#22987;&#38598;&#21512;&#30340;read-only&#35270;&#22270;&#38598;&#21512;,&#20961;&#26159;&#23545;&#35270;&#22270;&#38598;&#21512;&#36827;&#34892;&#22686;&#21024;&#25913;&#25805;&#20316;&#37117;&#23558;&#25253;&#38169;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201276183" ID="ID_1411552015" MODIFIED="1495202749781" TEXT="public static &lt;T&gt; Collection&lt;T&gt; unmodifiableCollection(Collection&lt;? extends T&gt; c)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276183" ID="ID_783002463" MODIFIED="1495202749783" TEXT="public static &lt;T&gt; Set&lt;T&gt; unmodifiableSet(Set&lt;? extends T&gt; s)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276186" ID="ID_616283291" MODIFIED="1495202749784" TEXT="public static &lt;T&gt; SortedSet&lt;T&gt; unmodifiableSortedSet(SortedSet&lt;T&gt; s)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276188" ID="ID_1620911362" MODIFIED="1495202749785" TEXT="public static &lt;T&gt; NavigableSet&lt;T&gt; unmodifiableNavigableSet(NavigableSet&lt;T&gt; s)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276191" ID="ID_1829793502" MODIFIED="1495202749786" TEXT="public static &lt;T&gt; List&lt;T&gt; unmodifiableList(List&lt;? extends T&gt; list)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276191" ID="ID_1902521219" MODIFIED="1495202749786" TEXT="public static &lt;K,V&gt; Map&lt;K,V&gt; unmodifiableMap(Map&lt;? extends K, ? extends V&gt; m)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276193" ID="ID_288145470" MODIFIED="1495202749787" TEXT="public static &lt;K,V&gt; SortedMap&lt;K,V&gt; unmodifiableSortedMap(SortedMap&lt;K, ? extends V&gt; m)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276193" ID="ID_1565754781" MODIFIED="1495202749788" TEXT="public static &lt;K,V&gt; NavigableMap&lt;K,V&gt; unmodifiableNavigableMap(NavigableMap&lt;K, ? extends V&gt; m)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495202871988" FOLDED="true" ID="ID_1443629784" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36820;&#22238;&#21407;&#22987;&#38598;&#21512;&#30340;&#21516;&#27493;&#30340;&#38598;&#21512;,&#32447;&#31243;&#23433;&#20840;&#30340;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201276195" ID="ID_1273411823" MODIFIED="1495202872001" TEXT="public static &lt;T&gt; Collection&lt;T&gt; synchronizedCollection(Collection&lt;T&gt; c)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276197" ID="ID_227522125" MODIFIED="1495202872002" TEXT="public static &lt;T&gt; Set&lt;T&gt; synchronizedSet(Set&lt;T&gt; s)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276197" ID="ID_514306285" MODIFIED="1495202872003" TEXT="public static &lt;T&gt; SortedSet&lt;T&gt; synchronizedSortedSet(SortedSet&lt;T&gt; s)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276198" ID="ID_1445062282" MODIFIED="1495202872004" TEXT="public static &lt;T&gt; NavigableSet&lt;T&gt; synchronizedNavigableSet(NavigableSet&lt;T&gt; s)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276198" ID="ID_6405733" MODIFIED="1495202872004" TEXT="public static &lt;T&gt; List&lt;T&gt; synchronizedList(List&lt;T&gt; list)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276198" ID="ID_343741527" MODIFIED="1495202872005" TEXT="public static &lt;K,V&gt; Map&lt;K,V&gt; synchronizedMap(Map&lt;K,V&gt; m)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276199" ID="ID_1740880613" MODIFIED="1495202872006" TEXT="public static &lt;K,V&gt; SortedMap&lt;K,V&gt; synchronizedSortedMap(SortedMap&lt;K,V&gt; m)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276199" ID="ID_1302271105" MODIFIED="1495202872007" TEXT="public static &lt;K,V&gt; NavigableMap&lt;K,V&gt; synchronizedNavigableMap(NavigableMap&lt;K,V&gt; m)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495203208473" FOLDED="true" ID="ID_455692446" MODIFIED="1497582684781">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20854;&#20182;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495201276201" ID="ID_92424296" MODIFIED="1495203208518" TEXT="public static &lt;E&gt; Queue&lt;E&gt; checkedQueue(Queue&lt;E&gt; queue, Class&lt;E&gt; type)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276202" ID="ID_107463248" MODIFIED="1495203208519" TEXT="public static &lt;E&gt; Set&lt;E&gt; checkedSet(Set&lt;E&gt; s, Class&lt;E&gt; type)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276203" ID="ID_87320328" MODIFIED="1495203208519" TEXT="public static &lt;E&gt; List&lt;E&gt; checkedList(List&lt;E&gt; list, Class&lt;E&gt; type)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276203" ID="ID_707939836" MODIFIED="1495203208520" TEXT="public static &lt;T&gt; Iterator&lt;T&gt; emptyIterator()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276204" ID="ID_1087170638" MODIFIED="1495203208520" TEXT="public static &lt;T&gt; ListIterator&lt;T&gt; emptyListIterator()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276204" ID="ID_416066768" MODIFIED="1495203208520" TEXT="public static &lt;T&gt; Enumeration&lt;T&gt; emptyEnumeration()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276205" ID="ID_1571407803" MODIFIED="1495203208521" TEXT="public static final &lt;T&gt; Set&lt;T&gt; emptySet()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276205" ID="ID_61631901" MODIFIED="1495203208521" TEXT="public static &lt;E&gt; SortedSet&lt;E&gt; emptySortedSet()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276206" ID="ID_1163743283" MODIFIED="1495203208521" TEXT="public static &lt;E&gt; NavigableSet&lt;E&gt; emptyNavigableSet()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276206" ID="ID_1401372375" MODIFIED="1495203208521" TEXT="public static final &lt;T&gt; List&lt;T&gt; emptyList()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276206" ID="ID_242015125" MODIFIED="1495203208522" TEXT="public static final &lt;K,V&gt; Map&lt;K,V&gt; emptyMap()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276207" ID="ID_946905241" MODIFIED="1495203208522" TEXT="public static final &lt;K,V&gt; SortedMap&lt;K,V&gt; emptySortedMap()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276207" ID="ID_1750938799" MODIFIED="1495203208522" TEXT="public static final &lt;K,V&gt; NavigableMap&lt;K,V&gt; emptyNavigableMap()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276207" ID="ID_975346356" MODIFIED="1495203208522" TEXT="public static &lt;T&gt; Set&lt;T&gt; singleton(T o)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276208" ID="ID_1939367335" MODIFIED="1495203208522" TEXT="public static &lt;T&gt; List&lt;T&gt; singletonList(T o)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276208" ID="ID_1537148666" MODIFIED="1495203208522" TEXT="public static &lt;K,V&gt; Map&lt;K,V&gt; singletonMap(K key, V value)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276209" ID="ID_1704426484" MODIFIED="1495203208522" TEXT="public static &lt;T&gt; List&lt;T&gt; nCopies(int n, T o)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276209" ID="ID_581084823" MODIFIED="1495203208522" TEXT="public static &lt;T&gt; Comparator&lt;T&gt; reverseOrder()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276209" ID="ID_1524702485" MODIFIED="1495203208523" TEXT="public static &lt;T&gt; Comparator&lt;T&gt; reverseOrder(Comparator&lt;T&gt; cmp)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276210" ID="ID_453187822" MODIFIED="1495203208523" TEXT="public static &lt;T&gt; Enumeration&lt;T&gt; enumeration(final Collection&lt;T&gt; c)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276210" ID="ID_234594211" MODIFIED="1495203208523" TEXT="public static &lt;T&gt; ArrayList&lt;T&gt; list(Enumeration&lt;T&gt; e)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276210" ID="ID_1592088254" MODIFIED="1495203208523" TEXT="public static int frequency(Collection&lt;?&gt; c, Object o)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276211" ID="ID_1007015115" MODIFIED="1495203208523" TEXT="public static boolean disjoint(Collection&lt;?&gt; c1, Collection&lt;?&gt; c2)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276211" ID="ID_1715043851" MODIFIED="1495203208523" TEXT="public static &lt;T&gt; boolean addAll(Collection&lt;? super T&gt; c, T... elements)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276211" ID="ID_819712017" MODIFIED="1495203208523" TEXT="public static &lt;E&gt; Set&lt;E&gt; newSetFromMap(Map&lt;E, Boolean&gt; map)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495201276212" ID="ID_1874359538" MODIFIED="1495203208523" TEXT="public static &lt;T&gt; Queue&lt;T&gt; asLifoQueue(Deque&lt;T&gt; deque)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684756" FOLDED="true" ID="4i61if879u0cdmgidqh3moq69d" LINK="images/&#x96c6;&#x5408;&#x6846;&#x67b6;&#x56fe;.png" MODIFIED="1517210514941" POSITION="left" TEXT="1_&#x96c6;&#x5408;&#x6846;&#x67b6;&#x56fe;.png">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684768" ID="ID_120746168" MODIFIED="1473598714814" TEXT="&#x865a;&#x6846;&#x4ee3;&#x8868;abstract&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684778" FOLDED="true" ID="01q1ejc3s2jmpuhqrlb1hduckr" MODIFIED="1497582684797" POSITION="left" TEXT="Queue ">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684778" FOLDED="true" ID="ID_1040095766" MODIFIED="1497582684797" TEXT="&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684778" ID="ID_1112725682" MODIFIED="1473598714971" TEXT="&#x5148;&#x8fdb;&#x5148;&#x51fa;&#x7684;&#x5bb9;&#x5668;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684778" ID="ID_791418875" MODIFIED="1473598714971" TEXT="&#x58f0;&#x660e;&#x4e0b;&#x4e00;&#x4e2a;&#x5f39;&#x51fa;&#x7684;&#x5143;&#x7d20;&#x662f;&#x6700;&#x9700;&#x8981;&#x7684;&#x5143;&#x7d20;&#xff08;&#x5177;&#x6709;&#x6700;&#x9ad8;&#x4f18;&#x5148;&#x7ea7;&#xff09;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684778" ID="ID_397558681" MODIFIED="1473598715047" TEXT="&#x5e38;&#x7528;&#x5728;&#x5e76;&#x53d1;&#x7f16;&#x7a0b;&#x4e2d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684778" FOLDED="true" ID="ID_1925605546" MODIFIED="1497582684797" TEXT="PriorityQueue">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684778" FOLDED="true" ID="ID_1946618230" MODIFIED="1497582684797" TEXT="&#x5e38;&#x7528;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684778" ID="ID_538674035" MODIFIED="1473598715048" TEXT="boolean contains(Object o)"/>
<node COLOR="#111111" CREATED="1473598684778" ID="ID_651638132" MODIFIED="1473598715048" TEXT="boolean add(E e)"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684778" FOLDED="true" ID="ID_985458076" MODIFIED="1497582684797" TEXT="&#x5e38;&#x7528;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684778" ID="ID_17554537" MODIFIED="1473598715049" TEXT="boolean add(E e)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684778" FOLDED="true" ID="ID_912183305" MODIFIED="1497582684797" TEXT="boolean offer(E e)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684778" ID="ID_1476073706" MODIFIED="1473598715049" TEXT="&#x63d2;&#x5165;&#x5143;&#x7d20;&#x5230;&#x961f;&#x5c3e;"/>
</node>
<node COLOR="#990000" CREATED="1473598684778" FOLDED="true" ID="ID_1247615989" MODIFIED="1497582684797" TEXT="E peek()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684778" ID="ID_724884725" MODIFIED="1473598715050" TEXT="&#x8fd4;&#x56de;&#x961f;&#x5934;&#x5143;&#x7d20;&#xff0c;&#x4f46;&#x4e0d;&#x79fb;&#x9664;"/>
<node COLOR="#111111" CREATED="1473598684779" ID="ID_1971173059" MODIFIED="1473598715050" TEXT="&#x961f;&#x5217;&#x4e3a;&#x7a7a;&#x65f6;&#x8fd4;&#x56de;null"/>
</node>
<node COLOR="#990000" CREATED="1473598684779" FOLDED="true" ID="ID_155377156" MODIFIED="1497582684797" TEXT="E element()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684779" ID="ID_1492144222" MODIFIED="1473598715051" TEXT="&#x8fd4;&#x56de;&#x961f;&#x5934;&#x5143;&#x7d20;&#xff0c;&#x4f46;&#x4e0d;&#x79fb;&#x9664;"/>
<node COLOR="#111111" CREATED="1473598684779" ID="ID_1488330879" MODIFIED="1473598715051" TEXT="&#x961f;&#x5217;&#x4e3a;&#x7a7a;&#x65f6;&#x629b;&#x51fa;NoSuchElementException"/>
</node>
<node COLOR="#990000" CREATED="1473598684779" FOLDED="true" ID="ID_847709456" MODIFIED="1497582684797" TEXT="E remove()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684779" ID="ID_1102613904" MODIFIED="1473598715051" TEXT="&#x8fd4;&#x56de;&#x961f;&#x5934;&#x5143;&#x7d20;&#xff0c;&#x5e76;&#x4e14;&#x79fb;&#x9664;"/>
<node COLOR="#111111" CREATED="1473598684779" ID="ID_730842563" MODIFIED="1473598715052" TEXT="&#x961f;&#x5217;&#x4e3a;&#x7a7a;&#x65f6;&#x629b;&#x51fa; NoSuchElementException"/>
</node>
<node COLOR="#990000" CREATED="1473598684779" FOLDED="true" ID="ID_559911739" MODIFIED="1497582684797" TEXT="E poll()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684779" ID="ID_1473225559" MODIFIED="1473598715052" TEXT="&#x8fd4;&#x56de;&#x961f;&#x5934;&#x5143;&#x7d20;&#xff0c;&#x5e76;&#x4e14;&#x79fb;&#x9664;"/>
<node COLOR="#111111" CREATED="1473598684779" ID="ID_1936959719" MODIFIED="1473598715052" TEXT="&#x961f;&#x5217;&#x4e3a;&#x7a7a;&#x65f6;&#x8fd4;&#x56de;null"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684779" FOLDED="true" ID="04k356omvql03b0nlg5dqqshc4" MODIFIED="1497582684797" POSITION="left" TEXT="Collection">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684779" FOLDED="true" ID="ID_1383375500" MODIFIED="1497582684797" TEXT="&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684779" ID="ID_51775534" MODIFIED="1473598715056" TEXT="&#x96c6;&#x5408;&#x7684;&#x6839;&#x63a5;&#x53e3;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684779" FOLDED="true" ID="ID_1932711258" MODIFIED="1497582684797" TEXT="&#x5de5;&#x5177;&#x7c7b; Collections">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684779" ID="ID_662420227" MODIFIED="1473598715057" TEXT="&#x7528;&#x6765;&#x64cd;&#x4f5c;&#x96c6;&#x5408;&#x7684;&#x5de5;&#x5177;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684776" FOLDED="true" ID="7kbei730dkjcr66m8549iaeb5g" MODIFIED="1531650110421" POSITION="right" TEXT="Set P477">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684776" ID="ID_666540299" LINK="https://www.cnblogs.com/smiles125/p/5370204.html" MODIFIED="1521758869246" TEXT="HashSet">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_1481551802" MODIFIED="1473598714957" TEXT="&#x4e3a;&#x5feb;&#x901f;&#x67e5;&#x627e;&#x8bbe;&#x8ba1;&#x7684;Set">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_1354801876" MODIFIED="1473598714958" TEXT="&#x5b58;&#x50a8;&#x5143;&#x7d20;&#x7684;&#x4f4d;&#x7f6e;&#x662f;&#x56fa;&#x5b9a;&#x7684;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1521758563430" ID="ID_1994037802" MODIFIED="1521758601647" TEXT="&#x7279;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1521758569721" ID="ID_1383328971" MODIFIED="1521758569721" TEXT="&#x4e0d;&#x80fd;&#x4fdd;&#x8bc1;&#x5143;&#x7d20;&#x7684;&#x6392;&#x5217;&#x987a;&#x5e8f;&#xff0c;&#x987a;&#x5e8f;&#x6709;&#x53ef;&#x80fd;&#x53d1;&#x751f;&#x53d8;&#x5316;"/>
<node COLOR="#111111" CREATED="1521758569737" ID="ID_1953749203" MODIFIED="1521758569737" TEXT="&#xf0d8; &#x4e0d;&#x662f;&#x540c;&#x6b65;&#x7684;"/>
<node COLOR="#111111" CREATED="1521758569847" ID="ID_820346389" MODIFIED="1521758569847" TEXT="&#xf0d8; &#x96c6;&#x5408;&#x5143;&#x7d20;&#x53ef;&#x4ee5;&#x662f;null,&#x4f46;&#x53ea;&#x80fd;&#x653e;&#x5165;&#x4e00;&#x4e2a;null"/>
<node COLOR="#111111" CREATED="1473598684776" ID="ID_329160858" MODIFIED="1521758602175" TEXT="&#x5143;&#x7d20;&#x4e0d;&#x53ef;&#x91cd;&#x590d;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1521758631332" ID="ID_1959047093" MODIFIED="1521758636036" TEXT="&#x5224;&#x65ad;&#x91cd;&#x590d;&#x6807;&#x51c6;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1521758651327" ID="ID_1272880357" MODIFIED="1531649853916" TEXT="&#x9996;&#x5148;&#x5224;&#x65ad;&#x4e24;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;hashCode()&#x65b9;&#x6cd5;&#x8fd4;&#x56de;&#x503c;&#x662f;&#x5426;&#x76f8;&#x7b49;"/>
<node COLOR="#111111" CREATED="1521758636397" ID="ID_924684159" MODIFIED="1531649897407">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22914;&#26524;hashcode&#30456;&#21516;&#21017;&#32487;&#32493;&#36890;&#36807;equals&#21028;&#26029;&#23545;&#35937;&#26159;&#21542;&#30456;&#21516;,&#19981;&#21516;&#21017;&#25554;&#20837;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684776" FOLDED="true" ID="ID_1191754207" MODIFIED="1531650018498" TEXT="TreeSet">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_1212529738" MODIFIED="1521758808917">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#19968;&#31181;&#25490;&#24207;&#20108;&#21449;&#26641;,Treeset&#20013;&#30340;&#25968;&#25454;&#26159;&#33258;&#21160;&#25490;&#22909;&#24207;&#30340;&#65292;&#19981;&#20801;&#35768;&#25918;&#20837;null&#20540;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_232026902" MODIFIED="1473598714959" TEXT="&#x5b58;&#x5165;&#x96c6;&#x5408;&#x4e2d;&#x7684;&#x503c;&#xff0c;&#x4f1a;&#x6309;&#x7167;&#x503c;&#x7684;&#x5927;&#x5c0f;&#x8fdb;&#x884c;&#x76f8;&#x5173;&#x7684;&#x6392;&#x5e8f;&#x64cd;&#x4f5c;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_25844387" MODIFIED="1473598714960" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;&#xff1a;new TreeSet&lt;String&gt;(String.CASE_INSENSITIVE_ORDER)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684776" FOLDED="true" ID="ID_1815911373" MODIFIED="1521758823984" TEXT="&#x4e13;&#x5c5e;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684776" ID="ID_905616377" MODIFIED="1473598714962" TEXT="boolean addAll(Collection&lt;? extends E&gt; c)"/>
<node COLOR="#111111" CREATED="1473598684776" ID="ID_1854122939" MODIFIED="1473598714962" TEXT="E first() "/>
<node COLOR="#111111" CREATED="1473598684776" ID="ID_1244699141" MODIFIED="1473598714962" TEXT="E last()"/>
<node COLOR="#111111" CREATED="1473598684777" ID="ID_17411603" MODIFIED="1473598714963" TEXT="E pollFirst()"/>
<node COLOR="#111111" CREATED="1473598684777" ID="ID_1000362881" MODIFIED="1473598714963" TEXT=" E pollLast()"/>
</node>
<node COLOR="#990000" CREATED="1521758721403" ID="ID_1557558213" MODIFIED="1521758731635" TEXT="&#x5224;&#x65ad;&#x91cd;&#x590d;&#x6807;&#x51c6;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1521758732142" ID="ID_137433865" MODIFIED="1531649992396" TEXT="TreeSet&#x5224;&#x65ad;&#x4e24;&#x4e2a;&#x5bf9;&#x8c61;&#x76f8;&#x7b49;&#x7684;&#x65b9;&#x5f0f;&#x662f;&#x4e24;&#x4e2a;&#x5bf9;&#x8c61;&#x901a;&#x8fc7;equals&#x65b9;&#x6cd5;&#x8fd4;&#x56de;true&#xff0c;&#x6216;&#x8005;&#x901a;&#x8fc7;CompareTo&#x65b9;&#x6cd5;&#x6bd4;&#x8f83;&#x8fd4;&#x56de;0"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684777" FOLDED="true" ID="ID_1066413116" MODIFIED="1516852910942" TEXT="LinkedHashSet">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_1382262412" MODIFIED="1516852902301" TEXT="&#x7279;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684777" ID="ID_1845562096" MODIFIED="1473598714964" TEXT="&#x5177;&#x6709;HashSet&#x7684;&#x67e5;&#x8be2;&#x901f;&#x5ea6;"/>
<node COLOR="#111111" CREATED="1473598684777" ID="ID_787410766" MODIFIED="1473598714964" TEXT="&#x5185;&#x90e8;&#x4f7f;&#x7528;&#x94fe;&#x8868;&#x7ef4;&#x62a4;&#x5143;&#x7d20;&#x7684;&#x987a;&#x5e8f;(&#x63d2;&#x5165;&#x7684;&#x6b21;&#x5e8f;)"/>
<node COLOR="#111111" CREATED="1473598684777" ID="ID_1417458581" MODIFIED="1473598714964" TEXT="&#x5143;&#x7d20;&#x7684;&#x987a;&#x5e8f;&#x662f;&#x63d2;&#x5165;&#x65f6;&#x7684;&#x5143;&#x7d20;"/>
<node COLOR="#111111" CREATED="1473598684777" ID="ID_1526123612" MODIFIED="1473598714964" TEXT="&#x5220;&#x9664;&#x901f;&#x5ea6;&#x5feb;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684777" ID="ID_1113587988" MODIFIED="1473598714965" TEXT="EnumSet">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473598684777" FOLDED="true" ID="ID_1867873343" MODIFIED="1500597095383" TEXT="&#x516c;&#x5171;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_855317068" MODIFIED="1473598714965" TEXT="boolean add(E e)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_1460169667" MODIFIED="1473598714966" TEXT="clear()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_1400149533" MODIFIED="1473598714966" TEXT="boolean contains(Object o)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_479316144" MODIFIED="1473598714966" TEXT="boolean isEmpty()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_943325135" MODIFIED="1473598714966" TEXT="Iterator&lt;E&gt; iterator()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_921046462" MODIFIED="1473598714967" TEXT="boolean remove(Object o)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684777" ID="ID_1910623975" MODIFIED="1473598714967" TEXT="int size() ">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684778" ID="ID_1634780494" MODIFIED="1473598714968" TEXT="&#x6ce8;&#x610f;&#xff1a; Set&#x4e2d;&#x4e0d;&#x4fdd;&#x5b58;&#x91cd;&#x590d;&#x7684;&#x6570;&#x636e;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684773" FOLDED="true" ID="1aqcnjua0cqupv097i6j9lk18k" MODIFIED="1521758548773" POSITION="right" TEXT="Map &#x7ee7;&#x627f;&#x81ea;Object">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473599052048" ID="ID_253709570" MODIFIED="1500544828056" TEXT="&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473599057308" ID="ID_1926469822" MODIFIED="1473599081833" TEXT="&#x6620;&#x5c04;&#x4e00;&#x79cd;&#x6570;&#x636e;&#x7ed3;&#x6784;&#x548c;&#x53e6;&#x4e00;&#x79cd;&#x6570;&#x636e;&#x7ed3;&#x6784;&#x7684;&#x96c6;&#x5408;&#x7c7b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473600729030" ID="ID_585501450" LINK="images/3b1460769a7.jpeg" MODIFIED="1500597357129" TEXT="&#x5e95;&#x5c42;&#x7ed3;&#x6784;&#x662f; &#xff1a; &#x6570;&#x7ec4;+&#x94fe;&#x8868;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473601697778" ID="ID_1671626350" MODIFIED="1500597045064" TEXT="&#x6570;&#x7ec4;&#x7684;&#x4e0b;&#x6807;&#x662f;&#x6839;&#x636e; map &#x7684;key&#x7684;hash&#x503c;&#x6765;&#x786e;&#x5b9a;&#x7684;"/>
<node COLOR="#111111" CREATED="1500597363680" ID="ID_845467398" MODIFIED="1500597379265" TEXT="hash(key)%len  &#x5c31;&#x662f;&#x6570;&#x7ec4;&#x7684;&#x4e0b;&#x6807;"/>
<node COLOR="#111111" CREATED="1473601729418" ID="ID_253103991" MODIFIED="1500597052492" TEXT="hash&#x503c;&#xff1f;">
<node COLOR="#111111" CREATED="1473601734248" ID="ID_288058770" MODIFIED="1500597054899" TEXT="&#x901a;&#x8fc7;hash&#x7b97;&#x6cd5;&#x8ba1;&#x7b97;&#x5f97;&#x5230;&#x7684;&#x503c;">
<node COLOR="#111111" CREATED="1473601774780" ID="ID_1783237029" MODIFIED="1473601774780" TEXT="&#x4e00;&#x79cd;&#x5c06;&#x4efb;&#x610f;&#x957f;&#x5ea6;&#x7684;&#x6d88;&#x606f;&#x538b;&#x7f29;&#x5230;&#x67d0;&#x4e00;&#x56fa;&#x5b9a;&#x957f;&#x5ea6;&#x7684;&#x6d88;&#x606f;&#x6458;&#x8981;&#x7684;&#x51fd;&#x6570;"/>
</node>
<node COLOR="#111111" CREATED="1473601782368" ID="ID_144290760" MODIFIED="1473601875573" TEXT="&#x4e0d;&#x540c;&#x7684;key&#x5f97;&#x5230;&#x7684;hash&#x503c;&#x6709;&#x53ef;&#x80fd;&#x4e00;&#x6837;&#xff0c;&#x8fd9;&#x53eb;&#x505a;hash&#x51b2;&#x7a81;"/>
<node COLOR="#111111" CREATED="1473601876931" ID="ID_183999110" MODIFIED="1473601925053" TEXT="&#x53d1;&#x751f;hash&#x51b2;&#x7a81;&#x7684;key&#x5c06;&#x4f1a;&#x4fdd;&#x5b58;&#x5728;&#x6570;&#x7ec4;&#x7684;&#x540c;&#x4e00;&#x4e2a;&#x4e0b;&#x6807;&#x4e2d;&#x7684;&#x94fe;&#x8868;&#x4e2d;"/>
<node COLOR="#111111" CREATED="1473601928081" ID="ID_41867220" MODIFIED="1473601942283" TEXT="&#x65b0;&#x63d2;&#x5165;&#x7684;&#x5728;&#x5bf9;&#x5e94;&#x4e0b;&#x6807;&#x94fe;&#x8868;&#x7684;&#x5934;&#x90e8;"/>
<node COLOR="#111111" CREATED="1473601829228" FOLDED="true" ID="ID_966240020" MODIFIED="1500597060134" TEXT="&#x5e38;&#x7528;&#x7684;hash&#x7b97;&#x6cd5;">
<node COLOR="#111111" CREATED="1473601838920" ID="ID_960805740" MODIFIED="1473601843340" TEXT="MD5 "/>
<node COLOR="#111111" CREATED="1473601844439" ID="ID_1832074617" MODIFIED="1473601850321" TEXT="SHA1"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1473600788507" FOLDED="true" ID="ID_1248652567" MODIFIED="1500544836095" TEXT="&#x6570;&#x7ec4;&#x4e2d;&#x7684;&#x5143;&#x7d20;&#x662f; &#xff1a; Entry">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473601095378" FOLDED="true" ID="ID_562714839" MODIFIED="1500544835282" TEXT="&#x5b50;&#x7c7b; Node&lt;K,V&gt;">
<node COLOR="#111111" CREATED="1473601137916" FOLDED="true" ID="ID_574050663" MODIFIED="1497582684797" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1473601140628" ID="ID_1947091705" MODIFIED="1473601140628" TEXT="Node(int hash, K key, V value, Node&lt;K,V&gt; next)"/>
</node>
<node COLOR="#111111" CREATED="1473601150530" FOLDED="true" ID="ID_1752963570" MODIFIED="1497582684797" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473601152042" ID="ID_1915681472" MODIFIED="1473601152042" TEXT="public final K getKey()"/>
<node COLOR="#111111" CREATED="1473601158274" ID="ID_897880355" MODIFIED="1473601158274" TEXT="public final V getValue()"/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598841533" FOLDED="true" ID="ID_1529020666" MODIFIED="1500544827213" TEXT="&#x5206;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684773" FOLDED="true" ID="ID_1904395754" MODIFIED="1497582684797" TEXT="HashMap">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684773" FOLDED="true" ID="ID_1699508347" MODIFIED="1497582684797" TEXT="&#xff1f; ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473598684773" ID="ID_974423643" MODIFIED="1473598714920" TEXT="&#x5c06;&#x5bf9;&#x8c61;&#x6620;&#x5c04;&#x5230;&#x5176;&#x4ed6;&#x5bf9;&#x8c61;&#x7684;&#x96c6;&#x5408;"/>
<node COLOR="#111111" CREATED="1473598684773" ID="ID_455226779" MODIFIED="1473598714920" TEXT="&#x91c7;&#x7528; key - value &#x5bf9;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473598684773" FOLDED="true" ID="ID_1758331097" MODIFIED="1497582684797" TEXT="SortedMap &#x63a5;&#x53e3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684773" FOLDED="true" ID="ID_1311087185" MODIFIED="1497582684797" TEXT="NavigableMap &#x63a5;&#x53e3;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473598684773" FOLDED="true" ID="ID_1828361083" MODIFIED="1497582684797" TEXT="TreeMap">
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1208644537" MODIFIED="1473598714924" TEXT="&#x952e;&#x7ecf;&#x8fc7;&#x6392;&#x5e8f;"/>
<node COLOR="#111111" CREATED="1473598684774" FOLDED="true" ID="ID_133768782" MODIFIED="1497582684797" TEXT="&#x4e13;&#x5c5e;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473598684774" ID="ID_167717082" MODIFIED="1473598714925" TEXT="Iterator&lt;K&gt; keyIterator()"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1280102518" MODIFIED="1473598714925" TEXT="NavigableMap&lt;K,V&gt; subMap(K fromKey, boolean fromInclusive,&#xd;&#xa;                                    K toKey,   boolean toInclusive)"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1562195186" MODIFIED="1473598714933" TEXT="Map.Entry&lt;K,V&gt; lowerEntry(K key)"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_477578671" MODIFIED="1473598714933" TEXT="K lowerKey(K key);"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_138312923" MODIFIED="1473598714933" TEXT="Map.Entry&lt;K,V&gt; floorEntry(K key);"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1642502298" MODIFIED="1473598714933" TEXT="K floorKey(K key);"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1095917382" MODIFIED="1473598714934" TEXT="Map.Entry&lt;K,V&gt; higherEntry(K key);"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1011866333" MODIFIED="1473598714934" TEXT="K higherKey(K key);"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1639868043" MODIFIED="1473598714934" TEXT="Map.Entry&lt;K,V&gt; firstEntry();"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1157736502" MODIFIED="1473598714934" TEXT="Map.Entry&lt;K,V&gt; lastEntry();"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_1321210733" MODIFIED="1473598714934" TEXT="Map.Entry&lt;K,V&gt; pollFirstEntry()"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_486128468" MODIFIED="1473598714935" TEXT="Map.Entry&lt;K,V&gt; pollLastEntry();"/>
<node COLOR="#111111" CREATED="1473598684774" ID="ID_806152020" MODIFIED="1473598714935" TEXT="&#x5176;&#x4ed6;&#xff0c;&#x53c2;&#x8003;&#x6e90;&#x7801;"/>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1473598684775" FOLDED="true" ID="ID_779740627" MODIFIED="1497582684797" TEXT="ConcurrentHashMap">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684775" FOLDED="true" ID="ID_913416251" MODIFIED="1497582684797" TEXT="&#xff1f;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473598684775" ID="ID_851883701" MODIFIED="1473598714936" TEXT="&#x7ebf;&#x7a0b;&#x5b89;&#x5168;&#x7684;HashMap"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473598684775" FOLDED="true" ID="ID_853810890" MODIFIED="1497582684797" TEXT="EnumMap">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684775" FOLDED="true" ID="ID_772190476" MODIFIED="1497582684797" TEXT="&#xff1f;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473598684775" ID="ID_1952942519" MODIFIED="1473598714946" TEXT="key &#x662f;&#x679a;&#x4e3e;&#x7c7b;&#x578b;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684775" FOLDED="true" ID="ID_1146977139" MODIFIED="1497582684797" TEXT="&#x5171;&#x540c;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_212178076" MODIFIED="1473598714947" TEXT="  V put(K key, V value);">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_382876761" MODIFIED="1473598714948" TEXT="void putAll(Map&lt;? extends K, ? extends V&gt; m);">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_387310405" MODIFIED="1473598714949" TEXT="V get(Object key);">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_1019960615" MODIFIED="1473598714949" TEXT="boolean containsKey(Object key)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_102401995" MODIFIED="1473598714949" TEXT="boolean containsValue(Object value)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_1601901013" MODIFIED="1473598714949" TEXT="Set&lt;Map.Entry&lt;K,V&gt;&gt;   entrySet()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_63989772" MODIFIED="1473598714950" TEXT="Set&lt;K&gt;  keySet();">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_1133528542" MODIFIED="1473598714950" TEXT=" Collection&lt;V&gt; values();">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684775" ID="ID_1673250151" MODIFIED="1473598714950" TEXT="void clear()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_39928073" MODIFIED="1473598714950" TEXT="V remove(Object key);">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_107550631" MODIFIED="1473598714951" TEXT="int size();">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684776" ID="ID_595829983" MODIFIED="1473598714951" TEXT="boolean isEmpty();">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684800" FOLDED="true" ID="7oi0lpriq0br0spcvt8kmgcg4k" MODIFIED="1500638346694" POSITION="right" TEXT="&#x6cdb;&#x578b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684800" ID="ID_545772230" MODIFIED="1500601287256" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684800" ID="ID_948982987" MODIFIED="1500601288225" TEXT="&#x53c2;&#x6570;&#x5316;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684800" ID="ID_1441986862" MODIFIED="1495187620883" TEXT="&#x5c31;&#x662f;&#x5c06;&#x7c7b;&#x578b;&#x7531;&#x539f;&#x6765;&#x7684;&#x5177;&#x4f53;&#x7684;&#x7c7b;&#x578b;&#x53c2;&#x6570;&#x5316;"/>
<node COLOR="#111111" CREATED="1473598684800" ID="ID_1425642169" MODIFIED="1495187620883" TEXT="&#x7c7b;&#x4f3c;&#x4e8e;&#x65b9;&#x6cd5;&#x4e2d;&#x7684;&#x53d8;&#x91cf;&#x53c2;&#x6570;&#xff0c;&#x6b64;&#x65f6;&#x7c7b;&#x578b;&#x4e5f;&#x5b9a;&#x4e49;&#x6210;&#x53c2;&#x6570;&#x5f62;&#x5f0f;&#xff08;&#x53ef;&#x4ee5;&#x79f0;&#x4e4b;&#x4e3a;&#x7c7b;&#x578b;&#x5f62;&#x53c2;&#xff09;&#xff0c;&#x7136;&#x540e;&#x5728;&#x4f7f;&#x7528;/&#x8c03;&#x7528;&#x65f6;&#x4f20;&#x5165;&#x5177;&#x4f53;&#x7684;&#x7c7b;&#x578b;&#xff08;&#x7c7b;&#x578b;&#x5b9e;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684800" ID="ID_901869838" MODIFIED="1495187620884" TEXT="&#x6cdb;&#x578b;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1473598684801" FOLDED="true" ID="ID_641455817" MODIFIED="1497582684765" TEXT="&#x6cdb;&#x578b;&#x5143;&#x7ec4;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684801" ID="ID_1161952260" MODIFIED="1495187620884" TEXT="public class Student&lt;A,B,C,D&gt; {  }">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684801" FOLDED="true" ID="ID_493698612" MODIFIED="1497582684765" TEXT="&#x6cdb;&#x578b;&#x63a5;&#x53e3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684801" ID="ID_510111444" MODIFIED="1495187620885" TEXT="public interface&lt;T&gt; IFace{  }">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684801" ID="ID_504765253" MODIFIED="1500631007462" TEXT="&#x6cdb;&#x578b;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684801" ID="ID_665577505" MODIFIED="1500631009257" TEXT="&#x683c;&#x5f0f; &#xff1a;   &#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;  &lt;T&gt;  &#x8fd4;&#x56de;&#x503c;  &#x65b9;&#x6cd5;&#x540d;&#xff08;T t&#xff09;{}">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495187762493" ID="ID_877849090" MODIFIED="1500631010319">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33539;&#20363;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495187735351" ID="ID_199260902" MODIFIED="1495187756294" TEXT="public &lt;T&gt; T get(T t){  }"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684801" FOLDED="true" ID="ID_97068518" MODIFIED="1500638345459" TEXT="&#x901a;&#x914d;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684801" ID="ID_698724867" MODIFIED="1495187620885" TEXT="&#x65e0;&#x754c;&#x901a;&#x914d;&#x7b26;  &#xff1a; &lt;?&gt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684801" ID="ID_1965990281" MODIFIED="1500620098476" TEXT="&lt;? extends &#x7c7b;&gt;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495187681699" ID="ID_1908836680" MODIFIED="1495187821306" TEXT="&lt;? extends T&gt;  &#x8868;&#x793a;&#x5305;&#x62ec;T&#x5728;&#x5185;&#x7684;T&#x7684;&#x4efb;&#x4f55;&#x5b50;&#x7c7b;"/>
</node>
<node COLOR="#990000" CREATED="1473598684802" ID="ID_357690709" MODIFIED="1500620099617" TEXT="&#x8d85;&#x7c7b;&#xff08;&#x57fa;&#x7c7b;&#xff09;&#x901a;&#x914d;&#x7b26; &#xff1a; &lt; ? super &#x7c7b;&gt;    p393">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495187657553" FOLDED="true" ID="ID_758943804" MODIFIED="1497582684765">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    &lt;? super T&gt;
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495187587117" ID="ID_1091615003" MODIFIED="1495187708191" TEXT="&#x8868;&#x793a;&#x5305;&#x62ec;T&#x5728;&#x5185;&#x7684;T&#x7684;&#x4efb;&#x4f55;&#x7236;&#x7c7b;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684802" FOLDED="true" ID="ID_980011386" MODIFIED="1497582684765" TEXT="&#x6ce8;&#x610f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684802" ID="ID_455095003" MODIFIED="1473598715298" TEXT="&#x51e1;&#x662f;&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x90fd;&#x4e0d;&#x53ef;&#x4ee5;&#x4f5c;&#x4e3a;&#x6cdb;&#x578b;&#x7684;&#x53c2;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="flag"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473598684768" FOLDED="true" ID="55t1gf4br57tu3ve4ut33e3rpi" MODIFIED="1517293911283" POSITION="right" TEXT="List">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473598684769" ID="ID_1562757393" MODIFIED="1500607647438" TEXT="ArrayList">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684769" ID="ID_719071494" MODIFIED="1500544857975" TEXT="&#x7279;&#x6027;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684769" ID="ID_353705244" MODIFIED="1473598714817" TEXT="&#x5728;&#x5143;&#x7d20;&#x4e4b;&#x95f4;&#x63d2;&#x5165;&#x5143;&#x7d20;&#x4e0e;&#x5220;&#x9664;&#x5143;&#x7d20;&#x7684;&#x901f;&#x5ea6;&#x76f8;&#x5bf9;&#x8f83;&#x6162;&#xff0c;&#x4ee3;&#x4ef7;&#x9ad8;&#x6602; P225"/>
<node COLOR="#111111" CREATED="1473598684769" ID="ID_335574734" MODIFIED="1473598714818" TEXT="&#x968f;&#x673a;&#x8bbf;&#x95ee;&#x5143;&#x7d20;&#x901f;&#x5ea6;&#x5feb;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684769" FOLDED="true" ID="ID_658999938" MODIFIED="1500607710254" TEXT="&#x516c;&#x7528;&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684769" ID="ID_973927486" MODIFIED="1473598714819" TEXT="boolean add(E e) ">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
</node>
<node COLOR="#990000" CREATED="1473598684769" ID="ID_1559390051" MODIFIED="1473598714819" TEXT="add(int index, E element)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684769" ID="ID_389738619" MODIFIED="1473598714819" TEXT="addAll(Collection&lt;? extends E&gt; c)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684769" ID="ID_273611979" MODIFIED="1473598714822" TEXT="boolean addAll(int index, Collection&lt;? extends E&gt; c)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684769" FOLDED="true" ID="ID_1167811728" MODIFIED="1497582684781" TEXT="E remove(int index)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684769" ID="ID_1208998828" MODIFIED="1473598714822" TEXT="// &#x5207;&#x8bb0;&#x6cdb;&#x578b;&#x662f;Integer&#x7c7b;&#x578b;&#x65f6;&#xff0c;&#x8c03;&#x7528; remove&#x65b9;&#x6cd5;&#x6240;&#x4f20;&#x5165;&#x7684;&#x53c2;&#x6570;&#x7c7b;&#x578b;&#xd;&#xa;        list.remove(new Integer(99));&#xd;&#xa;        list.remove(99);//&#x6570;&#x7ec4;&#x8d8a;&#x754c;"/>
</node>
<node COLOR="#990000" CREATED="1473598684769" ID="ID_201438785" MODIFIED="1473598714832" TEXT="boolean remove(Object o)">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_703709576" MODIFIED="1473598714838" TEXT="clear()">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1269626348" MODIFIED="1473598714838" TEXT="E get(int index)">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_347934661" MODIFIED="1473598714838" TEXT="boolean isEmpty()">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1766800856" MODIFIED="1473598714839" TEXT="int size()">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1849904545" MODIFIED="1473598714839" TEXT="boolean removeAll(Collection&lt;?&gt; c)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1488067833" MODIFIED="1473598714839" TEXT="boolean contains(Object o)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1726491303" MODIFIED="1473598714840" TEXT="int indexOf(Object o)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1440264894" MODIFIED="1473598714840" TEXT="Iterator&lt;E&gt; iterator()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_909681188" MODIFIED="1473598714840" TEXT="ListIterator&lt;E&gt; listIterator()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1238098214" MODIFIED="1473598714840" TEXT="E set(int index, E element)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_1668460145" MODIFIED="1473598714841" TEXT="List&lt;E&gt; subList(int fromIndex, int toIndex)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684770" ID="ID_544409095" MODIFIED="1473598714841" TEXT="Object[] toArray() ">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684771" ID="ID_1398313772" MODIFIED="1473598714859" TEXT="&lt;T&gt; T[] toArray(T[] a) ">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684771" FOLDED="true" ID="ID_263622250" MODIFIED="1517282789632" TEXT="LinkedList P 228">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684771" ID="ID_270151566" MODIFIED="1500607698112" TEXT="&#x7279;&#x6027;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_1306323681" MODIFIED="1473598714861" TEXT="&#x5728;&#x5143;&#x7d20;&#x4e4b;&#x95f4;&#x63d2;&#x5165;&#x5143;&#x7d20;&#x4e0e;&#x5220;&#x9664;&#x5143;&#x7d20;&#x7684;&#x901f;&#x5ea6;&#x76f8;&#x5bf9;&#x8f83;&#x5feb;"/>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_283616209" MODIFIED="1473598714862" TEXT="&#x968f;&#x673a;&#x8bbf;&#x95ee;&#x7a0d;&#x900a;&#x8272;"/>
</node>
<node COLOR="#990000" CREATED="1473598684771" ID="ID_1321666339" MODIFIED="1517221669224" TEXT="&#x4e13;&#x5c5e;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_1052267737" MODIFIED="1473598714862" TEXT="void addFirst(E e)"/>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_214971528" MODIFIED="1473598714862" TEXT="void addLast(E e)"/>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_246658417" MODIFIED="1517221672165" TEXT="E element()">
<node COLOR="#111111" CREATED="1473598684771" ID="ID_901795240" MODIFIED="1473598714863" TEXT="Retrieves, but does not remove, the head (first element) of this list."/>
</node>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_1703658008" MODIFIED="1500607801514" TEXT="E poll()">
<node COLOR="#111111" CREATED="1473598684771" ID="ID_1917241707" MODIFIED="1473598714863" TEXT="Retrieves and removes the head (first element) of this list."/>
</node>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_1330733187" MODIFIED="1473598714863" TEXT="E getFirst()"/>
<node COLOR="#111111" CREATED="1473598684771" ID="ID_1947448944" MODIFIED="1517221677004" TEXT="E getLast()">
<node COLOR="#111111" CREATED="1473598684771" ID="ID_1308791395" MODIFIED="1473598714864" TEXT="Returns the last element in this list."/>
</node>
<node COLOR="#111111" CREATED="1473598684772" ID="ID_257721990" MODIFIED="1500607774914" TEXT="E peek()">
<node COLOR="#111111" CREATED="1473598684772" ID="ID_1671767111" MODIFIED="1473598714864" TEXT="Retrieves, but does not remove, the head (first element) of this list."/>
</node>
<node COLOR="#111111" CREATED="1473598684772" ID="ID_1089868209" MODIFIED="1473598714864" TEXT="&#x5176;&#x4ed6;&#xff0c;&#x53c2;&#x8003;&#x6e90;&#x7801;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598684772" FOLDED="true" ID="ID_759776289" MODIFIED="1500544867038" TEXT="&#x5982;&#x4f55;&#x9009;&#x62e9;List&#xff1f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473598684773" ID="ID_1598186566" MODIFIED="1473598714865" TEXT="&#x6839;&#x636e;&#x7279;&#x6027;&#x548c;&#x5177;&#x4f53;&#x7684;&#x64cd;&#x4f5c;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473598684773" ID="ID_1926692903" MODIFIED="1473598714866" TEXT=" List &#x7684;&#x9009;&#x62e9;  P 502">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
