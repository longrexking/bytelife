package com.longcheng.mvpseconddemo.presenter;

/**
 * Created by LongWH on 2016/9/28.
 * All Rights Reserved by ZhiYou @2016 - 2017
 */
public interface IViewSuccess<T> {
    /**
     * @param data ：成功后的数据
     */
    void onSuccess(T data);

}
