package com.longcheng.mvpseconddemo.presenter;

/**
 * Created by LongWH on 2016/9/27.
 * All Rights Reserved by ZhiYou @2016 - 2017
 */
public interface IView<T> extends IViewBase<T> {
    void onStart(int textId);
}
