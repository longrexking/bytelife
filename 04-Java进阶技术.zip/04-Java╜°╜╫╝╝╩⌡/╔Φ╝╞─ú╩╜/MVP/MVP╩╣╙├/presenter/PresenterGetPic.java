package com.longcheng.mvpseconddemo.presenter;


import com.longcheng.mvpseconddemo.model.IAction;
import com.longcheng.mvpseconddemo.model.IActionSuccess;
import com.longcheng.mvpseconddemo.model.ModeGetPic;

import java.io.File;
import java.util.List;

/**
 * Created by LongWH on 2016/9/27.
 * All Rights Reserved by ZhiYou @2016 - 2017
 */
public class PresenterGetPic {
    private ModeGetPic mModeGetPic;
    private IView mIView;

    public PresenterGetPic(IView IView) {
        mIView = IView;
        mModeGetPic = new ModeGetPic(new MyAction());
    }

    /**获取图片文件集合
     * @param viewSuccess ：成功后的回调接口
     */
    public void getPicList(final IViewSuccess<List<File>> viewSuccess) {
      mModeGetPic.getPicList(new IActionSuccess<List<File>>() {
          @Override
          public void success(List<File> data) {
              viewSuccess.onSuccess(data);
          }
      });
    }

    /**获取txt文件的集合
     * @param success ：
     */
    public void getTxtList(final IViewSuccess<List<File>> success) {
        mModeGetPic.getTxtList(new IActionSuccess<List<File>>() {
            @Override
            public void success(List<File> data) {
                success.onSuccess(data);
            }
        });
    }


    private class MyAction implements
            IAction {
        @Override
        public void onStart(int textId) {
            if (mIView != null) {
                mIView.onStart(textId);
            }
        }

        @Override
        public void fail(int textId) {
            if (mIView != null) {
                mIView.onFail(textId);
            }
        }

        @Override
        public void error(String error) {
            if (mIView != null) {
                mIView.onError(error);
            }
        }
    }
}
