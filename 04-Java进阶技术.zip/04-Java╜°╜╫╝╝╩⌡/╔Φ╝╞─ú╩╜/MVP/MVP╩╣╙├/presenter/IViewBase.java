package com.longcheng.mvpseconddemo.presenter;

/**
 * Created by LongWH on 2016/9/27.
 * All Rights Reserved by ZhiYou @2016 - 2017
 *
 * 该接口处理Presenter中Model层的数据的转换
 * （Mode通过IAction把数据抛给Presenter），然后
 * Presenter通过该接口 IViewBase把数据抛给Activity
 * 或Fragment（也就是MVP 中的View层）
 */
public interface IViewBase<T> {

    void onFail(int textId);

    void onError(String msg);
}
