package com.longcheng.mvpseconddemo.model;

/**
 * Created by LongWH on 2016/9/27.
 * All Rights Reserved by ZhiYou @2016 - 2017
 */
public interface IActionBase {

    /**失败
     * @param textId ：失败后显示的内容
     */
    void fail(int textId);

    /**出错后需要显示的内容
     * @param error ：出错后提示的信息
     */
    void error(String error);
}
