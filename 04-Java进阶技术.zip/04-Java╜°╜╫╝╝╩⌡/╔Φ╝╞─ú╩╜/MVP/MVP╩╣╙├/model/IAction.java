package com.longcheng.mvpseconddemo.model;

/**
 * Created by LongWH on 2016/9/27.
 * All Rights Reserved by ZhiYou @2016 - 2017
 */
public interface IAction extends IActionBase {
    /**当操作准备开始时调用
     * @param textId :
     */
    void onStart(int textId);
}
