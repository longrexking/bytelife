package com.longcheng.mvpseconddemo.model;

/**
 * Created by LongWH on 2016/9/28.
 * All Rights Reserved by ZhiYou @2016 - 2017
 * Mode中的逻辑代码执行成功后，使用该接口把数据抛到
 * Presenter层
 */
public interface IActionSuccess<T> {
    /**成功
     * @param data :成功之后返回的数据
     */
    void success(T data);
}
