package com.longcheng.mvpseconddemo.model;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.longcheng.mvpseconddemo.R;
import com.longcheng.mvpseconddemo.utils.CommonUtils;
import com.longcheng.mvpseconddemo.utils.PathUtils;
import com.longcheng.mvpseconddemo.utils.WorkFactory;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by LongWH on 2016/9/27.
 * All Rights Reserved by ZhiYou @2016 - 2017
 * 用来处理获取图片的业务逻辑层的类
 */
public class ModeGetPic {
    private final String mTag = getClass().getName();
    /**
     * 操作结束后通过IAction 和Presenter交互
     */
    private IAction mIAction;
    /**
     * 保存图片文件的集合
     */
    private List<File> mPicList = new ArrayList<>();

    /**
     * txt文件的集合
     */
    private List<File> mTxtList = new ArrayList<>();

    /**
     * Handler来接收子线程发送的消息，通知主线程任务结束。
     */
    private Handler mHandler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            return true;
        }
    });

    public ModeGetPic(IAction IAction) {
        mIAction = IAction;
    }

    /**
     * 获取图片，用来和Presenter交互的
     */
    public void getPicList(final IActionSuccess<List<File>> actionSuccess) {
        //开始执行任务
        mIAction.onStart(R.string.onLoadingPic);
        //获取手机存储的根目录
        final File root = PathUtils.getRootFile();
        //判断根目录是否为null 或者是否不存在
        if (root == null || !root.exists()) {
            //如果不存在，则fail
            mIAction.fail(R.string.actionFail);
            return;
        }
        WorkFactory.instance().getService().submit(new Runnable() {
            @Override
            public void run() {
                //执行遍历图片
                searchPic(root);
                //结束后发送消息到主线程: Handler 的post()指的是：
                //mHandler 在哪个线程被初始化，post()方法就会在哪个
                //线程中执行
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        actionSuccess.success(mPicList);
                    }
                });
            }
        });
    }


    /**获取txt文件
     * @param actionSuccess :
     */
    public void getTxtList(final IActionSuccess<List<File>> actionSuccess) {
        //开始执行任务
        mIAction.onStart(R.string.onLoadingTxt);
        //获取手机存储的根目录
        final File root = PathUtils.getRootFile();
        //判断根目录是否为null 或者是否不存在
        if (root == null || !root.exists()) {
            //如果不存在，则fail
            mIAction.fail(R.string.actionFail);
            return;
        }
        WorkFactory.instance().getService().submit(new Runnable() {
            @Override
            public void run() {
                //执行遍历图片
                searchTxt(root);
                //结束后发送消息到主线程: Handler 的post()指的是：
                //mHandler 在哪个线程被初始化，post()方法就会在哪个
                //线程中执行
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        actionSuccess.success(mTxtList);
                    }
                });
            }
        });
    }

    /**搜索手机中的图片文件
     * @param root ： 被搜索的文件夹
     */
    private void searchPic(File root) {
        searchFile(root,0);
    }

    private void searchTxt(File root) {
        searchFile(root,1);
    }


    /**通过传入的what的值来遍历不同类型的文件
     * @param root ：
     * @param what ： 0 代表图片文件，1 代表txt文件
     */
    private void searchFile(File root, final int what) {
        if (root == null || !root.isDirectory()) {
            Log.w(mTag, "Warning searchPic---> root is null or is not a Directory ");
            return;
        }
        File[] files = root.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                switch (what) {
                    case 0: //0 代表获取pic
                        if (CommonUtils.isPic(file)) {
                            mPicList.add(file);
                        }
                        break;
                    case 1://代表txt文件
                        if (CommonUtils.isTxt(file)) {
                            mTxtList.add(file);
                        }
                        break;
                }
                return true;
            }
        });
        for (File f :files) {
            if (f.isDirectory()) {
                searchFile(f,what);
            }
        }
    }


}
