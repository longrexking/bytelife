import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Administrator on 2016/9/10.
 *
 */
public class TestConsumerProducer {
    private int mOrderNum = 0;
    public static void main(String[] args) {
        new TestConsumerProducer().new Restaurant().running();
    }

    private class Restaurant{
        ExecutorService service = Executors.newCachedThreadPool();
        private Meal mMeal;
        private final Consumer mConsumer = new Consumer(this);
        private final Producer mProducer = new Producer(this);

         Restaurant() {

        }

        private void running() {
                service.execute(mConsumer);
                service.execute(mProducer);
        }
    }

    private class Consumer implements Runnable{

        private Restaurant mRestaurant;

         Consumer(Restaurant restaurant) {
            mRestaurant = restaurant;
        }
 
        @Override
        public void run() {

            try {
                while (!Thread.interrupted()) {
                    synchronized (this) {

                        if (mRestaurant.mMeal == null) {
                            wait();
                        }
                    }
                    System.out.println("东西吃完啦");
                    synchronized (mRestaurant.mProducer) {
                        mRestaurant.mMeal = null;
                        mRestaurant.mProducer.notify();
                    }
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private class Producer implements Runnable{
        private Restaurant mRestaurant;

         Producer(Restaurant restaurant) {
            mRestaurant = restaurant;
        }

        @Override
        public void run() {
            try {
                while (!Thread.interrupted()) {
                    synchronized (this) {
                        if (mRestaurant.mMeal != null) {
                            wait();
                        }
                    }
                    if (mOrderNum > 10) {
                        mRestaurant.service.shutdownNow();
                    }
                    System.out.println("东西有啦");
                    synchronized (mRestaurant.mConsumer) {
                        mRestaurant.mMeal = new Meal(++mOrderNum);
                        mRestaurant.mConsumer.notify();
                    }
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private class Meal{
        private final int mOrderNum;

         Meal(int orderNum) {
            mOrderNum = orderNum;
        }

        @Override
        public String toString() {
            return "Meal{" +
                    "mOrderNum=" + mOrderNum +
                    '}';
        }
    }
}
