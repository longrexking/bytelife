<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1472778583080" ID="ID_1786379408" MODIFIED="1529657528257" TEXT="Java&#x8fdb;&#x9636;&#x6280;&#x672f;">
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1474807792668" FOLDED="true" ID="ID_502733012" MODIFIED="1529657527920" POSITION="left" TEXT="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;(&#x975e;&#x5e38;&#x91cd;&#x8981;)">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_ok"/>
<node COLOR="#00b439" CREATED="1474821696376" FOLDED="true" ID="ID_750140124" MODIFIED="1529657527920" TEXT="MVP &#x4e0e;MVC">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1474807806154" FOLDED="true" ID="ID_1681441821" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVC/mvc.png" MODIFIED="1529657527917" TEXT="MVC">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474821562571" ID="ID_954426392" MODIFIED="1474821708518" TEXT="&#xff1f;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1474821615010" FOLDED="true" ID="ID_148977520" MODIFIED="1529657527916" TEXT="&#x610f;&#x601d;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1474821564284" ID="ID_597218117" MODIFIED="1474821564284" TEXT="Model&#xff1a;&#x4e1a;&#x52a1;&#x903b;&#x8f91;&#x548c;&#x5b9e;&#x4f53;&#x6a21;&#x578b;"/>
<node COLOR="#111111" CREATED="1474821564286" ID="ID_830980956" MODIFIED="1474821564286" TEXT="View&#xff1a;&#x5bf9;&#x5e94;&#x4e8e;&#x5e03;&#x5c40;&#x6587;&#x4ef6;"/>
<node COLOR="#111111" CREATED="1474821564287" ID="ID_607607014" MODIFIED="1474821564287" TEXT="Controllor&#xff1a;&#x5bf9;&#x5e94;&#x4e8e;Activity"/>
</node>
</node>
<node COLOR="#990000" CREATED="1474807812137" FOLDED="true" ID="ID_1991543811" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP/mvp.png" MODIFIED="1529657527918" TEXT="MVP">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474821591551" FOLDED="true" ID="ID_1317248275" MODIFIED="1529657527918" TEXT="&#xff1f;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1474821594598" ID="ID_1979662729" MODIFIED="1474821594598" TEXT="&#x8ba9;Model&#x548c;View&#x5b8c;&#x5168;&#x89e3;&#x8026;"/>
</node>
<node COLOR="#111111" CREATED="1474821596879" FOLDED="true" ID="ID_1495826891" MODIFIED="1529657527918" TEXT="&#x610f;&#x601d;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1474821612228" ID="ID_760120367" MODIFIED="1474821612228" TEXT="Model &#x4f9d;&#x7136;&#x662f;&#x4e1a;&#x52a1;&#x903b;&#x8f91;&#x548c;&#x5b9e;&#x4f53;&#x6a21;&#x578b;"/>
<node COLOR="#111111" CREATED="1474821612229" ID="ID_1541693671" MODIFIED="1474821612229" TEXT="View &#x5bf9;&#x5e94;&#x4e8e;Activity&#xff0c;&#x8d1f;&#x8d23;View&#x7684;&#x7ed8;&#x5236;&#x4ee5;&#x53ca;&#x4e0e;&#x7528;&#x6237;&#x4ea4;&#x4e92;"/>
<node COLOR="#111111" CREATED="1474821612231" ID="ID_505984146" MODIFIED="1474821612231" TEXT="Presenter &#x8d1f;&#x8d23;&#x5b8c;&#x6210;View&#x4e8e;Model&#x95f4;&#x7684;&#x4ea4;&#x4e92;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1474821647191" FOLDED="true" ID="ID_1978967149" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/mvp&#x4e0e;mvc&#x5bf9;&#x6bd4;.png" MODIFIED="1529657527918" TEXT="&#x4e8c;&#x8005;&#x533a;&#x522b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474821652247" ID="ID_19819284" MODIFIED="1474821708527" TEXT="MVC&#x4e2d;&#x662f;&#x5141;&#x8bb8;Model&#x548c;View&#x8fdb;&#x884c;&#x4ea4;&#x4e92;&#x7684;&#xff0c;&#x800c;MVP&#x4e2d;&#x5f88;&#x660e;&#x663e;&#xff0c;Model&#x4e0e;View&#x4e4b;&#x95f4;&#x7684;&#x4ea4;&#x4e92;&#x7531;Presenter&#x5b8c;&#x6210;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1474821660109" ID="ID_1129569539" MODIFIED="1474943980538" TEXT="&#x5c31;&#x662f;Presenter&#x4e0e;View&#x4e4b;&#x95f4;&#x7684;&#x4ea4;&#x4e92;&#x662f;&#x901a;&#x8fc7;&#x63a5;&#x53e3;&#x7684;&#xff08;&#x4ee3;&#x7801;&#x4e2d;&#x4f1a;&#x4f53;&#x73b0;)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1475053605460" FOLDED="true" ID="ID_64001717" MODIFIED="1529657527919" TEXT="&#x4f7f;&#x7528;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475053611394" ID="ID_480762021" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP&#x548c;Mode&#x4ee5;&#x53ca;UI&#x5c42;&#x7684;&#x4ea4;&#x4e92;&#x6d41;&#x7a0b;.png" MODIFIED="1475053642941" TEXT="&#x9644;&#x4ef6;"/>
<node COLOR="#111111" CREATED="1475060969723" FOLDED="true" ID="ID_925605644" MODIFIED="1529657527919" TEXT="Model&#x5c42;">
<node COLOR="#111111" CREATED="1475060980804" ID="ID_1611774151" MODIFIED="1475060983942" TEXT="Mode"/>
<node COLOR="#111111" CREATED="1475060984665" ID="ID_1094888929" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP/MVP&#x4f7f;&#x7528;/model/IActionBase.java" MODIFIED="1475061307228" TEXT="IActionBase"/>
<node COLOR="#111111" CREATED="1475061032506" ID="ID_776487154" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP/MVP&#x4f7f;&#x7528;/model/IAction.java" MODIFIED="1475061324654" TEXT="IAction"/>
<node COLOR="#111111" CREATED="1475061045025" ID="ID_60200477" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP/MVP&#x4f7f;&#x7528;/model/IActionSuccess.java" MODIFIED="1475061329560" TEXT="IActionSuccess&lt;T&gt;"/>
</node>
<node COLOR="#111111" CREATED="1475061067107" FOLDED="true" ID="ID_163173419" MODIFIED="1529657527919" TEXT="Presenter&#x5c42;">
<node COLOR="#111111" CREATED="1475061075819" ID="ID_1653656191" MODIFIED="1475061080626" TEXT="Presenter"/>
<node COLOR="#111111" CREATED="1475061091653" ID="ID_540822008" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP/MVP&#x4f7f;&#x7528;/presenter/IViewBase.java" MODIFIED="1475061340781" TEXT="IViewBase"/>
<node COLOR="#111111" CREATED="1475061116621" ID="ID_1469325110" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP/MVP&#x4f7f;&#x7528;/presenter/IView.java" MODIFIED="1475061345344" TEXT="IView"/>
<node COLOR="#111111" CREATED="1475061120701" ID="ID_675331581" LINK="&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;/MVP/MVP&#x4f7f;&#x7528;/presenter/IViewSuccess.java" MODIFIED="1475061349766" TEXT="IViewSuccess&lt;T&gt;"/>
</node>
<node COLOR="#111111" CREATED="1475061356909" FOLDED="true" ID="ID_1307648114" MODIFIED="1529657527919" TEXT="View&#x5c42;">
<node COLOR="#111111" CREATED="1475061389084" ID="ID_1209672857" MODIFIED="1475061395498" TEXT="&#x6301;&#x6709;Presenter"/>
<node COLOR="#111111" CREATED="1475061395894" ID="ID_1388518141" MODIFIED="1475061402947" TEXT="&#x5b9e;&#x73b0;IView&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1475061403889" ID="ID_1350788621" MODIFIED="1475061413688" TEXT="&#x8c03;&#x7528;Presenter&#x7c7b;&#x4e2d;&#x7684;&#x65b9;&#x6cd5;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1475455100365" FOLDED="true" ID="ID_1487430547" MODIFIED="1529657527928" POSITION="left" TEXT="&#x6570;&#x636e;&#x89e3;&#x6790;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1474430939340" FOLDED="true" ID="ID_1850646032" MODIFIED="1529657527921" TEXT="Json&#x6570;&#x636e;&#x89e3;&#x6790;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1474553187800" FOLDED="true" ID="ID_664675291" MODIFIED="1529657527920" TEXT="&#x57fa;&#x7840;&#x7684;&#x89e3;&#x6790;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474553197212" FOLDED="true" ID="ID_299403094" MODIFIED="1529657527920" TEXT="FastJson">
<node COLOR="#111111" CREATED="1474430946270" ID="ID_793815171" MODIFIED="1474553220702" TEXT="&#x89e3;&#x6790;JsonObject">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1474430964250" ID="ID_109318066" MODIFIED="1474553220713" TEXT="&#x89e3;&#x6790;JsonArray">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474553202966" FOLDED="true" ID="ID_655127017" MODIFIED="1529657527920" TEXT="Gson">
<node COLOR="#111111" CREATED="1474430946270" ID="ID_423006049" MODIFIED="1474553221934" TEXT="&#x89e3;&#x6790;JsonObject">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1474430964250" ID="ID_1056769337" MODIFIED="1474553221937" TEXT="&#x89e3;&#x6790;JsonArray">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474553210565" FOLDED="true" ID="ID_441625828" MODIFIED="1529657527920" TEXT="&#x7cfb;&#x7edf;&#x81ea;&#x5e26;">
<node COLOR="#111111" CREATED="1474430946270" ID="ID_1951971566" MODIFIED="1474553223036" TEXT="&#x89e3;&#x6790;JsonObject">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1474430964250" ID="ID_695711911" MODIFIED="1474553223041" TEXT="&#x89e3;&#x6790;JsonArray">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1474814934902" FOLDED="true" ID="ID_1470394698" MODIFIED="1529657527921" TEXT="&#x9ad8;&#x7ea7;&#x89e3;&#x6790;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474824294998" ID="ID_228333117" LINK="Json&#x89e3;&#x6790;/&#x4f7f;&#x7528;FastJson/FastJsonUtils.java" MODIFIED="1495845282447" TEXT="FastJson&#x89e3;&#x6790;"/>
<node COLOR="#111111" CREATED="1474824303086" ID="ID_1677959728" LINK="Json&#x89e3;&#x6790;/&#x4f7f;&#x7528;Gson/GsonTools.java" MODIFIED="1474824313658" TEXT="Gson&#x89e3;&#x6790;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1475455120672" FOLDED="true" ID="ID_583452735" MODIFIED="1529657527928" TEXT="xml&#x89e3;&#x6790;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="stop-sign"/>
<node COLOR="#990000" CREATED="1475456545133" FOLDED="true" ID="ID_563023623" MODIFIED="1529657527921" TEXT="&#x6574;&#x4f53;&#x6bd4;&#x8f83;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475456553927" ID="ID_1189337375" MODIFIED="1475456553928" TEXT="1. DOM4J&#x6027;&#x80fd;&#x6700;&#x597d;&#xff0c;&#x8fde;Sun&#x7684;JAXM&#x4e5f;&#x5728;&#x7528;DOM4J&#x3002;&#x76ee;&#x524d;&#x8bb8;&#x591a;&#x5f00;&#x6e90;&#x9879;&#x76ee;&#x4e2d;&#x5927;&#x91cf;&#x91c7;&#x7528;DOM4J&#xff0c;&#x4f8b;&#x5982;&#x5927;&#x540d;&#x9f0e;&#x9f0e;&#x7684;Hibernate&#x4e5f;&#x7528;DOM4J&#x6765;&#x8bfb;&#x53d6;XML&#x914d;&#x7f6e;&#x6587;&#x4ef6;&#x3002;&#x5982;&#x679c;&#x4e0d;&#x8003;&#x8651;&#x53ef;&#x79fb;&#x690d;&#x6027;&#xff0c;&#x90a3;&#x5c31;&#x91c7;&#x7528;DOM4J."/>
<node COLOR="#111111" CREATED="1475456553942" ID="ID_197720981" MODIFIED="1475456553946" TEXT="2. JDOM&#x548c;DOM&#x5728;&#x6027;&#x80fd;&#x6d4b;&#x8bd5;&#x65f6;&#x8868;&#x73b0;&#x4e0d;&#x4f73;&#xff0c;&#x5728;&#x6d4b;&#x8bd5;10M&#x6587;&#x6863;&#x65f6;&#x5185;&#x5b58;&#x6ea2;&#x51fa;&#xff0c;&#x4f46;&#x53ef;&#x79fb;&#x690d;&#x3002;&#x5728;&#x5c0f;&#x6587;&#x6863;&#x60c5;&#x51b5;&#x4e0b;&#x8fd8;&#x503c;&#x5f97;&#x8003;&#x8651;&#x4f7f;&#x7528;DOM&#x548c;JDOM.&#x867d;&#x7136;JDOM&#x7684;&#x5f00;&#x53d1;&#x8005;&#x5df2;&#x7ecf;&#x8bf4;&#x660e;&#x4ed6;&#x4eec;&#x671f;&#x671b;&#x5728;&#x6b63;&#x5f0f;&#x53d1;&#x884c;&#x7248;&#x524d;&#x4e13;&#x6ce8;&#x6027;&#x80fd;&#x95ee;&#x9898;&#xff0c;&#x4f46;&#x662f;&#x4ece;&#x6027;&#x80fd;&#x89c2;&#x70b9;&#x6765;&#x770b;&#xff0c;&#x5b83;&#x786e;&#x5b9e;&#x6ca1;&#x6709;&#x503c;&#x5f97;&#x63a8;&#x8350;&#x4e4b;&#x5904;&#x3002;&#x53e6;&#x5916;&#xff0c;DOM&#x4ecd;&#x662f;&#x4e00;&#x4e2a;&#x975e;&#x5e38;&#x597d;&#x7684;&#x9009;&#x62e9;&#x3002;DOM&#x5b9e;&#x73b0;&#x5e7f;&#x6cdb;&#x5e94;&#x7528;&#x4e8e;&#x591a;&#x79cd;&#x7f16;&#x7a0b;&#x8bed;&#x8a00;&#x3002;&#x5b83;&#x8fd8;&#x662f;&#x8bb8;&#x591a;&#x5176;&#x5b83;&#x4e0e;XML&#x76f8;&#x5173;&#x7684;&#x6807;&#x51c6;&#x7684;&#x57fa;&#x7840;&#xff0c;&#x56e0;&#x4e3a;&#x5b83;&#x6b63;&#x5f0f;&#x83b7;&#x5f97;W3C&#x63a8;&#x8350;&#xff08;&#x4e0e;&#x57fa;&#x4e8e;&#x975e;&#x6807;&#x51c6;&#x7684;Java&#x6a21;&#x578b;&#x76f8;&#x5bf9;&#xff09;&#xff0c;&#x6240;&#x4ee5;&#x5728;&#x67d0;&#x4e9b;&#x7c7b;&#x578b;&#x7684;&#x9879;&#x76ee;&#x4e2d;&#x53ef;&#x80fd;&#x4e5f;&#x9700;&#x8981;&#x5b83;&#xff08;&#x5982;&#x5728;JavaScript&#x4e2d;&#x4f7f;&#x7528;DOM&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456553961" ID="ID_1359460903" MODIFIED="1475456553962" TEXT="3. SAX&#x8868;&#x73b0;&#x8f83;&#x597d;&#xff0c;&#x8fd9;&#x8981;&#x4f9d;&#x8d56;&#x4e8e;&#x5b83;&#x7279;&#x5b9a;&#x7684;&#x89e3;&#x6790;&#x65b9;&#x5f0f;&#xff0d;&#x4e8b;&#x4ef6;&#x9a71;&#x52a8;&#x3002;&#x4e00;&#x4e2a;SAX&#x68c0;&#x6d4b;&#x5373;&#x5c06;&#x5230;&#x6765;&#x7684;XML&#x6d41;&#xff0c;&#x4f46;&#x5e76;&#x6ca1;&#x6709;&#x8f7d;&#x5165;&#x5230;&#x5185;&#x5b58;&#xff08;&#x5f53;&#x7136;&#x5f53;XML&#x6d41;&#x88ab;&#x8bfb;&#x5165;&#x65f6;&#xff0c;&#x4f1a;&#x6709;&#x90e8;&#x5206;&#x6587;&#x6863;&#x6682;&#x65f6;&#x9690;&#x85cf;&#x5728;&#x5185;&#x5b58;&#x4e2d;&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456553973" ID="ID_47415565" MODIFIED="1475456603641" TEXT="&#x539f;&#x5219;&#xff1a;&#x5982;&#x679c;XML&#x6587;&#x6863;&#x8f83;&#x5927;&#x4e14;&#x4e0d;&#x8003;&#x8651;&#x79fb;&#x690d;&#x6027;&#x95ee;&#x9898;&#x5efa;&#x8bae;&#x91c7;&#x7528;DOM4J&#xff1b;&#x5982;&#x679c;XML&#x6587;&#x6863;&#x8f83;&#x5c0f;&#x5219;&#x5efa;&#x8bae;&#x91c7;&#x7528;JDOM&#xff1b;&#x5982;&#x679c;&#x9700;&#x8981;&#x53ca;&#x65f6;&#x5904;&#x7406;&#x800c;&#x4e0d;&#x9700;&#x8981;&#x4fdd;&#x5b58;&#x6570;&#x636e;&#x5219;&#x8003;&#x8651;SAX&#x3002;&#x4f46;&#x65e0;&#x8bba;&#x5982;&#x4f55;&#xff0c;&#x8fd8;&#x662f;&#x90a3;&#x53e5;&#x8bdd;&#xff1a;&#x9002;&#x5408;&#x81ea;&#x5df1;&#x7684;&#x624d;&#x662f;&#x6700;&#x597d;&#x7684;&#xff0c;&#x5982;&#x679c;&#x65f6;&#x95f4;&#x5141;&#x8bb8;&#xff0c;&#x5efa;&#x8bae;&#x5927;&#x5bb6;&#x8bb2;&#x8fd9;&#x56db;&#x79cd;&#x65b9;&#x6cd5;&#x90fd;&#x5c1d;&#x8bd5;&#x4e00;&#x904d;&#x7136;&#x540e;&#x9009;&#x62e9;&#x4e00;&#x79cd;&#x9002;&#x5408;&#x81ea;&#x5df1;&#x7684;&#x5373;&#x53ef;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475460551611" FOLDED="true" ID="ID_291174374" MODIFIED="1529657527923" TEXT="Java&#x4e2d;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455252490" FOLDED="true" ID="ID_418137990" MODIFIED="1529657527921" TEXT="Dom">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1475455637166" FOLDED="true" ID="ID_1344135685" MODIFIED="1529657527921" TEXT="&#x7279;&#x70b9;">
<node COLOR="#111111" CREATED="1475455265543" ID="ID_414642553" MODIFIED="1475455278122" TEXT="&#x52a0;&#x8f7d;&#x6574;&#x4e2a;&#x6587;&#x6863;&#x6811;&#x5230;&#x5185;&#x5b58;&#x4e2d;"/>
<node COLOR="#111111" CREATED="1475455278507" ID="ID_129445874" MODIFIED="1475455282529" TEXT="&#x975e;&#x5e38;&#x8017;&#x8d39;&#x5185;&#x5b58;"/>
<node COLOR="#111111" CREATED="1475455482189" ID="ID_1043496805" MODIFIED="1475455482189" TEXT="DOM&#x89e3;&#x6790;&#x5668;&#x5e38;&#x7528;&#x4e8e;XML&#x6587;&#x6863;&#x9700;&#x8981;&#x9891;&#x7e41;&#x7684;&#x6539;&#x53d8;&#x7684;&#x670d;&#x52a1;&#x4e2d;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475455631246" FOLDED="true" ID="ID_1483496277" MODIFIED="1529657527921" TEXT="&#x4f18;&#x70b9;">
<node COLOR="#111111" CREATED="1475455661960" ID="ID_1003245332" MODIFIED="1475455661960" TEXT="&#x2460;&#x5141;&#x8bb8;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x5bf9;&#x6570;&#x636e;&#x548c;&#x7ed3;&#x6784;&#x505a;&#x51fa;&#x66f4;&#x6539;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455661961" ID="ID_585559365" MODIFIED="1475455661961" TEXT="&#x2461;&#x8bbf;&#x95ee;&#x662f;&#x53cc;&#x5411;&#x7684;&#xff0c;&#x53ef;&#x4ee5;&#x5728;&#x4efb;&#x4f55;&#x65f6;&#x5019;&#x5728;&#x6811;&#x4e2d;&#x4e0a;&#x4e0b;&#x5bfc;&#x822a;&#xff0c;&#x83b7;&#x53d6;&#x548c;&#x64cd;&#x4f5c;&#x4efb;&#x610f;&#x90e8;&#x5206;&#x7684;&#x6570;&#x636e;&#xff08;&#x589e;&#x5220;&#x6539;&#x67e5;&#x7684;&#x64cd;&#x4f5c;&#x6bd4;&#x8f83;&#x5bb9;&#x6613;&#xff09;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475455680523" FOLDED="true" ID="ID_1492499702" MODIFIED="1529657527921" TEXT="&#x7f3a;&#x70b9;">
<node COLOR="#111111" CREATED="1475455688519" ID="ID_1756219332" MODIFIED="1475455688520" TEXT="&#x2460;&#x901a;&#x5e38;&#x9700;&#x8981;&#x52a0;&#x8f7d;&#x6574;&#x4e2a;XML&#x6587;&#x6863;&#x6765;&#x6784;&#x9020;&#x5c42;&#x6b21;&#x7ed3;&#x6784;&#xff0c;&#x9700;&#x8981;&#x5c06;&#x6574;&#x4e2a;xml&#x6587;&#x6863;&#x5148;&#x62f7;&#x8d1d;&#x5230;&#x5185;&#x5b58;&#x4e2d;&#xff0c;&#x5982;&#x679c;xml&#x6587;&#x4ef6;&#x8f83;&#x5927;&#x7684;&#x8bdd;&#xff0c;&#x6d88;&#x8017;&#x8d44;&#x6e90;&#x662f;&#x5f88;&#x5927;        &#x7684;&#xff0c;&#x8fd9;&#x4e2a;&#x5bf9;&#x4e8e;Android&#x6765;&#x8bf4;&#x771f;&#x662f;&#x4e2a;&#x5669;&#x68a6;&#x5440;&#xff0c;&#x56e0;&#x4e3a;&#x6709;OOM&#x7684;&#x6050;&#x60e7;&#xff01;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475455881712" FOLDED="true" ID="ID_324431680" MODIFIED="1529657527922" TEXT="JDOM(Java-based Document Object Model)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1475455971220" FOLDED="true" ID="ID_36168509" MODIFIED="1529657527922" TEXT="&#x7279;&#x70b9;">
<node COLOR="#111111" CREATED="1475455897860" ID="ID_1368467341" MODIFIED="1475455897861" TEXT="JDOM&#x7684;&#x76ee;&#x7684;&#x662f;&#x6210;&#x4e3a;Java&#x7279;&#x5b9a;&#x6587;&#x6863;&#x6a21;&#x578b;&#xff0c;&#x5b83;&#x7b80;&#x5316;&#x4e0e;XML&#x7684;&#x4ea4;&#x4e92;&#x5e76;&#x4e14;&#x6bd4;&#x4f7f;&#x7528;DOM&#x5b9e;&#x73b0;&#x66f4;&#x5feb;&#x3002;&#x7531;&#x4e8e;&#x662f;&#x7b2c;&#x4e00;&#x4e2a;Java&#x7279;&#x5b9a;&#x6a21;&#x578b;&#xff0c;JDOM&#x4e00;&#x76f4;&#x5f97;&#x5230;&#x5927;&#x529b;&#x63a8;&#x5e7f;&#x548c;&#x4fc3;&#x8fdb;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455903780" FOLDED="true" ID="ID_1129732718" MODIFIED="1529657527922" TEXT="JDOM&#x4e0e;DOM&#x4e3b;&#x8981;&#x6709;&#x4e24;&#x65b9;&#x9762;&#x4e0d;&#x540c;">
<node COLOR="#111111" CREATED="1475455915448" ID="ID_463783837" MODIFIED="1475455922631" TEXT="&#x9996;&#x5148;&#xff0c;JDOM&#x4ec5;&#x4f7f;&#x7528;&#x5177;&#x4f53;&#x7c7b;&#x800c;&#x4e0d;&#x4f7f;&#x7528;&#x63a5;&#x53e3;&#x3002;&#x8fd9;&#x5728;&#x67d0;&#x4e9b;&#x65b9;&#x9762;&#x7b80;&#x5316;&#x4e86;API&#xff0c;&#x4f46;&#x662f;&#x4e5f;&#x9650;&#x5236;&#x4e86;&#x7075;&#x6d3b;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455923756" ID="ID_323756030" MODIFIED="1475455923756" TEXT="&#x7b2c;&#x4e8c;&#xff0c;API&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;Collections&#x7c7b;&#xff0c;&#x7b80;&#x5316;&#x4e86;&#x90a3;&#x4e9b;&#x5df2;&#x7ecf;&#x719f;&#x6089;&#x8fd9;&#x4e9b;&#x7c7b;&#x7684;Java&#x5f00;&#x53d1;&#x8005;&#x7684;&#x4f7f;&#x7528;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475455940472" ID="ID_1618096853" MODIFIED="1475455940474" TEXT="JDOM&#x81ea;&#x8eab;&#x4e0d;&#x5305;&#x542b;&#x89e3;&#x6790;&#x5668;&#x3002;&#x5b83;&#x901a;&#x5e38;&#x4f7f;&#x7528;SAX2&#x89e3;&#x6790;&#x5668;&#x6765;&#x89e3;&#x6790;&#x548c;&#x9a8c;&#x8bc1;&#x8f93;&#x5165;XML&#x6587;&#x6863;&#xff08;&#x5c3d;&#x7ba1;&#x5b83;&#x8fd8;&#x53ef;&#x4ee5;&#x5c06;&#x4ee5;&#x524d;&#x6784;&#x9020;&#x7684;DOM&#x8868;&#x793a;&#x4f5c;&#x4e3a;&#x8f93;&#x5165;&#xff09;&#x3002;&#x5b83;&#x5305;&#x542b;&#x4e00;&#x4e9b;&#x8f6c;&#x6362;&#x5668;&#x4ee5;&#x5c06;JDOM&#x8868;&#x793a;&#x8f93;&#x51fa;&#x6210;SAX2&#x4e8b;&#x4ef6;&#x6d41;&#x3001;DOM&#x6a21;&#x578b;&#x6216;XML&#x6587;&#x672c;&#x6587;&#x6863;&#x3002;JDOM&#x662f;&#x5728;Apache&#x8bb8;&#x53ef;&#x8bc1;&#x53d8;&#x4f53;&#x4e0b;&#x53d1;&#x5e03;&#x7684;&#x5f00;&#x653e;&#x6e90;&#x7801;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475455961426" FOLDED="true" ID="ID_1910519536" MODIFIED="1529657527922" TEXT="&#x3010;&#x4f18;&#x70b9;&#x3011;">
<node COLOR="#111111" CREATED="1475455961428" ID="ID_1487705299" MODIFIED="1475455961428" TEXT="&#x2460;&#x4f7f;&#x7528;&#x5177;&#x4f53;&#x7c7b;&#x800c;&#x4e0d;&#x662f;&#x63a5;&#x53e3;&#xff0c;&#x7b80;&#x5316;&#x4e86;DOM&#x7684;API&#x3002;"/>
<node COLOR="#111111" CREATED="1475455961429" ID="ID_1680306986" MODIFIED="1475455961429" TEXT="&#x2461;&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;Java&#x96c6;&#x5408;&#x7c7b;&#xff0c;&#x65b9;&#x4fbf;&#x4e86;Java&#x5f00;&#x53d1;&#x4eba;&#x5458;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475455961434" FOLDED="true" ID="ID_574798276" MODIFIED="1529657527922" TEXT="&#x3010;&#x7f3a;&#x70b9;&#x3011;">
<node COLOR="#111111" CREATED="1475455961435" ID="ID_1294682299" MODIFIED="1475455961435" TEXT="&#x2460;&#x6ca1;&#x6709;&#x8f83;&#x597d;&#x7684;&#x7075;&#x6d3b;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455961436" ID="ID_225783818" MODIFIED="1475455961437" TEXT="&#x2461;&#x6027;&#x80fd;&#x8f83;&#x5dee;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475456132171" FOLDED="true" ID="ID_797729397" MODIFIED="1529657527923" TEXT="DOM4J(Document Object Model for Java)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1475456279231" FOLDED="true" ID="ID_611507641" MODIFIED="1529657527922" TEXT="&#x7279;&#x70b9;">
<node COLOR="#111111" CREATED="1475456281784" ID="ID_44332129" MODIFIED="1475456281784" TEXT="DOM4J&#x4f7f;&#x7528;&#x63a5;&#x53e3;&#x548c;&#x62bd;&#x8c61;&#x57fa;&#x672c;&#x7c7b;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1475456288843" ID="ID_1618187084" MODIFIED="1475456288844" TEXT="DOM4J&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;API&#x4e2d;&#x7684;Collections&#x7c7b;&#xff0c;&#x4f46;&#x662f;&#x5728;&#x8bb8;&#x591a;&#x60c5;&#x51b5;&#x4e0b;&#xff0c;&#x5b83;&#x8fd8;&#x63d0;&#x4f9b;&#x4e00;&#x4e9b;&#x66ff;&#x4ee3;&#x65b9;&#x6cd5;&#x4ee5;&#x5141;&#x8bb8;&#x66f4;&#x597d;&#x7684;&#x6027;&#x80fd;&#x6216;&#x66f4;&#x76f4;&#x63a5;&#x7684;&#x7f16;&#x7801;&#x65b9;&#x6cd5;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456293320" ID="ID_1020862076" MODIFIED="1475456293320" TEXT="&#x76f4;&#x63a5;&#x597d;&#x5904;&#x662f;&#xff0c;&#x867d;&#x7136;DOM4J&#x4ed8;&#x51fa;&#x4e86;&#x66f4;&#x590d;&#x6742;&#x7684;API&#x7684;&#x4ee3;&#x4ef7;&#xff0c;&#x4f46;&#x662f;&#x5b83;&#x63d0;&#x4f9b;&#x4e86;&#x6bd4;JDOM&#x5927;&#x5f97;&#x591a;&#x7684;&#x7075;&#x6d3b;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456301864" ID="ID_303877105" MODIFIED="1475456301864" TEXT="&#x9488;&#x5bf9;Java&#x5f00;&#x53d1;&#x8005;&#x7684;&#x6613;&#x7528;&#x6027;&#x548c;&#x76f4;&#x89c2;&#x64cd;&#x4f5c;"/>
<node COLOR="#111111" CREATED="1475456315182" ID="ID_341371052" MODIFIED="1475456315182" TEXT="&#x6027;&#x80fd;&#x4f18;&#x5f02;&#x3001;&#x529f;&#x80fd;&#x5f3a;&#x5927;&#x548c;&#x6781;&#x7aef;&#x6613;&#x7528;&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#111111" CREATED="1475456340907" FOLDED="true" ID="ID_1301630940" MODIFIED="1529657527922" TEXT="&#x3010;&#x4f18;&#x70b9;&#x3011;">
<node COLOR="#111111" CREATED="1475456340908" ID="ID_1648120385" MODIFIED="1475456340909" TEXT="&#x2460;&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;Java&#x96c6;&#x5408;&#x7c7b;&#xff0c;&#x65b9;&#x4fbf;Java&#x5f00;&#x53d1;&#x4eba;&#x5458;&#xff0c;&#x540c;&#x65f6;&#x63d0;&#x4f9b;&#x4e00;&#x4e9b;&#x63d0;&#x9ad8;&#x6027;&#x80fd;&#x7684;&#x66ff;&#x4ee3;&#x65b9;&#x6cd5;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456340910" ID="ID_1564827352" MODIFIED="1475456340910" TEXT="&#x2461;&#x652f;&#x6301;XPath&#x3002;"/>
<node COLOR="#111111" CREATED="1475456340912" ID="ID_1543140641" MODIFIED="1475456340912" TEXT="&#x2462;&#x6709;&#x5f88;&#x597d;&#x7684;&#x6027;&#x80fd;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475456340914" FOLDED="true" ID="ID_1925131956" MODIFIED="1529657527922" TEXT="&#x3010;&#x7f3a;&#x70b9;&#x3011;">
<node COLOR="#111111" CREATED="1475456340916" ID="ID_1569749676" MODIFIED="1475456340916" TEXT="&#x2460;&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;&#x63a5;&#x53e3;&#xff0c;API&#x8f83;&#x4e3a;&#x590d;&#x6742;&#x3002;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1475460555274" FOLDED="true" ID="ID_653419322" MODIFIED="1529657527928" TEXT="Android&#x4e2d;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455283828" FOLDED="true" ID="ID_477534357" MODIFIED="1529657527926" TEXT="SAX&#xff08;Simple API for XML)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1475455312497" FOLDED="true" ID="ID_1021206609" MODIFIED="1529657527923" TEXT="&#x7279;&#x70b9;">
<node COLOR="#111111" CREATED="1475455520547" ID="ID_1332070937" MODIFIED="1475455756558" TEXT="SAX&#x5bf9;&#x5185;&#x5b58;&#x7684;&#x8981;&#x6c42;&#x901a;&#x5e38;&#x4f1a;&#x6bd4;&#x8f83;&#x4f4e;&#xff0c;"/>
<node COLOR="#111111" CREATED="1475455734075" ID="ID_1833462273" MODIFIED="1475455765349" TEXT="&#x5206;&#x6790;&#x80fd;&#x591f;&#x7acb;&#x5373;&#x5f00;&#x59cb;&#xff0c;&#x800c;&#x4e0d;&#x662f;&#x7b49;&#x5f85;&#x6240;&#x6709;&#x7684;&#x6570;&#x636e;&#x88ab;&#x5904;&#x7406;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455316669" ID="ID_504185105" MODIFIED="1475455744357" TEXT="SAX&#x5904;&#x7406;&#x7684;&#x4f18;&#x70b9;&#x975e;&#x5e38;&#x7c7b;&#x4f3c;&#x4e8e;&#x6d41;&#x5a92;&#x4f53;&#x7684;&#x4f18;&#x70b9;&#x3002;&#x4e8b;&#x5b9e;&#x4e0a;&#xff0c;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x751a;&#x81f3;&#x4e0d;&#x5fc5;&#x89e3;&#x6790;&#x6574;&#x4e2a;&#x6587;&#x6863;&#xff1b;&#x5b83;&#x53ef;&#x4ee5;&#x5728;&#x67d0;&#x4e2a;&#x6761;&#x4ef6;&#x5f97;&#x5230;&#x6ee1;&#x8db3;&#x65f6;&#x505c;&#x6b62;&#x89e3;&#x6790;&#x3002;&#x4e00;&#x822c;&#x6765;&#x8bf4;&#xff0c;SAX&#x8fd8;&#x6bd4;&#x5b83;&#x7684;&#x66ff;&#x4ee3;&#x8005;DOM&#x5feb;&#x8bb8;&#x591a;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455746084" ID="ID_792462103" MODIFIED="1475455746084" TEXT="&#x800c;&#x4e14;&#xff0c;&#x7531;&#x4e8e;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x53ea;&#x662f;&#x5728;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#x65f6;&#x68c0;&#x67e5;&#x6570;&#x636e;&#xff0c;&#x56e0;&#x6b64;&#x4e0d;&#x9700;&#x8981;&#x5c06;&#x6570;&#x636e;&#x5b58;&#x50a8;&#x5728;&#x5185;&#x5b58;&#x4e2d;&#x3002;&#x8fd9;&#x5bf9;&#x4e8e;&#x5927;&#x578b;&#x6587;&#x6863;&#x6765;&#x8bf4;&#x662f;&#x4e2a;&#x5de8;&#x5927;&#x7684;&#x4f18;&#x70b9;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475455571261" FOLDED="true" ID="ID_1109901468" MODIFIED="1529657527923" TEXT="&#x4f18;&#x52bf;">
<node COLOR="#111111" CREATED="1475455577072" ID="ID_1539381789" MODIFIED="1475455577072" TEXT="&#x2460;&#x4e0d;&#x9700;&#x8981;&#x7b49;&#x5f85;&#x6240;&#x6709;&#x6570;&#x636e;&#x90fd;&#x88ab;&#x5904;&#x7406;&#xff0c;&#x5206;&#x6790;&#x5c31;&#x80fd;&#x7acb;&#x5373;&#x5f00;&#x59cb;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455577072" ID="ID_944180104" MODIFIED="1475455577072" TEXT="&#x2461;&#x53ea;&#x5728;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#x65f6;&#x68c0;&#x67e5;&#x6570;&#x636e;&#xff0c;&#x4e0d;&#x9700;&#x8981;&#x4fdd;&#x5b58;&#x5728;&#x5185;&#x5b58;&#x4e2d;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455577072" ID="ID_1528775808" MODIFIED="1475455577072" TEXT="&#x2462;&#x53ef;&#x4ee5;&#x5728;&#x67d0;&#x4e2a;&#x6761;&#x4ef6;&#x5f97;&#x5230;&#x6ee1;&#x8db3;&#x65f6;&#x505c;&#x6b62;&#x89e3;&#x6790;&#xff0c;&#x4e0d;&#x5fc5;&#x89e3;&#x6790;&#x6574;&#x4e2a;&#x6587;&#x6863;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455577072" ID="ID_336237169" MODIFIED="1475455577072" TEXT="&#x2463;&#x6548;&#x7387;&#x548c;&#x6027;&#x80fd;&#x8f83;&#x9ad8;&#xff0c;&#x80fd;&#x89e3;&#x6790;&#x5927;&#x4e8e;&#x7cfb;&#x7edf;&#x5185;&#x5b58;&#x7684;&#x6587;&#x6863;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475460578176" FOLDED="true" ID="ID_1119428923" MODIFIED="1529657527926" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1475460580959" ID="ID_405349639" LINK="Xml&#x89e3;&#x6790;/Sax&#x89e3;&#x6790;/test.xml" MODIFIED="1475464227788" TEXT="&#x88ab;&#x89e3;&#x6790;&#x7684;&#x6587;&#x4ef6;"/>
<node COLOR="#111111" CREATED="1475460585390" FOLDED="true" ID="ID_92985380" MODIFIED="1529657527923" TEXT="&#x89e3;&#x6790;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475460676938" ID="ID_1016636377" LINK="Xml&#x89e3;&#x6790;/Sax&#x89e3;&#x6790;/User.java" MODIFIED="1475460696973" TEXT="bean"/>
<node COLOR="#111111" CREATED="1475460911472" ID="ID_1617863528" LINK="Xml&#x89e3;&#x6790;/Sax&#x89e3;&#x6790;/SaxHandler.java" MODIFIED="1475460921974" TEXT="SaxHandler"/>
</node>
<node COLOR="#111111" CREATED="1475460934733" FOLDED="true" ID="ID_318414923" MODIFIED="1529657527923" TEXT="&#x6ce8;&#x610f;">
<node COLOR="#111111" CREATED="1475460951667" ID="ID_990781083" MODIFIED="1475460988013" TEXT="DefaultHandler &#x7684;&#x88ab;&#x590d;&#x5199;&#x7684;&#x65b9;&#x6cd5;&#x4e0d;&#x80fd;&#x88ab;super"/>
<node COLOR="#111111" CREATED="1475460988713" ID="ID_703383284" MODIFIED="1475461019477" TEXT="mPreTag&#x9700;&#x8981;&#x8d4b;&#x503c;null"/>
</node>
<node COLOR="#111111" CREATED="1475462526604" FOLDED="true" ID="ID_1711797" MODIFIED="1529657527925" TEXT="&#x76f8;&#x5173;&#x7684;&#x7c7b;">
<node COLOR="#111111" CREATED="1475462531528" FOLDED="true" ID="ID_1341656573" MODIFIED="1529657527924" TEXT="SAXParserFactory">
<node COLOR="#111111" CREATED="1475462652538" FOLDED="true" ID="ID_241348046" MODIFIED="1529657527923" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475462654249" ID="ID_907901225" MODIFIED="1475462654249" TEXT="SAXParserFactory.newInstance()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475462559976" FOLDED="true" ID="ID_457675587" MODIFIED="1529657527924" TEXT="SAXParser">
<node COLOR="#111111" CREATED="1475462707942" FOLDED="true" ID="ID_1637471207" MODIFIED="1529657527924" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475462710398" ID="ID_1707775049" MODIFIED="1475462710398" TEXT="public void reset()"/>
<node COLOR="#111111" CREATED="1475462754394" ID="ID_1326117923" MODIFIED="1475462754394" TEXT="public void parse(InputStream is, DefaultHandler dh)"/>
<node COLOR="#111111" CREATED="1475462804420" ID="ID_1286704730" MODIFIED="1475462804421" TEXT="public void parse(String uri, DefaultHandler dh)"/>
<node COLOR="#111111" CREATED="1475462813722" ID="ID_1019406451" MODIFIED="1475462813722" TEXT="public void parse(File f, DefaultHandler dh)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475462569641" FOLDED="true" ID="ID_1498485024" MODIFIED="1529657527925" TEXT="DefaultHandler">
<node COLOR="#111111" CREATED="1475463002956" FOLDED="true" ID="ID_1108431729" MODIFIED="1529657527924" TEXT="public void startDocument ()">
<node COLOR="#111111" CREATED="1475463115186" ID="ID_189107220" MODIFIED="1475463119417" TEXT="&#x5f00;&#x59cb;&#x6587;&#x6863;"/>
</node>
<node COLOR="#111111" CREATED="1475463014050" FOLDED="true" ID="ID_653630970" MODIFIED="1529657527924" TEXT="public void endDocument ()">
<node COLOR="#111111" CREATED="1475463121077" ID="ID_1693190244" MODIFIED="1475463124722" TEXT="&#x7ed3;&#x675f;&#x6587;&#x6863;"/>
</node>
<node COLOR="#111111" CREATED="1475463023418" FOLDED="true" ID="ID_1968060945" MODIFIED="1529657527924" TEXT="public void startElement (String uri, String localName,String qName, Attributes attributes) ">
<node COLOR="#111111" CREATED="1475463106119" ID="ID_1991772603" MODIFIED="1475463112220" TEXT="&#x5f00;&#x59cb;&#x89e3;&#x6790;&#x5355;&#x4e2a;&#x5143;&#x7d20;"/>
</node>
<node COLOR="#111111" CREATED="1475463031356" FOLDED="true" ID="ID_1410483308" MODIFIED="1529657527924" TEXT="public void endElement (String uri, String localName, String qName)">
<node COLOR="#111111" CREATED="1475463092341" ID="ID_337252458" MODIFIED="1475463103535" TEXT="&#x89e3;&#x6790;&#x5355;&#x4e2a;&#x5143;&#x7d20;&#x7ed3;&#x675f;"/>
</node>
<node COLOR="#111111" CREATED="1475463038483" FOLDED="true" ID="ID_161289778" MODIFIED="1529657527924" TEXT="public void characters (char ch[], int start, int length)">
<node COLOR="#111111" CREATED="1475463068568" ID="ID_369818383" MODIFIED="1475463088151" TEXT="&#x5b9e;&#x9645;&#x7684;&#x503c;&#xff0c;&#x5b57;&#x7b26;&#x4e32;&#x7c7b;&#x578b;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475462592087" FOLDED="true" ID="ID_850027779" MODIFIED="1529657527925" TEXT="AssetManager">
<node COLOR="#111111" CREATED="1475463804807" FOLDED="true" ID="ID_1355514849" MODIFIED="1529657527925" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1475463807556" ID="ID_1450002805" MODIFIED="1475463828069" TEXT="&#x7528;&#x6765;&#x8bfb;assets&#x6587;&#x4ef6;&#x5939;&#x4e0b;&#x7684;&#x6587;&#x4ef6;&#x7684;&#x5de5;&#x5177;"/>
</node>
<node COLOR="#111111" CREATED="1475463796703" FOLDED="true" ID="ID_1825308081" MODIFIED="1529657527925" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475463376183" ID="ID_1209003260" MODIFIED="1475463386091" TEXT="&#x83b7;&#x53d6;&#x5b9e;&#x4f8b;&#xff1a;AssetManager am = context.getAssets();"/>
<node COLOR="#111111" CREATED="1475463392602" FOLDED="true" ID="ID_760680359" MODIFIED="1529657527925" TEXT="&#x5217;&#x51fa;assets&#x76ee;&#x5f55;&#x4e0b;&#x6240;&#x6709;&#x6587;&#x4ef6;">
<node COLOR="#111111" CREATED="1475463392605" ID="ID_1934089137" MODIFIED="1475463392605" TEXT="String[] filePathList = am.list(&quot;&quot;);"/>
</node>
<node COLOR="#111111" CREATED="1475463399812" ID="ID_838937412" MODIFIED="1475463406320" TEXT="&#x6253;&#x5f00;&#x67d0;&#x4e2a;&#x6587;&#x4ef6; : InputStream is = am.open(&quot;test.txt&quot;);"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1475456400932" FOLDED="true" ID="ID_190948783" MODIFIED="1529657527927" TEXT="PULL">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1475456404896" FOLDED="true" ID="ID_164477860" MODIFIED="1529657527926" TEXT="&#x548c;Sax&#x7684;&#x533a;&#x522b;">
<node COLOR="#111111" CREATED="1475456430705" ID="ID_1466933567" MODIFIED="1475456430705" TEXT="SAX&#x89e3;&#x6790;&#x5668;&#x7684;&#x5de5;&#x4f5c;&#x65b9;&#x5f0f;&#x662f;&#x81ea;&#x52a8;&#x5c06;&#x4e8b;&#x4ef6;&#x63a8;&#x5165;&#x6ce8;&#x518c;&#x7684;&#x4e8b;&#x4ef6;&#x5904;&#x7406;&#x5668;&#x8fdb;&#x884c;&#x5904;&#x7406;&#xff0c;&#x56e0;&#x6b64;&#x4f60;&#x4e0d;&#x80fd;&#x63a7;&#x5236;&#x4e8b;&#x4ef6;&#x7684;&#x5904;&#x7406;&#x4e3b;&#x52a8;&#x7ed3;&#x675f;&#xff1b;"/>
<node COLOR="#111111" CREATED="1475456446002" ID="ID_642940180" MODIFIED="1475456446002" TEXT="&#x800c;Pull&#x89e3;&#x6790;&#x5668;&#x7684;&#x5de5;&#x4f5c;&#x65b9;&#x5f0f;&#x4e3a;&#x5141;&#x8bb8;&#x4f60;&#x7684;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x4ee3;&#x7801;&#x4e3b;&#x52a8;&#x4ece;&#x89e3;&#x6790;&#x5668;&#x4e2d;&#x83b7;&#x53d6;&#x4e8b;&#x4ef6;&#xff0c;&#x6b63;&#x56e0;&#x4e3a;&#x662f;&#x4e3b;&#x52a8;&#x83b7;&#x53d6;&#x4e8b;&#x4ef6;&#xff0c;&#x56e0;&#x6b64;&#x53ef;&#x4ee5;&#x5728;&#x6ee1;&#x8db3;&#x4e86;&#x9700;&#x8981;&#x7684;&#x6761;&#x4ef6;&#x540e;&#x4e0d;&#x518d;&#x83b7;&#x53d6;&#x4e8b;&#x4ef6;&#xff0c;&#x7ed3;&#x675f;&#x89e3;&#x6790;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475464825774" FOLDED="true" ID="ID_438739399" MODIFIED="1529657527927" TEXT="&#x76f8;&#x5173;&#x7684;&#x7c7b;">
<node COLOR="#111111" CREATED="1475470502013" FOLDED="true" ID="ID_1280867165" MODIFIED="1529657527927" TEXT="XmlPullParser">
<node COLOR="#111111" CREATED="1475470727393" FOLDED="true" ID="ID_1727399425" MODIFIED="1529657527927" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475470729508" FOLDED="true" ID="ID_1151889308" MODIFIED="1529657527926" TEXT="int getEventType()">
<node COLOR="#111111" CREATED="1475471034073" ID="ID_153705341" MODIFIED="1475471044152" TEXT="&#x83b7;&#x53d6;&#x4e8b;&#x4ef6;&#x7c7b;&#x578b;"/>
</node>
<node COLOR="#111111" CREATED="1475470894930" FOLDED="true" ID="ID_117058266" MODIFIED="1529657527926" TEXT="String getAttributeValue(int index)">
<node COLOR="#111111" CREATED="1475471027521" ID="ID_1331262815" MODIFIED="1475471031173" TEXT="&#x83b7;&#x53d6;&#x5c5e;&#x6027;&#x503c;"/>
</node>
<node COLOR="#111111" CREATED="1475470922779" FOLDED="true" ID="ID_1691864792" MODIFIED="1529657527926" TEXT="String getAttributeName (int index)">
<node COLOR="#111111" CREATED="1475471018356" ID="ID_47660325" MODIFIED="1475471025159" TEXT="&#x83b7;&#x53d6;&#x5c5e;&#x6027;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1475470960572" FOLDED="true" ID="ID_1237001045" MODIFIED="1529657527926" TEXT="int next()">
<node COLOR="#111111" CREATED="1475471056069" ID="ID_1763156288" MODIFIED="1475471060189" TEXT="&#x4e0b;&#x4e00;&#x4e2a;&#x4e8b;&#x4ef6;"/>
</node>
<node COLOR="#111111" CREATED="1475470969503" ID="ID_1561756007" MODIFIED="1475470969503" TEXT="String nextText() throws XmlPullParserException, IOException"/>
<node COLOR="#111111" CREATED="1475470979653" ID="ID_233187197" MODIFIED="1475470979653" TEXT="int nextTag() throws XmlPullParserException, IOException"/>
<node COLOR="#111111" CREATED="1475470996830" FOLDED="true" ID="ID_1435892884" MODIFIED="1529657527927" TEXT="String getName()">
<node COLOR="#111111" CREATED="1475471000299" ID="ID_980120260" MODIFIED="1475471007789" TEXT="&#x83b7;&#x53d6;&#x6807;&#x7b7e;&#x7684;&#x540d;&#x5b57;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1475470504327" FOLDED="true" ID="ID_1983455399" MODIFIED="1529657527927" TEXT="Xml">
<node COLOR="#111111" CREATED="1475470711131" ID="ID_1939638981" MODIFIED="1475470810245" TEXT="public static XmlPullParser newPullParser() "/>
</node>
</node>
<node COLOR="#111111" CREATED="1475471092933" ID="ID_1640745287" LINK="Xml&#x89e3;&#x6790;/Pull&#x89e3;&#x6790;/&#x89e3;&#x6790;&#x65b9;&#x6cd5;.txt" MODIFIED="1475471103504" TEXT="&#x4f7f;&#x7528;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1495155093659" ID="ID_1942429761" MODIFIED="1495155096699" POSITION="left" TEXT="JVM">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1495155265913" ID="ID_889721583" LINK="../&#x6b63;&#x5219;/&#x6b63;&#x5219;.mm" MODIFIED="1495155376827" POSITION="left" TEXT="&#x6b63;&#x5219;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1495155458155" ID="ID_217122728" LINK="../&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x7279;&#x6027;/&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x7684;&#x7279;&#x5f81;.mm" MODIFIED="1495155486805" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38754;&#21521;&#23545;&#35937;&#29305;&#24449;
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1472795259456" FOLDED="true" ID="ID_1202808021" LINK="../java&#x5e76;&#x53d1;&#x7f16;&#x7a0b;/Java&#x5e76;&#x53d1;&#x7f16;&#x7a0b;.mm" MODIFIED="1529657527950" POSITION="right" TEXT="&#x5e76;&#x53d1;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472795637653" FOLDED="true" ID="ID_989291183" MODIFIED="1529657527931" TEXT="&#x8fdb;&#x7a0b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472796014682" FOLDED="true" ID="ID_1155801750" MODIFIED="1529657527929" TEXT="&#xff1f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472796020327" ID="ID_1934489388" MODIFIED="1472796032157" TEXT="&#x72ed;&#x4e49;&#x5b9a;&#x4e49;&#xff1a;&#x8fdb;&#x7a0b;&#x662f;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7a0b;&#x5e8f;&#x7684;&#x5b9e;&#x4f8b;&#xff08;an instance of a computer program that is being executed&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1472796038195" ID="ID_143388785" MODIFIED="1472796039464" TEXT="&#x5e7f;&#x4e49;&#x5b9a;&#x4e49;&#xff1a;&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x5177;&#x6709;&#x4e00;&#x5b9a;&#x72ec;&#x7acb;&#x529f;&#x80fd;&#x7684;&#x7a0b;&#x5e8f;&#x5173;&#x4e8e;&#x67d0;&#x4e2a;&#x6570;&#x636e;&#x96c6;&#x5408;&#x7684;&#x4e00;&#x6b21;&#x8fd0;&#x884c;&#x6d3b;&#x52a8;&#x3002;&#x5b83;&#x662f;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x52a8;&#x6001;&#x6267;&#x884c;&#x7684;&#x57fa;&#x672c;&#x5355;&#x5143;&#xff0c;&#x5728;&#x4f20;&#x7edf;&#x7684;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x4e2d;&#xff0c;&#x8fdb;&#x7a0b;&#x65e2;&#x662f;&#x57fa;&#x672c;&#x7684;&#x5206;&#x914d;&#x5355;&#x5143;&#xff0c;&#x4e5f;&#x662f;&#x57fa;&#x672c;&#x7684;&#x6267;&#x884c;&#x5355;&#x5143;&#x3002;"/>
<node COLOR="#111111" CREATED="1472796078155" ID="ID_451148568" MODIFIED="1472796079157" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x5b9e;&#x4f53;"/>
<node COLOR="#111111" CREATED="1472796095934" FOLDED="true" ID="ID_562759768" MODIFIED="1529657527929" TEXT="&#x6bcf;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x90fd;&#x6709;&#x5b83;&#x81ea;&#x5df1;&#x7684;&#x5730;&#x5740;&#x7a7a;&#x95f4;">
<node COLOR="#111111" CREATED="1472796111013" FOLDED="true" ID="ID_1353950888" MODIFIED="1529657527929" TEXT="&#x6587;&#x672c;&#x533a;&#x57df;&#xff08;text region&#xff09;">
<node COLOR="#111111" CREATED="1472796135773" ID="ID_116974450" MODIFIED="1472796135774" TEXT="&#x5b58;&#x50a8;&#x5904;&#x7406;&#x5668;&#x6267;&#x884c;&#x7684;&#x4ee3;&#x7801;"/>
</node>
<node COLOR="#111111" CREATED="1472796117878" FOLDED="true" ID="ID_1183906668" MODIFIED="1529657527929" TEXT="&#x6570;&#x636e;&#x533a;&#x57df;&#xff08;data region&#xff09;">
<node COLOR="#111111" CREATED="1472796148312" ID="ID_42883738" MODIFIED="1472796148313" TEXT="&#x5b58;&#x50a8;&#x53d8;&#x91cf;&#x548c;&#x8fdb;&#x7a0b;&#x6267;&#x884c;&#x671f;&#x95f4;&#x4f7f;&#x7528;&#x7684;&#x52a8;&#x6001;&#x5206;&#x914d;&#x7684;&#x5185;&#x5b58;"/>
</node>
<node COLOR="#111111" CREATED="1472796123061" FOLDED="true" ID="ID_156678237" MODIFIED="1529657527929" TEXT="&#x5806;&#x6808;&#xff08;stack region&#xff09;">
<node COLOR="#111111" CREATED="1472796159161" ID="ID_15448851" MODIFIED="1472796159161" TEXT="&#x5b58;&#x50a8;&#x7740;&#x6d3b;&#x52a8;&#x8fc7;&#x7a0b;&#x8c03;&#x7528;&#x7684;&#x6307;&#x4ee4;&#x548c;&#x672c;&#x5730;&#x53d8;&#x91cf;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472796169629" FOLDED="true" ID="ID_311754454" MODIFIED="1529657527929" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x201c;&#x6267;&#x884c;&#x4e2d;&#x7684;&#x7a0b;&#x5e8f;&#x201d;">
<node COLOR="#111111" CREATED="1472796180766" ID="ID_1940244742" MODIFIED="1472796180766" TEXT="&#x7a0b;&#x5e8f;&#x662f;&#x4e00;&#x4e2a;&#x6ca1;&#x6709;&#x751f;&#x547d;&#x7684;&#x5b9e;&#x4f53;&#xff0c;&#x53ea;&#x6709;&#x5904;&#x7406;&#x5668;&#x8d4b;&#x4e88;&#x7a0b;&#x5e8f;&#x751f;&#x547d;&#x65f6;&#xff08;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x6267;&#x884c;&#x4e4b;&#xff09;&#xff0c;&#x5b83;&#x624d;&#x80fd;&#x6210;&#x4e3a;&#x4e00;&#x4e2a;&#x6d3b;&#x52a8;&#x7684;&#x5b9e;&#x4f53;&#xff0c;&#x6211;&#x4eec;&#x79f0;&#x5176;&#x4e3a;&#x8fdb;&#x7a0b;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472796227321" ID="ID_1958985775" MODIFIED="1472796227321" TEXT="&#x4ece;&#x5b9e;&#x73b0;&#x89d2;&#x5ea6;&#x770b;&#xff0c;&#x662f;&#x4e00;&#x79cd;&#x6570;&#x636e;&#x7ed3;&#x6784;&#xff0c;&#x76ee;&#x7684;&#x5728;&#x4e8e;&#x6e05;&#x6670;&#x5730;&#x523b;&#x753b;&#x52a8;&#x6001;&#x7cfb;&#x7edf;&#x7684;&#x5185;&#x5728;&#x89c4;&#x5f8b;&#xff0c;&#x6709;&#x6548;&#x7ba1;&#x7406;&#x548c;&#x8c03;&#x5ea6;&#x8fdb;&#x5165;&#x8ba1;&#x7b97;&#x673a;&#x7cfb;&#x7edf;&#x4e3b;&#x5b58;&#x50a8;&#x5668;&#x8fd0;&#x884c;&#x7684;&#x7a0b;&#x5e8f;&#x3002;"/>
<node COLOR="#111111" CREATED="1472796232532" ID="ID_113804624" MODIFIED="1472796232533" TEXT="&#x4ece;&#x7406;&#x8bba;&#x89d2;&#x5ea6;&#x770b;&#xff0c;&#x662f;&#x5bf9;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7a0b;&#x5e8f;&#x8fc7;&#x7a0b;&#x7684;&#x62bd;&#x8c61;&#xff1b;"/>
</node>
<node COLOR="#990000" CREATED="1472796253382" FOLDED="true" ID="ID_1418462290" MODIFIED="1529657527930" TEXT="&#x7279;&#x5f81;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472796263257" ID="ID_1044714098" MODIFIED="1472796263258" TEXT="&#x52a8;&#x6001;&#x6027;&#xff1a;&#x8fdb;&#x7a0b;&#x7684;&#x5b9e;&#x8d28;&#x662f;&#x7a0b;&#x5e8f;&#x5728;&#x591a;&#x9053;&#x7a0b;&#x5e8f;&#x7cfb;&#x7edf;&#x4e2d;&#x7684;&#x4e00;&#x6b21;&#x6267;&#x884c;&#x8fc7;&#x7a0b;&#xff0c;&#x8fdb;&#x7a0b;&#x662f;&#x52a8;&#x6001;&#x4ea7;&#x751f;&#xff0c;&#x52a8;&#x6001;&#x6d88;&#x4ea1;&#x7684;&#x3002;"/>
<node COLOR="#111111" CREATED="1472796263259" ID="ID_14698456" MODIFIED="1472796263260" TEXT="&#x5e76;&#x53d1;&#x6027;&#xff1a;&#x4efb;&#x4f55;&#x8fdb;&#x7a0b;&#x90fd;&#x53ef;&#x4ee5;&#x540c;&#x5176;&#x4ed6;&#x8fdb;&#x7a0b;&#x4e00;&#x8d77;&#x5e76;&#x53d1;&#x6267;&#x884c;"/>
<node COLOR="#111111" CREATED="1472796263263" ID="ID_814145194" MODIFIED="1472796263263" TEXT="&#x72ec;&#x7acb;&#x6027;&#xff1a;&#x8fdb;&#x7a0b;&#x662f;&#x4e00;&#x4e2a;&#x80fd;&#x72ec;&#x7acb;&#x8fd0;&#x884c;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;&#xff0c;&#x540c;&#x65f6;&#x4e5f;&#x662f;&#x7cfb;&#x7edf;&#x5206;&#x914d;&#x8d44;&#x6e90;&#x548c;&#x8c03;&#x5ea6;&#x7684;&#x72ec;&#x7acb;&#x5355;&#x4f4d;&#xff1b;"/>
<node COLOR="#111111" CREATED="1472796263265" ID="ID_125908833" MODIFIED="1472796263265" TEXT="&#x5f02;&#x6b65;&#x6027;&#xff1a;&#x7531;&#x4e8e;&#x8fdb;&#x7a0b;&#x95f4;&#x7684;&#x76f8;&#x4e92;&#x5236;&#x7ea6;&#xff0c;&#x4f7f;&#x8fdb;&#x7a0b;&#x5177;&#x6709;&#x6267;&#x884c;&#x7684;&#x95f4;&#x65ad;&#x6027;&#xff0c;&#x5373;&#x8fdb;&#x7a0b;&#x6309;&#x5404;&#x81ea;&#x72ec;&#x7acb;&#x7684;&#x3001;&#x4e0d;&#x53ef;&#x9884;&#x77e5;&#x7684;&#x901f;&#x5ea6;&#x5411;&#x524d;&#x63a8;&#x8fdb;"/>
<node COLOR="#111111" CREATED="1472796263266" ID="ID_1811088302" MODIFIED="1472796263267" TEXT="&#x7ed3;&#x6784;&#x7279;&#x5f81;&#xff1a;&#x8fdb;&#x7a0b;&#x7531;&#x7a0b;&#x5e8f;&#x3001;&#x6570;&#x636e;&#x548c;&#x8fdb;&#x7a0b;&#x63a7;&#x5236;&#x5757;&#x4e09;&#x90e8;&#x5206;&#x7ec4;&#x6210;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472796336141" FOLDED="true" ID="ID_634785178" MODIFIED="1529657527930" TEXT="&#x5207;&#x6362;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472796347720" ID="ID_1407856960" MODIFIED="1472796347720" TEXT="&#x4ece;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x8fdb;&#x7a0b;&#x4e2d;&#x6536;&#x56de;&#x5904;&#x7406;&#x5668;&#xff0c;&#x7136;&#x540e;&#x518d;&#x4f7f;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x6765;&#x5360;&#x7528;&#x5904;&#x7406;&#x5668;&#x3002;"/>
<node COLOR="#111111" CREATED="1472796370848" ID="ID_1876028902" MODIFIED="1472796482192" TEXT="&#x5b9e;&#x8d28;&#x4e0a;&#x5c31;&#x662f;&#x628a;&#x8fdb;&#x7a0b;&#x5b58;&#x653e;&#x5728;&#x5904;&#x7406;&#x5668;&#x7684;&#x5bc4;&#x5b58;&#x5668;&#x4e2d;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#x627e;&#x4e2a;&#x5730;&#x65b9;&#x5b58;&#x8d77;&#x6765;&#xff0c;&#x4ece;&#x800c;&#x628a;&#x5904;&#x7406;&#x5668;&#x7684;&#x5bc4;&#x5b58;&#x5668;&#x817e;&#x51fa;&#x6765;&#x8ba9;&#x5176;&#x4ed6;&#x8fdb;&#x7a0b;&#x4f7f;&#x7528;&#x3002;&#x90a3;&#x4e48;&#x88ab;&#x4e2d;&#x6b62;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#x5b58;&#x5728;&#x8fdb;&#x7a0b;&#x7684;&#x79c1;&#x6709;&#x5806;&#x6808;&#x3002;"/>
<node COLOR="#111111" CREATED="1472796515244" ID="ID_1232908142" MODIFIED="1472796537438" TEXT="&#x7136;&#x540e;&#x628a;&#x67d0;&#x4e2a;&#x8fdb;&#x7a0b;&#x5b58;&#x653e;&#x5728;&#x79c1;&#x6709;&#x5806;&#x6808;&#x4e2d;&#x5bc4;&#x5b58;&#x5668;&#x7684;&#x6570;&#x636e;&#xff08;&#x524d;&#x4e00;&#x6b21;&#x672c;&#x8fdb;&#x7a0b;&#x88ab;&#x4e2d;&#x6b62;&#x65f6;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#xff09;&#x518d;&#x6062;&#x590d;&#x5230;&#x5904;&#x7406;&#x5668;&#x7684;&#x5bc4;&#x5b58;&#x5668;&#x4e2d;&#x53bb;&#xff0c;&#x5e76;&#x628a;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x7684;&#x65ad;&#x70b9;&#x9001;&#x5165;&#x5904;&#x7406;&#x5668;&#x7684;&#x7a0b;&#x5e8f;&#x6307;&#x9488;PC&#xff0c;&#x4e8e;&#x662f;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x5c31;&#x5f00;&#x59cb;&#x88ab;&#x5904;&#x7406;&#x5668;&#x8fd0;&#x884c;&#x4e86;"/>
<node COLOR="#111111" CREATED="1472796428511" FOLDED="true" ID="ID_221904929" MODIFIED="1529657527930" TEXT="&#x4e0a;&#x4e0b;&#x6587;context">
<node COLOR="#111111" CREATED="1472796420096" ID="ID_571000356" MODIFIED="1473812568683" TEXT="&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x5b58;&#x50a8;&#x5728;&#x5904;&#x7406;&#x5668;&#x5404;&#x5bc4;&#x5b58;&#x5668;&#x4e2d;&#x7684;&#x4e2d;&#x95f4;&#x6570;&#x636e;&#x53eb;&#x505a;&#x8fdb;&#x7a0b;&#x7684;&#x4e0a;&#x4e0b;&#x6587;&#xff0c;&#x6240;&#x4ee5;&#x8fdb;&#x7a0b;&#x7684;&#x5207;&#x6362;&#x5b9e;&#x8d28;&#x4e0a;&#x5c31;&#x662f;&#x88ab;&#x4e2d;&#x6b62;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x4e0e;&#x5f85;&#x8fd0;&#x884c;&#x8fdb;&#x7a0b;&#x4e0a;&#x4e0b;&#x6587;&#x7684;&#x5207;&#x6362;&#x3002;&#x5728;&#x8fdb;&#x7a0b;&#x672a;&#x5360;&#x7528;&#x5904;&#x7406;&#x5668;&#x65f6;&#xff0c;&#x8fdb;&#x7a0b; &#x7684;&#x4e0a;&#x4e0b;&#x6587;&#x662f;&#x5b58;&#x50a8;&#x5728;&#x8fdb;&#x7a0b;&#x7684;&#x79c1;&#x6709;&#x5806;&#x6808;&#x4e2d;&#x7684;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472805038307" FOLDED="true" ID="ID_1315270985" MODIFIED="1529657527930" TEXT="&#x72b6;&#x6001;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805043812" FOLDED="true" ID="ID_245275029" MODIFIED="1529657527930" TEXT="&#x5c31;&#x7eea;&#x72b6;&#x6001;&#xff08;Ready&#xff09;">
<node COLOR="#111111" CREATED="1472805058055" ID="ID_1244365981" MODIFIED="1472805058055" TEXT="&#x8fdb;&#x7a0b;&#x5df2;&#x83b7;&#x5f97;&#x9664;&#x5904;&#x7406;&#x5668;&#x5916;&#x7684;&#x6240;&#x9700;&#x8d44;&#x6e90;&#xff0c;&#x7b49;&#x5f85;&#x5206;&#x914d;&#x5904;&#x7406;&#x5668;&#x8d44;&#x6e90;&#xff1b;&#x53ea;&#x8981;&#x5206;&#x914d;&#x4e86;&#x5904;&#x7406;&#x5668;&#x8fdb;&#x7a0b;&#x5c31;&#x53ef;&#x6267;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1472805065018" ID="ID_129302685" MODIFIED="1472805065019" TEXT="&#x5c31;&#x7eea;&#x8fdb;&#x7a0b;&#x53ef;&#x4ee5;&#x6309;&#x591a;&#x4e2a;&#x4f18;&#x5148;&#x7ea7;&#x6765;&#x5212;&#x5206;&#x961f;&#x5217;"/>
</node>
<node COLOR="#111111" CREATED="1472805072010" FOLDED="true" ID="ID_1886846801" MODIFIED="1529657527930" TEXT="&#x8fd0;&#x884c;&#x72b6;&#x6001;(Running)">
<node COLOR="#111111" CREATED="1472805099236" ID="ID_1984703508" MODIFIED="1472805099237" TEXT="&#x8fdb;&#x7a0b;&#x5360;&#x7528;&#x5904;&#x7406;&#x5668;&#x8d44;&#x6e90;&#xff1b;&#x5904;&#x4e8e;&#x6b64;&#x72b6;&#x6001;&#x7684;&#x8fdb;&#x7a0b;&#x7684;&#x6570;&#x76ee;&#x5c0f;&#x4e8e;&#x7b49;&#x4e8e;&#x5904;&#x7406;&#x5668;&#x7684;&#x6570;&#x76ee;&#x3002;&#x5728;&#x6ca1;&#x6709;&#x5176;&#x4ed6;&#x8fdb;&#x7a0b;&#x53ef;&#x4ee5;&#x6267;&#x884c;&#x65f6;(&#x5982;&#x6240;&#x6709;&#x8fdb;&#x7a0b;&#x90fd;&#x5728;&#x963b;&#x585e;&#x72b6;&#x6001;)&#xff0c;&#x901a;&#x5e38;&#x4f1a;&#x81ea;&#x52a8;&#x6267;&#x884c;&#x7cfb;&#x7edf;&#x7684;&#x7a7a;&#x95f2;&#x8fdb;&#x7a0b;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472805105665" FOLDED="true" ID="ID_1817393322" MODIFIED="1529657527930" TEXT="&#x963b;&#x585e;&#x72b6;&#x6001;(Blocked)">
<node COLOR="#111111" CREATED="1472805156130" ID="ID_1281772127" MODIFIED="1472805173493" TEXT="&#x7531;&#x4e8e;&#x8fdb;&#x7a0b;&#x7b49;&#x5f85;&#x67d0;&#x79cd;&#x6761;&#x4ef6;&#xff08;&#x5982;I/O&#x64cd;&#x4f5c;&#x6216;&#x8fdb;&#x7a0b;&#x540c;&#x6b65;&#xff09;&#xff0c;&#x5728;&#x6761;&#x4ef6;&#x6ee1;&#x8db3;&#x4e4b;&#x524d;&#x65e0;&#x6cd5;&#x7ee7;&#x7eed;&#x6267;&#x884c;&#x3002;&#x5373;&#x4f7f;&#x628a;&#x5904;&#x7406;&#x5668;&#x8d44;&#x6e90;&#x5206;&#x914d;&#x7ed9;&#x8be5;&#x8fdb;&#x7a0b;&#xff0c;&#x4e5f;&#x65e0;&#x6cd5;&#x8fd0;&#x884c;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472805209668" FOLDED="true" ID="ID_1053232621" MODIFIED="1529657527930" TEXT="&#x7a0b;&#x5e8f;&#x548c;&#x8fdb;&#x7a0b;&#x7684;&#x533a;&#x522b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805225439" ID="ID_1543736654" MODIFIED="1473818135751" TEXT="&#x7a0b;&#x5e8f;&#x662f;&#x6307;&#x4ee4;&#x548c;&#x6570;&#x636e;&#x7684;&#x6709;&#x5e8f;&#x96c6;&#x5408;&#xff0c;&#x5176;&#x672c;&#x8eab;&#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x8fd0;&#x884c;&#x7684;&#x542b;&#x4e49;&#xff0c;&#x662f;&#x4e00;&#x4e2a;&#x9759;&#x6001;&#x7684;&#x6982;&#x5ff5;"/>
<node COLOR="#111111" CREATED="1472805235106" ID="ID_1192349499" MODIFIED="1472805235106" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x7a0b;&#x5e8f;&#x5728;&#x5904;&#x7406;&#x673a;&#x4e0a;&#x7684;&#x4e00;&#x6b21;&#x6267;&#x884c;&#x8fc7;&#x7a0b;&#xff0c;&#x5b83;&#x662f;&#x4e00;&#x4e2a;&#x52a8;&#x6001;&#x7684;&#x6982;&#x5ff5;&#x3002;"/>
<node COLOR="#111111" CREATED="1472805249977" ID="ID_1155052305" MODIFIED="1472805249977" TEXT="&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#x4f5c;&#x4e3a;&#x4e00;&#x79cd;&#x8f6f;&#x4ef6;&#x8d44;&#x6599;&#x957f;&#x671f;&#x5b58;&#x5728;&#xff0c;&#x800c;&#x8fdb;&#x7a0b;&#x662f;&#x6709;&#x4e00;&#x5b9a;&#x751f;&#x547d;&#x671f;&#x7684;&#x3002;&#x7a0b;&#x5e8f;&#x662f;&#x6c38;&#x4e45;&#x7684;&#xff0c;&#x8fdb;&#x7a0b;&#x662f;&#x6682;&#x65f6;&#x7684;&#x3002;"/>
<node COLOR="#111111" CREATED="1472805290368" ID="ID_6466345" MODIFIED="1472805290369" TEXT="&#x540c;&#x4e00;&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#x5bf9;&#x5e94;&#x591a;&#x4e2a;&#x8fdb;&#x7a0b;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472795640669" FOLDED="true" ID="ID_499181589" MODIFIED="1529657527943" TEXT="&#x7ebf;&#x7a0b;Thread">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472805328449" FOLDED="true" ID="ID_1943706304" MODIFIED="1529657527931" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805330280" ID="ID_233078617" MODIFIED="1472805330281" TEXT="&#x6709;&#x65f6;&#x88ab;&#x79f0;&#x4e3a;&#x8f7b;&#x91cf;&#x7ea7;&#x8fdb;&#x7a0b;(Lightweight Process&#xff0c;LWP&#xff09;&#xff0c;&#x662f;&#x7a0b;&#x5e8f;&#x6267;&#x884c;&#x6d41;&#x7684;&#x6700;&#x5c0f;&#x5355;&#x5143;"/>
<node COLOR="#111111" CREATED="1472805345589" ID="ID_1432596315" MODIFIED="1472805345589" TEXT="&#x4e00;&#x4e2a;&#x6807;&#x51c6;&#x7684;&#x7ebf;&#x7a0b;&#x7531;&#x7ebf;&#x7a0b;ID&#xff0c;&#x5f53;&#x524d;&#x6307;&#x4ee4;&#x6307;&#x9488;(PC&#xff09;&#xff0c;&#x5bc4;&#x5b58;&#x5668;&#x96c6;&#x5408;&#x548c;&#x5806;&#x6808;&#x7ec4;&#x6210;&#x3002;"/>
<node COLOR="#111111" CREATED="1472805366679" ID="ID_1122312416" MODIFIED="1472805366680" TEXT="&#x7ebf;&#x7a0b;&#x662f;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x4e00;&#x4e2a;&#x5b9e;&#x4f53;&#xff0c;&#x662f;&#x88ab;&#x7cfb;&#x7edf;&#x72ec;&#x7acb;&#x8c03;&#x5ea6;&#x548c;&#x5206;&#x6d3e;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;&#xff0c;&#x7ebf;&#x7a0b;&#x81ea;&#x5df1;&#x4e0d;&#x62e5;&#x6709;&#x7cfb;&#x7edf;&#x8d44;&#x6e90;&#xff0c;&#x53ea;&#x62e5;&#x6709;&#x4e00;&#x70b9;&#x513f;&#x5728;&#x8fd0;&#x884c;&#x4e2d;&#x5fc5;&#x4e0d;&#x53ef;&#x5c11;&#x7684;&#x8d44;&#x6e90;&#xff0c;&#x4f46;&#x5b83;&#x53ef;&#x4e0e;&#x540c;&#x5c5e;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x7684;&#x5176;&#x5b83;&#x7ebf;&#x7a0b;&#x5171;&#x4eab;&#x8fdb;&#x7a0b;&#x6240;&#x62e5;&#x6709;&#x7684;&#x5168;&#x90e8;&#x8d44;&#x6e90;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1472805734159" FOLDED="true" ID="ID_35543851" MODIFIED="1529657527931" TEXT="&#x7279;&#x5f81;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472805764986" FOLDED="true" ID="ID_1219606031" MODIFIED="1529657527931" TEXT="&#x8f7b;&#x578b;&#x5b9e;&#x4f53;">
<node COLOR="#111111" CREATED="1472805741580" ID="ID_909482276" MODIFIED="1472805741581" TEXT="&#x7ebf;&#x7a0b;&#x662f;&#x80fd;&#x72ec;&#x7acb;&#x8fd0;&#x884c;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;&#xff0c;&#x56e0;&#x800c;&#x4e5f;&#x662f;&#x72ec;&#x7acb;&#x8c03;&#x5ea6;&#x548c;&#x5206;&#x6d3e;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;"/>
<node COLOR="#111111" CREATED="1472805750749" ID="ID_943594150" MODIFIED="1472805750749" TEXT="&#x7ebf;&#x7a0b;&#x5f88;&#x201c;&#x8f7b;&#x201d;&#xff0c;&#x6545;&#x7ebf;&#x7a0b;&#x7684;&#x5207;&#x6362;&#x975e;&#x5e38;&#x8fc5;&#x901f;&#x4e14;&#x5f00;&#x9500;&#x5c0f;&#xff08;&#x5728;&#x540c;&#x4e00;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#xff09;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472805777307" ID="ID_1100300635" MODIFIED="1472805777307" TEXT="&#x72ec;&#x7acb;&#x8c03;&#x5ea6;&#x548c;&#x5206;&#x6d3e;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;"/>
<node COLOR="#111111" CREATED="1472805802387" FOLDED="true" ID="ID_838116416" MODIFIED="1529657527931" TEXT="&#x53ef;&#x5e76;&#x53d1;&#x6267;&#x884c;">
<node COLOR="#111111" CREATED="1472805817637" ID="ID_93707698" MODIFIED="1472805817638" TEXT="&#x5728;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x4e4b;&#x95f4;&#xff0c;&#x53ef;&#x4ee5;&#x5e76;&#x53d1;&#x6267;&#x884c;&#xff0c;&#x751a;&#x81f3;&#x5141;&#x8bb8;&#x5728;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x4e2d;&#x6240;&#x6709;&#x7ebf;&#x7a0b;&#x90fd;&#x80fd;&#x5e76;&#x53d1;&#x6267;&#x884c;&#xff1b;&#x540c;&#x6837;&#xff0c;&#x4e0d;&#x540c;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x7ebf;&#x7a0b;&#x4e5f;&#x80fd;&#x5e76;&#x53d1;&#x6267;&#x884c;&#xff0c;&#x5145;&#x5206;&#x5229;&#x7528;&#x548c;&#x53d1;&#x6325;&#x4e86;&#x5904;&#x7406;&#x673a;&#x4e0e;&#x5916;&#x56f4;&#x8bbe;&#x5907;&#x5e76;&#x884c;&#x5de5;&#x4f5c;&#x7684;&#x80fd;&#x529b;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472805823433" FOLDED="true" ID="ID_753446485" MODIFIED="1529657527931" TEXT="&#x5171;&#x4eab;&#x8fdb;&#x7a0b;&#x8d44;&#x6e90;">
<node COLOR="#111111" CREATED="1472805851470" ID="ID_514026108" MODIFIED="1472805851470" TEXT="&#x5728;&#x540c;&#x4e00;&#x8fdb;&#x7a0b;&#x4e2d;&#x7684;&#x5404;&#x4e2a;&#x7ebf;&#x7a0b;&#xff0c;&#x90fd;&#x53ef;&#x4ee5;&#x5171;&#x4eab;&#x8be5;&#x8fdb;&#x7a0b;&#x6240;&#x62e5;&#x6709;&#x7684;&#x8d44;&#x6e90;&#xff0c;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472806295705" FOLDED="true" ID="ID_1339242591" LINK="&#x7ebf;&#x7a0b;&#x751f;&#x547d;&#x5468;&#x671f;.png" MODIFIED="1529657527932" TEXT="&#x7ebf;&#x7a0b;&#x7684;&#x751f;&#x547d;&#x5468;&#x671f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472806321131" FOLDED="true" ID="ID_1568591040" MODIFIED="1529657527932" TEXT="&#x65b0;&#x7ebf;&#x7a0b;&#x6001;&#xff08;New Thread)">
<node COLOR="#111111" CREATED="1472806346386" ID="ID_557195206" MODIFIED="1472806346386" TEXT="&#x5f53;&#x7ebf;&#x7a0b;&#x5904;&#x4e8e;&quot;&#x65b0;&#x7ebf;&#x7a0b;&quot;&#x72b6;&#x6001;&#x65f6;&#xff0c;&#x4ec5;&#x4ec5;&#x662f;&#x4e00;&#x4e2a;&#x7a7a;&#x7ebf;&#x7a0b;&#x5bf9;&#x8c61;&#xff0c;&#x5b83;&#x8fd8;&#x6ca1;&#x6709;&#x5206;&#x914d;&#x5230;&#x7cfb;&#x7edf;&#x8d44;&#x6e90;&#x3002;&#x56e0;&#x6b64;&#x53ea;&#x80fd;&#x542f;&#x52a8;&#x6216;&#x7ec8;&#x6b62;&#x5b83;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472806352825" FOLDED="true" ID="ID_736307518" MODIFIED="1529657527932" TEXT="&#x5c31;&#x7eea;&#x72b6;&#x6001;:">
<node COLOR="#111111" CREATED="1472806444316" ID="ID_412849903" MODIFIED="1472806444317" TEXT="&#x5f53;&#x7ebf;&#x7a0b;&#x5bf9;&#x8c61;&#x8c03;&#x7528;&#x4e86;start()&#x65b9;&#x6cd5;&#x4e4b;&#x540e;&#xff0c;&#x8be5;&#x7ebf;&#x7a0b;&#x5c31;&#x8fdb;&#x5165;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x3002;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x5904;&#x4e8e;&#x5c31;&#x7eea;&#x961f;&#x5217;&#x4e2d;&#xff0c;&#x8981;&#x7b49;&#x5f85;JVM&#x91cc;&#x7ebf;&#x7a0b;&#x8c03;&#x5ea6;&#x5668;&#x7684;&#x8c03;&#x5ea6;"/>
</node>
<node COLOR="#111111" CREATED="1472806455381" FOLDED="true" ID="ID_1288712713" MODIFIED="1529657527932" TEXT="&#x8fd0;&#x884c;&#x72b6;&#x6001;:">
<node COLOR="#111111" CREATED="1472806461273" ID="ID_301418233" MODIFIED="1472806461273" TEXT="&#x5982;&#x679c;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x83b7;&#x53d6; CPU &#x8d44;&#x6e90;&#xff0c;&#x5c31;&#x53ef;&#x4ee5;&#x6267;&#x884c; run()&#xff0c;&#x6b64;&#x65f6;&#x7ebf;&#x7a0b;&#x4fbf;&#x5904;&#x4e8e;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x3002;&#x5904;&#x4e8e;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x6700;&#x4e3a;&#x590d;&#x6742;&#xff0c;&#x5b83;&#x53ef;&#x4ee5;&#x53d8;&#x4e3a;&#x963b;&#x585e;&#x72b6;&#x6001;&#x3001;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x548c;&#x6b7b;&#x4ea1;&#x72b6;&#x6001;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472806467339" FOLDED="true" ID="ID_682744155" MODIFIED="1529657527932" TEXT="&#x963b;&#x585e;&#x72b6;&#x6001;:">
<node COLOR="#111111" CREATED="1472806483557" ID="ID_1231975665" MODIFIED="1472806483558" TEXT="&#x5982;&#x679c;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x6267;&#x884c;&#x4e86;sleep&#xff08;&#x7761;&#x7720;&#xff09;&#x3001;suspend&#xff08;&#x6302;&#x8d77;&#xff09;&#x7b49;&#x65b9;&#x6cd5;&#xff0c;&#x5931;&#x53bb;&#x6240;&#x5360;&#x7528;&#x8d44;&#x6e90;&#x4e4b;&#x540e;&#xff0c;&#x8be5;&#x7ebf;&#x7a0b;&#x5c31;&#x4ece;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x8fdb;&#x5165;&#x963b;&#x585e;&#x72b6;&#x6001;&#x3002;&#x5728;&#x7761;&#x7720;&#x65f6;&#x95f4;&#x5df2;&#x5230;&#x6216;&#x83b7;&#x5f97;&#x8bbe;&#x5907;&#x8d44;&#x6e90;&#x540e;&#x53ef;&#x4ee5;&#x91cd;&#x65b0;&#x8fdb;&#x5165;&#x5c31;&#x7eea;&#x72b6;&#x6001;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472807114713" FOLDED="true" ID="ID_1166178017" MODIFIED="1529657527933" TEXT="&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472807131292" FOLDED="true" ID="ID_1132999761" MODIFIED="1529657527933" TEXT="?">
<node COLOR="#111111" CREATED="1472807135252" FOLDED="true" ID="ID_1866525281" MODIFIED="1529657527933" TEXT="&#x6307;&#x7684;&#x662f;&#x7ebf;&#x7a0b;&#x88ab;&#x8c03;&#x5ea6;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x987a;&#x5e8f;">
<node COLOR="#111111" CREATED="1472806489522" FOLDED="true" ID="ID_999981579" MODIFIED="1529657527933" TEXT="&#x6b7b;&#x4ea1;&#x72b6;&#x6001;:">
<node COLOR="#111111" CREATED="1472806497027" ID="ID_1464879794" MODIFIED="1472806497027" TEXT="&#x4e00;&#x4e2a;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x7684;&#x7ebf;&#x7a0b;&#x5b8c;&#x6210;&#x4efb;&#x52a1;&#x6216;&#x8005;&#x5176;&#x4ed6;&#x7ec8;&#x6b62;&#x6761;&#x4ef6;&#x53d1;&#x751f;&#x65f6;&#xff0c;&#x8be5;&#x7ebf;&#x7a0b;&#x5c31;&#x5207;&#x6362;&#x5230;&#x7ec8;&#x6b62;&#x72b6;&#x6001;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472807160482" ID="ID_730217361" MODIFIED="1472807161554" TEXT="&#x6bcf;&#x4e00;&#x4e2a;Java&#x7ebf;&#x7a0b;&#x90fd;&#x6709;&#x4e00;&#x4e2a;&#x4f18;&#x5148;&#x7ea7;&#xff0c;&#x8fd9;&#x6837;&#x6709;&#x52a9;&#x4e8e;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x786e;&#x5b9a;&#x7ebf;&#x7a0b;&#x7684;&#x8c03;&#x5ea6;&#x987a;&#x5e8f;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472807182262" FOLDED="true" ID="ID_994454375" MODIFIED="1529657527933" TEXT="&#x53d6;&#x503c;">
<node COLOR="#111111" CREATED="1472807185104" ID="ID_1746403823" MODIFIED="1472807208974" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x6574;&#x6570;&#xff0c;&#x5176;&#x53d6;&#x503c;&#x8303;&#x56f4;&#x662f;1 &#xff08;Thread.MIN_PRIORITY &#xff09; &#x2014;&#x2014; &#x300b;10 &#xff08;Thread.MAX_PRIORITY &#xff09;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472807225204" FOLDED="true" ID="ID_1961434363" MODIFIED="1529657527933" TEXT="&#x9ed8;&#x8ba4;&#x4f18;&#x5148;&#x7ea7;">
<node COLOR="#111111" CREATED="1472807238113" ID="ID_1101583125" MODIFIED="1472807241904" TEXT="&#x6bcf;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x90fd;&#x4f1a;&#x5206;&#x914d;&#x4e00;&#x4e2a;&#x4f18;&#x5148;&#x7ea7;NORM_PRIORITY&#xff08;5&#xff09;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473485973385" FOLDED="true" ID="ID_102825382" MODIFIED="1529657527933" TEXT="&#x8be6;&#x60c5;">
<node COLOR="#111111" CREATED="1473485976427" ID="ID_415724947" MODIFIED="1473485984667" TEXT="&#x5f53;&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x6ca1;&#x6709;&#x6307;&#x5b9a;&#x65f6;&#xff0c;&#x6240;&#x6709;&#x7ebf;&#x7a0b;&#x90fd;&#x643a;&#x5e26;&#x666e;&#x901a;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976427" ID="ID_1955526544" MODIFIED="1473485976427" TEXT="&#x4f18;&#x5148;&#x7ea7;&#x53ef;&#x4ee5;&#x7528;&#x4ece;1&#x5230;10&#x7684;&#x8303;&#x56f4;&#x6307;&#x5b9a;&#x3002;10&#x8868;&#x793a;&#x6700;&#x9ad8;&#x4f18;&#x5148;&#x7ea7;&#xff0c;1&#x8868;&#x793a;&#x6700;&#x4f4e;&#x4f18;&#x5148;&#x7ea7;&#xff0c;5&#x662f;&#x666e;&#x901a;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_1354364185" MODIFIED="1473812688366" TEXT="&#x4f18;&#x5148;&#x7ea7;&#x6700;&#x9ad8;&#x7684;&#x7ebf;&#x7a0b;&#x5728;&#x6267;&#x884c;&#x65f6;&#x88ab;&#x7ed9;&#x4e88;&#x4f18;&#x5148;&#x3002;&#x4f46;&#x662f;&#x4e0d;&#x80fd;&#x4fdd;&#x8bc1;&#x7ebf;&#x7a0b;&#x5728;&#x542f;&#x52a8;&#x65f6;&#x5c31;&#x8fdb;&#x5165;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_1669394273" MODIFIED="1473485976437" TEXT="&#x4e0e;&#x5728;&#x7ebf;&#x7a0b;&#x6c60;&#x4e2d;&#x7b49;&#x5f85;&#x8fd0;&#x884c;&#x673a;&#x4f1a;&#x7684;&#x7ebf;&#x7a0b;&#x76f8;&#x6bd4;&#xff0c;&#x5f53;&#x524d;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7ebf;&#x7a0b;&#x53ef;&#x80fd;&#x603b;&#x662f;&#x62e5;&#x6709;&#x66f4;&#x9ad8;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_1121289792" MODIFIED="1473485976437" TEXT="&#x7531;&#x8c03;&#x5ea6;&#x7a0b;&#x5e8f;&#x51b3;&#x5b9a;&#x54ea;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x88ab;&#x6267;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_1139463386" MODIFIED="1473822146268" TEXT="t.setPriority(int)&#x7528;&#x6765;&#x8bbe;&#x5b9a;&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x3002;"/>
<node COLOR="#111111" CREATED="1473485976437" ID="ID_942057239" MODIFIED="1473812762069" TEXT="&#x6ce8;&#x610f;&#xff1a; &#x5728;&#x7ebf;&#x7a0b;&#x5f00;&#x59cb;&#x65b9;&#x6cd5;&#x88ab;&#x8c03;&#x7528;&#x4e4b;&#x524d;&#xff0c;&#x7ebf;&#x7a0b;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x5e94;&#x8be5;&#x88ab;&#x8bbe;&#x5b9a;&#x3002;">
<icon BUILTIN="messagebox_warning"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1473485992445" FOLDED="true" ID="ID_781803646" MODIFIED="1529657527937" TEXT="&#x7ebf;&#x7a0b;&#x7684;&#x8c03;&#x5ea6;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473486013430" FOLDED="true" ID="ID_1737775963" MODIFIED="1529657527934" TEXT="yield()">
<node COLOR="#111111" CREATED="1473486023623" FOLDED="true" ID="ID_1429948615" MODIFIED="1529657527934" TEXT="?">
<node COLOR="#111111" CREATED="1473486026025" ID="ID_1078717645" MODIFIED="1473486031805" TEXT="&#x653e;&#x624b;&#xff0c;&#x653e;&#x5f03;&#xff0c;&#x6295;&#x964d;&#x7684;&#x610f;&#x601d;"/>
<node COLOR="#111111" CREATED="1473486046989" ID="ID_723445096" MODIFIED="1473486046989" TEXT="&#x4e00;&#x4e2a;&#x8c03;&#x7528;yield()&#x65b9;&#x6cd5;&#x7684;&#x7ebf;&#x7a0b;&#x544a;&#x8bc9;&#x865a;&#x62df;&#x673a;&#x5b83;&#x4e50;&#x610f;&#x8ba9;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x5360;&#x7528;&#x81ea;&#x5df1;&#x7684;&#x4f4d;&#x7f6e;"/>
<node COLOR="#111111" CREATED="1473486060461" ID="ID_170210915" MODIFIED="1473486060461" TEXT="&#x8fd9;&#x8868;&#x660e;&#x8be5;&#x7ebf;&#x7a0b;&#x6ca1;&#x6709;&#x5728;&#x505a;&#x4e00;&#x4e9b;&#x7d27;&#x6025;&#x7684;&#x4e8b;&#x60c5;"/>
<node COLOR="#111111" CREATED="1473486095277" ID="ID_718530298" MODIFIED="1473486095277" TEXT="Yield&#x662f;&#x4e00;&#x4e2a;&#x9759;&#x6001;&#x7684;&#x539f;&#x751f;(native)&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1473486095277" ID="ID_22763230" MODIFIED="1473486095277" TEXT="Yield&#x544a;&#x8bc9;&#x5f53;&#x524d;&#x6b63;&#x5728;&#x6267;&#x884c;&#x7684;&#x7ebf;&#x7a0b;&#x628a;&#x8fd0;&#x884c;&#x673a;&#x4f1a;&#x4ea4;&#x7ed9;&#x7ebf;&#x7a0b;&#x6c60;&#x4e2d;&#x62e5;&#x6709;&#x76f8;&#x540c;&#x4f18;&#x5148;&#x7ea7;&#x7684;&#x7ebf;&#x7a0b;&#x3002;"/>
<node COLOR="#111111" CREATED="1473486095277" ID="ID_1865531220" MODIFIED="1473832176118" TEXT="Yield&#x4e0d;&#x80fd;&#x4fdd;&#x8bc1;&#x4f7f;&#x5f97;&#x5f53;&#x524d;&#x6b63;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x7ebf;&#x7a0b;&#x8fc5;&#x901f;&#x8f6c;&#x6362;&#x5230;&#x53ef;&#x8fd0;&#x884c;&#x7684;&#x72b6;&#x6001;"/>
<node COLOR="#111111" CREATED="1473486095287" ID="ID_1208803006" MODIFIED="1473486095287" TEXT="&#x5b83;&#x4ec5;&#x80fd;&#x4f7f;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#x4ece;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x8f6c;&#x5230;&#x53ef;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#xff0c;&#x800c;&#x4e0d;&#x662f;&#x7b49;&#x5f85;&#x6216;&#x963b;&#x585e;&#x72b6;&#x6001;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473486150596" FOLDED="true" ID="ID_1924503488" MODIFIED="1529657527934" TEXT="join()">
<node COLOR="#111111" CREATED="1473486154174" FOLDED="true" ID="ID_575495220" MODIFIED="1529657527934" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473486179566" ID="ID_1480951305" MODIFIED="1473487621239" TEXT="&#x8c03;&#x7528;&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x7ebf;&#x7a0b;&#x4f1a;&#x7b49;&#x5f85;"/>
</node>
<node COLOR="#111111" CREATED="1473487627997" FOLDED="true" ID="ID_104600732" MODIFIED="1529657527934" TEXT="&#x91cd;&#x8f7d;&#x7684;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473487658527" ID="ID_547888203" MODIFIED="1473487658527" TEXT="public final synchronized void join(long millis)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473487718572" ID="ID_829724177" MODIFIED="1473487728704" TEXT="sleep(time)"/>
<node COLOR="#111111" CREATED="1473487675712" FOLDED="true" ID="ID_947008418" MODIFIED="1529657527934" TEXT="wait">
<node COLOR="#111111" CREATED="1473487887238" FOLDED="true" ID="ID_224314802" MODIFIED="1529657527934" TEXT="?">
<node COLOR="#111111" CREATED="1473487888850" ID="ID_585528685" MODIFIED="1473487888850" TEXT="&#x8ba9;&#x5f53;&#x524d;&#x7ebf;&#x7a0b;&#x963b;&#x585e;&#xff0c;&#x5e76;&#x4e14;&#x5f53;&#x524d;&#x7ebf;&#x7a0b;&#x5fc5;&#x987b;&#x62e5;&#x6709;&#x6b64;&#x5bf9;&#x8c61;&#x7684;monitor&#xff08;&#x5373;&#x9501;&#xff09;"/>
<node COLOR="#111111" CREATED="1473488038420" ID="ID_635018300" MODIFIED="1473488038420" TEXT="&#x8c03;&#x7528;wait()&#x65b9;&#x6cd5;&#x5fc5;&#x987b;&#x5728;&#x540c;&#x6b65;&#x5757;&#x6216;&#x8005;&#x540c;&#x6b65;&#x65b9;&#x6cd5;&#x4e2d;&#x8fdb;&#x884c;&#xff08;synchronized&#x5757;&#x6216;&#x8005;synchronized&#x65b9;&#x6cd5;&#xff09;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473487680492" FOLDED="true" ID="ID_1986992493" MODIFIED="1529657527934" TEXT="notify()">
<node COLOR="#111111" CREATED="1473487913650" ID="ID_601768607" MODIFIED="1473487913650" TEXT="&#x5524;&#x9192;&#x4e00;&#x4e2a;&#x6b63;&#x5728;&#x7b49;&#x5f85;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;monitor&#x7684;&#x7ebf;&#x7a0b;&#xff0c;&#x5982;&#x679c;&#x6709;&#x591a;&#x4e2a;&#x7ebf;&#x7a0b;&#x90fd;&#x5728;&#x7b49;&#x5f85;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;monitor&#xff0c;&#x5219;&#x53ea;&#x80fd;&#x5524;&#x9192;&#x5176;&#x4e2d;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#111111" CREATED="1473487685402" FOLDED="true" ID="ID_1024543299" MODIFIED="1529657527935" TEXT="notifyAll()">
<node COLOR="#111111" CREATED="1473487924610" ID="ID_1256021478" MODIFIED="1473487924610" TEXT="&#x5524;&#x9192;&#x6240;&#x6709;&#x6b63;&#x5728;&#x7b49;&#x5f85;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;monitor&#x7684;&#x7ebf;&#x7a0b;&#xff1b;"/>
</node>
<node COLOR="#111111" CREATED="1473488118878" ID="ID_1562745902" MODIFIED="1473488124190" TEXT="&#x6ce8;&#x610f;&#xff1a; notify()&#x548c;notifyAll()&#x65b9;&#x6cd5;&#x53ea;&#x662f;&#x5524;&#x9192;&#x7b49;&#x5f85;&#x8be5;&#x5bf9;&#x8c61;&#x7684;monitor&#x7684;&#x7ebf;&#x7a0b;&#xff0c;&#x5e76;&#x4e0d;&#x51b3;&#x5b9a;&#x54ea;&#x4e2a;&#x7ebf;&#x7a0b;&#x80fd;&#x591f;&#x83b7;&#x53d6;&#x5230;monitor"/>
<node COLOR="#111111" CREATED="1473487954148" FOLDED="true" ID="ID_1572672517" LINK="&#x7ebf;&#x7a0b;/&#x751f;&#x4ea7;&#x6d88;&#x8d39;&#x8005;.txt" MODIFIED="1529657527936" TEXT="monitor &#x9501;">
<node COLOR="#111111" CREATED="1473489366009" FOLDED="true" ID="ID_788116496" MODIFIED="1529657527936" TEXT="&#x6b7b;&#x9501;">
<node COLOR="#111111" CREATED="1473489371409" FOLDED="true" ID="ID_539720850" MODIFIED="1529657527935" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473489412109" ID="ID_1993744865" MODIFIED="1473489413292" TEXT="&#x6240;&#x8c13;&#x6b7b;&#x9501;&#xff1a; &#x662f;&#x6307;&#x4e24;&#x4e2a;&#x6216;&#x4e24;&#x4e2a;&#x4ee5;&#x4e0a;&#x7684;&#x8fdb;&#x7a0b;&#x5728;&#x6267;&#x884c;&#x8fc7;&#x7a0b;&#x4e2d;&#xff0c;&#x7531;&#x4e8e;&#x7ade;&#x4e89;&#x8d44;&#x6e90;&#x6216;&#x8005;&#x7531;&#x4e8e;&#x5f7c;&#x6b64;&#x901a;&#x4fe1;&#x800c;&#x9020;&#x6210;&#x7684;&#x4e00;&#x79cd;&#x963b;&#x585e;&#x7684;&#x73b0;&#x8c61;&#xff0c;&#x82e5;&#x65e0;&#x5916;&#x529b;&#x4f5c;&#x7528;&#xff0c;&#x5b83;&#x4eec;&#x90fd;&#x5c06;&#x65e0;&#x6cd5;&#x63a8;&#x8fdb;&#x4e0b;&#x53bb;&#x3002;&#x6b64;&#x65f6;&#x79f0;&#x7cfb;&#x7edf;&#x5904;&#x4e8e;&#x6b7b;&#x9501;&#x72b6;&#x6001;&#x6216;&#x7cfb;&#x7edf;&#x4ea7;&#x751f;&#x4e86;&#x6b7b;&#x9501;&#xff0c;&#x8fd9;&#x4e9b;&#x6c38;&#x8fdc;&#x5728;&#x4e92;&#x76f8;&#x7b49;&#x5f85;&#x7684;&#x8fdb;&#x7a0b;&#x79f0;&#x4e3a;&#x6b7b;&#x9501;&#x8fdb;&#x7a0b;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473489425720" FOLDED="true" ID="ID_1986606199" MODIFIED="1529657527935" TEXT="&#x4ea7;&#x751f;&#x6b7b;&#x9501;&#x7684;&#x6761;&#x4ef6;">
<node COLOR="#111111" CREATED="1473489445703" ID="ID_1332762518" MODIFIED="1473489445704" TEXT="1&#xff09;&#x4e92;&#x65a5;&#x6761;&#x4ef6;&#xff1a;&#x6307;&#x8fdb;&#x7a0b;&#x5bf9;&#x6240;&#x5206;&#x914d;&#x5230;&#x7684;&#x8d44;&#x6e90;&#x8fdb;&#x884c;&#x6392;&#x5b83;&#x6027;&#x4f7f;&#x7528;&#xff0c;&#x5373;&#x5728;&#x4e00;&#x6bb5;&#x65f6;&#x95f4;&#x5185;&#x67d0;&#x8d44;&#x6e90;&#x53ea;&#x7531;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x5360;&#x7528;&#x3002;&#x5982;&#x679c;&#x6b64;&#x65f6;&#x8fd8;&#x6709;&#x5176;&#x5b83;&#x8fdb;&#x7a0b;&#x8bf7;&#x6c42;&#x8d44;&#x6e90;&#xff0c;&#x5219;&#x8bf7;&#x6c42;&#x8005;&#x53ea;&#x80fd;&#x7b49;&#x5f85;&#xff0c;&#x76f4;&#x81f3;&#x5360;&#x6709;&#x8d44;&#x6e90;&#x7684;&#x8fdb;&#x7a0b;&#x7528;&#x6bd5;&#x91ca;&#x653e;&#x3002;"/>
<node COLOR="#111111" CREATED="1473489445713" ID="ID_1694330864" MODIFIED="1473489445714" TEXT="2&#xff09;&#x8bf7;&#x6c42;&#x548c;&#x4fdd;&#x6301;&#x6761;&#x4ef6;&#xff1a;&#x6307;&#x8fdb;&#x7a0b;&#x5df2;&#x7ecf;&#x4fdd;&#x6301;&#x81f3;&#x5c11;&#x4e00;&#x4e2a;&#x8d44;&#x6e90;&#xff0c;&#x4f46;&#x53c8;&#x63d0;&#x51fa;&#x4e86;&#x65b0;&#x7684;&#x8d44;&#x6e90;&#x8bf7;&#x6c42;&#xff0c;&#x800c;&#x8be5;&#x8d44;&#x6e90;&#x5df2;&#x88ab;&#x5176;&#x5b83;&#x8fdb;&#x7a0b;&#x5360;&#x6709;&#xff0c;&#x6b64;&#x65f6;&#x8bf7;&#x6c42;&#x8fdb;&#x7a0b;&#x963b;&#x585e;&#xff0c;&#x4f46;&#x53c8;&#x5bf9;&#x81ea;&#x5df1;&#x5df2;&#x83b7;&#x5f97;&#x7684;&#x5176;&#x5b83;&#x8d44;&#x6e90;&#x4fdd;&#x6301;&#x4e0d;&#x653e;&#x3002;"/>
<node COLOR="#111111" CREATED="1473489445731" ID="ID_432262293" MODIFIED="1473489445731" TEXT="3&#xff09;&#x4e0d;&#x5265;&#x593a;&#x6761;&#x4ef6;&#xff1a;&#x6307;&#x8fdb;&#x7a0b;&#x5df2;&#x83b7;&#x5f97;&#x7684;&#x8d44;&#x6e90;&#xff0c;&#x5728;&#x672a;&#x4f7f;&#x7528;&#x5b8c;&#x4e4b;&#x524d;&#xff0c;&#x4e0d;&#x80fd;&#x88ab;&#x5265;&#x593a;&#xff0c;&#x53ea;&#x80fd;&#x5728;&#x4f7f;&#x7528;&#x5b8c;&#x65f6;&#x7531;&#x81ea;&#x5df1;&#x91ca;&#x653e;&#x3002;"/>
<node COLOR="#111111" CREATED="1473489445736" ID="ID_1737047205" MODIFIED="1473489445738" TEXT="4&#xff09;&#x73af;&#x8def;&#x7b49;&#x5f85;&#x6761;&#x4ef6;&#xff1a;&#x6307;&#x5728;&#x53d1;&#x751f;&#x6b7b;&#x9501;&#x65f6;&#xff0c;&#x5fc5;&#x7136;&#x5b58;&#x5728;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x2014;&#x2014;&#x8d44;&#x6e90;&#x7684;&#x73af;&#x5f62;&#x94fe;&#xff0c;&#x5373;&#x8fdb;&#x7a0b;&#x96c6;&#x5408;{P0&#xff0c;P1&#xff0c;P2&#xff0c;&#xb7;&#xb7;&#xb7;&#xff0c;Pn}&#x4e2d;&#x7684;P0&#x6b63;&#x5728;&#x7b49;&#x5f85;&#x4e00;&#x4e2a;P1&#x5360;&#x7528;&#x7684;&#x8d44;&#x6e90;&#xff1b;P1&#x6b63;&#x5728;&#x7b49;&#x5f85;P2&#x5360;&#x7528;&#x7684;&#x8d44;&#x6e90;&#xff0c;&#x2026;&#x2026;&#xff0c;Pn&#x6b63;&#x5728;&#x7b49;&#x5f85;&#x5df2;&#x88ab;P0&#x5360;&#x7528;&#x7684;&#x8d44;&#x6e90;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473489505754" FOLDED="true" ID="ID_1562452888" MODIFIED="1529657527936" TEXT="&#x5904;&#x7406;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473489513889" FOLDED="true" ID="ID_1191796292" MODIFIED="1529657527935" TEXT="&#x9884;&#x9632;&#x6b7b;&#x9501;">
<node COLOR="#111111" CREATED="1473489534141" ID="ID_689011129" MODIFIED="1473489534141" TEXT="&#x7834;&#x574f;&#x4ea7;&#x751f;&#x6b7b;&#x9501;&#x7684;&#x56db;&#x4e2a;&#x5fc5;&#x8981;&#x6761;&#x4ef6;&#x4e2d;&#x7684;&#x4e00;&#x4e2a;&#x6216;&#x8005;&#x51e0;&#x4e2a;&#xff0c;&#x6765;&#x9884;&#x9632;&#x53d1;&#x751f;&#x6b7b;&#x9501;"/>
</node>
<node COLOR="#111111" CREATED="1473489525427" FOLDED="true" ID="ID_652650897" MODIFIED="1529657527935" TEXT="&#x68c0;&#x6d4b;&#x548c;&#x89e3;&#x9664;&#x6b7b;&#x9501;">
<node COLOR="#111111" CREATED="1473489569181" FOLDED="true" ID="ID_660464118" MODIFIED="1529657527935" TEXT="&#x68c0;&#x67e5;">
<node COLOR="#111111" CREATED="1473489571698" ID="ID_1524171934" MODIFIED="1473489571698" TEXT="&#x68c0;&#x6d4b;&#x65b9;&#x6cd5;&#x5305;&#x62ec;&#x5b9a;&#x65f6;&#x68c0;&#x6d4b;&#x3001;&#x6548;&#x7387;&#x4f4e;&#x65f6;&#x68c0;&#x6d4b;&#x3001;&#x8fdb;&#x7a0b;&#x7b49;&#x5f85;&#x65f6;&#x68c0;&#x6d4b;&#x7b49;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473489580246" FOLDED="true" ID="ID_1529997210" MODIFIED="1529657527935" TEXT="&#x89e3;&#x9664;">
<node COLOR="#111111" CREATED="1473489582484" ID="ID_1738600569" MODIFIED="1473489582484" TEXT="&#x91c7;&#x53d6;&#x9002;&#x5f53;&#x63aa;&#x65bd;&#xff0c;&#x4ece;&#x7cfb;&#x7edf;&#x4e2d;&#x5c06;&#x5df2;&#x53d1;&#x751f;&#x7684;&#x6b7b;&#x9501;&#x6e05;&#x9664;&#x6389;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473489710065" FOLDED="true" ID="ID_1985127553" MODIFIED="1529657527936" TEXT="&#x7ecf;&#x5178;&#x6848;&#x4f8b;">
<node COLOR="#111111" CREATED="1473489720894" FOLDED="true" ID="ID_350227106" LINK="&#x7ebf;&#x7a0b;/&#x54f2;&#x5b66;&#x5bb6;.txt" MODIFIED="1529657527936" TEXT="&#x54f2;&#x5b66;&#x5bb6;&#x5c31;&#x9910;">
<node COLOR="#111111" CREATED="1473489731595" ID="ID_1076518948" MODIFIED="1473489748316" TEXT="&#x5047;&#x8bbe;&#x6709;&#x51e0;&#x4f4d;&#x54f2;&#x5b66;&#x5bb6;&#x56f4;&#x5750;&#x5728;&#x4e00;&#x5f20;&#x9910;&#x684c;&#x65c1;&#xff0c;&#x684c;&#x4e0a;&#x6709;&#x5403;&#x4e0d;&#x5c3d;&#x7684;&#x98df;&#x54c1;&#xff0c;&#x6bcf;&#x4e24;&#x4f4d;&#x54f2;&#x5b66;&#x5bb6;&#x4e4b;&#x95f4;&#x6446;&#x653e;&#x7740;&#x4e00;&#x6839;&#x7b77;&#x5b50;&#xff0c;&#x7b77;&#x5b50;&#x7684;&#x4e2a;&#x6570;&#x4e0e;&#x54f2;&#x5b66;&#x5bb6;&#x7684;&#x6570;&#x91cf;&#x76f8;&#x7b49;&#xff0c;&#x6bcf;&#x4e00;&#x4f4d;&#x54f2;&#x5b66;&#x5bb6;&#x8981;&#x4e48;&#x601d;&#x8003;&#xff0c;&#x8981;&#x4e48;&#x7b49;&#x5f85;&#xff0c;&#x8981;&#x4e48;&#x62ff;&#x8d77;&#x5de6;&#x53f3;&#x4e24;&#x6839;&#x7b77;&#x5b50;&#x8fdb;&#x9910;"/>
</node>
<node COLOR="#111111" CREATED="1473493009811" ID="ID_1874763365" LINK="&#x7ebf;&#x7a0b;/&#x751f;&#x4ea7;&#x6d88;&#x8d39;&#x8005;.txt" MODIFIED="1473493025333" TEXT="&#x751f;&#x4ea7;&#x8005;&#x6d88;&#x8d39;&#x8005;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473489873075" ID="ID_1479210879" MODIFIED="1473489891011" TEXT="&#x706b;&#x8f66;&#x4e0a;&#x5395;&#x6240;&#x4f8b;&#x5b50;"/>
</node>
<node COLOR="#111111" CREATED="1473489945051" FOLDED="true" ID="ID_966444858" MODIFIED="1529657527937" TEXT="sychronized">
<node COLOR="#111111" CREATED="1473489953722" FOLDED="true" ID="ID_11410771" MODIFIED="1529657527937" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473489956722" ID="ID_1824778194" MODIFIED="1473489985215" TEXT="&#x540c;&#x6b65;"/>
<node COLOR="#111111" CREATED="1473489985753" ID="ID_744444745" MODIFIED="1473490003466" TEXT="&#x6307;&#x7684;&#x662f;&#x4e8b;&#x60c5;&#x6309;&#x7ebf;&#x6027;&#x987a;&#x5e8f;&#x8fdb;&#x884c;"/>
</node>
<node COLOR="#111111" CREATED="1473490005644" ID="ID_790722974" MODIFIED="1473490008573" TEXT="&#x540c;&#x6b65;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1473490008861" ID="ID_1193839517" MODIFIED="1473490012063" TEXT="&#x540c;&#x6b65;&#x4ee3;&#x7801;&#x5757;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473485459276" FOLDED="true" ID="ID_23597191" MODIFIED="1529657527939" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473485497891" FOLDED="true" ID="ID_355172943" MODIFIED="1529657527937" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1473485501523" ID="ID_951531013" MODIFIED="1473485501523" TEXT="public Thread()"/>
<node COLOR="#111111" CREATED="1473485509975" ID="ID_1060237657" MODIFIED="1473485509975" TEXT="public Thread(Runnable target)"/>
<node COLOR="#111111" CREATED="1473485523765" ID="ID_1106671765" MODIFIED="1473485523765" TEXT="public Thread(String name)"/>
<node COLOR="#111111" CREATED="1473485533367" ID="ID_1902881146" MODIFIED="1473485533367" TEXT="public Thread(Runnable target, String name)"/>
</node>
<node COLOR="#111111" CREATED="1473485562398" FOLDED="true" ID="ID_1215626122" MODIFIED="1529657527938" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473485554499" ID="ID_869806313" MODIFIED="1473485554499" TEXT="public static native Thread currentThread()"/>
<node COLOR="#111111" CREATED="1473485578554" ID="ID_1285104674" MODIFIED="1473485578554" TEXT="public static native void yield()"/>
<node COLOR="#111111" CREATED="1473485588071" ID="ID_1910496719" MODIFIED="1473485588071" TEXT="public static native void sleep(long millis) throws InterruptedException"/>
<node COLOR="#111111" CREATED="1473485612753" ID="ID_148058498" MODIFIED="1473485612753" TEXT="public synchronized void start()"/>
<node COLOR="#111111" CREATED="1473485648135" ID="ID_1131533180" MODIFIED="1473485648135" TEXT="public void interrupt()"/>
<node COLOR="#111111" CREATED="1473485655247" ID="ID_591133424" MODIFIED="1473485655247" TEXT="public static boolean interrupted()"/>
<node COLOR="#111111" CREATED="1473485660851" ID="ID_251876176" MODIFIED="1473485660851" TEXT="public boolean isInterrupted()"/>
<node COLOR="#111111" CREATED="1473485670243" ID="ID_476388164" MODIFIED="1473485670243" TEXT="public final native boolean isAlive()"/>
<node COLOR="#111111" CREATED="1473485687074" ID="ID_1202835303" MODIFIED="1473485687074" TEXT="public final native boolean isAlive()"/>
<node COLOR="#111111" CREATED="1473485696176" ID="ID_1216178948" MODIFIED="1473485696176" TEXT="public final void setPriority(int newPriority)"/>
<node COLOR="#111111" CREATED="1473485704617" ID="ID_286682785" MODIFIED="1473485704617" TEXT="public final int getPriority()"/>
<node COLOR="#111111" CREATED="1473485711388" ID="ID_1709346084" MODIFIED="1473485711388" TEXT="public final synchronized void setName(String name)"/>
<node COLOR="#111111" CREATED="1473485720099" ID="ID_128109676" MODIFIED="1473485720099" TEXT="public final String getName()"/>
<node COLOR="#111111" CREATED="1473485733341" ID="ID_1253516713" MODIFIED="1473485733341" TEXT="public final synchronized void join(long millis)"/>
<node COLOR="#111111" CREATED="1473485745631" ID="ID_626591310" MODIFIED="1473485745631" TEXT="public final void join() throws InterruptedException"/>
<node COLOR="#111111" CREATED="1473485758840" FOLDED="true" ID="ID_626221035" MODIFIED="1529657527938" TEXT="public final void setDaemon(boolean on)">
<node COLOR="#111111" CREATED="1473485869859" ID="ID_1005339156" MODIFIED="1473485881821" TEXT="&#x8bbe;&#x7f6e;&#x662f;&#x5426;&#x662f;&#x540e;&#x53f0;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#111111" CREATED="1473485765099" FOLDED="true" ID="ID_1639921640" MODIFIED="1529657527938" TEXT="public final boolean isDaemon()">
<node COLOR="#111111" CREATED="1473485860159" ID="ID_1580840380" MODIFIED="1473485867511" TEXT="&#x662f;&#x5426;&#x662f;&#x540e;&#x53f0;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#111111" CREATED="1473485818111" ID="ID_1583541444" MODIFIED="1473485818111" TEXT="public long getId()"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472807281253" FOLDED="true" ID="ID_1774229408" MODIFIED="1529657527942" TEXT="&#x5982;&#x4f55;&#x4f7f;&#x7528;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472807296683" FOLDED="true" ID="ID_190407792" MODIFIED="1529657527939" TEXT="&#x65b9;&#x6cd5;&#x4e00;&#xff1a;">
<node COLOR="#111111" CREATED="1472807317075" ID="ID_78376619" MODIFIED="1472808147345" TEXT="&#x521b;&#x5efa;&#x4e00;&#x4e2a;&#x7ebf;&#x7a0b;&#xff1a; Thread thread = new Thread()"/>
<node COLOR="#111111" CREATED="1472808127203" ID="ID_176530022" MODIFIED="1472808161355" TEXT="&#x7136;&#x540e;&#x8c03;&#x7528;: thread.start()"/>
<node COLOR="#111111" CREATED="1472807437757" ID="ID_611912213" MODIFIED="1472807441099" TEXT="Thread"/>
</node>
<node COLOR="#111111" CREATED="1472807336163" FOLDED="true" ID="ID_189251039" MODIFIED="1529657527939" TEXT="&#x65b9;&#x6cd5;&#x4e8c;">
<node COLOR="#111111" CREATED="1472807340365" ID="ID_1265151918" MODIFIED="1472807340365" TEXT="&#x5b9e;&#x73b0;Runnable&#x63a5;&#x53e3;&#x6765;&#x521b;&#x5efa;&#x7ebf;&#x7a0b;"/>
<node COLOR="#111111" CREATED="1472807490977" ID="ID_998308344" MODIFIED="1472807548919" TEXT="Runnable"/>
</node>
<node COLOR="#111111" CREATED="1473226826871" FOLDED="true" ID="ID_267735985" MODIFIED="1529657527942" TEXT="&#x65b9;&#x6cd5;&#x4e09;&#xff1a; &#x7ebf;&#x7a0b;&#x6c60;">
<node COLOR="#111111" CREATED="1473226957513" FOLDED="true" ID="ID_1493222934" MODIFIED="1529657527942" TEXT="ExecutorService">
<node COLOR="#111111" CREATED="1473483668987" FOLDED="true" ID="ID_578949897" MODIFIED="1529657527939" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473483696174" ID="ID_1220499154" MODIFIED="1473483696175" TEXT="Executor&#x5c31;&#x662f;Runnable&#x548c;Callable&#x7684;&#x8c03;&#x5ea6;&#x5bb9;&#x5668;"/>
</node>
<node COLOR="#111111" CREATED="1473468171805" FOLDED="true" ID="ID_640317275" MODIFIED="1529657527939" TEXT="&#x9759;&#x6001;&#x83b7;&#x53d6;&#x7ebf;&#x7a0b;&#x6c60;&#x7684;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473226977847" ID="ID_1544480715" MODIFIED="1473226977847" TEXT="public static ExecutorService newFixedThreadPool(int nThreads)"/>
<node COLOR="#111111" CREATED="1473226993620" ID="ID_496144506" MODIFIED="1473226993620" TEXT="public static ExecutorService newCachedThreadPool()"/>
<node COLOR="#111111" CREATED="1473227002968" ID="ID_613769480" MODIFIED="1473227002968" TEXT="public static ExecutorService newSingleThreadExecutor()"/>
</node>
<node COLOR="#111111" CREATED="1473484080898" FOLDED="true" ID="ID_1308956293" MODIFIED="1529657527941" TEXT="&#x76f8;&#x5173;&#x7c7b;">
<node COLOR="#111111" CREATED="1473483610186" FOLDED="true" ID="ID_105092771" MODIFIED="1529657527939" TEXT="Runnable">
<node COLOR="#111111" CREATED="1473483728210" ID="ID_410150524" MODIFIED="1473483741330" TEXT="&#x6267;&#x884c;&#x5b8c;&#x6bd5;&#x53ea;&#x6709;&#x6ca1;&#x6709;&#x7ed3;&#x679c;&#x53ef;&#x4ee5;&#x8fd4;&#x56de;"/>
</node>
<node COLOR="#111111" CREATED="1473483622696" FOLDED="true" ID="ID_1169912287" MODIFIED="1529657527939" TEXT="Callable">
<node COLOR="#111111" CREATED="1473483747598" ID="ID_1154251671" MODIFIED="1491830511708" TEXT="&#x6267;&#x884c;&#x5b8c;&#x6bd5;&#x6709;&#x7ed3;&#x679c;&#x8fd4;&#x56de;"/>
</node>
<node COLOR="#111111" CREATED="1473483628796" FOLDED="true" ID="ID_732975092" MODIFIED="1529657527941" TEXT="Future">
<node COLOR="#111111" CREATED="1473484847974" FOLDED="true" ID="ID_7178218" MODIFIED="1529657527940" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473483716650" ID="ID_1640472298" MODIFIED="1473484857246" TEXT=" &#x662f;&#x5bf9;&#x4e8e;&#x5177;&#x4f53;&#x7684;&#x8c03;&#x5ea6;&#x4efb;&#x52a1;&#x7684;&#x6267;&#x884c;&#x7ed3;&#x679c;&#x8fdb;&#x884c;&#x67e5;&#x770b;&#xff0c;&#x6700;&#x4e3a;&#x5173;&#x952e;&#x7684;&#x662f;Future&#x53ef;&#x4ee5;&#x68c0;&#x67e5;&#x5bf9;&#x5e94;&#x7684;&#x4efb;&#x52a1;&#x662f;&#x5426;&#x5df2;&#x7ecf;&#x5b8c;&#x6210;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x963b;&#x585e;&#x5728;get&#x65b9;&#x6cd5;&#x4e0a;&#x4e00;&#x76f4;&#x7b49;&#x5f85;&#x4efb;&#x52a1;&#x8fd4;&#x56de;&#x7ed3;&#x679c;"/>
</node>
<node COLOR="#111111" CREATED="1473484861694" FOLDED="true" ID="ID_170618425" MODIFIED="1529657527940" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473484871271" ID="ID_1096156466" MODIFIED="1473484871271" TEXT="boolean cancel(boolean mayInterruptIfRunning)"/>
<node COLOR="#111111" CREATED="1473484883437" ID="ID_525215343" MODIFIED="1473484883437" TEXT="boolean isCancelled()"/>
<node COLOR="#111111" CREATED="1473484889301" ID="ID_1753093855" MODIFIED="1473484889301" TEXT="boolean isDone()"/>
<node COLOR="#111111" CREATED="1473484897292" FOLDED="true" ID="ID_8201986" MODIFIED="1529657527940" TEXT="V get() throws InterruptedException, ExecutionException">
<node COLOR="#111111" CREATED="1473484900590" ID="ID_1534805971" MODIFIED="1473484911982" TEXT="&#x83b7;&#x53d6;&#x6267;&#x884c;&#x7684;&#x7ed3;&#x679c;&#xff0c;&#x4f1a;&#x963b;&#x585e;&#x7ebf;&#x7a0b;"/>
</node>
<node COLOR="#111111" CREATED="1473484925258" FOLDED="true" ID="ID_168745868" MODIFIED="1529657527940" TEXT="V get(long timeout, TimeUnit unit) throws InterruptedException, ExecutionException, TimeoutException">
<node COLOR="#111111" CREATED="1473484942657" ID="ID_1563937565" MODIFIED="1473484953698" TEXT="&#x8bbe;&#x7f6e;&#x8d85;&#x65f6;&#x65f6;&#x95f4;&#xff0c;&#x4f1a;&#x963b;&#x585e;&#x7ebf;&#x7a0b;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473483634266" FOLDED="true" ID="ID_95317297" MODIFIED="1529657527940" TEXT="&#x5b50;&#x7c7b;FutureTask">
<node COLOR="#111111" CREATED="1473485067311" FOLDED="true" ID="ID_40517919" MODIFIED="1529657527940" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473483794650" ID="ID_1024343016" MODIFIED="1473483813820" TEXT="&#x4e00;&#x4e2a;RunnableFuture&lt;V&gt;&#xff0c;&#x5373;&#x5b9e;&#x73b0;&#x4e86;Runnbale&#x53c8;&#x5b9e;&#x73b0;&#x4e86;Futrue&lt;V&gt;&#x8fd9;&#x4e24;&#x4e2a;&#x63a5;&#x53e3;&#xff0c;&#x53e6;&#x5916;&#x5b83;&#x8fd8;&#x53ef;&#x4ee5;&#x5305;&#x88c5;Runnable&#x548c;Callable&lt;V&gt;&#xff0c;&#x6240;&#x4ee5;&#x662f;&#x4e00;&#x4e2a;&#x590d;&#x5408;&#x4f53;&#xff0c;&#x5b83;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;Thread&#x5305;&#x88c5;&#x6765;&#x76f4;&#x63a5;&#x6267;&#x884c;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x63d0;&#x4ea4;&#x7ed9;ExecuteService&#x6765;&#x6267;&#x884c;"/>
</node>
<node COLOR="#111111" CREATED="1473485062191" FOLDED="true" ID="ID_236813522" MODIFIED="1529657527940" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1473485064983" ID="ID_710133342" MODIFIED="1473485064983" TEXT="public FutureTask(Callable&lt;V&gt; callable)"/>
<node COLOR="#111111" CREATED="1473485079714" ID="ID_1887742558" MODIFIED="1473485079714" TEXT="public FutureTask(Runnable runnable, V result)"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473484095578" FOLDED="true" ID="ID_1327974000" MODIFIED="1529657527942" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473484111052" ID="ID_1154628060" MODIFIED="1473484111052" TEXT="shutdown()"/>
<node COLOR="#111111" CREATED="1473484140240" ID="ID_840782911" MODIFIED="1473484140240" TEXT="List&lt;Runnable&gt; shutdownNow();"/>
<node COLOR="#111111" CREATED="1473484245477" ID="ID_1368160523" MODIFIED="1473484245477" TEXT="boolean isShutdown()"/>
<node COLOR="#111111" CREATED="1473484252576" FOLDED="true" ID="ID_609671653" MODIFIED="1529657527941" TEXT="boolean isTerminated()">
<node COLOR="#111111" CREATED="1474332167276" ID="ID_568786039" MODIFIED="1474332176838" TEXT="&#x4efb;&#x52a1;&#x5b8c;&#x6210;"/>
</node>
<node COLOR="#111111" CREATED="1473484339767" ID="ID_1033905775" MODIFIED="1473484339767" TEXT="boolean awaitTermination(long timeout, TimeUnit unit)"/>
<node COLOR="#111111" CREATED="1473484384398" ID="ID_1533223360" MODIFIED="1473484384398" TEXT="&lt;T&gt; Future&lt;T&gt; submit(Callable&lt;T&gt; task)"/>
<node COLOR="#111111" CREATED="1473484390793" ID="ID_669777662" MODIFIED="1473484423688" TEXT="&lt;T&gt; Future&lt;T&gt; submit(Runnable task, T result)"/>
<node COLOR="#111111" CREATED="1473484417088" ID="ID_355519210" MODIFIED="1473484498427" TEXT="Future&lt;?&gt; submit(Runnable task)">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1473491489652" ID="ID_1218997239" MODIFIED="1473491611336" TEXT="void execute(Runnable task)">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1522211090733" FOLDED="true" ID="ID_482594920" MODIFIED="1529657527942">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32447;&#31243;&#30340;&#21516;&#27493;&#30340;&#19977;&#31181;&#26041;&#24335;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522211556743" ID="ID_266145995" MODIFIED="1522211560089" TEXT="&#x540c;&#x6b65;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1522211560428" ID="ID_284005721" MODIFIED="1522211563017" TEXT="&#x540c;&#x6b65;&#x4ee3;&#x7801;&#x5757;"/>
<node COLOR="#111111" CREATED="1522211563484" ID="ID_1887122040" MODIFIED="1522211591753" TEXT="&#x4f7f;&#x7528;ReentrantLock"/>
</node>
<node COLOR="#990000" CREATED="1522714477639" FOLDED="true" ID="ID_645821311" MODIFIED="1529657527943" TEXT="&#x6b7b;&#x9501;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522714485310" ID="ID_1520728645" MODIFIED="1522714487850">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 15.0pt"><font color="#000080"><b>package </b></font>org.lc;<br /><br /><font color="#000080"><b>public class </b></font>DeadLock {<br />    <font color="#000080"><b>private </b></font>Object <font color="#660e7a"><b>wifeLock </b></font>= <font color="#008000"><b>&quot;lock1&quot;</b></font>;<br />    <font color="#000080"><b>private </b></font>Object <font color="#660e7a"><b>husbandLock </b></font>= <font color="#008000"><b>&quot;lock2&quot;</b></font>;<br /><br />    <font color="#000080"><b>void </b></font>wife() {<br />        <font color="#000080"><b>while </b></font>(<font color="#000080"><b>true</b></font>) {<br />            System.<font color="#660e7a"><b><i>out</i></b></font>.println(Thread.<i>currentThread</i>().getName()+<font color="#008000"><b>&quot;  wife&quot;</b></font>);<br />            <font color="#000080"><b>synchronized </b></font>(<font color="#660e7a"><b>wifeLock</b></font>) {<br />                System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;wife&quot;</b></font>);<br />                <font color="#000080"><b>synchronized </b></font>(<font color="#660e7a"><b>husbandLock</b></font>) {<br />                    System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;husband&quot;</b></font>);<br />                }<br />            }<br />        }<br />    }<br /><br />    <font color="#000080"><b>void </b></font>husband() {<br />        System.<font color="#660e7a"><b><i>out</i></b></font>.println(Thread.<i>currentThread</i>().getName()+<font color="#008000"><b>&quot;  husband&quot;</b></font>);<br />        <font color="#000080"><b>while </b></font>(<font color="#000080"><b>true</b></font>) {<br />            <font color="#000080"><b>synchronized </b></font>(<font color="#660e7a"><b>husbandLock</b></font>) {<br />                System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;husbank-----&quot;</b></font>);<br />                <font color="#000080"><b>synchronized </b></font>(<font color="#660e7a"><b>wifeLock</b></font>) {<br />                    System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;wife------&quot;</b></font>);<br />                }<br />            }<br />        }<br />    }<br /><br />    <font color="#000080"><b>public static void </b></font>main(String[] args) {<br />        DeadLock deadLock = <font color="#000080"><b>new </b></font>DeadLock();<br />        Runnable runnableWife = <font color="#000080"><b>new </b></font>Runnable() {<br />            <font color="#808000">@Override<br />            </font><font color="#000080"><b>public void </b></font>run() {<br />                <font color="#660e7a">deadLock</font>.wife();<br />            }<br />        };<br />        Thread wifeThread = <font color="#000080"><b>new </b></font>Thread(runnableWife);<br /><br />        Runnable runnableHus = <font color="#000080"><b>new </b></font>Runnable() {<br />            <font color="#808000">@Override<br />            </font><font color="#000080"><b>public void </b></font>run() {<br />                <font color="#660e7a">deadLock</font>.husband();<br />            }<br />        };<br />        Thread husThread = <font color="#000080"><b>new </b></font>Thread(runnableHus);<br /><br />        husThread.start();<br />        wifeThread.start();<br /><br /><br />    }<br /><br /><br />}<br /></pre>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1472805880007" FOLDED="true" ID="ID_987552318" MODIFIED="1529657527944" TEXT="&#x4e8c;&#x8005;&#x533a;&#x522b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472805958580" ID="ID_260691392" MODIFIED="1472805958581" TEXT="&#x8fdb;&#x7a0b;&#x662f;&#x8d44;&#x6e90;&#x5206;&#x914d;&#x7684;&#x57fa;&#x672c;&#x5355;&#x4f4d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472805988654" ID="ID_1963736449" MODIFIED="1472805988654" TEXT="&#x7ebf;&#x7a0b;&#x4e0e;&#x8d44;&#x6e90;&#x5206;&#x914d;&#x65e0;&#x5173;&#xff0c;&#x5b83;&#x5c5e;&#x4e8e;&#x67d0;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#xff0c;&#x5e76;&#x4e0e;&#x8fdb;&#x7a0b;&#x5185;&#x7684;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x4e00;&#x8d77;&#x5171;&#x4eab;&#x8fdb;&#x7a0b;&#x7684;&#x8d44;&#x6e90;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472806022641" ID="ID_1719338325" MODIFIED="1472806022642" TEXT="&#x901a;&#x5e38;&#x5728;&#x4e00;&#x4e2a;&#x8fdb;&#x7a0b;&#x4e2d;&#x53ef;&#x4ee5;&#x5305;&#x542b;&#x82e5;&#x5e72;&#x4e2a;&#x7ebf;&#x7a0b;&#xff0c;&#x5b83;&#x4eec;&#x53ef;&#x4ee5;&#x5229;&#x7528;&#x8fdb;&#x7a0b;&#x6240;&#x62e5;&#x6709;&#x7684;&#x8d44;&#x6e90;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472806088135" ID="ID_1468161804" MODIFIED="1472806088136" TEXT="&#x7ebf;&#x7a0b;&#x4e0a;&#x4e0b;&#x6587;&#x5207;&#x6362;&#x6bd4;&#x8fdb;&#x7a0b;&#x4e0a;&#x4e0b;&#x6587;&#x5207;&#x6362;&#x8981;&#x5feb;&#x5f97;&#x591a;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472806094600" ID="ID_604455623" MODIFIED="1472806099654" TEXT="&#x8fdb;&#x7a0b;&#x95f4;&#x901a;&#x4fe1;IPC&#xff0c;&#x7ebf;&#x7a0b;&#x95f4;&#x53ef;&#x4ee5;&#x76f4;&#x63a5;&#x8bfb;&#x5199;&#x8fdb;&#x7a0b;&#x6570;&#x636e;&#x6bb5;&#xff08;&#x5982;&#x5168;&#x5c40;&#x53d8;&#x91cf;&#xff09;&#x6765;&#x8fdb;&#x884c;&#x901a;&#x4fe1;&#x2014;&#x2014;&#x9700;&#x8981;&#x8fdb;&#x7a0b;&#x540c;&#x6b65;&#x548c;&#x4e92;&#x65a5;&#x624b;&#x6bb5;&#x7684;&#x8f85;&#x52a9;&#xff0c;&#x4ee5;&#x4fdd;&#x8bc1;&#x6570;&#x636e;&#x7684;&#x4e00;&#x81f4;&#x6027;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473484599590" FOLDED="true" ID="ID_1690708890" MODIFIED="1529657527945" TEXT="&#x76f8;&#x5173;&#x7684;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473493110062" FOLDED="true" ID="ID_398149784" MODIFIED="1529657527944" TEXT="Lock  &#x4e0e; Condition">
<font BOLD="true" NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473493882732" ID="ID_1896980722" MODIFIED="1473493891464" TEXT="&#x5904;&#x7406;&#x590d;&#x6742;&#x7684;&#x5e76;&#x53d1;&#x65f6;&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#990000" CREATED="1473493129732" ID="ID_1421509609" MODIFIED="1473493136004" TEXT="BlockingQueue">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473493145762" ID="ID_1157574214" MODIFIED="1473493154464" TEXT="CountDownLatch">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473493155242" FOLDED="true" ID="ID_506306407" MODIFIED="1529657527944" TEXT="CycliBarrier">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473494357009" FOLDED="true" ID="ID_719432915" MODIFIED="1529657527944" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473494363212" ID="ID_76423577" MODIFIED="1473494363212" TEXT="&#x4e00;&#x4e2a;&#x540c;&#x6b65;&#x8f85;&#x52a9;&#x7c7b;&#xff0c;&#x5b83;&#x5141;&#x8bb8;&#x4e00;&#x7ec4;&#x7ebf;&#x7a0b;&#x4e92;&#x76f8;&#x7b49;&#x5f85;&#xff0c;&#x76f4;&#x5230;&#x5230;&#x8fbe;&#x67d0;&#x4e2a;&#x516c;&#x5171;&#x5c4f;&#x969c;&#x70b9; (common barrier point)&#x3002;&#x5728;&#x6d89;&#x53ca;&#x4e00;&#x7ec4;&#x56fa;&#x5b9a;&#x5927;&#x5c0f;&#x7684;&#x7ebf;&#x7a0b;&#x7684;&#x7a0b;&#x5e8f;&#x4e2d;&#xff0c;&#x8fd9;&#x4e9b;&#x7ebf;&#x7a0b;&#x5fc5;&#x987b;&#x4e0d;&#x65f6;&#x5730;&#x4e92;&#x76f8;&#x7b49;&#x5f85;&#xff0c;&#x6b64;&#x65f6; CyclicBarrier &#x5f88;&#x6709;&#x7528;&#x3002;&#x56e0;&#x4e3a;&#x8be5; barrier &#x5728;&#x91ca;&#x653e;&#x7b49;&#x5f85;&#x7ebf;&#x7a0b;&#x540e;&#x53ef;&#x4ee5;&#x91cd;&#x7528;&#xff0c;&#x6240;&#x4ee5;&#x79f0;&#x5b83;&#x4e3a;&#x5faa;&#x73af; &#x7684; barrier&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473494368995" FOLDED="true" ID="ID_206012997" MODIFIED="1529657527944" TEXT="&#x4f7f;&#x7528;&#x573a;&#x666f;">
<node COLOR="#111111" CREATED="1473494375734" ID="ID_1809439476" MODIFIED="1473494375734" TEXT="&#x9700;&#x8981;&#x6240;&#x6709;&#x7684;&#x5b50;&#x4efb;&#x52a1;&#x90fd;&#x5b8c;&#x6210;&#x65f6;&#xff0c;&#x624d;&#x6267;&#x884c;&#x4e3b;&#x4efb;&#x52a1;&#xff0c;&#x8fd9;&#x4e2a;&#x65f6;&#x5019;&#x5c31;&#x53ef;&#x4ee5;&#x9009;&#x62e9;&#x4f7f;&#x7528;CyclicBarrier&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473494384782" FOLDED="true" ID="ID_1442883297" MODIFIED="1529657527944" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1473494386184" ID="ID_384994338" MODIFIED="1473494386184" TEXT="public int await()"/>
</node>
<node COLOR="#111111" CREATED="1473494556068" ID="ID_1020488318" LINK="&#x7ebf;&#x7a0b;/&#x5e76;&#x53d1;&#x76f8;&#x5173;&#x7684;&#x7c7b;/CyclicBarrier.txt" MODIFIED="1473494565720" TEXT="&#x9644;&#x4ef6;"/>
</node>
<node COLOR="#990000" CREATED="1473493163712" FOLDED="true" ID="ID_1178071587" MODIFIED="1529657527944" TEXT="Semaphore &#x4fe1;&#x53f7;&#x91cf;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473494313216" ID="ID_1512799536" MODIFIED="1473494313216" TEXT="&#x7528;&#x6765;&#x63a7;&#x5236;&#x540c;&#x65f6;&#x8bbf;&#x95ee;&#x7279;&#x5b9a;&#x8d44;&#x6e90;&#x7684;&#x7ebf;&#x7a0b;&#x6570;&#x91cf;&#xff0c;&#x5b83;&#x901a;&#x8fc7;&#x534f;&#x8c03;&#x5404;&#x4e2a;&#x7ebf;&#x7a0b;&#xff0c;&#x4ee5;&#x4fdd;&#x8bc1;&#x5408;&#x7406;&#x7684;&#x4f7f;&#x7528;&#x516c;&#x5171;&#x8d44;&#x6e90;"/>
</node>
<node COLOR="#990000" CREATED="1473493172613" ID="ID_1362345141" MODIFIED="1473493183284" TEXT="Exchanger">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473493183532" FOLDED="true" ID="ID_990738574" MODIFIED="1529657527945" TEXT="&#x514d;&#x9501;&#x5bb9;&#x5668;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473493211212" ID="ID_617154352" MODIFIED="1473493257495" TEXT="CopyOnWriteArrayList&lt;E&gt;"/>
<node COLOR="#111111" CREATED="1473493251883" ID="ID_461287979" MODIFIED="1473493255055" TEXT="CopyOnWriteArraySet&lt;E&gt;"/>
<node COLOR="#111111" CREATED="1473493263793" ID="ID_946715414" MODIFIED="1473493276983" TEXT="ConcurrentHashMap&lt;K,V&gt;"/>
<node COLOR="#111111" CREATED="1473493289520" ID="ID_1386437127" MODIFIED="1473493290462" TEXT="ConcurrentLinkedQueue&lt;E&gt;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495711799703" FOLDED="true" ID="ID_152902073" MODIFIED="1529657527948">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Timer
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495719702705" FOLDED="true" ID="ID_269207388" MODIFIED="1529657527945" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495719705460" ID="ID_834073463" MODIFIED="1495719705460" TEXT="public Timer()"/>
<node COLOR="#111111" CREATED="1495719715637" FOLDED="true" ID="ID_1742835940" MODIFIED="1529657527945" TEXT="public Timer(String name)">
<node COLOR="#111111" CREATED="1495720918302" FOLDED="true" ID="ID_5744676" MODIFIED="1529657527945" TEXT="name">
<node COLOR="#111111" CREATED="1495720921457" ID="ID_1701668369" MODIFIED="1495720931126" TEXT="&#x5b9a;&#x65f6;&#x5668;&#x7684;&#x540d;&#x5b57;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720360023" FOLDED="true" ID="ID_586306859" MODIFIED="1529657527945" TEXT="public Timer(String name, boolean isDaemon)">
<node COLOR="#111111" CREATED="1495720934368" FOLDED="true" ID="ID_1967642518" MODIFIED="1529657527945" TEXT="isDaemon">
<node COLOR="#111111" CREATED="1495720941292" ID="ID_382396859" MODIFIED="1495720954214" TEXT="&#x662f;&#x5426;&#x8bbe;&#x7f6e;&#x4e3a;&#x540e;&#x53f0;&#x7ebf;&#x7a0b;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495720374673" FOLDED="true" ID="ID_605618299" MODIFIED="1529657527948" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495720376582" FOLDED="true" ID="ID_666047092" MODIFIED="1529657527946" TEXT="public void schedule(TimerTask task, long delay)">
<node COLOR="#111111" CREATED="1495720957657" FOLDED="true" ID="ID_598719033" MODIFIED="1529657527945" TEXT="?">
<node COLOR="#111111" CREATED="1495720964679" ID="ID_1550802319" MODIFIED="1495720973184" TEXT="&#x5b9a;&#x65f6;&#x6267;&#x884c;&#x4efb;&#x52a1;"/>
</node>
<node COLOR="#111111" CREATED="1495720974545" FOLDED="true" ID="ID_1017288220" MODIFIED="1529657527946" TEXT="TimerTask">
<arrowlink DESTINATION="ID_1650574484" ENDARROW="Default" ENDINCLINATION="448;0;" ID="Arrow_ID_835366314" STARTARROW="None" STARTINCLINATION="448;0;"/>
<node COLOR="#111111" CREATED="1495720983452" ID="ID_328988391" MODIFIED="1495720994055" TEXT="&#x4e00;&#x4e2a;&#x5b9a;&#x65f6;&#x4efb;&#x52a1;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_1363799868" MODIFIED="1529657527946" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_915183348" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720390342" FOLDED="true" ID="ID_300547047" MODIFIED="1529657527947" TEXT="public void schedule(TimerTask task, Date time)">
<node COLOR="#111111" CREATED="1495721069628" ID="ID_342960082" MODIFIED="1495721087940" TEXT="&#x5728;&#x672a;&#x6765;&#x7684;&#x67d0;&#x4e2a;&#x65f6;&#x95f4; time&#x6267;&#x884c;"/>
<node COLOR="#111111" CREATED="1495721088453" ID="ID_1990036126" MODIFIED="1495721102118" TEXT="time:&#x672a;&#x6765;&#x67d0;&#x4e2a;&#x65e5;&#x671f;"/>
</node>
<node COLOR="#111111" CREATED="1495720424345" FOLDED="true" ID="ID_1494274988" MODIFIED="1529657527947" TEXT="public void schedule(TimerTask task, long delay, long period)">
<node COLOR="#111111" CREATED="1495721106799" ID="ID_185295240" MODIFIED="1495721133859" TEXT="&#x4efb;&#x52a1;&#x6bcf;&#x9694; period&#x6267;&#x884c;&#x4e00;&#x6b21;"/>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_1773164714" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_1409090879" MODIFIED="1529657527947" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_1061308242" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720410305" FOLDED="true" ID="ID_1789051404" MODIFIED="1529657527947" TEXT="public void schedule(TimerTask task, Date firstTime, long period)">
<node COLOR="#111111" CREATED="1495721137538" ID="ID_237587403" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721882093" ID="ID_285571300" MODIFIED="1495721914513">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      firstTime : &#39318;&#27425;&#25191;&#34892;&#30340;&#26102;&#38388;,&#29992;Date&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495720444767" FOLDED="true" ID="ID_253357917" MODIFIED="1529657527948" TEXT="public void scheduleAtFixedRate(TimerTask task, long delay, long period)">
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_764304382" MODIFIED="1529657527947" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_1609057719" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_989185369" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
</node>
<node COLOR="#111111" CREATED="1495720460358" FOLDED="true" ID="ID_605233019" MODIFIED="1529657527948" TEXT="public void scheduleAtFixedRate(TimerTask task, Date firstTime,     long period)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_1926199847" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721882093" ID="ID_424558010" MODIFIED="1495721914513">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      firstTime : &#39318;&#27425;&#25191;&#34892;&#30340;&#26102;&#38388;,&#29992;Date&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495720490697" FOLDED="true" ID="ID_1020148639" MODIFIED="1529657527948" TEXT="public void cancel()">
<node COLOR="#111111" CREATED="1495722025551" ID="ID_1841405845" MODIFIED="1495722033537" TEXT="&#x53d6;&#x6d88;&#x4efb;&#x52a1;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1495721015686" FOLDED="true" ID="ID_1650574484" MODIFIED="1529657527949">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      TimerTask&#25277;&#35937;&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495722213466" FOLDED="true" ID="ID_1678365498" MODIFIED="1529657527949">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495722194538" ID="ID_985057047" MODIFIED="1495722213472" TEXT="&#x548c;Timer&#x5171;&#x540c;&#x4f7f;&#x7528;&#x6765;&#x5b9a;&#x65f6;&#x4e00;&#x4e2a;&#x4efb;&#x52a1;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495722074591" ID="ID_351274268" MODIFIED="1495722074592" TEXT="public abstract void run()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495722151326" ID="ID_934257226" MODIFIED="1495722151327" TEXT="public boolean cancel()">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473992305923" FOLDED="true" ID="ID_182750237" MODIFIED="1529657527970" POSITION="right" TEXT="&#x7f51;&#x7edc;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1473997933506" FOLDED="true" ID="ID_711682443" MODIFIED="1529657527959" TEXT="&#x7406;&#x8bba;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473992559570" FOLDED="true" ID="ID_1549927126" LINK="&#x7f51;&#x7edc;/&#x56db;&#x5c42;&#x548c;&#x4e03;&#x5c42;&#x5bf9;&#x6bd4;.png" MODIFIED="1529657527953">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      TCP/IP&#27169;&#22411;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1473992563100" FOLDED="true" ID="ID_1778154690" MODIFIED="1529657527953" TEXT="&#x56db;&#x5c42;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473993078737" FOLDED="true" ID="ID_1664982620" MODIFIED="1529657527952" TEXT="&#x5e94;&#x7528;&#x5c42;">
<icon BUILTIN="full-4"/>
<node COLOR="#111111" CREATED="1473993097227" ID="ID_1664536213" MODIFIED="1473993097227" TEXT="TCP/IP&#x6a21;&#x578b;&#x5c06;OSI&#x53c2;&#x8003;&#x6a21;&#x578b;&#x4e2d;&#x7684;&#x4f1a;&#x8bdd;&#x5c42;&#x548c;&#x8868;&#x793a;&#x5c42;&#x7684;&#x529f;&#x80fd;&#x5408;&#x5e76;&#x5230;&#x5e94;&#x7528;&#x5c42;&#x5b9e;&#x73b0;&#x3002;&#x3000;"/>
</node>
<node COLOR="#111111" CREATED="1473993010284" FOLDED="true" ID="ID_500675474" MODIFIED="1529657527952" TEXT="&#x4f20;&#x8f93;&#x5c42;">
<icon BUILTIN="full-3"/>
<node COLOR="#111111" CREATED="1473993033842" ID="ID_586585529" MODIFIED="1501203251318" TEXT="&#x5728;TCP/IP&#x6a21;&#x578b;&#x4e2d;&#xff0c;&#x4f20;&#x8f93;&#x5c42;&#x7684;&#x529f;&#x80fd;&#x662f;&#x4f7f;&#x6e90;&#x7aef;&#x4e3b;&#x673a;&#x548c;&#x76ee;&#x6807;&#x7aef;&#x4e3b;&#x673a;&#x4e0a;&#xa;&#x7684;&#x5bf9;&#x7b49;&#x5b9e;&#x4f53;&#x53ef;&#x4ee5;&#x8fdb;&#x884c;&#x4f1a;&#x8bdd;&#x3002;&#x5728;&#x4f20;&#x8f93;&#x5c42;&#x5b9a;&#x4e49;&#x4e86;&#x4e24;&#x79cd;&#x670d;&#x52a1;&#x8d28;&#x91cf;&#x4e0d;&#x540c;&#x7684;&#xa;&#x534f;&#x8bae;&#x3002;&#x5373;&#xff1a;&#x4f20;&#x8f93;&#x63a7;&#x5236;&#x534f;&#x8bae;TCP&#xff08;transmission control protocol&#xff09;&#x548c;&#xa;&#x7528;&#x6237;&#x6570;&#x636e;&#x62a5;&#x534f;&#x8bae;UDP&#xff08;user datagram protocol&#xff09;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473992983997" FOLDED="true" ID="ID_372693499" MODIFIED="1529657527952" TEXT="&#x7f51;&#x7edc;&#x4e92;&#x8fde;&#x5c42;">
<icon BUILTIN="full-2"/>
<node COLOR="#111111" CREATED="1473992992989" ID="ID_807498730" MODIFIED="1473992992989" TEXT="&#x7f51;&#x7edc;&#x4e92;&#x8fde;&#x5c42;&#x662f;&#x6574;&#x4e2a;TCP/IP&#x534f;&#x8bae;&#x6808;&#x7684;&#x6838;&#x5fc3;&#x3002;&#x5b83;&#x7684;&#x529f;&#x80fd;&#x662f;&#x628a;&#x5206;&#x7ec4;&#x53d1;&#x5f80;&#x76ee;&#x6807;&#x7f51;&#x7edc;&#x6216;&#x4e3b;&#x673a;&#x3002;&#x540c;&#x65f6;&#xff0c;&#x4e3a;&#x4e86;&#x5c3d;&#x5feb;&#x5730;&#x53d1;&#x9001;&#x5206;&#x7ec4;&#xff0c;&#x53ef;&#x80fd;&#x9700;&#x8981;&#x6cbf;&#x4e0d;&#x540c;&#x7684;&#x8def;&#x5f84;&#x540c;&#x65f6;&#x8fdb;&#x884c;&#x5206;&#x7ec4;&#x4f20;&#x9012;&#x3002;&#x56e0;&#x6b64;&#xff0c;&#x5206;&#x7ec4;&#x5230;&#x8fbe;&#x7684;&#x987a;&#x5e8f;&#x548c;&#x53d1;&#x9001;&#x7684;&#x987a;&#x5e8f;&#x53ef;&#x80fd;&#x4e0d;&#x540c;&#xff0c;&#x8fd9;&#x5c31;&#x9700;&#x8981;&#x4e0a;&#x5c42;&#x5fc5;&#x987b;&#x5bf9;&#x5206;&#x7ec4;&#x8fdb;&#x884c;&#x6392;&#x5e8f;&#x3002;&#x3000;&#x3000;"/>
<node COLOR="#111111" CREATED="1473992993009" ID="ID_1886718719" MODIFIED="1473992993009" TEXT="&#x3000;&#x3000;&#x7f51;&#x7edc;&#x4e92;&#x8fde;&#x5c42;&#x5b9a;&#x4e49;&#x4e86;&#x5206;&#x7ec4;&#x683c;&#x5f0f;&#x548c;&#x534f;&#x8bae;&#xff0c;&#x5373;IP&#x534f;&#x8bae;&#xff08;Internet Protocol&#xff09;&#x3002;&#x3000;&#x3000;"/>
<node COLOR="#111111" CREATED="1473992993009" ID="ID_1514849743" MODIFIED="1473992993009" TEXT="&#x3000;&#x3000;&#x7f51;&#x7edc;&#x4e92;&#x8fde;&#x5c42;&#x9664;&#x4e86;&#x9700;&#x8981;&#x5b8c;&#x6210;&#x8def;&#x7531;&#x7684;&#x529f;&#x80fd;&#x5916;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x5b8c;&#x6210;&#x5c06;&#x4e0d;&#x540c;&#x7c7b;&#x578b;&#x7684;&#x7f51;&#x7edc;&#xff08;&#x5f02;&#x6784;&#x7f51;&#xff09;&#x4e92;&#x8fde;&#x7684;&#x4efb;&#x52a1;&#x3002;&#x9664;&#x6b64;&#x4e4b;&#x5916;&#xff0c;&#x7f51;&#x7edc;&#x4e92;&#x8fde;&#x5c42;&#x8fd8;&#x9700;&#x8981;&#x5b8c;&#x6210;&#x62e5;&#x585e;&#x63a7;&#x5236;&#x7684;&#x529f;&#x80fd;&#x3002;&#x3000;&#x3000;"/>
</node>
<node COLOR="#111111" CREATED="1473992935645" FOLDED="true" ID="ID_1602600378" MODIFIED="1529657527952" TEXT="&#x4e3b;&#x673a;&#x5230;&#x7f51;&#x7edc;&#x5c42;">
<icon BUILTIN="full-1"/>
<node COLOR="#111111" CREATED="1473993004220" ID="ID_1985398376" MODIFIED="1473993004220" TEXT="&#x5b9e;&#x9645;&#x4e0a;TCP/IP&#x53c2;&#x8003;&#x6a21;&#x578b;&#x6ca1;&#x6709;&#x771f;&#x6b63;&#x63cf;&#x8ff0;&#x8fd9;&#x4e00;&#x5c42;&#x7684;&#x5b9e;&#x73b0;&#xff0c;&#x53ea;&#x662f;&#x8981;&#x6c42;&#x80fd;&#x591f;&#x63d0;&#x4f9b;&#x7ed9;&#x5176;&#x4e0a;&#x5c42;-&#x7f51;&#x7edc;&#x4e92;&#x8fde;&#x5c42;&#x4e00;&#x4e2a;&#x8bbf;&#x95ee;&#x63a5;&#x53e3;&#xff0c;&#x4ee5;&#x4fbf;&#x5728;&#x5176;&#x4e0a;&#x4f20;&#x9012;IP&#x5206;&#x7ec4;&#x3002;&#x7531;&#x4e8e;&#x8fd9;&#x4e00;&#x5c42;&#x6b21;&#x672a;&#x88ab;&#x5b9a;&#x4e49;&#xff0c;&#x6240;&#x4ee5;&#x5176;&#x5177;&#x4f53;&#x7684;&#x5b9e;&#x73b0;&#x65b9;&#x6cd5;&#x5c06;&#x968f;&#x7740;&#x7f51;&#x7edc;&#x7c7b;&#x578b;&#x7684;&#x4e0d;&#x540c;&#x800c;&#x4e0d;&#x540c;&#x3002;&#x3000;&#x3000;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473992566110" FOLDED="true" ID="ID_1950738077" LINK="&#x7f51;&#x7edc;/osi&#x4e03;&#x5c42;&#x6a21;&#x578b;.gif" MODIFIED="1529657527953" TEXT="&#x4e03;&#x5c42;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495724954553" ID="ID_819994330" LINK="http://blog.csdn.net/yaopeng_2005/article/details/7064869" MODIFIED="1495724977742">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38142;&#25509;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1473998046286" FOLDED="true" ID="ID_475626410" MODIFIED="1529657527955" TEXT="TCP &#x548c;UDP">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473993037900" FOLDED="true" ID="ID_895163458" MODIFIED="1529657527955" TEXT="TCP">
<node COLOR="#111111" CREATED="1473993057051" ID="ID_1504506248" MODIFIED="1473993057061" TEXT="&#x4e00;&#x4e2a;&#x9762;&#x5411;&#x8fde;&#x63a5;&#x7684;&#x3001;&#x53ef;&#x9760;&#x7684;&#x534f;&#x8bae;&#x3002;&#x5b83;&#x5c06;&#x4e00;&#x53f0;&#x4e3b;&#x673a;&#x53d1;&#x51fa;&#x7684;&#x5b57;&#x8282;&#x6d41;&#x65e0;&#x5dee;&#x9519;&#x5730;&#x53d1;&#x5f80;&#x4e92;&#x8054;&#x7f51;&#x4e0a;&#x7684;&#x5176;&#x4ed6;&#x4e3b;&#x673a;&#x3002;&#x5728;&#x53d1;&#x9001;&#x7aef;&#xff0c;&#x5b83;&#x8d1f;&#x8d23;&#x628a;&#x4e0a;&#x5c42;&#x4f20;&#x9001;&#x4e0b;&#x6765;&#x7684;&#x5b57;&#x8282;&#x6d41;&#x5206;&#x6210;&#x62a5;&#x6587;&#x6bb5;&#x5e76;&#x4f20;&#x9012;&#x7ed9;&#x4e0b;&#x5c42;&#x3002;&#x5728;&#x63a5;&#x6536;&#x7aef;&#xff0c;&#x5b83;&#x8d1f;&#x8d23;&#x628a;&#x6536;&#x5230;&#x7684;&#x62a5;&#x6587;&#x8fdb;&#x884c;&#x91cd;&#x7ec4;&#x540e;&#x9012;&#x4ea4;&#x7ed9;&#x4e0a;&#x5c42;&#x3002;TCP&#x534f;&#x8bae;&#x8fd8;&#x8981;&#x5904;&#x7406;&#x7aef;&#x5230;&#x7aef;&#x7684;&#x6d41;&#x91cf;&#x63a7;&#x5236;&#xff0c;&#x4ee5;&#x907f;&#x514d;&#x7f13;&#x6162;&#x63a5;&#x6536;&#x7684;&#x63a5;&#x6536;&#x65b9;&#x6ca1;&#x6709;&#x8db3;&#x591f;&#x7684;&#x7f13;&#x51b2;&#x533a;&#x63a5;&#x6536;&#x53d1;&#x9001;&#x65b9;&#x53d1;&#x9001;&#x7684;&#x5927;&#x91cf;&#x6570;&#x636e;&#x3002;"/>
<node COLOR="#111111" CREATED="1473993459072" ID="ID_171847620" LINK="&#x7f51;&#x7edc;/&#x4e09;&#x6b21;&#x63e1;&#x624b;.png" MODIFIED="1474423846631" TEXT="&#x4e09;&#x6b21;&#x63e1;&#x624b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1473993465622" FOLDED="true" ID="ID_1618104527" LINK="&#x7f51;&#x7edc;/&#x56db;&#x6b21;&#x63e1;&#x624b;.png" MODIFIED="1529657527954" TEXT="&#x56db;&#x6b21;&#x63e1;&#x624b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1501202825430" ID="ID_983077747" MODIFIED="1501202825431" TEXT="&#xff08;1&#xff09;&#x5ba2;&#x6237;&#x7aef;A&#x53d1;&#x9001;&#x4e00;&#x4e2a;FIN&#xff0c;&#x7528;&#x6765;&#x5173;&#x95ed;&#x5ba2;&#x6237;A&#x5230;&#x670d;&#x52a1;&#x5668;B&#x7684;&#x6570;&#x636e;&#x4f20;&#x9001;&#x3002;"/>
<node COLOR="#111111" CREATED="1501202825432" ID="ID_1821463145" MODIFIED="1501202825432" TEXT="&#xff08;2&#xff09;&#x670d;&#x52a1;&#x5668;B&#x6536;&#x5230;&#x8fd9;&#x4e2a;FIN&#xff0c;&#x5b83;&#x53d1;&#x56de;&#x4e00;&#x4e2a;ACK&#xff0c;&#x786e;&#x8ba4;&#x5e8f;&#x53f7;&#x4e3a;&#x6536;&#x5230;&#x7684;&#x5e8f;&#x53f7;&#x52a0;1&#x3002;&#x548c;SYN&#x4e00;&#x6837;&#xff0c;&#x4e00;&#x4e2a;FIN&#x5c06;&#x5360;&#x7528;&#x4e00;&#x4e2a;&#x5e8f;&#x53f7;&#x3002;"/>
<node COLOR="#111111" CREATED="1501202825434" ID="ID_1128246746" MODIFIED="1501202825434" TEXT="&#xff08;3&#xff09;&#x670d;&#x52a1;&#x5668;B&#x5173;&#x95ed;&#x4e0e;&#x5ba2;&#x6237;&#x7aef;A&#x7684;&#x8fde;&#x63a5;&#xff0c;&#x53d1;&#x9001;&#x4e00;&#x4e2a;FIN&#x7ed9;&#x5ba2;&#x6237;&#x7aef;A&#x3002;"/>
<node COLOR="#111111" CREATED="1501202825435" ID="ID_1477768366" MODIFIED="1501202825435" TEXT="&#xff08;4&#xff09;&#x5ba2;&#x6237;&#x7aef;A&#x53d1;&#x56de;ACK&#x62a5;&#x6587;&#x786e;&#x8ba4;&#xff0c;&#x5e76;&#x5c06;&#x786e;&#x8ba4;&#x5e8f;&#x53f7;&#x8bbe;&#x7f6e;&#x4e3a;&#x6536;&#x5230;&#x5e8f;&#x53f7;&#x52a0;1&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1474375628138" ID="ID_556298662" LINK="&#x7f51;&#x7edc;/&#x4e09;&#x6b21;&#x2014;&#x2014;&#x56db;&#x5c42;&#x63e1;&#x624b;.jpg" MODIFIED="1474375639815" TEXT="&#x5bf9;&#x6bd4;"/>
<node COLOR="#111111" CREATED="1501202951498" FOLDED="true" ID="ID_1050707481" MODIFIED="1529657527954" TEXT="&#x672f;&#x8bed;">
<node COLOR="#111111" CREATED="1501203189017" FOLDED="true" ID="ID_1660426156" MODIFIED="1529657527954" TEXT="&#x9644;&#x4ef6;">
<node COLOR="#111111" CREATED="1501203191784" ID="ID_980532717" MODIFIED="1501203191785">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_7027815191310155304.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1501202956666" ID="ID_1693412530" MODIFIED="1501202956666" TEXT="SYN(synchronous&#x5efa;&#x7acb;&#x8054;&#x673a;)"/>
<node COLOR="#111111" CREATED="1501202956666" ID="ID_1068591091" MODIFIED="1501202956667" TEXT="ACK(acknowledgement &#x786e;&#x8ba4;)"/>
<node COLOR="#111111" CREATED="1501202956667" ID="ID_1933391863" MODIFIED="1501202956667" TEXT="PSH(push&#x4f20;&#x9001;)"/>
<node COLOR="#111111" CREATED="1501202956667" ID="ID_681814729" MODIFIED="1501202956667" TEXT="FIN(finish&#x7ed3;&#x675f;)"/>
<node COLOR="#111111" CREATED="1501202956668" ID="ID_942751575" MODIFIED="1501202956668" TEXT="RST(reset&#x91cd;&#x7f6e;)"/>
<node COLOR="#111111" CREATED="1501202956668" ID="ID_1119842779" MODIFIED="1501202956668" TEXT="URG(urgent&#x7d27;&#x6025;)"/>
<node COLOR="#111111" CREATED="1501202956669" ID="ID_1783996561" MODIFIED="1501202956669" TEXT="Sequence number(&#x987a;&#x5e8f;&#x53f7;&#x7801;)"/>
<node COLOR="#111111" CREATED="1501202956669" ID="ID_468049952" MODIFIED="1501202956669" TEXT="Acknowledge number(&#x786e;&#x8ba4;&#x53f7;&#x7801;)"/>
<node COLOR="#111111" CREATED="1501203159084" ID="ID_1753474608" MODIFIED="1501203159085" TEXT="LISTEN - &#x4fa6;&#x542c;&#x6765;&#x81ea;&#x8fdc;&#x65b9;TCP&#x7aef;&#x53e3;&#x7684;&#x8fde;&#x63a5;&#x8bf7;&#x6c42;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159086" ID="ID_739048957" MODIFIED="1501203159086" TEXT="SYN-SENT -&#x5728;&#x53d1;&#x9001;&#x8fde;&#x63a5;&#x8bf7;&#x6c42;&#x540e;&#x7b49;&#x5f85;&#x5339;&#x914d;&#x7684;&#x8fde;&#x63a5;&#x8bf7;&#x6c42;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159086" ID="ID_316203496" MODIFIED="1501203159088" TEXT="SYN-RECEIVED - &#x5728;&#x6536;&#x5230;&#x548c;&#x53d1;&#x9001;&#x4e00;&#x4e2a;&#x8fde;&#x63a5;&#x8bf7;&#x6c42;&#x540e;&#x7b49;&#x5f85;&#x5bf9;&#x8fde;&#x63a5;&#x8bf7;&#x6c42;&#x7684;&#x786e;&#x8ba4;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159089" ID="ID_1523047451" MODIFIED="1501203159090" TEXT="ESTABLISHED- &#x4ee3;&#x8868;&#x4e00;&#x4e2a;&#x6253;&#x5f00;&#x7684;&#x8fde;&#x63a5;&#xff0c;&#x6570;&#x636e;&#x53ef;&#x4ee5;&#x4f20;&#x9001;&#x7ed9;&#x7528;&#x6237;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159090" ID="ID_136770612" MODIFIED="1501203159091" TEXT="FIN-WAIT-1 - &#x7b49;&#x5f85;&#x8fdc;&#x7a0b;TCP&#x7684;&#x8fde;&#x63a5;&#x4e2d;&#x65ad;&#x8bf7;&#x6c42;&#xff0c;&#x6216;&#x5148;&#x524d;&#x7684;&#x8fde;&#x63a5;&#x4e2d;&#x65ad;&#x8bf7;&#x6c42;&#x7684;&#x786e;&#x8ba4;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159091" ID="ID_1298620638" MODIFIED="1501203159092" TEXT="FIN-WAIT-2 - &#x4ece;&#x8fdc;&#x7a0b;TCP&#x7b49;&#x5f85;&#x8fde;&#x63a5;&#x4e2d;&#x65ad;&#x8bf7;&#x6c42;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159092" ID="ID_1962382229" MODIFIED="1501203159092" TEXT="CLOSE-WAIT - &#x7b49;&#x5f85;&#x4ece;&#x672c;&#x5730;&#x7528;&#x6237;&#x53d1;&#x6765;&#x7684;&#x8fde;&#x63a5;&#x4e2d;&#x65ad;&#x8bf7;&#x6c42;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159093" ID="ID_1997745421" MODIFIED="1501203159093" TEXT="CLOSING -&#x7b49;&#x5f85;&#x8fdc;&#x7a0b;TCP&#x5bf9;&#x8fde;&#x63a5;&#x4e2d;&#x65ad;&#x7684;&#x786e;&#x8ba4;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159094" ID="ID_1304053371" MODIFIED="1501203159094" TEXT="LAST-ACK - &#x7b49;&#x5f85;&#x539f;&#x6765;&#x53d1;&#x5411;&#x8fdc;&#x7a0b;TCP&#x7684;&#x8fde;&#x63a5;&#x4e2d;&#x65ad;&#x8bf7;&#x6c42;&#x7684;&#x786e;&#x8ba4;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159094" ID="ID_884729946" MODIFIED="1501203159094" TEXT="TIME-WAIT -&#x7b49;&#x5f85;&#x8db3;&#x591f;&#x7684;&#x65f6;&#x95f4;&#x4ee5;&#x786e;&#x4fdd;&#x8fdc;&#x7a0b;TCP&#x63a5;&#x6536;&#x5230;&#x8fde;&#x63a5;&#x4e2d;&#x65ad;&#x8bf7;&#x6c42;&#x7684;&#x786e;&#x8ba4;&#xff1b;"/>
<node COLOR="#111111" CREATED="1501203159095" ID="ID_1434592372" MODIFIED="1501203159095" TEXT="CLOSED - &#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x8fde;&#x63a5;&#x72b6;&#x6001;&#xff1b;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473993064755" FOLDED="true" ID="ID_297034853" MODIFIED="1529657527955" TEXT="UDP">
<node COLOR="#111111" CREATED="1473993067587" ID="ID_894211530" MODIFIED="1473993067587" TEXT="&#x4e00;&#x4e2a;&#x4e0d;&#x53ef;&#x9760;&#x7684;&#x3001;&#x65e0;&#x8fde;&#x63a5;&#x534f;&#x8bae;&#xff0c;&#x4e3b;&#x8981;&#x9002;&#x7528;&#x4e8e;&#x4e0d;&#x9700;&#x8981;&#x5bf9;&#x62a5;&#x6587;&#x8fdb;&#x884c;&#x6392;&#x5e8f;&#x548c;&#x6d41;&#x91cf;&#x63a7;&#x5236;&#x7684;&#x573a;&#x5408;&#x3002;&#x3000;&#x3000;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473993381355" ID="ID_764078562" LINK="&#x7f51;&#x7edc;/&#x6570;&#x636e;&#x5c01;&#x5305;&#x548c;&#x89e3;&#x5305;&#x8fc7;&#x7a0b;.png" MODIFIED="1473997941608" TEXT="&#x6570;&#x636e;&#x7684;&#x5c01;&#x5305;&#x548c;&#x89e3;&#x5305;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473993471942" FOLDED="true" ID="ID_1895690227" MODIFIED="1529657527955" TEXT="&#x5957;&#x63a5;&#x5b57;Socket">
<edge STYLE="bezier" WIDTH="thin"/>
<arrowlink DESTINATION="ID_1131660894" ENDARROW="Default" ENDINCLINATION="420;0;" ID="Arrow_ID_3631868" STARTARROW="None" STARTINCLINATION="391;0;"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473998396900" ID="ID_1353338915" MODIFIED="1473998708951" TEXT="socket&#x8d77;&#x6e90;&#x4e8e;Unix&#xff0c;&#x800c;Unix/Linux&#x57fa;&#x672c;&#x54f2;&#x5b66;&#x4e4b;&#x4e00;&#x5c31;&#x662f;&#x201c;&#x4e00;&#x5207;&#x7686;&#x6587;&#x4ef6;&#x201d;&#xff0c;&#x90fd;&#x53ef;&#x4ee5;&#x7528;&#x201c;&#x6253;&#x5f00;open &#x2013;&gt; &#x8bfb;&#x5199;write/read &#x2013;&gt; &#x5173;&#x95ed;close&#x201d;&#x6a21;&#x5f0f;&#x6765;&#x64cd;&#x4f5c;&#x3002;&#x6211;&#x7684;&#x7406;&#x89e3;&#x5c31;&#x662f;Socket&#x5c31;&#x662f;&#x8be5;&#x6a21;&#x5f0f;&#x7684;&#x4e00;&#x4e2a;&#x5b9e;&#x73b0;&#xff0c;socket&#x5373;&#x662f;&#x4e00;&#x79cd;&#x7279;&#x6b8a;&#x7684;&#x6587;&#x4ef6;&#xff0c;&#x4e00;&#x4e9b;socket&#x51fd;&#x6570;&#x5c31;&#x662f;&#x5bf9;&#x5176;&#x8fdb;&#x884c;&#x7684;&#x64cd;&#x4f5c;&#xff08;&#x8bfb;/&#x5199;IO&#x3001;&#x6253;&#x5f00;&#x3001;&#x5173;&#x95ed;&#xff09;&#xff0c;"/>
</node>
<node COLOR="#990000" CREATED="1473993721198" FOLDED="true" ID="ID_961143380" MODIFIED="1529657527959" TEXT="&#x5730;&#x5740;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1473993728777" FOLDED="true" ID="ID_846740086" MODIFIED="1529657527957" TEXT="ip">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473994161091" FOLDED="true" ID="ID_1586638040" MODIFIED="1529657527955" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473994162643" ID="ID_1665100861" MODIFIED="1473994162643" TEXT="IP&#x5730;&#x5740;&#x5de5;&#x4f5c;&#x5728;OSI&#x53c2;&#x8003;&#x6a21;&#x578b;&#x7684;&#x7b2c;&#x4e09;&#x5c42;&#x7f51;&#x7edc;&#x5c42;"/>
<node COLOR="#111111" CREATED="1473994170130" ID="ID_433692478" MODIFIED="1473994170130" TEXT="&#x4e13;&#x6ce8;&#x4e8e;&#x7f51;&#x7edc;&#x5c42;&#xff0c;&#x5c06;&#x6570;&#x636e;&#x5305;&#x4ece;&#x4e00;&#x4e2a;&#x7f51;&#x7edc;&#x8f6c;&#x53d1;&#x5230;&#x53e6;&#x5916;&#x4e00;&#x4e2a;&#x7f51;&#x7edc;"/>
<node COLOR="#111111" CREATED="1473994352180" ID="ID_1207312737" MODIFIED="1473994352180" TEXT="IP&#x5730;&#x5740;&#x4e3a;32&#x4f4d;"/>
<node COLOR="#111111" CREATED="1495725594430" ID="ID_790529670" MODIFIED="1501133829863" TEXT="Internet IP&#x5730;&#x5740;&#x7531;NIC(Internet Network Information Center)&#xa;&#x7edf;&#x4e00;&#x8d1f;&#x8d23;&#x5168;&#x7403;&#x5730;&#x5740;&#x7684;&#x89c4;&#x5212;&#x3001;&#x7ba1;&#x7406;;&#x540c;&#x65f6;&#x7531;Inter NIC&#x3001;APNIC&#x3001;&#xa;RIPE&#x4e09;&#x5927;&#x7f51;&#x7edc;&#x4fe1;&#x606f;&#x4e2d;&#x5fc3;&#x5177;&#x4f53;&#x8d1f;&#x8d23;&#x7f8e;&#x56fd;&#x53ca;&#x5176;&#x5b83;&#x5730;&#x533a;&#x7684;IP&#x5730;&#x5740;&#x5206;&#x914d;&#x3002;&#xa;&#x53ef;&#x4ee5;&#x8bf4;&#xff0c;&#x6bcf;&#x53f0;&#x4e0a;&#x7f51;&#x7684;&#x7535;&#x8111;&#x90fd;&#x5fc5;&#x987b;&#x6709;&#x4e00;&#x4e2a;&#x552f;&#x4e00;&#x7684;IP&#x5730;&#x5740;&#xff0c;&#x5c31;&#x50cf;&#x6bcf;&#xa;&#x4e2a;&#x4eba;&#x90fd;&#x6709;&#x4e00;&#x4e2a;&#x8eab;&#x4efd;&#x8bc1;&#x53f7;&#x4e00;&#x6837;"/>
<node COLOR="#111111" CREATED="1495725905962" ID="ID_1988671005" MODIFIED="1495725916884" TEXT="&#x5728; 000.000.000.000~255.255.255.255&#x4e4b;&#x95f4;"/>
</node>
<node COLOR="#111111" CREATED="1473995439231" FOLDED="true" ID="ID_1915915901" MODIFIED="1529657527956" TEXT="&#x7ec4;&#x6210;">
<node COLOR="#111111" CREATED="1473995442575" ID="ID_1409225261" MODIFIED="1473995458938" TEXT="&#x7f51;&#x7edc;&#x53f7;"/>
<node COLOR="#111111" CREATED="1473995446644" ID="ID_1517849669" MODIFIED="1473995453134" TEXT="&#x4e3b;&#x673a;&#x53f7;"/>
<node COLOR="#111111" CREATED="1495726064066" FOLDED="true" ID="ID_103971490" MODIFIED="1529657527955" TEXT="&#x6bd4;&#x5982;">
<node COLOR="#111111" CREATED="1495726067783" ID="ID_1751638991" MODIFIED="1495726067783" TEXT="&#x3000;A&#x7c7b;IP&#xff1a;*.?.?.?"/>
<node COLOR="#111111" CREATED="1495726067786" ID="ID_1265502035" MODIFIED="1495726067786" TEXT="&#x3000;&#x3000;B&#x7c7b;IP&#xff1a;*.*.?.?"/>
<node COLOR="#111111" CREATED="1495726067787" ID="ID_1145924388" MODIFIED="1495726067787" TEXT="&#x3000;&#x3000;C&#x7c7b;IP&#xff1a;*.*.*.?"/>
</node>
<node COLOR="#111111" CREATED="1495726085292" ID="ID_1167235308" MODIFIED="1495727345829" TEXT="&#x201c;*&#x201d;&#x4ee3;&#x8868;&#x7f51;&#x7edc;&#x6807;&#x8bc6;&#xff0c;&#x201c;?&#x201d;&#x4ee3;&#x8868;&#x4e3b;&#x673a;&#x6807;&#x8bc6;&#x3002;&#x7f51;&#x7edc;&#x6807;&#x8bc6;&#x4ee3;&#x8868;&#x4f60;&#x7535;&#x8111;&#x7f51;&#x7edc;&#x5728;&#x4e92;&#x8054;&#x7f51;&#x4e2d;&#x5c5e;&#x4e8e;&#x90a3;&#x4e2a;&#x516c;&#x7f51;&#xff0c;&#x800c;&#x4e3b;&#x673a;&#x6807;&#x8bc6;&#x786e;&#x5b9a;&#x4f60;&#x7684;&#x7535;&#x8111;&#x5728;&#x516c;&#x7f51;&#x4e2d;&#x7684;&#x4f4d;&#x7f6e;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473995462644" FOLDED="true" ID="ID_1718377493" LINK="&#x7f51;&#x7edc;/ip&#x5730;&#x5740;&#x5206;&#x7c7b;.PNG" MODIFIED="1529657527957" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1473995467191" FOLDED="true" ID="ID_283337339" MODIFIED="1529657527956" TEXT="A">
<node COLOR="#111111" CREATED="1473995663663" ID="ID_917726917" MODIFIED="1473995663664" TEXT="&#x5728;IP&#x5730;&#x5740;&#x7684;&#x56db;&#x6bb5;&#x53f7;&#x7801;&#x4e2d;&#xff0c;&#x7b2c;&#x4e00;&#x6bb5;&#x53f7;&#x7801;&#x4e3a;&#x7f51;&#x7edc;&#x53f7;&#x7801;&#xff0c;&#x5269;&#x4e0b;&#x7684;&#x4e09;&#x6bb5;&#x53f7;&#x7801;&#x4e3a;&#x672c;&#x5730;&#x8ba1;&#x7b97;&#x673a;&#x7684;&#x53f7;&#x7801;"/>
<node COLOR="#111111" CREATED="1473995822913" ID="ID_1465166668" MODIFIED="1473995822914" TEXT="A&#x7c7b;IP&#x5730;&#x5740;&#x7684;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x4e3a;255.0.0.0&#xff0c;&#x6bcf;&#x4e2a;&#x7f51;&#x7edc;&#x652f;&#x6301;&#x7684;&#x6700;&#x5927;&#x4e3b;&#x673a;&#x6570;&#x4e3a;256&#x7684;3&#x6b21;&#x65b9;-2=16777214&#x53f0;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473995470548" FOLDED="true" ID="ID_1679878517" MODIFIED="1529657527956" TEXT="B">
<node COLOR="#111111" CREATED="1473995725004" ID="ID_257568908" MODIFIED="1473995725004" TEXT="&#x5728;IP&#x5730;&#x5740;&#x7684;&#x56db;&#x6bb5;&#x53f7;&#x7801;&#x4e2d;&#xff0c;&#x524d;&#x4e24;&#x6bb5;&#x53f7;&#x7801;&#x4e3a;&#x7f51;&#x7edc;&#x53f7;&#x7801;"/>
<node COLOR="#111111" CREATED="1473995831868" ID="ID_346430937" MODIFIED="1473995831868" TEXT="B&#x7c7b;IP&#x5730;&#x5740;&#x7684;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x4e3a;255.255.0.0&#xff0c;&#x6bcf;&#x4e2a;&#x7f51;&#x7edc;&#x652f;&#x6301;&#x7684;&#x6700;&#x5927;&#x4e3b;&#x673a;&#x6570;&#x4e3a;256&#x7684;2&#x6b21;&#x65b9;-2=65534&#x53f0;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473995472393" FOLDED="true" ID="ID_1395845151" MODIFIED="1529657527956" TEXT="C">
<node COLOR="#111111" CREATED="1473995850195" ID="ID_294033901" MODIFIED="1473995850196" TEXT="&#x5728;IP&#x5730;&#x5740;&#x7684;&#x56db;&#x6bb5;&#x53f7;&#x7801;&#x4e2d;&#xff0c;&#x524d;&#x4e09;&#x6bb5;&#x53f7;&#x7801;&#x4e3a;&#x7f51;&#x7edc;&#x53f7;&#x7801;&#xff0c;&#x5269;&#x4e0b;&#x7684;&#x4e00;&#x6bb5;&#x53f7;&#x7801;&#x4e3a;&#x672c;&#x5730;&#x8ba1;&#x7b97;&#x673a;&#x7684;&#x53f7;&#x7801;"/>
<node COLOR="#111111" CREATED="1473995901611" ID="ID_1655546753" MODIFIED="1473995901612" TEXT="C&#x7c7b;IP&#x5730;&#x5740;&#x7684;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x4e3a;255.255.255.0&#xff0c;&#x6bcf;&#x4e2a;&#x7f51;&#x7edc;&#x652f;&#x6301;&#x7684;&#x6700;&#x5927;&#x4e3b;&#x673a;&#x6570;&#x4e3a;256-2=254&#x53f0;"/>
</node>
<node COLOR="#111111" CREATED="1473995644761" FOLDED="true" ID="ID_1393355259" MODIFIED="1529657527956" TEXT="D">
<node COLOR="#111111" CREATED="1473995994250" ID="ID_1183405593" MODIFIED="1473995994252" TEXT="D&#x7c7b;IP&#x5730;&#x5740;&#x5728;&#x5386;&#x53f2;&#x4e0a;&#x88ab;&#x53eb;&#x505a;&#x591a;&#x64ad;&#x5730;&#x5740;(multicast address)&#xff0c;&#x5373;&#x7ec4;&#x64ad;&#x5730;&#x5740;&#x3002;&#x5728;&#x4ee5;&#x592a;&#x7f51;&#x4e2d;&#xff0c;&#x591a;&#x64ad;&#x5730;&#x5740;&#x547d;&#x540d;&#x4e86;&#x4e00;&#x7ec4;&#x5e94;&#x8be5;&#x5728;&#x8fd9;&#x4e2a;&#x7f51;&#x7edc;&#x4e2d;&#x5e94;&#x7528;&#x63a5;&#x6536;&#x5230;&#x4e00;&#x4e2a;&#x5206;&#x7ec4;&#x7684;&#x7ad9;&#x70b9;&#x3002;&#x591a;&#x64ad;&#x5730;&#x5740;&#x7684;&#x6700;&#x9ad8;&#x4f4d;&#x5fc5;&#x987b;&#x662f;&#x201c;1110&#x201d;&#xff0c;&#x8303;&#x56f4;&#x4ece;224.0.0.0&#x5230;239.255.255.255&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473995645894" FOLDED="true" ID="ID_605826956" MODIFIED="1529657527956" TEXT="E">
<node COLOR="#111111" CREATED="1473997424210" ID="ID_553559607" MODIFIED="1473997437921" TEXT="&#x5b9e;&#x9a8c;&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#111111" CREATED="1473995979372" FOLDED="true" ID="ID_372897564" MODIFIED="1529657527956" TEXT="&#x7279;&#x6b8a;&#x7684;&#x7f51;&#x5740;">
<node COLOR="#111111" CREATED="1473995985756" ID="ID_395495869" MODIFIED="1473995985757" TEXT="&#x6bcf;&#x4e00;&#x4e2a;&#x5b57;&#x8282;&#x90fd;&#x4e3a;0&#x7684;&#x5730;&#x5740;&#xff08;&#x201c;0.0.0.0&#x201d;&#xff09;&#x5bf9;&#x5e94;&#x4e8e;&#x5f53;&#x524d;&#x4e3b;&#x673a;&#xff1b;"/>
<node COLOR="#111111" CREATED="1473995985758" ID="ID_1642355630" MODIFIED="1473995985759" TEXT="IP&#x5730;&#x5740;&#x4e2d;&#x7684;&#x6bcf;&#x4e00;&#x4e2a;&#x5b57;&#x8282;&#x90fd;&#x4e3a;1&#x7684;IP&#x5730;&#x5740;&#xff08;&#x201c;255&#xff0e;255&#xff0e;255&#xff0e;255&#x201d;&#xff09;&#x662f;&#x5f53;&#x524d;&#x5b50;&#x7f51;&#x7684;&#x5e7f;&#x64ad;&#x5730;&#x5740;&#xff1b;"/>
<node COLOR="#111111" CREATED="1473995985760" ID="ID_1365162270" MODIFIED="1473995985760" TEXT="IP&#x5730;&#x5740;&#x4e2d;&#x51e1;&#x662f;&#x4ee5;&#x201c;11110&#x201d;&#x5f00;&#x5934;&#x7684;E&#x7c7b;IP&#x5730;&#x5740;&#x90fd;&#x4fdd;&#x7559;&#x7528;&#x4e8e;&#x5c06;&#x6765;&#x548c;&#x5b9e;&#x9a8c;&#x4f7f;&#x7528;&#x3002;"/>
<node COLOR="#111111" CREATED="1473995985761" ID="ID_18524623" LINK="http://127.0.0.1&#x201d;&#x5c31;&#x53ef;&#x4ee5;&#x6d4b;&#x8bd5;&#x672c;&#x673a;&#x4e2d;&#x914d;&#x7f6e;&#x7684;Web&#x670d;&#x52a1;&#x5668;&#x3002;" MODIFIED="1473995985764" TEXT="IP&#x5730;&#x5740;&#x4e2d;&#x4e0d;&#x80fd;&#x4ee5;&#x5341;&#x8fdb;&#x5236;&#x201c;127&#x201d;&#x4f5c;&#x4e3a;&#x5f00;&#x5934;&#xff0c;&#x8be5;&#x7c7b;&#x5730;&#x5740;&#x4e2d;&#x6570;&#x5b57;127&#xff0e;0&#xff0e;0&#xff0e;1&#x5230;127&#xff0e;255&#xff0e;255&#xff0e;255&#x7528;&#x4e8e;&#x56de;&#x8def;&#x6d4b;&#x8bd5;&#xff0c;&#x5982;&#xff1a;127.0.0.1&#x53ef;&#x4ee5;&#x4ee3;&#x8868;&#x672c;&#x673a;IP&#x5730;&#x5740;&#xff0c;&#x7528;&#x201c;http://127.0.0.1&#x201d;&#x5c31;&#x53ef;&#x4ee5;&#x6d4b;&#x8bd5;&#x672c;&#x673a;&#x4e2d;&#x914d;&#x7f6e;&#x7684;Web&#x670d;&#x52a1;&#x5668;&#x3002;"/>
<node COLOR="#111111" CREATED="1473995985775" ID="ID_1388081812" MODIFIED="1473995985775" TEXT="&#x7f51;&#x7edc;ID&#x7684;&#x7b2c;&#x4e00;&#x4e2a;8&#x4f4d;&#x7ec4;&#x4e5f;&#x4e0d;&#x80fd;&#x5168;&#x7f6e;&#x4e3a;&#x201c;0&#x201d;&#xff0c;&#x5168;&#x201c;0&#x201d;&#x8868;&#x793a;&#x672c;&#x5730;&#x7f51;&#x7edc;&#x3002;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473993730397" FOLDED="true" ID="ID_126420664" MODIFIED="1529657527958" TEXT="mac">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="ksmiletris"/>
<node COLOR="#111111" CREATED="1473993906787" FOLDED="true" ID="ID_1720595003" MODIFIED="1529657527958" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1473993908829" FOLDED="true" ID="ID_1643844935" MODIFIED="1529657527957" TEXT="MAC&#xff08;Media Access Control&#xff0c;&#x4ecb;&#x8d28;&#x8bbf;&#x95ee;&#x63a7;&#x5236;&#xff09;&#x5730;&#x5740;&#xff0c;&#x4e5f;&#x53eb;&#x786c;&#x4ef6;&#x5730;&#x5740;&#xff0c;&#x957f;&#x5ea6;&#x662f;48&#x6bd4;&#x7279;&#xff08;6&#x5b57;&#x8282;&#xff09;&#xff0c;&#x7531;16&#x8fdb;&#x5236;&#x7684;&#x6570;&#x5b57;&#x7ec4;&#x6210;&#xff0c;&#x5206;&#x4e3a;&#x524d;24&#x4f4d;&#x548c;&#x540e;24&#x4f4d;&#xff1a;">
<node COLOR="#111111" CREATED="1473993992521" ID="ID_1870179714" MODIFIED="1473993992521" TEXT="&#x524d;24&#x4f4d;&#x53eb;&#x505a;&#x7ec4;&#x7ec7;&#x552f;&#x4e00;&#x6807;&#x5fd7;&#x7b26;&#xff08;Organizationally Unique Identifier&#xff0c;&#x5373;OUI&#xff09;&#xff0c;&#x662f;&#x7531;IEEE&#x7684;&#x6ce8;&#x518c;&#x7ba1;&#x7406;&#x673a;&#x6784;&#x7ed9;&#x4e0d;&#x540c;&#x5382;&#x5bb6;&#x5206;&#x914d;&#x7684;&#x4ee3;&#x7801;&#xff0c;&#x533a;&#x5206;&#x4e86;&#x4e0d;&#x540c;&#x7684;&#x5382;&#x5bb6;&#x3002;"/>
<node COLOR="#111111" CREATED="1473994003507" ID="ID_1771472335" MODIFIED="1473994003507" TEXT="&#x540e;24&#x4f4d;&#x662f;&#x7531;&#x5382;&#x5bb6;&#x81ea;&#x5df1;&#x5206;&#x914d;&#x7684;&#xff0c;&#x79f0;&#x4e3a;&#x6269;&#x5c55;&#x6807;&#x8bc6;&#x7b26;&#x3002;&#x540c;&#x4e00;&#x4e2a;&#x5382;&#x5bb6;&#x751f;&#x4ea7;&#x7684;&#x7f51;&#x5361;&#x4e2d;MAC&#x5730;&#x5740;&#x540e;24&#x4f4d;&#x662f;&#x4e0d;&#x540c;&#x7684;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473994034582" ID="ID_758417826" MODIFIED="1473994034582" TEXT="MAC&#x5730;&#x5740;&#x5bf9;&#x5e94;&#x4e8e;OSI&#x53c2;&#x8003;&#x6a21;&#x578b;&#x7684;&#x7b2c;&#x4e8c;&#x5c42;&#x6570;&#x636e;&#x94fe;&#x8def;&#x5c42;&#xff0c;&#x5de5;&#x4f5c;&#x5728;&#x6570;&#x636e;&#x94fe;&#x8def;&#x5c42;&#x7684;&#x4ea4;&#x6362;&#x673a;&#x7ef4;&#x62a4;&#x7740;&#x8ba1;&#x7b97;&#x673a;MAC&#x5730;&#x5740;&#x548c;&#x81ea;&#x8eab;&#x7aef;&#x53e3;&#x7684;&#x6570;&#x636e;&#x5e93;&#xff0c;&#x4ea4;&#x6362;&#x673a;&#x6839;&#x636e;&#x6536;&#x5230;&#x7684;&#x6570;&#x636e;&#x5e27;&#x4e2d;&#x7684;&#x201c;&#x76ee;&#x7684;MAC&#x5730;&#x5740;&#x201d;&#x5b57;&#x6bb5;&#x6765;&#x8f6c;&#x53d1;&#x6570;&#x636e;&#x5e27;&#x3002;"/>
<node COLOR="#111111" CREATED="1473994116619" ID="ID_628597879" MODIFIED="1473994116619" TEXT="&#x5728;&#x7f51;&#x7edc;&#x5e95;&#x5c42;&#x7684;&#x7269;&#x7406;&#x4f20;&#x8f93;&#x8fc7;&#x7a0b;&#x4e2d;&#xff0c;&#x662f;&#x901a;&#x8fc7;&#x7269;&#x7406;&#x5730;&#x5740;&#x6765;&#x8bc6;&#x522b;&#x4e3b;&#x673a;&#x7684;&#xff0c;&#x5b83;&#x4e00;&#x5b9a;&#x662f;&#x5168;&#x7403;&#x552f;&#x4e00;&#x7684;"/>
<node COLOR="#111111" CREATED="1473994123418" ID="ID_818676468" MODIFIED="1495727460273" TEXT="&#x5f62;&#x8c61;&#x5730;&#x8bf4;&#xff0c;MAC&#x5730;&#x5740;&#x5c31;&#x5982;&#x540c;&#x6211;&#x4eec;&#x8eab;&#x4efd;&#x8bc1;&#x4e0a;&#x7684;&#x8eab;&#x4efd;&#x8bc1;&#x53f7;&#x7801;&#xff0c;&#x5177;&#x6709;&#x5168;&#x7403;&#x552f;&#x4e00;&#x6027;&#x3002;">
<icon BUILTIN="idea"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473997487579" FOLDED="true" ID="ID_1041848591" MODIFIED="1529657527959" TEXT="&#x5b50;&#x7f51;&#x63a9;&#x7801;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473997669752" ID="ID_1295591855" MODIFIED="1501207983455" TEXT="&#x662f;&#x4e3a;&#x4e86;&#x5212;&#x5206;&#x7f51;&#x7edc;&#x5730;&#x5740;&#x548c;&#x4e3b;&#x673a;&#x5730;&#x5740;&#xff1b;&#xa;&#x5229;&#x7528;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x53ef;&#x4ee5;&#x628a;&#x5927;&#x7684;&#x7f51;&#x7edc;&#x5212;&#x5206;&#x6210;&#x5b50;&#x7f51;&#xff0c;&#xa;&#x5373;VLSM&#xff08;&#x53ef;&#x53d8;&#x957f;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#xff09;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x628a;&#x5c0f;&#xa;&#x7684;&#x7f51;&#x7edc;&#x5f52;&#x5e76;&#x6210;&#x5927;&#x7684;&#x7f51;&#x7edc;&#x5373;&#x8d85;&#x7f51;&#x3002;"/>
<node COLOR="#111111" CREATED="1495727710947" ID="ID_269905356" MODIFIED="1495727715241">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    &#23376;&#32593;&#25513;&#30721;&#21482;&#26377;&#19968;&#20010;&#20316;&#29992;&#65292;&#23601;&#26159;&#23558;&#26576;&#20010;IP&#22320;&#22336;&#21010;&#20998;&#25104;

    <p>
      <a target="_blank" href="http://baike.baidu.com/item/%E7%BD%91%E7%BB%9C%E5%9C%B0%E5%9D%80">&#32593;&#32476;&#22320;&#22336;</a>&#21644;<a target="_blank" href="http://baike.baidu.com/item/%E4%B8%BB%E6%9C%BA%E5%9C%B0%E5%9D%80">&#20027;&#26426;&#22320;&#22336;</a>&#20004;&#37096;&#20998;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495728873014" FOLDED="true" ID="ID_1412862886" MODIFIED="1529657527958">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#40664;&#35748;&#25513;&#30721;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1473997531122" ID="ID_465806956" MODIFIED="1495728888920" TEXT="&#x5bf9;&#x4e8e;A&#x7c7b;&#x5730;&#x5740;&#x6765;&#x8bf4;&#xff0c;&#x9ed8;&#x8ba4;&#x7684;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x662f;255.0.0.0&#xff1b;"/>
<node COLOR="#111111" CREATED="1495728892014" ID="ID_12463067" MODIFIED="1495728898147" TEXT="&#x5bf9;&#x4e8e;B&#x7c7b;&#x5730;&#x5740;&#x6765;&#x8bf4;&#x9ed8;&#x8ba4;&#x7684;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x662f;255.255.0.0&#xff1b;"/>
<node COLOR="#111111" CREATED="1495728899912" ID="ID_1576789111" MODIFIED="1495728899912" TEXT="&#x5bf9;&#x4e8e;C&#x7c7b;&#x5730;&#x5740;&#x6765;&#x8bf4;&#x9ed8;&#x8ba4;&#x7684;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x662f;255.255.255.0&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473997611814" ID="ID_386420144" MODIFIED="1473997835288" TEXT="&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x7684;&#x957f;&#x5ea6;&#x4e5f;&#x662f;32&#x4f4d;&#xff0c;&#x5de6;&#x8fb9;&#x662f;&#x7f51;&#x7edc;&#x4f4d;&#xff0c;&#x7528;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x5b57;&#x201c;1&#x201d;&#x8868;&#x793a;&#xff0c;1&#x7684;&#x6570;&#x76ee;&#x7b49;&#x4e8e;&#x7f51;&#x7edc;&#x4f4d;&#x7684;&#x957f;&#x5ea6;&#xff1b;&#x53f3;&#x8fb9;&#x662f;&#x4e3b;&#x673a;&#x4f4d;&#xff0c;&#x7528;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x5b57;&#x201c;0&#x201d;&#x8868;&#x793a;&#xff0c;0&#x7684;&#x6570;&#x76ee;&#x7b49;&#x4e8e;&#x4e3b;&#x673a;&#x4f4d;&#x7684;&#x957f;&#x5ea6;&#x3002;"/>
<node COLOR="#111111" CREATED="1495728480157" ID="ID_442048837" MODIFIED="1501208089718" TEXT="&#x6700;&#x4e3a;&#x7b80;&#x5355;&#x7684;&#x7406;&#x89e3;&#x5c31;&#x662f;&#x4e24;&#x53f0;&#x8ba1;&#x7b97;&#x673a;&#x5404;&#x81ea;&#x7684;IP&#x5730;&#x5740;&#xa;&#x4e0e;&#x5b50;&#x7f51;&#x63a9;&#x7801;&#x8fdb;&#x884c;AND&#x8fd0;&#x7b97;&#x540e;&#xff0c;&#x5982;&#x679c;&#x5f97;&#x51fa;&#x7684;&#x7ed3;&#x679c;&#xa;&#x662f;&#x76f8;&#x540c;&#x7684;&#xff0c;&#x5219;&#x8bf4;&#x660e;&#x8fd9;&#x4e24;&#x53f0;&#x8ba1;&#x7b97;&#x673a;&#x662f;&#x5904;&#x4e8e;&#x540c;&#x4e00;&#x4e2a;&#xa;&#x5b50;&#x7f51;&#x7edc;&#x4e0a;&#x7684;&#xff0c;&#x53ef;&#x4ee5;&#x8fdb;&#x884c;&#x76f4;&#x63a5;&#x7684;&#x901a;&#x8baf;&#x3002;&#x5c31;&#x8fd9;&#x4e48;&#x7b80;&#x5355;&#x3002;"/>
<node COLOR="#111111" CREATED="1495728943735" FOLDED="true" ID="ID_624793155" MODIFIED="1529657527959" TEXT="&#x5982;&#x4f55;&#x8ba1;&#x7b97;:&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1495728960327" ID="ID_478776927" MODIFIED="1495769224742">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <span style="color: #111111"><font color="#111111">I P &#22320;&#22336;&#12288;192.168.0.1</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">&#23376;&#32593;&#25513;&#30721;&#12288;255.255.255.0</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">AND&#36816;&#31639;(AND&#36816;&#31639;&#27861;&#21017;&#65306;1 &#19982;1 = 1 ,1 &#19982;0 = 0 ,0 &#19982;1 = 0 ,0 &#19982;0 = 0 ,&#21363;&#24403;&#23545;&#24212;&#20301;&#22343;&#20026;1&#26102;&#32467;&#26524;&#20026;1&#65292;&#20854;&#20313;&#20026;0&#12290;)</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">&#36716;&#21270;&#20026;&#20108;&#36827;&#21046;&#36827;&#34892;&#36816;&#31639;&#65306;</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">I P &#22320;&#22336;&#12288;11000000.10101000.00000000.00000001</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">&#23376;&#32593;&#25513;&#30721;&#12288;11111111.11111111.11111111.00000000</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">AND&#36816;&#31639;</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">11000000.10101000.00000000.00000000</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">&#36716;&#21270;&#20026;&#21313;&#36827;&#21046;&#21518;&#20026;&#65306;</font></span>
    </p>
    <p>
      <span style="color: #111111"><font color="#111111">192.168.0.0</font></span>
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1473993733127" FOLDED="true" ID="ID_1998150761" MODIFIED="1529657527959" TEXT="&#x7aef;&#x53e3;">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1473996591123" ID="ID_437359794" MODIFIED="1473996591124" TEXT="&#x662f;&#x8bbe;&#x5907;&#x4e0e;&#x5916;&#x754c;&#x901a;&#x8baf;&#x4ea4;&#x6d41;&#x7684;&#x51fa;&#x53e3;"/>
<node COLOR="#111111" CREATED="1473996594172" FOLDED="true" ID="ID_119471884" MODIFIED="1529657527959" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1473996795871" FOLDED="true" ID="ID_1315296435" MODIFIED="1529657527959" TEXT="&#x53ef;&#x89c1;&#x4e0d;&#x53ef;&#x89c1;">
<node COLOR="#111111" CREATED="1473996597787" FOLDED="true" ID="ID_645590998" MODIFIED="1529657527959" TEXT="&#x865a;&#x62df;&#x7aef;&#x53e3;">
<node COLOR="#111111" CREATED="1473996648264" ID="ID_313450329" MODIFIED="1473996648264" TEXT="&#x8ba1;&#x7b97;&#x673a;&#x5185;&#x90e8;&#x6216;&#x4ea4;&#x6362;&#x673a;&#x8def;&#x7531;&#x5668;&#x5185;&#x7684;&#x7aef;&#x53e3;&#xff0c;&#x4e0d;&#x53ef;&#x89c1;&#x3002;&#x4f8b;&#x5982;&#x8ba1;&#x7b97;&#x673a;&#x4e2d;&#x7684;80&#x7aef;&#x53e3;&#x3001;21&#x7aef;&#x53e3;&#x3001;23&#x7aef;&#x53e3;&#x7b49;"/>
</node>
<node COLOR="#111111" CREATED="1473996619051" FOLDED="true" ID="ID_581585200" MODIFIED="1529657527959" TEXT="&#x7269;&#x7406;&#x7aef;&#x53e3;">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473996667097" ID="ID_1101961571" MODIFIED="1473996667098" TEXT="&#x7269;&#x7406;&#x7aef;&#x53e3;&#x53c8;&#x79f0;&#x4e3a;&#x63a5;&#x53e3;&#xff0c;&#x662f;&#x53ef;&#x89c1;&#x7aef;&#x53e3;&#xff0c;&#x8ba1;&#x7b97;&#x673a;&#x80cc;&#x677f;&#x7684;RJ45&#x7f51;&#x53e3;&#xff0c;&#x4ea4;&#x6362;&#x673a;&#x8def;&#x7531;&#x5668;&#x96c6;&#x7ebf;&#x5668;&#x7b49;RJ45&#x7aef;&#x53e3;&#x3002;&#x7535;&#x8bdd;&#x4f7f;&#x7528;RJ11&#x63d2;&#x53e3;&#x4e5f;&#x5c5e;&#x4e8e;&#x7269;&#x7406;&#x7aef;&#x53e3;&#x7684;&#x8303;&#x7574;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1473996900258" FOLDED="true" ID="ID_1788158044" MODIFIED="1529657527959" TEXT="&#x534f;&#x8bae;">
<node COLOR="#111111" CREATED="1473996908000" FOLDED="true" ID="ID_211090513" MODIFIED="1529657527959" TEXT="TCP&#x7aef;&#x53e3;">
<node COLOR="#111111" CREATED="1473996913788" ID="ID_1078990171" MODIFIED="1473996913798" TEXT="TCP&#xff1a;Transmission Control Protocol&#x4f20;&#x8f93;&#x63a7;&#x5236;&#x534f;&#x8bae;TCP&#x662f;&#x4e00;&#x79cd;&#x9762;&#x5411;&#x8fde;&#x63a5;&#xff08;&#x8fde;&#x63a5;&#x5bfc;&#x5411;&#xff09;&#x7684;&#x3001;&#x53ef;&#x9760;&#x7684;&#x3001;&#x57fa;&#x4e8e;&#x5b57;&#x8282;&#x6d41;&#x7684;&#x4f20;&#x8f93;&#x5c42;&#xff08;Transport layer&#xff09;&#x901a;&#x4fe1;&#x534f;&#x8bae;&#xff0c;&#x7531;IETF&#x7684;RFC 793&#x8bf4;&#x660e;&#xff08;specified&#xff09;&#x3002;&#x5728;&#x7b80;&#x5316;&#x7684;&#x8ba1;&#x7b97;&#x673a;&#x7f51;&#x7edc;OSI&#x6a21;&#x578b;&#x4e2d;&#xff0c;&#x5b83;&#x5b8c;&#x6210;&#x7b2c;&#x56db;&#x5c42;&#x4f20;&#x8f93;&#x5c42;&#x6240;&#x6307;&#x5b9a;&#x7684;&#x529f;&#x80fd;&#xff0c;UDP&#x662f;&#x540c;&#x4e00;&#x5c42;&#x5185;&#x53e6;&#x4e00;&#x4e2a;&#x91cd;&#x8981;&#x7684;&#x4f20;&#x8f93;&#x534f;&#x8bae;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473996924901" FOLDED="true" ID="ID_177844281" MODIFIED="1529657527959" TEXT="UDP&#x7aef;&#x53e3;">
<node COLOR="#111111" CREATED="1473996924911" ID="ID_281370675" MODIFIED="1473996924911" TEXT="UDP:UDP&#x662f;OSI&#x53c2;&#x8003;&#x6a21;&#x578b;&#x4e2d;&#x4e00;&#x79cd;&#x65e0;&#x8fde;&#x63a5;&#x7684;&#x4f20;&#x8f93;&#x5c42;&#x534f;&#x8bae;&#xff0c;&#x63d0;&#x4f9b;&#x9762;&#x5411;&#x4e8b;&#x52a1;&#x7684;&#x7b80;&#x5355;&#x4e0d;&#x53ef;&#x9760;&#x4fe1;&#x606f;&#x4f20;&#x9001;&#x670d;&#x52a1;&#x3002;UDP &#x534f;&#x8bae;&#x57fa;&#x672c;&#x4e0a;&#x662f;IP&#x534f;&#x8bae;&#x4e0e;&#x4e0a;&#x5c42;&#x534f;&#x8bae;&#x7684;&#x63a5;&#x53e3;&#x3002;UDP&#x534f;&#x8bae;&#x9002;&#x7528;&#x7aef;&#x53e3;&#x5206;&#x522b;&#x8fd0;&#x884c;&#x5728;&#x540c;&#x4e00;&#x53f0;&#x8bbe;&#x5907;&#x4e0a;&#x7684;&#x591a;&#x4e2a;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x3002;"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1473994379455" FOLDED="true" ID="ID_1735024030" MODIFIED="1529657527959" TEXT="ip&#x548c;mac&#x7684;&#x533a;&#x522b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473994387026" ID="ID_724105359" MODIFIED="1473997941618" TEXT="IP&#x5730;&#x5740;&#x7684;&#x5206;&#x914d;&#x662f;&#x57fa;&#x4e8e;&#x7f51;&#x7edc;&#x62d3;&#x6251;&#xff0c;MAC&#x5730;&#x5740;&#x7684;&#x5206;&#x914d;&#x662f;&#x57fa;&#x4e8e;&#x5236;&#x9020;&#x5546;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473994427515" ID="ID_634408495" MODIFIED="1473997941618" TEXT="&#x957f;&#x5ea6;&#x4e0d;&#x540c;&#x3002;IP&#x5730;&#x5740;&#x4e3a;32&#x4f4d;&#xff0c;MAC&#x5730;&#x5740;&#x4e3a;48&#x4f4d;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473994462763" ID="ID_959538113" MODIFIED="1473997941618" TEXT="&#x5bfb;&#x5740;&#x534f;&#x8bae;&#x5c42;&#x4e0d;&#x540c;&#x3002;IP&#x5730;&#x5740;&#x5e94;&#x7528;&#x4e8e;OSI&#x7b2c;&#x4e09;&#x5c42;&#xff0c;&#x5373;&#x7f51;&#x7edc;&#x5c42;&#xff0c;&#x800c;MAC&#x5730;&#x5740;&#x5e94;&#x7528;&#x5728;OSI&#x7b2c;&#x4e8c;&#x5c42;&#xff0c;&#x5373;&#x6570;&#x636e;&#x94fe;&#x8def;&#x5c42;&#x3002; &#x6570;&#x636e;&#x94fe;&#x8def;&#x5c42;&#x534f;&#x8bae;&#x53ef;&#x4ee5;&#x4f7f;&#x6570;&#x636e;&#x4ece;&#x4e00;&#x4e2a;&#x8282;&#x70b9;&#x4f20;&#x9012;&#x5230;&#x76f8;&#x540c;&#x94fe;&#x8def;&#x7684;&#x53e6;&#x4e00;&#x4e2a;&#x8282;&#x70b9;&#x4e0a;&#xff08;&#x901a;&#x8fc7;MAC&#x5730;&#x5740;&#xff09;&#xff0c;&#x800c;&#x7f51;&#x7edc;&#x5c42;&#x534f;&#x8bae;&#x4f7f;&#x6570;&#x636e;&#x53ef;&#x4ee5;&#x4ece;&#x4e00;&#x4e2a;&#x7f51;&#x7edc;&#x4f20;&#x9012;&#x5230;&#x53e6;&#x4e00;&#x4e2a;&#x7f51;&#x7edc;&#x4e0a;&#xff08;ARP&#x6839;&#x636e;&#x76ee;&#x7684;IP&#x5730;&#x5740;&#xff0c;&#x627e;&#x5230;&#x4e2d;&#x95f4;&#x8282;&#x70b9;&#x7684;MAC&#x5730;&#x5740;&#xff0c;&#x901a;&#x8fc7;&#x4e2d;&#x95f4;&#x8282;&#x70b9;&#x4f20;&#x9001;&#xff0c;&#x4ece;&#x800c;&#x6700;&#x7ec8;&#x5230;&#x8fbe;&#x76ee;&#x7684;&#x7f51;&#x7edc;&#xff09;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473996127209" FOLDED="true" ID="ID_758812360" MODIFIED="1529657527959" TEXT="IPV4&#x548c;IPV6">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473996152467" FOLDED="true" ID="ID_156971068" MODIFIED="1529657527959" TEXT="IPV4">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473996334978" ID="ID_1628148619" MODIFIED="1473996346016" TEXT="Ip&#x534f;&#x8bae;&#x7684;&#x7b2c;&#x56db;&#x4e2a;&#x7248;&#x672c;"/>
<node COLOR="#111111" CREATED="1473996444226" ID="ID_374734914" MODIFIED="1473996444226" TEXT="IPv4&#x4e2d;&#x89c4;&#x5b9a;IP&#x5730;&#x5740;&#x957f;&#x5ea6;&#x4e3a;32&#xff08;&#x6309;TCP/IP&#x53c2;&#x8003;&#x6a21;&#x578b;&#x5212;&#x5206;) &#xff0c;&#x5373;&#x6709;2^32-1&#x4e2a;&#x5730;&#x5740;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473996156206" FOLDED="true" ID="ID_240986062" MODIFIED="1529657527959" TEXT="IPV6">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1473996269305" FOLDED="true" ID="ID_1562473145" MODIFIED="1529657527959" TEXT="&#x4f18;&#x52bf;">
<node COLOR="#111111" CREATED="1473996274351" ID="ID_77428025" MODIFIED="1501209429248" TEXT="&#x7b2c;&#x4e00;&#xff0c;&#x660e;&#x663e;&#x5730;&#x6269;&#x5927;&#x4e86;&#x5730;&#x5740;&#x7a7a;&#x95f4;&#x3002;IPv6&#x91c7;&#x7528;128&#x4f4d;&#xa;&#x5730;&#x5740;&#x957f;&#x5ea6;&#xff0c;&#x51e0;&#x4e4e;&#x53ef;&#x4ee5;&#x4e0d;&#x53d7;&#x9650;&#x5236;&#x5730;&#x63d0;&#x4f9b;IP&#x5730;&#x5740;&#xff0c;&#x4ece;&#xa;&#x800c;&#x786e;&#x4fdd;&#x4e86;&#x7aef;&#x5230;&#x7aef;&#x8fde;&#x63a5;&#x7684;&#x53ef;&#x80fd;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1473996274358" ID="ID_1484471680" MODIFIED="1501209417603" TEXT="&#x7b2c;&#x4e8c;&#xff0c;&#x63d0;&#x9ad8;&#x4e86;&#x7f51;&#x7edc;&#x7684;&#x6574;&#x4f53;&#x541e;&#x5410;&#x91cf;&#x3002;&#x7531;&#x4e8e;IPv6&#x7684;&#xa;&#x6570;&#x636e;&#x5305;&#x53ef;&#x4ee5;&#x8fdc;&#x8fdc;&#x8d85;&#x8fc7;64k&#x5b57;&#x8282;&#xff0c;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#xa;&#x5229;&#x7528;&#x6700;&#x5927;&#x4f20;&#x8f93;&#x5355;&#x5143;&#xff08;MTU&#xff09;&#xff0c;&#x83b7;&#x5f97;&#x66f4;&#x5feb;&#x3001;&#x66f4;&#x53ef;&#xa;&#x9760;&#x7684;&#x6570;&#x636e;&#x4f20;&#x8f93;&#xff0c;&#x540c;&#x65f6;&#x5728;&#x8bbe;&#x8ba1;&#x4e0a;&#x6539;&#x8fdb;&#x4e86;&#x9009;&#x8def;&#x7ed3;&#x6784;&#xff0c;&#xa;&#x91c7;&#x7528;&#x7b80;&#x5316;&#x7684;&#x62a5;&#x5934;&#x5b9a;&#x957f;&#x7ed3;&#x6784;&#x548c;&#x66f4;&#x5408;&#x7406;&#x7684;&#x5206;&#x6bb5;&#x65b9;&#x6cd5;&#xff0c;&#xa;&#x4f7f;&#x8def;&#x7531;&#x5668;&#x52a0;&#x5feb;&#x6570;&#x636e;&#x5305;&#x5904;&#x7406;&#x901f;&#x5ea6;&#xff0c;&#x63d0;&#x9ad8;&#x4e86;&#x8f6c;&#x53d1;&#x6548;&#xa;&#x7387;&#xff0c;&#x4ece;&#x800c;&#x63d0;&#x9ad8;&#x7f51;&#x7edc;&#x7684;&#x6574;&#x4f53;&#x541e;&#x5410;&#x91cf;&#x3002;"/>
<node COLOR="#111111" CREATED="1473996274366" ID="ID_660307906" MODIFIED="1501209446699" TEXT="&#x7b2c;&#x4e09;&#xff0c;&#x4f7f;&#x5f97;&#x6574;&#x4e2a;&#x670d;&#x52a1;&#x8d28;&#x91cf;&#x5f97;&#x5230;&#x5f88;&#x5927;&#x6539;&#x5584;&#x3002;&#xa;&#x62a5;&#x5934;&#x4e2d;&#x7684;&#x4e1a;&#x52a1;&#x7ea7;&#x522b;&#x548c;&#x6d41;&#x6807;&#x8bb0;&#x901a;&#x8fc7;&#x8def;&#x7531;&#x5668;&#x7684;&#x914d;&#x7f6e;&#x53ef;&#xa;&#x4ee5;&#x5b9e;&#x73b0;&#x4f18;&#x5148;&#x7ea7;&#x63a7;&#x5236;&#x548c;QoS&#x4fdd;&#x969c;&#xff0c;&#x4ece;&#x800c;&#x6781;&#x5927;&#x6539;&#x5584;&#xa;&#x4e86;IPv6&#x7684;&#x670d;&#x52a1;&#x8d28;&#x91cf;&#x3002;"/>
<node COLOR="#111111" CREATED="1473996274376" ID="ID_1242783353" MODIFIED="1501209457630" TEXT="&#x7b2c;&#x56db;&#xff0c;&#x5b89;&#x5168;&#x6027;&#x6709;&#x4e86;&#x66f4;&#x597d;&#x7684;&#x4fdd;&#x8bc1;&#x3002;&#x91c7;&#x7528;IPSec&#x53ef;&#x4ee5;&#xa;&#x4e3a;&#x4e0a;&#x5c42;&#x534f;&#x8bae;&#x548c;&#x5e94;&#x7528;&#x63d0;&#x4f9b;&#x6709;&#x6548;&#x7684;&#x7aef;&#x5230;&#x7aef;&#x5b89;&#x5168;&#x4fdd;&#x8bc1;&#xff0c;&#xa;&#x80fd;&#x63d0;&#x9ad8;&#x5728;&#x8def;&#x7531;&#x5668;&#x6c34;&#x5e73;&#x4e0a;&#x7684;&#x5b89;&#x5168;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1473996274384" ID="ID_1074442849" MODIFIED="1501209475616" TEXT="&#x7b2c;&#x4e94;&#xff0c;&#x652f;&#x6301;&#x5373;&#x63d2;&#x5373;&#x7528;&#x548c;&#x79fb;&#x52a8;&#x6027;&#x3002;&#x8bbe;&#x5907;&#x63a5;&#x5165;&#x7f51;&#x7edc;&#x65f6;&#xa;&#x901a;&#x8fc7;&#x81ea;&#x52a8;&#x914d;&#x7f6e;&#x53ef;&#x81ea;&#x52a8;&#x83b7;&#x53d6;IP&#x5730;&#x5740;&#x548c;&#x5fc5;&#x8981;&#x7684;&#x53c2;&#x6570;&#xff0c;&#xa;&#x5b9e;&#x73b0;&#x5373;&#x63d2;&#x5373;&#x7528;&#xff0c;&#x7b80;&#x5316;&#x4e86;&#x7f51;&#x7edc;&#x7ba1;&#x7406;&#xff0c;&#x6613;&#x4e8e;&#x652f;&#x6301;&#x79fb;&#x52a8;&#xa;&#x8282;&#x70b9;&#x3002;&#x800c;&#x4e14;IPv6&#x4e0d;&#x4ec5;&#x4ece;IPv4&#x4e2d;&#x501f;&#x9274;&#x4e86;&#x8bb8;&#x591a;&#x6982;&#x5ff5;&#x548c;&#xa;&#x672f;&#x8bed;&#xff0c;&#x5b83;&#x8fd8;&#x5b9a;&#x4e49;&#x4e86;&#x8bb8;&#x591a;&#x79fb;&#x52a8;IPv6&#x6240;&#x9700;&#x7684;&#x65b0;&#x529f;&#x80fd;&#x3002;"/>
<node COLOR="#111111" CREATED="1473996274392" ID="ID_1110902379" MODIFIED="1501209490428" TEXT="&#x7b2c;&#x516d;&#xff0c;&#x66f4;&#x597d;&#x5730;&#x5b9e;&#x73b0;&#x4e86;&#x591a;&#x64ad;&#x529f;&#x80fd;&#x3002;&#x5728;IPv6&#x7684;&#x591a;&#x64ad;&#x529f;&#xa;&#x80fd;&#x4e2d;&#x589e;&#x52a0;&#x4e86;&#x201c;&#x8303;&#x56f4;&#x201d;&#x548c;&#x201c;&#x6807;&#x5fd7;&#x201d;&#xff0c;&#x9650;&#x5b9a;&#x4e86;&#x8def;&#x7531;&#x8303;&#x56f4;&#x548c;&#x53ef;&#xa;&#x4ee5;&#x533a;&#x5206;&#x6c38;&#x4e45;&#x6027;&#x4e0e;&#x4e34;&#x65f6;&#x6027;&#x5730;&#x5740;&#xff0c;&#x66f4;&#x6709;&#x5229;&#x4e8e;&#x591a;&#x64ad;&#x529f;&#x80fd;&#xa;&#x7684;&#x5b9e;&#x73b0;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1473996350618" ID="ID_1982500842" MODIFIED="1473996362768" TEXT="Ip&#x534f;&#x8bae;&#x7684;&#x7b2c;&#x516d;&#x4e2a;&#x7248;&#x672c;"/>
<node COLOR="#111111" CREATED="1473996462843" ID="ID_1707299116" MODIFIED="1473996462844" TEXT="IPv6&#x4f7f;&#x7528;&#x7684;128&#x4f4d;&#x5730;&#x5740;&#x6240;&#x91c7;&#x7528;&#x7684;&#x4f4d;&#x5740;&#x8bb0;&#x6570;&#x6cd5;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1473993504961" FOLDED="true" ID="ID_1030902674" MODIFIED="1529657527962" TEXT="Http">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473993634703" FOLDED="true" ID="ID_1479053542" MODIFIED="1529657527960" TEXT="HttpClient">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474429197768" ID="ID_1586899645" MODIFIED="1474429208280" TEXT="&#x5df2;&#x7ecf;&#x4e0d;&#x4f7f;&#x7528;&#x4e86;"/>
</node>
<node COLOR="#990000" CREATED="1473993643432" FOLDED="true" ID="ID_1314009398" MODIFIED="1529657527960" TEXT="HttpUrlConnection">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474429211618" ID="ID_903016793" MODIFIED="1474429220530" TEXT="&#x76ee;&#x524d;&#x4f7f;&#x7528;&#x7684;&#x662f;&#x8fd9;&#x4e2a;"/>
</node>
<node COLOR="#990000" CREATED="1473993661882" FOLDED="true" ID="ID_769499842" MODIFIED="1529657527961" TEXT="&#x8bf7;&#x6c42;&#x5934;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474808857177" FOLDED="true" ID="ID_372570816" MODIFIED="1529657527960" TEXT="Content-Disposition">
<node COLOR="#111111" CREATED="1474810210741" ID="ID_1693212089" MODIFIED="1474810217870" TEXT="&#xff1f;    &#x5c31;&#x662f;&#x5f53;&#x7528;&#x6237;&#x60f3;&#x628a;&#x8bf7;&#x6c42;&#x6240;&#x5f97;&#x7684;&#x5185;&#x5bb9;&#x5b58;&#x4e3a;&#x4e00;&#x4e2a;&#x6587;&#x4ef6;&#x7684;&#x65f6;&#x5019;&#x63d0;&#x4f9b;&#x4e00;&#x4e2a;&#x9ed8;&#x8ba4;&#x7684;&#x6587;&#x4ef6;&#x540d;"/>
<node COLOR="#111111" CREATED="1474810227923" ID="ID_543150850" MODIFIED="1474810227923" TEXT="&#x4f8b;&#x5b50;&#xff1a;Content-Disposition: attachment; filename=&#x201c;filename.xls&#x201d;"/>
</node>
<node COLOR="#111111" CREATED="1474808966886" FOLDED="true" ID="ID_227223421" MODIFIED="1529657527960" TEXT="Accept-Language">
<node COLOR="#111111" CREATED="1474809027027" ID="ID_355430110" MODIFIED="1474809027028" TEXT="Accept-Language&#x8868;&#x793a;&#x6d4f;&#x89c8;&#x5668;&#x6240;&#x652f;&#x6301;&#x7684;&#x8bed;&#x8a00;&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1474809039532" FOLDED="true" ID="ID_301750359" MODIFIED="1529657527960" TEXT="&#x4f8b;&#x5982;&#xff1a;Accept-Language: zh-cn,zh;q=0.5 ">
<node COLOR="#111111" CREATED="1474808976236" ID="ID_663168961" MODIFIED="1474808976238" TEXT="&#x6d4f;&#x89c8;&#x5668;&#x652f;&#x6301;&#x7684;&#x8bed;&#x8a00;&#x5206;&#x522b;&#x662f;&#x4e2d;&#x6587;&#x548c;&#x7b80;&#x4f53;&#x4e2d;&#x6587;&#xff0c;&#x4f18;&#x5148;&#x652f;&#x6301;&#x7b80;&#x4f53;&#x4e2d;&#x6587;"/>
<node COLOR="#111111" CREATED="1474809079213" ID="ID_1749410065" MODIFIED="1474809079213" TEXT="zh-cn&#x8868;&#x793a;&#x7b80;&#x4f53;&#x4e2d;&#x6587;&#xff1b;zh &#x8868;&#x793a;&#x4e2d;&#x6587;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474809086740" FOLDED="true" ID="ID_116056471" MODIFIED="1529657527960" TEXT="q &#x662f;&#x6743;&#x91cd;&#x7cfb;&#x6570;">
<node COLOR="#111111" CREATED="1474809096155" ID="ID_1618333317" MODIFIED="1474809096155" TEXT="&#x8303;&#x56f4; 0 =&lt; q &lt;= 1&#xff0c;q &#x503c;&#x8d8a;&#x5927;&#xff0c;&#x8bf7;&#x6c42;&#x8d8a;&#x503e;&#x5411;&#x4e8e;&#x83b7;&#x5f97;&#x5176;&#x201c;;&#x201d;&#x4e4b;&#x524d;&#x7684;&#x7c7b;&#x578b;&#x8868;&#x793a;&#x7684;&#x5185;&#x5bb9;&#xff0c;&#x82e5;&#x6ca1;&#x6709;&#x6307;&#x5b9a; q &#x503c;&#xff0c;&#x5219;&#x9ed8;&#x8ba4;&#x4e3a;1&#xff0c;&#x82e5;&#x88ab;&#x8d4b;&#x503c;&#x4e3a;0&#xff0c;&#x5219;&#x7528;&#x4e8e;&#x63d0;&#x9192;&#x670d;&#x52a1;&#x5668;&#x54ea;&#x4e9b;&#x662f;&#x6d4f;&#x89c8;&#x5668;&#x4e0d;&#x63a5;&#x53d7;&#x7684;&#x5185;&#x5bb9;&#x7c7b;&#x578b;&#x3002;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474809106755" FOLDED="true" ID="ID_639061772" MODIFIED="1529657527960" TEXT="Accept-Charset">
<node COLOR="#111111" CREATED="1474809130085" ID="ID_304953852" MODIFIED="1474809130085" TEXT="&#x6d4f;&#x89c8;&#x5668;&#x652f;&#x6301;&#x7684;&#x5b57;&#x7b26;&#x7f16;&#x7801;&#x5206;&#x522b;&#x662f; GB2312&#x3001;utf-8 &#x548c;&#x4efb;&#x610f;&#x5b57;&#x7b26;&#xff0c;&#x4f18;&#x5148;&#x987a;&#x5e8f;&#x662f; GB2312&#x3001;utf-8&#x3001;*&#x3002;"/>
<node COLOR="#111111" CREATED="1474809140519" ID="ID_559651442" MODIFIED="1474809152159" TEXT="&#x4f8b;&#x5982;&#xff1a;Accept-Charset: GB2312,utf-8;q=0.7,*;q=0.7"/>
</node>
<node COLOR="#111111" CREATED="1474809188874" FOLDED="true" ID="ID_1121798383" MODIFIED="1529657527960" TEXT="&#x3000;&#x3000;Accept">
<node COLOR="#111111" CREATED="1474809195839" FOLDED="true" ID="ID_1795536380" MODIFIED="1529657527960" TEXT="&#xff1f;  &#x8868;&#x793a;&#x6d4f;&#x89c8;&#x5668;&#x652f;&#x6301;&#x7684; MIME &#x7c7b;&#x578b;">
<node COLOR="#111111" CREATED="1474809227291" FOLDED="true" ID="ID_1081572706" MODIFIED="1529657527960" TEXT="MIME">
<node COLOR="#111111" CREATED="1474809235473" ID="ID_101079154" MODIFIED="1474809235473" TEXT="&#x82f1;&#x6587;&#x5168;&#x79f0;&#x662f; Multipurpose Internet Mail Extensions&#xff08;&#x591a;&#x529f;&#x80fd; Internet &#x90ae;&#x4ef6;&#x6269;&#x5145;&#x670d;&#x52a1;&#xff09;&#xff0c;&#x5b83;&#x662f;&#x4e00;&#x79cd;&#x591a;&#x7528;&#x9014;&#x7f51;&#x9645;&#x90ae;&#x4ef6;&#x6269;&#x5145;&#x534f;&#x8bae;&#xff0c;&#x5728;1992&#x5e74;&#x6700;&#x65e9;&#x5e94;&#x7528;&#x4e8e;&#x7535;&#x5b50;&#x90ae;&#x4ef6;&#x7cfb;&#x7edf;&#xff0c;&#x4f46;&#x540e;&#x6765;&#x4e5f;&#x5e94;&#x7528;&#x5230;&#x6d4f;&#x89c8;&#x5668;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474809252766" FOLDED="true" ID="ID_764924362" MODIFIED="1529657527960" TEXT="&#x4f8b;&#x5982;&#xff1a; text/html,application/xhtml+xml,application/xml">
<node COLOR="#111111" CREATED="1474809267063" ID="ID_812544724" MODIFIED="1474809267063" TEXT="&#x5a92;&#x4f53;&#x7c7b;&#x578b;&#x548c;&#x5185;&#x5bb9;&#x7c7b;&#x578b;&#xff0c;&#x659c;&#x6760;&#x524d;&#x9762;&#x7684;&#x662f; type&#xff08;&#x7c7b;&#x578b;&#xff09;&#xff0c;&#x659c;&#x6760;&#x540e;&#x9762;&#x7684;&#x662f; subtype&#xff08;&#x5b50;&#x7c7b;&#x578b;&#xff09;&#xff1b;type &#x6307;&#x5b9a;&#x5927;&#x7684;&#x8303;&#x56f4;&#xff0c;subtype &#x662f; type &#x4e2d;&#x8303;&#x56f4;&#x66f4;&#x660e;&#x786e;&#x7684;&#x7c7b;&#x578b;&#xff0c;&#x5373;&#x5927;&#x7c7b;&#x4e2d;&#x7684;&#x5c0f;&#x7c7b;&#x3002;"/>
<node COLOR="#111111" CREATED="1474809287554" ID="ID_516621986" MODIFIED="1474809287554" TEXT="Text&#xff1a;&#x7528;&#x4e8e;&#x6807;&#x51c6;&#x5316;&#x5730;&#x8868;&#x793a;&#x7684;&#x6587;&#x672c;&#x4fe1;&#x606f;&#xff0c;&#x6587;&#x672c;&#x6d88;&#x606f;&#x53ef;&#x4ee5;&#x662f;&#x591a;&#x79cd;&#x5b57;&#x7b26;&#x96c6;&#x548c;&#x6216;&#x8005;&#x591a;&#x79cd;&#x683c;&#x5f0f;&#x7684;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474809287570" ID="ID_980528930" MODIFIED="1474809287570" TEXT="&#x3000;&#x3000;text/html&#x8868;&#x793a; html &#x6587;&#x6863;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474809287570" ID="ID_417380525" MODIFIED="1474809287570" TEXT="&#x3000;&#x3000;Application&#xff1a;&#x7528;&#x4e8e;&#x4f20;&#x8f93;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x6570;&#x636e;&#x6216;&#x8005;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x636e;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474809287570" ID="ID_832646283" MODIFIED="1474809287570" TEXT="&#x3000;&#x3000;application/xhtml+xml&#x8868;&#x793a; xhtml &#x6587;&#x6863;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474809287570" ID="ID_833794142" MODIFIED="1474809287570" TEXT="&#x3000;&#x3000;application/xml&#x8868;&#x793a; xml &#x6587;&#x6863;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1474809197732" FOLDED="true" ID="ID_41568616" MODIFIED="1529657527960" TEXT="&#x4f8b;&#x5982;">
<node COLOR="#111111" CREATED="1474809208571" FOLDED="true" ID="ID_1837480645" MODIFIED="1529657527960" TEXT="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8">
<node COLOR="#111111" CREATED="1474809216176" ID="ID_1965924334" MODIFIED="1474809216176" TEXT="&#x6d4f;&#x89c8;&#x5668;&#x652f;&#x6301;&#x7684; MIME &#x7c7b;&#x578b;&#x5206;&#x522b;&#x662f; text/html&#x3001;application/xhtml+xml&#x3001;application/xml &#x548c; */*&#xff0c;&#x4f18;&#x5148;&#x987a;&#x5e8f;&#x662f;&#x5b83;&#x4eec;&#x4ece;&#x5de6;&#x5230;&#x53f3;&#x7684;&#x6392;&#x5217;&#x987a;&#x5e8f;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1474817193884" ID="ID_881380030" MODIFIED="1474817193884" TEXT="application/octet-stream  &#x8fd9;&#x4ee3;&#x8868;&#x4efb;&#x610f;&#x7684;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x636e;&#x4f20;&#x8f93;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474809481058" FOLDED="true" ID="ID_459797224" MODIFIED="1529657527960" TEXT="Accept-Encoding">
<node COLOR="#111111" CREATED="1474809487553" FOLDED="true" ID="ID_662371878" MODIFIED="1529657527960" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1474809489045" ID="ID_1474250812" MODIFIED="1474809489045" TEXT="&#x8868;&#x793a;&#x6d4f;&#x89c8;&#x5668;&#x6709;&#x80fd;&#x529b;&#x89e3;&#x7801;&#x7684;&#x7f16;&#x7801;&#x7c7b;&#x578b;&#xff1b;"/>
</node>
<node COLOR="#111111" CREATED="1474809499362" FOLDED="true" ID="ID_1180031" MODIFIED="1529657527960" TEXT="&#x4f8b;&#x5982;">
<node COLOR="#111111" CREATED="1474809502945" FOLDED="true" ID="ID_275285400" MODIFIED="1529657527960" TEXT="Accept-Encoding: gzip, deflate">
<node COLOR="#111111" CREATED="1474809512546" ID="ID_895186873" MODIFIED="1474809512546" TEXT="gzip&#x662f; GNU zip &#x7684;&#x7f29;&#x5199;&#xff0c;&#x5b83;&#x662f;&#x4e00;&#x4e2a; GNU &#x81ea;&#x7531;&#x8f6f;&#x4ef6;&#x7684;&#x6587;&#x4ef6;&#x538b;&#x7f29;&#x7a0b;&#x5e8f;&#xff0c;&#x4e5f;&#x7ecf;&#x5e38;&#x7528;&#x6765;&#x8868;&#x793a; gzip &#x8fd9;&#x79cd;&#x6587;&#x4ef6;&#x683c;&#x5f0f;&#x3002;"/>
<node COLOR="#111111" CREATED="1474809518217" ID="ID_77233720" MODIFIED="1474809518217" TEXT="deflate&#x662f;&#x540c;&#x65f6;&#x4f7f;&#x7528;&#x4e86; LZ77 &#x7b97;&#x6cd5;&#x4e0e;&#x54c8;&#x592b;&#x66fc;&#x7f16;&#x7801;&#xff08;Huffman Coding&#xff09;&#x7684;&#x4e00;&#x4e2a;&#x65e0;&#x635f;&#x6570;&#x636e;&#x538b;&#x7f29;&#x7b97;&#x6cd5;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474809531563" FOLDED="true" ID="ID_1059783220" MODIFIED="1529657527961" TEXT="User-Agent">
<node COLOR="#111111" CREATED="1474809546482" FOLDED="true" ID="ID_149539549" MODIFIED="1529657527960" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1474809548380" ID="ID_1862350412" MODIFIED="1474809548380" TEXT="&#x7528;&#x6237;&#x4ee3;&#x7406;&#xff09;&#xff0c;&#x7b80;&#x79f0; UA&#xff0c;&#x5b83;&#x662f;&#x4e00;&#x4e2a;&#x7279;&#x6b8a;&#x5b57;&#x7b26;&#x4e32;&#x5934;&#xff0c;&#x4f7f;&#x5f97;&#x670d;&#x52a1;&#x5668;&#x80fd;&#x591f;&#x8bc6;&#x522b;&#x5ba2;&#x6237;&#x7aef;&#x4f7f;&#x7528;&#x7684;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x53ca;&#x7248;&#x672c;&#x3001;CPU &#x7c7b;&#x578b;&#x3001;&#x6d4f;&#x89c8;&#x5668;&#x53ca;&#x7248;&#x672c;&#x3001;&#x6d4f;&#x89c8;&#x5668;&#x6e32;&#x67d3;&#x5f15;&#x64ce;&#x3001;&#x6d4f;&#x89c8;&#x5668;&#x8bed;&#x8a00;&#x3001;&#x6d4f;&#x89c8;&#x5668;&#x63d2;&#x4ef6;&#x7b49;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1474809558229" FOLDED="true" ID="ID_1769336213" MODIFIED="1529657527961" TEXT="&#x4f8b;&#x5982;">
<node COLOR="#111111" CREATED="1474809560829" FOLDED="true" ID="ID_1403548388" MODIFIED="1529657527961" TEXT="User-Agent: Mozilla/5.0 (compatible;&#x57df;&#x540d;)">
<node COLOR="#111111" CREATED="1474809567888" ID="ID_952175832" MODIFIED="1474809567888" TEXT="&#x610f;&#x601d;&#xff1a;&#x4f7f;&#x7528;&#x7684;&#x7528;&#x6237;&#x4ee3;&#x7406;&#x662f; Mozilla/5.0 (compatible; &#x57df;&#x540d;)&#x3002;"/>
<node COLOR="#111111" CREATED="1474809580165" ID="ID_626410601" MODIFIED="1474809580165" TEXT="Mozilla/5.0&#xff1a;Mozilla &#x662f;&#x6d4f;&#x89c8;&#x5668;&#x540d;&#xff0c;&#x7248;&#x672c;&#x662f; 5.0&#xff1b;"/>
<node COLOR="#111111" CREATED="1474809580165" ID="ID_1124840728" MODIFIED="1474809580165" TEXT="&#x3000;&#x3000;compatible&#xff08;&#x517c;&#x5bb9;&#x7684;&#xff09;&#x8868;&#x793a;&#x5e73;&#x53f0;&#x662f;&#x517c;&#x5bb9;&#x6a21;&#x5f0f;&#xff1b;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474809611981" FOLDED="true" ID="ID_1365307158" MODIFIED="1529657527961" TEXT="Host">
<node COLOR="#111111" CREATED="1474809614530" FOLDED="true" ID="ID_1492087794" MODIFIED="1529657527961" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1474809617845" ID="ID_1566844972" MODIFIED="1474809620639" TEXT="&#x57df;&#x540d;"/>
<node COLOR="#111111" CREATED="1474809627776" ID="ID_1376718286" MODIFIED="1474809627776" TEXT="Host&#x8868;&#x793a;&#x8bf7;&#x6c42;&#x7684;&#x670d;&#x52a1;&#x5668;&#x7f51;&#x5740;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474809641200" FOLDED="true" ID="ID_299745051" MODIFIED="1529657527961" TEXT="Connection:">
<node COLOR="#111111" CREATED="1474809647869" ID="ID_819494941" MODIFIED="1474809647869" TEXT="Connection: Keep-Alive"/>
<node COLOR="#111111" CREATED="1474809647869" ID="ID_981462012" MODIFIED="1474809647869" TEXT="&#x3000;&#x3000;Connection&#x8868;&#x793a;&#x5ba2;&#x6237;&#x7aef;&#x4e0e;&#x670d;&#x52a1;&#x8fde;&#x63a5;&#x7c7b;&#x578b;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474809647869" ID="ID_1491375437" MODIFIED="1474809647869" TEXT="&#x3000;&#x3000;Keep-Alive&#x8868;&#x793a;&#x6301;&#x4e45;&#x8fde;&#x63a5;&#xff1b;"/>
</node>
<node COLOR="#111111" CREATED="1474810304812" FOLDED="true" ID="ID_1320111525" MODIFIED="1529657527961" TEXT="boundary">
<node COLOR="#111111" CREATED="1474810671687" ID="ID_1058563945" MODIFIED="1474810671687" TEXT="&#x6307;&#x5b9a;&#x5206;&#x9694;&#x7b26;&#x53f7;&#x7684;&#x6807;&#x5fd7;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810698478" ID="ID_1728365198" MODIFIED="1474810711038" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x4efb;&#x610f;&#x7684;&#x5b57;&#x7b26;&#x4e32;"/>
<node COLOR="#111111" CREATED="1474810724108" ID="ID_17909774" MODIFIED="1474810729888" TEXT="&#x4f8b;&#x5982;&#xff1a; Content-Type:multipart/form-data; boundary=----WebKitFormBoundaryuwYcfA2AIgxqIxA0"/>
</node>
<node COLOR="#111111" CREATED="1474810865952" FOLDED="true" ID="ID_1570638974" MODIFIED="1529657527961" TEXT="Content-Length">
<node COLOR="#111111" CREATED="1474810876565" FOLDED="true" ID="ID_1251189869" MODIFIED="1529657527961" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1474810878111" ID="ID_223566892" MODIFIED="1474810878112" TEXT="&#x7528;&#x4e8e;&#x63cf;&#x8ff0;HTTP&#x6d88;&#x606f;&#x5b9e;&#x4f53;&#x7684;&#x4f20;&#x8f93;&#x957f;&#x5ea6;the transfer-length of the message-body&#x3002;&#x5728;HTTP&#x534f;&#x8bae;&#x4e2d;&#xff0c;&#x6d88;&#x606f;&#x5b9e;&#x4f53;&#x957f;&#x5ea6;&#x548c;&#x6d88;&#x606f;&#x5b9e;&#x4f53;&#x7684;&#x4f20;&#x8f93;&#x957f;&#x5ea6;&#x662f;&#x6709;&#x533a;&#x522b;&#xff0c;&#x6bd4;&#x5982;&#x8bf4;gzip&#x538b;&#x7f29;&#x4e0b;&#xff0c;&#x6d88;&#x606f;&#x5b9e;&#x4f53;&#x957f;&#x5ea6;&#x662f;&#x538b;&#x7f29;&#x524d;&#x7684;&#x957f;&#x5ea6;&#xff0c;&#x6d88;&#x606f;&#x5b9e;&#x4f53;&#x7684;&#x4f20;&#x8f93;&#x957f;&#x5ea6;&#x662f;gzip&#x538b;&#x7f29;&#x540e;&#x7684;&#x957f;&#x5ea6;&#x3002;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1473993666522" FOLDED="true" ID="ID_1558934965" MODIFIED="1529657527961" TEXT="&#x54cd;&#x5e94;&#x5934;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474810125614" ID="ID_1174677079" MODIFIED="1474810125619" TEXT="Cache-Control&#xff1a;must-revalidate, no-cache, private&#x3002;&#x8fd9;&#x4e2a;&#x503c;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#xff0c;&#x670d;&#x52a1;&#x7aef;&#x4e0d;&#x5e0c;&#x671b;&#x5ba2;&#x6237;&#x7aef;&#x7f13;&#x5b58;&#x8d44;&#x6e90;&#xff0c;&#x5728;&#x4e0b;&#x6b21;&#x8bf7;&#x6c42;&#x8d44;&#x6e90;&#x65f6;&#xff0c;&#x5fc5;&#x987b;&#x8981;&#x4ece;&#x65b0;&#x8bf7;&#x6c42;&#x670d;&#x52a1;&#x5668;&#xff0c;&#x4e0d;&#x80fd;&#x4ece;&#x7f13;&#x5b58;&#x526f;&#x672c;&#x4e2d;&#x83b7;&#x53d6;&#x8d44;&#x6e90;&#x3002; Cache-Control&#x662f;&#x54cd;&#x5e94;&#x5934;&#x4e2d;&#x5f88;&#x91cd;&#x8981;&#x7684;&#x4fe1;&#x606f;&#xff0c;&#x5f53;&#x5ba2;&#x6237;&#x7aef;&#x8bf7;&#x6c42;&#x5934;&#x4e2d;&#x5305;&#x542b;Cache-Control:max-age=0&#x8bf7;&#x6c42;&#xff0c;&#x660e;&#x786e;&#x8868;&#x793a;&#x4e0d;&#x4f1a;&#x7f13;&#x5b58;&#x670d;&#x52a1;&#x5668;&#x8d44;&#x6e90;&#x65f6;,Cache-Control&#x4f5c;&#x4e3a;&#x4f5c;&#x4e3a;&#x56de;&#x5e94;&#x4fe1;&#x606f;&#xff0c;&#x901a;&#x5e38;&#x4f1a;&#x8fd4;&#x56de;no-cache&#xff0c;&#x610f;&#x601d;&#x5c31;&#x662f;&#x8bf4;&#xff0c;&#x201c;&#x4e0d;&#x7f13;&#x5b58;&#x5c31;&#x4e0d;&#x7f13;&#x5b58;&#x5457;&#x201d;&#xff1b;&#x5f53;&#x5ba2;&#x6237;&#x7aef;&#x5728;&#x8bf7;&#x6c42;&#x5934;&#x4e2d;&#x6ca1;&#x6709;&#x5305;&#x542b;Cache-Control&#x65f6;&#xff0c;&#x670d;&#x52a1;&#x7aef;&#x5f80;&#x5f80;&#x4f1a;&#x5b9a;,&#x4e0d;&#x540c;&#x7684;&#x8d44;&#x6e90;&#x4e0d;&#x540c;&#x7684;&#x7f13;&#x5b58;&#x7b56;&#x7565;&#xff0c;&#x6bd4;&#x5982;&#x8bf4;oschina&#x5728;&#x7f13;&#x5b58;&#x56fe;&#x7247;&#x8d44;&#x6e90;&#x7684;&#x7b56;&#x7565;&#x5c31;&#x662f;Cache-Control&#xff1a;max-age=86400,&#x8fd9;&#x4e2a;&#x610f;&#x601d;&#x662f;&#xff0c;&#x4ece;&#x5f53;&#x524d;&#x65f6;&#x95f4;&#x5f00;&#x59cb;&#xff0c;&#x5728;86400&#x79d2;&#x7684;&#x65f6;&#x95f4;&#x5185;&#xff0c;&#x5ba2;&#x6237;&#x7aef;&#x53ef;&#x4ee5;&#x76f4;&#x63a5;&#x4ece;&#x7f13;&#x5b58;&#x526f;&#x672c;&#x4e2d;&#x8bfb;&#x53d6;&#x8d44;&#x6e90;&#xff0c;&#x800c;&#x4e0d;&#x9700;&#x8981;&#x5411;&#x670d;&#x52a1;&#x5668;&#x8bf7;&#x6c42;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125628" ID="ID_606201338" MODIFIED="1474810125629" TEXT="Connection&#xff1a;keep-alive&#xff0c;&#x8fd9;&#x4e2a;&#x5b57;&#x6bb5;&#x4f5c;&#x4e3a;&#x56de;&#x5e94;&#x5ba2;&#x6237;&#x7aef;&#x7684;Connection&#xff1a;keep-alive&#xff0c;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#x670d;&#x52a1;&#x5668;&#x7684;tcp&#x8fde;&#x63a5;&#x4e5f;&#x662f;&#x4e00;&#x4e2a;&#x957f;&#x8fde;&#x63a5;&#xff0c;&#x5ba2;&#x6237;&#x7aef;&#x53ef;&#x4ee5;&#x7ee7;&#x7eed;&#x4f7f;&#x7528;&#x8fd9;&#x4e2a;tcp&#x8fde;&#x63a5;&#x53d1;&#x9001;http&#x8bf7;&#x6c42;&#x3002;&#x5173;&#x4e8e;&#x957f;&#x8fde;&#x63a5;&#x7684;&#x66f4;&#x591a;&#x77e5;&#x8bc6;&#xff0c;&#x540e;&#x9762;&#x6211;&#x518d;&#x8be6;&#x7ec6;&#x8bb2;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125635" ID="ID_100842547" MODIFIED="1474810125635" TEXT="Content-Encoding:gzip,&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#xff0c;&#x670d;&#x52a1;&#x7aef;&#x53d1;&#x9001;&#x7684;&#x8d44;&#x6e90;&#x662f;&#x91c7;&#x7528;gzip&#x7f16;&#x7801;&#x7684;&#xff0c;&#x5ba2;&#x6237;&#x7aef;&#x770b;&#x5230;&#x8fd9;&#x4e2a;&#x4fe1;&#x606f;&#x540e;&#xff0c;&#x5e94;&#x8be5;&#x91c7;&#x7528;gzip&#x5bf9;&#x8d44;&#x6e90;&#x8fdb;&#x884c;&#x89e3;&#x7801;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125640" ID="ID_913707778" MODIFIED="1474810125642" TEXT="Content-Type&#xff1a;text/html;charset=UTF-8&#xff0c;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#xff0c;&#x8d44;&#x6e90;&#x6587;&#x4ef6;&#x7684;&#x7c7b;&#x578b;&#xff0c;&#x8fd8;&#x6709;&#x5b57;&#x7b26;&#x7f16;&#x7801;&#xff0c;&#x5ba2;&#x6237;&#x7aef;&#x901a;&#x8fc7;utf-8&#x5bf9;&#x8d44;&#x6e90;&#x8fdb;&#x884c;&#x89e3;&#x7801;&#xff0c;&#x7136;&#x540e;&#x5bf9;&#x8d44;&#x6e90;&#x8fdb;&#x884c;html&#x89e3;&#x6790;&#x3002;&#x901a;&#x5e38;&#x6211;&#x4eec;&#x4f1a;&#x770b;&#x5230;&#x6709;&#x4e9b;&#x7f51;&#x7ad9;&#x662f;&#x4e71;&#x7801;&#x7684;&#xff0c;&#x5f80;&#x5f80;&#x5c31;&#x662f;&#x670d;&#x52a1;&#x5668;&#x7aef;&#x6ca1;&#x6709;&#x8fd4;&#x56de;&#x6b63;&#x786e;&#x7684;&#x7f16;&#x7801;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125646" ID="ID_1846739717" MODIFIED="1474810125647" TEXT="Date&#xff1a;Sun, 21 Sep 2014 06:18:21 GMT&#xff0c;&#x8fd9;&#x4e2a;&#x662f;&#x670d;&#x52a1;&#x7aef;&#x53d1;&#x9001;&#x8d44;&#x6e90;&#x65f6;&#x7684;&#x670d;&#x52a1;&#x5668;&#x65f6;&#x95f4;&#xff0c;&#x521a;&#x5f00;&#x59cb;&#x6211;&#x4e0d;&#x77e5;&#x9053;GMT&#x662f;&#x683c;&#x6797;&#x5c3c;&#x6cbb;&#x6240;&#x5728;&#x5730;&#x7684;&#x6807;&#x51c6;&#x65f6;&#x95f4;&#xff0c;&#x4ee5;&#x4e3a;&#x662f;&#x670d;&#x52a1;&#x5668;&#x7684;&#x65f6;&#x95f4;&#x9519;&#x4e86;&#xff0c;&#x8fd8;&#x53bb;&#x670d;&#x52a1;&#x5668;&#x4e0a;&#x67e5;&#x770b;&#x8fc7;&#x65f6;&#x95f4;&#x3002;http&#x534f;&#x8bae;&#x4e2d;&#x53d1;&#x9001;&#x7684;&#x65f6;&#x95f4;&#x90fd;&#x662f;GMT&#x7684;&#xff0c;&#x8fd9;&#x4e3b;&#x8981;&#x662f;&#x89e3;&#x51b3;&#x5728;&#x4e92;&#x8054;&#x7f51;&#x4e0a;&#xff0c;&#x4e0d;&#x540c;&#x65f6;&#x533a;&#x5728;&#x76f8;&#x4e92;&#x8bf7;&#x6c42;&#x8d44;&#x6e90;&#x7684;&#x65f6;&#x5019;&#xff0c;&#x65f6;&#x95f4;&#x6df7;&#x4e71;&#x95ee;&#x9898;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125652" ID="ID_301753350" MODIFIED="1474810125654" TEXT="Expires:Sun, 1 Jan 2000 01:00:00 GMT,&#x8fd9;&#x4e2a;&#x54cd;&#x5e94;&#x5934;&#x4e5f;&#x662f;&#x8ddf;&#x7f13;&#x5b58;&#x6709;&#x5173;&#x7684;&#xff0c;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#x5728;&#x8fd9;&#x4e2a;&#x65f6;&#x95f4;&#x524d;&#xff0c;&#x53ef;&#x4ee5;&#x76f4;&#x63a5;&#x8bbf;&#x95ee;&#x7f13;&#x5b58;&#x526f;&#x672c;&#xff0c;&#x5f88;&#x663e;&#x7136;&#x8fd9;&#x4e2a;&#x503c;&#x4f1a;&#x5b58;&#x5728;&#x95ee;&#x9898;&#xff0c;&#x56e0;&#x4e3a;&#x5ba2;&#x6237;&#x7aef;&#x548c;&#x670d;&#x52a1;&#x5668;&#x7684;&#x65f6;&#x95f4;&#x4e0d;&#x4e00;&#x5b9a;&#x4f1a;&#x90fd;&#x662f;&#x76f8;&#x540c;&#x7684;&#xff0c;&#x5982;&#x679c;&#x65f6;&#x95f4;&#x4e0d;&#x540c;&#x5c31;&#x4f1a;&#x5bfc;&#x81f4;&#x95ee;&#x9898;&#x3002;&#x6240;&#x4ee5;&#x8fd9;&#x4e2a;&#x54cd;&#x5e94;&#x5934;&#x662f;&#x6ca1;&#x6709;Cache-Control&#xff1a;max-age=*&#x8fd9;&#x4e2a;&#x54cd;&#x5e94;&#x5934;&#x51c6;&#x786e;&#x7684;&#xff0c;&#x56e0;&#x4e3a;max-age=date&#x4e2d;&#x7684;date&#x662f;&#x4e2a;&#x76f8;&#x5bf9;&#x65f6;&#x95f4;&#xff0c;&#x4e0d;&#x4ec5;&#x66f4;&#x597d;&#x7406;&#x89e3;&#xff0c;&#x4e5f;&#x66f4;&#x51c6;&#x786e;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125659" ID="ID_1849686136" MODIFIED="1474810125659" TEXT="Pragma:no-cache,&#x8fd9;&#x4e2a;&#x542b;&#x4e49;&#x4e0e;Cache-Control&#x7b49;&#x540c;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125660" ID="ID_1390257310" MODIFIED="1474810125660" TEXT="Server&#xff1a;Tengine/1.4.6&#xff0c;&#x8fd9;&#x4e2a;&#x662f;&#x670d;&#x52a1;&#x5668;&#x548c;&#x76f8;&#x5bf9;&#x5e94;&#x7684;&#x7248;&#x672c;&#xff0c;&#x53ea;&#x662f;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#x670d;&#x52a1;&#x5668;&#x4fe1;&#x606f;&#xff0c;&#x6ca1;&#x6709;&#x66f4;&#x591a;&#x7684;&#x610f;&#x601d;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125661" ID="ID_1867929645" MODIFIED="1474810125662" TEXT="Transfer-Encoding&#xff1a;chunked&#xff0c;&#x8fd9;&#x4e2a;&#x54cd;&#x5e94;&#x5934;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#xff0c;&#x670d;&#x52a1;&#x5668;&#x53d1;&#x9001;&#x7684;&#x8d44;&#x6e90;&#x7684;&#x65b9;&#x5f0f;&#x662f;&#x5206;&#x5757;&#x53d1;&#x9001;&#x7684;&#x3002;&#x4e00;&#x822c;&#x5206;&#x5757;&#x53d1;&#x9001;&#x7684;&#x8d44;&#x6e90;&#x90fd;&#x662f;&#x670d;&#x52a1;&#x5668;&#x52a8;&#x6001;&#x751f;&#x6210;&#x7684;&#xff0c;&#x5728;&#x53d1;&#x9001;&#x65f6;&#x8fd8;&#x4e0d;&#x77e5;&#x9053;&#x53d1;&#x9001;&#x8d44;&#x6e90;&#x7684;&#x5927;&#x5c0f;&#xff0c;&#x6240;&#x4ee5;&#x91c7;&#x7528;&#x5206;&#x5757;&#x53d1;&#x9001;&#xff0c;&#x6bcf;&#x4e00;&#x5757;&#x90fd;&#x662f;&#x72ec;&#x7acb;&#x7684;&#xff0c;&#x72ec;&#x7acb;&#x7684;&#x5757;&#x90fd;&#x80fd;&#x6807;&#x793a;&#x81ea;&#x5df1;&#x7684;&#x957f;&#x5ea6;&#xff0c;&#x6700;&#x540e;&#x4e00;&#x5757;&#x662f;0&#x957f;&#x5ea6;&#x7684;&#xff0c;&#x5f53;&#x5ba2;&#x6237;&#x7aef;&#x8bfb;&#x5230;&#x8fd9;&#x4e2a;0&#x957f;&#x5ea6;&#x7684;&#x5757;&#x65f6;&#xff0c;&#x5c31;&#x53ef;&#x4ee5;&#x786e;&#x5b9a;&#x8d44;&#x6e90;&#x5df2;&#x7ecf;&#x4f20;&#x8f93;&#x5b8c;&#x4e86;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810125667" ID="ID_90712131" MODIFIED="1474810125667" TEXT="Vary: Accept-Encoding&#xff0c;&#x544a;&#x8bc9;&#x7f13;&#x5b58;&#x670d;&#x52a1;&#x5668;&#xff0c;&#x7f13;&#x5b58;&#x538b;&#x7f29;&#x6587;&#x4ef6;&#x548c;&#x975e;&#x538b;&#x7f29;&#x6587;&#x4ef6;&#x4e24;&#x4e2a;&#x7248;&#x672c;&#xff0c;&#x73b0;&#x5728;&#x8fd9;&#x4e2a;&#x5b57;&#x6bb5;&#x7528;&#x5904;&#x5e76;&#x4e0d;&#x5927;&#xff0c;&#x56e0;&#x4e3a;&#x73b0;&#x5728;&#x7684;&#x6d4f;&#x89c8;&#x5668;&#x90fd;&#x662f;&#x652f;&#x6301;&#x538b;&#x7f29;&#x7684;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810132690" ID="ID_124144204" MODIFIED="1474810132694" TEXT="Content-leng:&#x8d44;&#x6e90;&#x957f;&#x5ea6;&#xff0c;&#x5982;&#x679c;&#x670d;&#x52a1;&#x5668;&#x54cd;&#x5e94;&#x5934;&#x4e2d;&#x6ca1;&#x6709;Transfer-Encoding&#xff1a;chunked&#xff0c;&#x4e5f;&#x5c31;&#x662f;&#x8bf4;&#x5982;&#x679c;&#x8d44;&#x6e90;&#x4e0d;&#x662f;&#x5206;&#x5757;&#x4f20;&#x8f93;&#x7684;&#xff0c;&#x90a3;&#x4e48;&#x8fd9;&#x4e2a;&#x5b57;&#x6bb5;&#x5c31;&#x662f;&#x5fc5;&#x987b;&#x7684;&#xff0c;&#x56e0;&#x4e3a;&#x5982;&#x679c;&#x670d;&#x52a1;&#x5668;&#x7aef;&#x4e0d;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#x8d44;&#x6e90;&#x7684;&#x957f;&#x5ea6;&#xff0c;&#x90a3;&#x4e48;&#x5728;Connection&#xff1a;keep-alive,&#x4e5f;&#x5c31;&#x662f;&#x8bf4;&#x5ba2;&#x6237;&#x7aef;&#x4e0e;&#x670d;&#x52a1;&#x5668;&#x7aef;&#x662f;&#x957f;&#x8fde;&#x63a5;&#x65f6;&#xff0c;&#x5ba2;&#x6237;&#x7aef;&#x5c31;&#x65e0;&#x6cd5;&#x786e;&#x5b9a;&#x8d44;&#x6e90;&#x5728;&#x4ec0;&#x4e48;&#x65f6;&#x5019;&#x7ed3;&#x675f;&#x3002;&#x6240;&#x4ee5;&#x8fd9;&#x4e2a;&#x54cd;&#x5e94;&#x5934;&#x5bf9;&#x4e8e;&#x9759;&#x6001;&#x8d44;&#x6e90;&#x65f6;&#x5fc5;&#x987b;&#x7684;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810132708" ID="ID_1723272358" MODIFIED="1474810132708" TEXT="Content-Range:&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#xff0c;&#x8fd9;&#x6b21;&#x53d1;&#x9001;&#x7684;&#x662f;&#x8d44;&#x6e90;&#x7684;&#x54ea;&#x90e8;&#x95e8;&#x5b57;&#x8282;&#xff0c;&#x901a;&#x5e38;&#x503c;&#x4e3a; &#xff1a;bytes 100-1000 /5000&#x3002;"/>
<node COLOR="#111111" CREATED="1474810132710" ID="ID_6292984" MODIFIED="1474810132710" TEXT="Cookie&#xff1a;&#x7528;&#x4e8e;&#x6807;&#x8bc6;&#x5ba2;&#x6237;&#x7aef;&#xff0c;&#x8ddf;&#x8e2a;&#x5ba2;&#x6237;&#x7aef;,&#x5b58;&#x50a8;&#x7528;&#x6237;&#x4fe1;&#x606f;&#x3001;&#x7528;&#x6237;&#x884c;&#x4e3a;&#x3002;"/>
<node COLOR="#111111" CREATED="1474810132711" ID="ID_1495521403" MODIFIED="1474810132712" TEXT="Location&#xff1a;&#x670d;&#x52a1;&#x7aef;&#x5c06;&#x8d44;&#x6e90;&#x7684;&#x771f;&#x5b9e;&#x76ee;&#x7684;&#x5730;&#x653e;&#x5728;&#x8fd9;&#x4e2a;&#x54cd;&#x5e94;&#x5934;&#x4e2d;&#xff0c;&#x5f15;&#x5bfc;&#x5ba2;&#x6237;&#x7aef;&#x91cd;&#x5b9a;&#x5411;&#x5230;&#x8fd9;&#x4e2a;&#x5730;&#x5740;&#x53bb;&#xff0c;&#x5982;&#x679c;&#x670d;&#x52a1;&#x5668;&#x8fd4;&#x56de;302&#xff0c;&#x90a3;&#x4e48;&#x8fd9;&#x4e2a;&#x503c;&#x662f;&#x5fc5;&#x987b;&#x7684;,&#x901a;&#x5e38;&#x8fd9;&#x4e2a;&#x503c;&#x662f;&#x4e00;&#x4e2a;&#x5b8c;&#x6574;&#x7684;url&#xff1a;www.oschina.net&#x3002;"/>
<node COLOR="#111111" CREATED="1474810132718" ID="ID_1885060254" MODIFIED="1474810132720" TEXT="WWW-Authenticate:&#x8fd9;&#x4e2a;&#x5b57;&#x6bb5;&#x4e3b;&#x8981;&#x7528;&#x5728;&#x670d;&#x52a1;&#x5668;&#x8d44;&#x6e90;&#x662f;&#x6709;&#x8bbf;&#x95ee;&#x9650;&#x5236;&#x7684;&#xff0c;&#x901a;&#x5e38;&#x5ba2;&#x6237;&#x7aef;&#x5728;&#x8bbf;&#x95ee;&#x670d;&#x52a1;&#x5668;&#x8d44;&#x6e90;&#x65f6;&#xff0c;&#x670d;&#x52a1;&#x5668;&#x4f1a;&#x8fd4;&#x56de;401&#xff0c;&#x8981;&#x6c42;&#x5ba2;&#x6237;&#x7aef;&#x53d1;&#x9001;&#x8ba4;&#x8bc1;&#x4fe1;&#x606f;&#xff0c;&#x540c;&#x65f6;&#x4f1a;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#x5982;&#x4f55;&#x5c06;&#x8ba4;&#x8bc1;&#x4fe1;&#x606f;&#x7f16;&#x7801;&#x3002;&#x8fd9;&#x4e2a;&#x54cd;&#x5e94;&#x5934;&#x7684;&#x503c;&#x5c31;&#x662f;&#x5b58;&#x50a8;&#x670d;&#x52a1;&#x5668;&#x544a;&#x8bc9;&#x5ba2;&#x6237;&#x7aef;&#x7f16;&#x7801;&#x7684;&#x65b9;&#x5f0f;&#xff0c;&#x901a;&#x5e38;&#x662f;Basic-64&#x7f16;&#x7801;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1474869040520" FOLDED="true" ID="ID_38001973" MODIFIED="1529657527962" TEXT="&#x5b9e;&#x4f53;&#x5934;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474869055290" FOLDED="true" ID="ID_1341164115" MODIFIED="1529657527962" TEXT="Content-Type">
<node COLOR="#111111" CREATED="1474869066520" ID="ID_1320985723" MODIFIED="1474869066522" TEXT="&#x4ee3;&#x8868;&#x53d1;&#x9001;&#x7aef;&#xff08;&#x5ba2;&#x6237;&#x7aef;|&#x670d;&#x52a1;&#x5668;&#xff09;&#x53d1;&#x9001;&#x7684;&#x5b9e;&#x4f53;&#x6570;&#x636e;&#x7684;&#x6570;&#x636e;&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1474869170642" FOLDED="true" ID="ID_1118975449" MODIFIED="1529657527961" TEXT="&#x662f;MIME&#x7c7b;&#x578b;&#x7684;&#x4e00;&#x79cd;&#x6216;&#x591a;&#x79cd;">
<node COLOR="#111111" CREATED="1474869368124" ID="ID_1308412262" MODIFIED="1474869372783" TEXT="1 text/html HTML&#x6587;&#x672c;"/>
<node COLOR="#111111" CREATED="1474869368126" ID="ID_475618157" MODIFIED="1474869368127" TEXT="2 image/jpeg JPG&#x56fe;&#x7247;"/>
<node COLOR="#111111" CREATED="1474869368128" ID="ID_1112611658" MODIFIED="1474869368128" TEXT="3 image/gif GIF&#x56fe;&#x7247;"/>
<node COLOR="#111111" CREATED="1474869368129" ID="ID_766527" MODIFIED="1474869368130" TEXT="4 application/xml XML&#x6587;&#x6863;"/>
<node COLOR="#111111" CREATED="1474869368135" ID="ID_1972502270" MODIFIED="1474869368139" TEXT="5 audio/x-mpegurl MP3&#x6587;&#x4ef6;&#x5217;&#x8868;&#xff0c;&#x5982;&#x679c;&#x5b89;&#x88c5;&#x4e86;Winamp&#xff0c;&#x5219;&#x53ef;&#x4ee5;&#x76f4;&#x63a5;&#x628a;&#x5b83;&#x5f53;&#x9762;M3U&#x6587;&#x4ef6;&#x6765;&#x6253;&#x5f00;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1474809998281" FOLDED="true" ID="ID_1495524259" MODIFIED="1529657527962" TEXT="&#x8fd4;&#x56de;&#x7801;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474810006793" ID="ID_658347926" MODIFIED="1474810006793" TEXT="&#x9519;&#x8bef;&#x4ee3;&#x7801;&#x89e3;&#x91ca;"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_881338554" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;100&quot; : Continue"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_1417123178" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;101&quot; : witching Protocols"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_1810240389" MODIFIED="1474871960214" TEXT="&#x3000;&#x3000;&quot;200&quot; : OK">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_1446872932" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;201&quot; : Created"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_1384800614" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;202&quot; : Accepted"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_1857319552" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;203&quot; : Non-Authoritative Information"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_844947672" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;204&quot; : No Content"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_743003663" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;205&quot; : Reset Content"/>
<node COLOR="#111111" CREATED="1474810006824" ID="ID_1397032912" MODIFIED="1474810006824" TEXT="&#x3000;&#x3000;&quot;206&quot; : Partial Content"/>
<node COLOR="#111111" CREATED="1474810006840" ID="ID_1758394245" MODIFIED="1474810006840" TEXT="&#x3000;&#x3000;&quot;300&quot; : Multiple Choices"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_549110979" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;&quot;301&quot; : Moved Permanently"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_898287659" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;&quot;302&quot; : Found"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_86947499" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;&quot;303&quot; : See Other"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_143869384" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;&quot;304&quot; : Not Modified"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_752808442" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;&quot;305&quot; : Use Proxy"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_677850616" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;&quot;307&quot; : Temporary Redirect"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_1954520321" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;HTTP 400 - &#x8bf7;&#x6c42;&#x65e0;&#x6548;"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_862403605" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;HTTP 401.1 - &#x672a;&#x6388;&#x6743;&#xff1a;&#x767b;&#x5f55;&#x5931;&#x8d25;"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_662359647" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;HTTP 401.2 - &#x672a;&#x6388;&#x6743;&#xff1a;&#x670d;&#x52a1;&#x5668;&#x914d;&#x7f6e;&#x95ee;&#x9898;&#x5bfc;&#x81f4;&#x767b;&#x5f55;&#x5931;&#x8d25;"/>
<node COLOR="#111111" CREATED="1474810006949" ID="ID_1936120381" MODIFIED="1474810006949" TEXT="&#x3000;&#x3000;HTTP 401.3 - ACL &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#x8d44;&#x6e90;"/>
<node COLOR="#111111" CREATED="1474810006965" ID="ID_1960992764" MODIFIED="1474810006965" TEXT="&#x3000;&#x3000;HTTP 401.4 - &#x672a;&#x6388;&#x6743;&#xff1a;&#x6388;&#x6743;&#x88ab;&#x7b5b;&#x9009;&#x5668;&#x62d2;&#x7edd;"/>
<node COLOR="#111111" CREATED="1474810006965" ID="ID_236471381" MODIFIED="1474810006965" TEXT="&#x3000;&#x3000;HTTP 401.5 - &#x672a;&#x6388;&#x6743;&#xff1a;ISAPI &#x6216; CGI &#x6388;&#x6743;&#x5931;&#x8d25;"/>
<node COLOR="#111111" CREATED="1474810006965" ID="ID_1944070375" MODIFIED="1474810006965" TEXT="&#x3000;&#x3000;HTTP 403 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;"/>
<node COLOR="#111111" CREATED="1474810006965" ID="ID_951644336" MODIFIED="1474810006965" TEXT="&#x3000;&#x3000;HTTP 403 - &#x5bf9; Internet &#x670d;&#x52a1;&#x7ba1;&#x7406;&#x5668; (HTML) &#x7684;&#x8bbf;&#x95ee;&#x4ec5;&#x9650;&#x4e8e; Localhost"/>
<node COLOR="#111111" CREATED="1474810006965" ID="ID_1068334849" MODIFIED="1474810006965" TEXT="&#x3000;&#x3000;HTTP 403.1 &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x7981;&#x6b62;&#x53ef;&#x6267;&#x884c;&#x8bbf;&#x95ee;"/>
<node COLOR="#111111" CREATED="1474810006965" ID="ID_1983216886" MODIFIED="1474810006965" TEXT="&#x3000;&#x3000;HTTP 403.2 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x7981;&#x6b62;&#x8bfb;&#x8bbf;&#x95ee;"/>
<node COLOR="#111111" CREATED="1474810006965" ID="ID_198868908" MODIFIED="1474810006965" TEXT="&#x3000;&#x3000;HTTP 403.3 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x7981;&#x6b62;&#x5199;&#x8bbf;&#x95ee;"/>
<node COLOR="#111111" CREATED="1474810006996" ID="ID_966425221" MODIFIED="1474810006996" TEXT="&#x3000;&#x3000;HTTP 403.4 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x8981;&#x6c42; SSL"/>
<node COLOR="#111111" CREATED="1474810006996" ID="ID_540355138" MODIFIED="1474810006996" TEXT="&#x3000;&#x3000;HTTP 403.5 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x8981;&#x6c42; SSL 128"/>
<node COLOR="#111111" CREATED="1474810006996" ID="ID_67451868" MODIFIED="1474810006996" TEXT="&#x3000;&#x3000;HTTP 403.6 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;IP &#x5730;&#x5740;&#x88ab;&#x62d2;&#x7edd;"/>
<node COLOR="#111111" CREATED="1474810006996" ID="ID_1875926689" MODIFIED="1474810006996" TEXT="&#x3000;&#x3000;HTTP 403.7 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x8981;&#x6c42;&#x5ba2;&#x6237;&#x8bc1;&#x4e66;"/>
<node COLOR="#111111" CREATED="1474810006996" ID="ID_1590555333" MODIFIED="1474810006996" TEXT="&#x3000;&#x3000;HTTP 403.8 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x7981;&#x6b62;&#x7ad9;&#x70b9;&#x8bbf;&#x95ee;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_622364845" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.9 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x8fde;&#x63a5;&#x7684;&#x7528;&#x6237;&#x8fc7;&#x591a;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_746480182" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.10 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x914d;&#x7f6e;&#x65e0;&#x6548;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_1875479372" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.11 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x5bc6;&#x7801;&#x66f4;&#x6539;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_1135663556" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.12 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x6620;&#x5c04;&#x5668;&#x62d2;&#x7edd;&#x8bbf;&#x95ee;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_371575178" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.13 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x5ba2;&#x6237;&#x8bc1;&#x4e66;&#x5df2;&#x88ab;&#x540a;&#x9500;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_1417491820" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.15 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x5ba2;&#x6237;&#x8bbf;&#x95ee;&#x8bb8;&#x53ef;&#x8fc7;&#x591a;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_370717983" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.16 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x5ba2;&#x6237;&#x8bc1;&#x4e66;&#x4e0d;&#x53ef;&#x4fe1;&#x6216;&#x8005;&#x65e0;&#x6548;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_615204503" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 403.17 - &#x7981;&#x6b62;&#x8bbf;&#x95ee;&#xff1a;&#x5ba2;&#x6237;&#x8bc1;&#x4e66;&#x5df2;&#x7ecf;&#x5230;&#x671f;&#x6216;&#x8005;&#x5c1a;&#x672a;&#x751f;&#x6548;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_1195645716" MODIFIED="1474810007012" TEXT="&#x3000;&#x3000;HTTP 404.1 - &#x65e0;&#x6cd5;&#x627e;&#x5230; Web &#x7ad9;&#x70b9;"/>
<node COLOR="#111111" CREATED="1474810007012" ID="ID_359073297" MODIFIED="1474872172549" TEXT="&#x3000;&#x3000;HTTP 404 - &#x65e0;&#x6cd5;&#x627e;&#x5230;&#x6587;&#x4ef6;">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_1301297533" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 405 - &#x8d44;&#x6e90;&#x88ab;&#x7981;&#x6b62;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_61781921" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 406 - &#x65e0;&#x6cd5;&#x63a5;&#x53d7;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_1135941879" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 407 - &#x8981;&#x6c42;&#x4ee3;&#x7406;&#x8eab;&#x4efd;&#x9a8c;&#x8bc1;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_1506185552" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 410 - &#x6c38;&#x8fdc;&#x4e0d;&#x53ef;&#x7528;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_1874433238" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 412 - &#x5148;&#x51b3;&#x6761;&#x4ef6;&#x5931;&#x8d25;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_1069007190" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 414 - &#x8bf7;&#x6c42; - URI &#x592a;&#x957f;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_348299279" MODIFIED="1474872159221" TEXT="&#x3000;&#x3000;HTTP 500 - &#x5185;&#x90e8;&#x670d;&#x52a1;&#x5668;&#x9519;&#x8bef;">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_195605522" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 500.100 - &#x5185;&#x90e8;&#x670d;&#x52a1;&#x5668;&#x9519;&#x8bef; - ASP &#x9519;&#x8bef;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_1223793021" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 500-11 &#x670d;&#x52a1;&#x5668;&#x5173;&#x95ed;"/>
<node COLOR="#111111" CREATED="1474810007027" ID="ID_1376205163" MODIFIED="1474810007027" TEXT="&#x3000;&#x3000;HTTP 500-12 &#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x91cd;&#x65b0;&#x542f;&#x52a8;"/>
<node COLOR="#111111" CREATED="1474810007043" ID="ID_1452667500" MODIFIED="1474810007043" TEXT="&#x3000;&#x3000;HTTP 500-13 - &#x670d;&#x52a1;&#x5668;&#x592a;&#x5fd9;"/>
<node COLOR="#111111" CREATED="1474810007043" ID="ID_352972608" MODIFIED="1474810007043" TEXT="&#x3000;&#x3000;HTTP 500-14 - &#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x65e0;&#x6548;"/>
<node COLOR="#111111" CREATED="1474810007043" ID="ID_292465426" MODIFIED="1474810007043" TEXT="&#x3000;&#x3000;HTTP 500-15 - &#x4e0d;&#x5141;&#x8bb8;&#x8bf7;&#x6c42; global.asa"/>
<node COLOR="#111111" CREATED="1474810007043" ID="ID_728407907" MODIFIED="1474810007043" TEXT="&#x3000;&#x3000;Error 501 - &#x672a;&#x5b9e;&#x73b0;"/>
<node COLOR="#111111" CREATED="1474810007043" ID="ID_278022977" MODIFIED="1474810007043" TEXT="&#x3000;&#x3000;HTTP 502 - &#x7f51;&#x5173;&#x9519;&#x8bef;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495155180515" FOLDED="true" ID="ID_1131660894" MODIFIED="1529657527964" TEXT="Socket&#x7f16;&#x7a0b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495729503607" FOLDED="true" ID="ID_1750734953" MODIFIED="1529657527963" TEXT="Socket">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495732007907" FOLDED="true" ID="ID_1810898368" MODIFIED="1529657527962" TEXT="?">
<node COLOR="#111111" CREATED="1495732009765" ID="ID_457227632" MODIFIED="1495732014433" TEXT="&#x5957;&#x63a5;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1495730594315" FOLDED="true" ID="ID_512359860" MODIFIED="1529657527962" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495731682941" ID="ID_1176213951" MODIFIED="1495731701952" TEXT="public Socket()"/>
<node COLOR="#111111" CREATED="1495730596839" ID="ID_676393426" MODIFIED="1495731998069" TEXT="public Socket(InetAddress address, int port) throws IOException"/>
<node COLOR="#111111" CREATED="1495730640942" FOLDED="true" ID="ID_869655109" MODIFIED="1529657527962" TEXT="public Socket(InetAddress address, int port, InetAddress localAddr,  int localPort) throws IOException">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495730658356" ID="ID_1502542497" MODIFIED="1495730671108" TEXT="address : &#x670d;&#x52a1;&#x5668;&#x5730;&#x5740;"/>
<node COLOR="#111111" CREATED="1495730675920" ID="ID_1661283608" MODIFIED="1495730708420" TEXT="localAddr :&#x672c;&#x5730;&#x5730;&#x5740;"/>
</node>
<node COLOR="#111111" CREATED="1495730726024" ID="ID_1632954489" MODIFIED="1495730734016">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      public Socket(String host, int port, InetAddress localAddr, int localPort)
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495731499794" FOLDED="true" ID="ID_1285640531" MODIFIED="1529657527963" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495731682946" ID="ID_1157235126" MODIFIED="1495731682946" TEXT="public void connect(SocketAddress endpoint) throws IOException"/>
<node COLOR="#111111" CREATED="1495731682948" ID="ID_1363690162" MODIFIED="1495731682948" TEXT="public void connect(SocketAddress endpoint, int timeout) throws IOException"/>
<node COLOR="#111111" CREATED="1495731682948" ID="ID_1737547599" MODIFIED="1495731682948" TEXT="public void bind(SocketAddress bindpoint) throws IOException"/>
<node COLOR="#111111" CREATED="1495731682950" ID="ID_915568943" MODIFIED="1495731682950" TEXT="public InetAddress getInetAddress()"/>
<node COLOR="#111111" CREATED="1495731682951" ID="ID_622065466" MODIFIED="1495731682951" TEXT="public InetAddress getLocalAddress()"/>
<node COLOR="#111111" CREATED="1495731682952" ID="ID_925050379" MODIFIED="1495731682952" TEXT="public int getPort()"/>
<node COLOR="#111111" CREATED="1495731682953" ID="ID_187312913" MODIFIED="1495731682953" TEXT="public int getLocalPort()"/>
<node COLOR="#111111" CREATED="1495731682953" ID="ID_1541704040" MODIFIED="1495731682954" TEXT="public SocketAddress getRemoteSocketAddress()"/>
<node COLOR="#111111" CREATED="1495731682954" ID="ID_1768078142" MODIFIED="1495731682955" TEXT="public SocketAddress getLocalSocketAddress()"/>
<node COLOR="#111111" CREATED="1495731682956" ID="ID_757121175" MODIFIED="1495731682956" TEXT="public SocketChannel getChannel()"/>
<node COLOR="#111111" CREATED="1495731682957" FOLDED="true" ID="ID_178040263" MODIFIED="1529657527962" TEXT="public InputStream getInputStream() throws IOException">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495731943224" ID="ID_1171515074" MODIFIED="1495731946960" TEXT="&#x83b7;&#x53d6;&#x8f93;&#x5165;&#x6d41;"/>
</node>
<node COLOR="#111111" CREATED="1495731682957" FOLDED="true" ID="ID_1317832912" MODIFIED="1529657527963" TEXT="public OutputStream getOutputStream() throws IOException">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495731949070" ID="ID_1480615488" MODIFIED="1495731953445" TEXT="&#x83b7;&#x53d6;&#x8f93;&#x51fa;&#x6d41;"/>
</node>
<node COLOR="#111111" CREATED="1495731924451" FOLDED="true" ID="ID_1130409963" MODIFIED="1529657527963">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20854;&#20182;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495731682958" ID="ID_115143117" MODIFIED="1495731682958" TEXT="public void setTcpNoDelay(boolean on) throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682960" ID="ID_92839063" MODIFIED="1495731682960" TEXT="public boolean getTcpNoDelay() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682961" ID="ID_1858926045" MODIFIED="1495731682961" TEXT="public void setSoLinger(boolean on, int linger) throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682962" ID="ID_1063554371" MODIFIED="1495731682962" TEXT="public int getSoLinger() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682963" ID="ID_1371331817" MODIFIED="1495731682963" TEXT="public void sendUrgentData (int data) throws IOException"/>
<node COLOR="#111111" CREATED="1495731682963" ID="ID_231913790" MODIFIED="1495731682963" TEXT="public void setOOBInline(boolean on) throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682964" ID="ID_307958004" MODIFIED="1495731682964" TEXT="public boolean getOOBInline() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682965" ID="ID_1967195001" MODIFIED="1495731682965" TEXT="public synchronized void setSoTimeout(int timeout) throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682965" ID="ID_1111163431" MODIFIED="1495731682965" TEXT="public synchronized int getSoTimeout() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682966" ID="ID_1510320957" MODIFIED="1495731682966" TEXT="public synchronized void setSendBufferSize(int size"/>
<node COLOR="#111111" CREATED="1495731682967" ID="ID_373530789" MODIFIED="1495731682967" TEXT="public synchronized int getSendBufferSize() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682967" ID="ID_1276047550" MODIFIED="1495731682967" TEXT="public synchronized void setReceiveBufferSize(int size"/>
<node COLOR="#111111" CREATED="1495731682968" ID="ID_1144581862" MODIFIED="1495731682968" TEXT="public synchronized int getReceiveBufferSize("/>
<node COLOR="#111111" CREATED="1495731682970" ID="ID_1852677741" MODIFIED="1495731682970" TEXT="public void setKeepAlive(boolean on) throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682970" ID="ID_429524118" MODIFIED="1495731682970" TEXT="public boolean getKeepAlive() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682971" ID="ID_437759070" MODIFIED="1495731682972" TEXT="public void setTrafficClass(int tc) throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682974" ID="ID_22052651" MODIFIED="1495731682974" TEXT="public int getTrafficClass() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682975" ID="ID_132133158" MODIFIED="1495731682975" TEXT="public void setReuseAddress(boolean on) throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682976" ID="ID_839163220" MODIFIED="1495731682976" TEXT="public boolean getReuseAddress() throws SocketException"/>
<node COLOR="#111111" CREATED="1495731682977" ID="ID_27811108" MODIFIED="1495731682977" TEXT="public synchronized void close() throws IOException"/>
<node COLOR="#111111" CREATED="1495731682978" ID="ID_395158540" MODIFIED="1495731682979" TEXT="public boolean isConnected()"/>
<node COLOR="#111111" CREATED="1495731682979" ID="ID_1739928298" MODIFIED="1495731682979" TEXT="public boolean isBound()"/>
<node COLOR="#111111" CREATED="1495731682980" ID="ID_1831732913" MODIFIED="1495731682980" TEXT="public boolean isClosed()"/>
<node COLOR="#111111" CREATED="1495731682981" ID="ID_796345670" MODIFIED="1495731682981" TEXT="public boolean isInputShutdown()"/>
<node COLOR="#111111" CREATED="1495731682982" ID="ID_1127384172" MODIFIED="1495731682982" TEXT="public boolean isOutputShutdown()"/>
<node COLOR="#111111" CREATED="1495731682983" ID="ID_1401492611" MODIFIED="1495731906588" TEXT="public static synchronized void setSocketImplFactory(SocketImplFactory fac)"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495729507540" FOLDED="true" ID="ID_1690200500" MODIFIED="1529657527963" TEXT="ServerSocket">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495732113495" FOLDED="true" ID="ID_55736845" MODIFIED="1529657527963">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495732102752" ID="ID_1135778761" MODIFIED="1495732102752" TEXT="public ServerSocket() throws IOException"/>
<node COLOR="#111111" CREATED="1495732102755" ID="ID_988933521" MODIFIED="1495732102756" TEXT="public ServerSocket(int port) throws IOException"/>
<node COLOR="#111111" CREATED="1495732102759" ID="ID_1504136853" MODIFIED="1495732102759" TEXT="public ServerSocket(int port, int backlog) throws IOException"/>
<node COLOR="#111111" CREATED="1495732102761" ID="ID_1954915138" MODIFIED="1495732102761" TEXT="public ServerSocket(int port, int backlog, InetAddress bindAddr) throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495732167122" FOLDED="true" ID="ID_709962018" MODIFIED="1529657527963">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495732102761" ID="ID_175087914" MODIFIED="1495732102761" TEXT="public void bind(SocketAddress endpoint) throws IOException"/>
<node COLOR="#111111" CREATED="1495732102762" ID="ID_57722563" MODIFIED="1495732102762" TEXT="public void bind(SocketAddress endpoint, int backlog) throws IOException"/>
<node COLOR="#111111" CREATED="1495732102763" ID="ID_663843939" MODIFIED="1495732102763" TEXT="public InetAddress getInetAddress()"/>
<node COLOR="#111111" CREATED="1495732102764" ID="ID_193878099" MODIFIED="1495732102764" TEXT="public int getLocalPort()"/>
<node COLOR="#111111" CREATED="1495732102765" ID="ID_76676445" MODIFIED="1495732102765" TEXT="public SocketAddress getLocalSocketAddress()"/>
<node COLOR="#111111" CREATED="1495732102766" ID="ID_1601388493" MODIFIED="1495732184270" TEXT="public Socket accept() throws IOException">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1495732142385" FOLDED="true" ID="ID_394339469" MODIFIED="1529657527963">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20854;&#20182;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495732102767" ID="ID_1281502668" MODIFIED="1495732102767" TEXT="public void close() throws IOException"/>
<node COLOR="#111111" CREATED="1495732102768" ID="ID_1212174587" MODIFIED="1495732102768" TEXT="public ServerSocketChannel getChannel()"/>
<node COLOR="#111111" CREATED="1495732102769" ID="ID_1245817316" MODIFIED="1495732102769" TEXT="public boolean isBound()"/>
<node COLOR="#111111" CREATED="1495732102770" ID="ID_1622831323" MODIFIED="1495732102770" TEXT="public boolean isClosed()"/>
<node COLOR="#111111" CREATED="1495732102771" ID="ID_649867751" MODIFIED="1495732102771" TEXT="public synchronized void setSoTimeout(int timeout) throws SocketException"/>
<node COLOR="#111111" CREATED="1495732102771" ID="ID_172281994" MODIFIED="1495732102772" TEXT="public synchronized int getSoTimeout() throws IOException"/>
<node COLOR="#111111" CREATED="1495732102772" ID="ID_1709780595" MODIFIED="1495732102772" TEXT="public void setReuseAddress(boolean on) throws SocketException"/>
<node COLOR="#111111" CREATED="1495732102773" ID="ID_85162818" MODIFIED="1495732102773" TEXT="public boolean getReuseAddress() throws SocketException"/>
<node COLOR="#111111" CREATED="1495732102773" ID="ID_563307043" MODIFIED="1495732102773" TEXT="public String toString()"/>
<node COLOR="#111111" CREATED="1495732102774" ID="ID_429326446" MODIFIED="1495732102774" TEXT="public static synchronized void setSocketFactory(SocketImplFactory fac) throws IOException"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495731525709" FOLDED="true" ID="ID_634366559" MODIFIED="1529657527964" TEXT="SocketAddress">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495731548160" FOLDED="true" ID="ID_507663256" MODIFIED="1529657527964">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      InetSocketAddress&#23376;&#31867;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495731561436" FOLDED="true" ID="ID_459116042" MODIFIED="1529657527964" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495731562957" ID="ID_1507273548" MODIFIED="1495731562957" TEXT="public InetSocketAddress(int port)"/>
<node COLOR="#111111" CREATED="1495731562958" ID="ID_250640341" MODIFIED="1495731562958" TEXT="public InetSocketAddress(InetAddress addr, int port)"/>
<node COLOR="#111111" CREATED="1495731562962" ID="ID_1552663879" MODIFIED="1495731562962" TEXT="public InetSocketAddress(String hostname, int port)"/>
</node>
<node COLOR="#111111" CREATED="1495731576059" FOLDED="true" ID="ID_1403980294" MODIFIED="1529657527964" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495731577090" ID="ID_167689552" MODIFIED="1495731577090" TEXT="public final int getPort()"/>
<node COLOR="#111111" CREATED="1495731577091" ID="ID_453063153" MODIFIED="1495731577091" TEXT="public final InetAddress getAddress()"/>
<node COLOR="#111111" CREATED="1495731577092" ID="ID_661386493" MODIFIED="1495731577092" TEXT="public final String getHostName()"/>
<node COLOR="#111111" CREATED="1495731577094" ID="ID_456668167" MODIFIED="1495731577094" TEXT="public final String getHostString()"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495732396954" FOLDED="true" ID="ID_1979764733" MODIFIED="1529657527964" TEXT="&#x804a;&#x5929;&#x5ba4;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495732404954" FOLDED="true" ID="ID_426198919" LINK="&#x7f51;&#x7edc;/&#x804a;&#x5929;&#x5ba4;/server/ChatServer.java" MODIFIED="1529657527964" TEXT="ChatServer&#x670d;&#x52a1;&#x5668;">
<node COLOR="#111111" CREATED="1495732673140" ID="ID_758218136" LINK="&#x7f51;&#x7edc;/&#x804a;&#x5929;&#x5ba4;/server/WrapSocket.java" MODIFIED="1495732694497" TEXT="&#x5305;&#x88c5;&#x7684;WrapSocket"/>
</node>
<node COLOR="#111111" CREATED="1495732437293" FOLDED="true" ID="ID_1481909976" LINK="&#x7f51;&#x7edc;/&#x804a;&#x5929;&#x5ba4;/client/Client01.java" MODIFIED="1529657527964" TEXT="Client&#x5ba2;&#x6237;&#x7aef;">
<node COLOR="#111111" CREATED="1495732453098" ID="ID_329965987" LINK="&#x7f51;&#x7edc;/&#x804a;&#x5929;&#x5ba4;/client/ReadTask.java" MODIFIED="1495732649840" TEXT="&#x8bfb;&#x6d88;&#x606f;&#x7684;&#x4efb;&#x52a1;ReadTask"/>
<node COLOR="#111111" CREATED="1495732477373" ID="ID_1580634552" LINK="&#x7f51;&#x7edc;/&#x804a;&#x5929;&#x5ba4;/client/WriteTask.java" MODIFIED="1495732653949" TEXT="&#x63a5;&#x53d7;&#x63a7;&#x5236;&#x53f0;&#x6d88;&#x606f;&#x5e76;&#x5199;&#x51fa;&#x6d88;&#x606f;&#x7684;&#x4efb;&#x52a1;WriteTask"/>
</node>
<node COLOR="#111111" CREATED="1495732604110" ID="ID_565314784" LINK="&#x7f51;&#x7edc;/&#x804a;&#x5929;&#x5ba4;/utils/WorkPool.java" MODIFIED="1495732628733">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22788;&#29702;&#20219;&#21153;&#30340;&#32447;&#31243;&#27744;WorkPool
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495732857946" ID="ID_227045253" LINK="&#x7f51;&#x7edc;/&#x804a;&#x5929;&#x5ba4;/constants/HttpKeys.java" MODIFIED="1495732877482">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24120;&#37327;&#31867;HttpKeys
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1474553092707" FOLDED="true" ID="ID_1845709784" MODIFIED="1529657527969">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32852;&#32593;&#26694;&#26550;android&#30456;&#20851;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1474553100599" FOLDED="true" ID="ID_1249196769" MODIFIED="1529657527967" TEXT="Volley">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1474553403038" FOLDED="true" ID="ID_1186596250" MODIFIED="1529657527964" TEXT="&#x7279;&#x70b9;">
<node COLOR="#111111" CREATED="1474553406543" ID="ID_352774490" MODIFIED="1474553406544" TEXT="&#x9002;&#x7528;&#x4e8e;&#x9891;&#x7e41;&#x8bf7;&#x6c42;&#x800c;&#x6bcf;&#x6b21;&#x8bf7;&#x6c42;&#x6570;&#x636e;&#x91cf;&#x4e0d;&#x4f1a;&#x5f88;&#x5927;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474553406546" ID="ID_918900311" MODIFIED="1474553406547" TEXT="&#x5728;&#x8bf7;&#x6c42;&#x7684;&#x57fa;&#x7840;&#x4e0a;&#x505a;&#x4e86;&#x78c1;&#x76d8;&#x7f13;&#x5b58;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474553406548" ID="ID_1449692718" MODIFIED="1474553406548" TEXT="&#x9632;&#x6b62;&#x591a;&#x6b21;&#x76f8;&#x540c;&#x8bf7;&#x6c42;&#x6d6a;&#x8d39;&#x8d44;&#x6e90;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474553406549" ID="ID_1290877017" MODIFIED="1474553406550" TEXT="&#x63d0;&#x4f9b;String&#x3001;Json&#x3001;&#x56fe;&#x7247;&#x5f02;&#x6b65;&#x4e0b;&#x8f7d;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474553406554" ID="ID_1508625794" MODIFIED="1474553406554" TEXT="&#x7f51;&#x7edc;&#x8bf7;&#x6c42;&#x7684;&#x4f18;&#x5148;&#x7ea7;&#x5904;&#x7406;&#xff1b;"/>
<node COLOR="#111111" CREATED="1474553406555" ID="ID_1880168844" MODIFIED="1474553406556" TEXT="&#x56fe;&#x7247;&#x8bf7;&#x6c42;&#x65e0;&#x9700;&#x62c5;&#x5fc3;&#x751f;&#x547d;&#x5468;&#x671f;&#x95ee;&#x9898;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1474553567461" FOLDED="true" ID="ID_904453989" MODIFIED="1529657527964" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474553571782" ID="ID_1480997544" MODIFIED="1474553574593" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;"/>
</node>
<node COLOR="#111111" CREATED="1474553418764" FOLDED="true" ID="ID_1593965500" MODIFIED="1529657527965" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1474553423222" FOLDED="true" ID="ID_1387348992" MODIFIED="1529657527964" TEXT="&#x5355;&#x4f8b;&#x7684;&#x7c7b;&#x6765;&#x6301;&#x6709;&#x4e00;&#x4e2a;&#xff1a; ">
<node COLOR="#111111" CREATED="1474553443106" ID="ID_812895619" MODIFIED="1474553443107" TEXT="RequestQueue mQueue = Volley.newRequestQueue(context);"/>
</node>
<node COLOR="#111111" CREATED="1474553446565" ID="ID_201424081" MODIFIED="1474553472496" TEXT="&#x901a;&#x8fc7; mQueue.add(request)&#x6765;&#x53d1;&#x9001;&#x8bf7;&#x6c42;"/>
<node COLOR="#111111" CREATED="1474562626857" FOLDED="true" ID="ID_704438026" MODIFIED="1529657527964" TEXT="&#x81ea;&#x5b9a;&#x4e49;&#x4e00;&#x4e2a;Request">
<node COLOR="#111111" CREATED="1474562639653" ID="ID_1230041515" LINK="&#x7f51;&#x7edc;&#x6846;&#x67b6;/Volley/&#x81ea;&#x5b9a;&#x4e49;Request/request/MyRequest.java" MODIFIED="1474562745403" TEXT="&#x9644;&#x4ef6;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474553657818" FOLDED="true" ID="ID_1334783209" MODIFIED="1529657527966" TEXT="&#x6d89;&#x53ca;&#x7684;&#x7c7b;">
<node COLOR="#111111" CREATED="1474553663290" FOLDED="true" ID="ID_1135006063" MODIFIED="1529657527965" TEXT="RequestQueue">
<node COLOR="#111111" CREATED="1474554795879" FOLDED="true" ID="ID_1485057999" MODIFIED="1529657527965" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474554801800" ID="ID_148981263" MODIFIED="1474555595514" TEXT="public RequestQueue(Cache cache, Network network, int threadPoolSize,ResponseDelivery delivery)"/>
<node COLOR="#111111" CREATED="1474554814854" ID="ID_1221220556" MODIFIED="1474554814854" TEXT="public RequestQueue(Cache cache, Network network, int threadPoolSize)"/>
<node COLOR="#111111" CREATED="1474554822917" ID="ID_1442718920" MODIFIED="1474554822918" TEXT="public RequestQueue(Cache cache, Network network)"/>
</node>
<node COLOR="#111111" CREATED="1474554825192" FOLDED="true" ID="ID_1518257195" MODIFIED="1529657527965" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474554841800" ID="ID_1690869712" MODIFIED="1474554841800" TEXT="public &lt;T&gt; Request&lt;T&gt; add(Request&lt;T&gt; request)"/>
<node COLOR="#111111" CREATED="1474555246790" ID="ID_568331543" MODIFIED="1474555246790" TEXT="public void cancelAll(final Object tag)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474555109135" FOLDED="true" ID="ID_780404616" MODIFIED="1529657527966" TEXT="Request">
<node COLOR="#111111" CREATED="1474555129098" FOLDED="true" ID="ID_1124728417" MODIFIED="1529657527966" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1474555143086" FOLDED="true" ID="ID_1311994618" MODIFIED="1529657527966" TEXT="JsonRequest &#x62bd;&#x8c61;&#x7c7b;">
<node COLOR="#111111" CREATED="1474555149218" FOLDED="true" ID="ID_621508649" MODIFIED="1529657527966" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1474555159314" FOLDED="true" ID="ID_782154445" MODIFIED="1529657527965" TEXT="JsonObjectRequest">
<node COLOR="#111111" CREATED="1474556599292" FOLDED="true" ID="ID_1364534341" MODIFIED="1529657527965" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474556602233" ID="ID_1648658432" MODIFIED="1474556608054" TEXT="public JsonObjectRequest(int method, String url, JSONObject jsonRequest,Listener&lt;JSONObject&gt; listener, ErrorListener errorListener) "/>
<node COLOR="#111111" CREATED="1474556622385" ID="ID_1764199215" MODIFIED="1474556627058" TEXT="public JsonObjectRequest(int method, String url, JSONObject jsonRequest,Listener&lt;JSONObject&gt; listener, ErrorListener errorListener) "/>
</node>
</node>
<node COLOR="#111111" CREATED="1474555163896" FOLDED="true" ID="ID_1590053294" MODIFIED="1529657527966" TEXT="JsonArrayRequest">
<node COLOR="#111111" CREATED="1474556080765" FOLDED="true" ID="ID_586534488" MODIFIED="1529657527966" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474556121630" ID="ID_1786479919" MODIFIED="1474556121630" TEXT="public JsonArrayRequest(String url, Listener&lt;JSONArray&gt; listener, ErrorListener errorListener)"/>
<node COLOR="#111111" CREATED="1474556164748" FOLDED="true" ID="ID_1692947671" MODIFIED="1529657527965" TEXT="public JsonArrayRequest(int method, String url, JSONArray jsonRequest,Listener&lt;JSONArray&gt; listener, ErrorListener errorListener)">
<node COLOR="#111111" CREATED="1474556188507" ID="ID_1533828885" MODIFIED="1474556203678" TEXT="jsonRequest&#x6307;&#x7684;&#x662f;&#x8bf7;&#x6c42;&#x7684;&#x53c2;&#x6570;&#x7684;&#x6570;&#x7ec4;"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474555178308" FOLDED="true" ID="ID_325591238" MODIFIED="1529657527966" TEXT="ImageRequest">
<node COLOR="#111111" CREATED="1474556307141" FOLDED="true" ID="ID_431102993" MODIFIED="1529657527966" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474556313173" ID="ID_1329330046" MODIFIED="1474556321268" TEXT="public ImageRequest(String url, Response.Listener&lt;Bitmap&gt; listener, int maxWidth, int maxHeight,Config decodeConfig, Response.ErrorListener errorListener)"/>
<node COLOR="#111111" CREATED="1474556344484" ID="ID_1406392827" MODIFIED="1474556364688" TEXT="public ImageRequest(String url, Response.Listener&lt;Bitmap&gt; listener, int maxWidth, int maxHeight,ScaleType scaleType, Config decodeConfig, Response.ErrorListener errorListener) "/>
<node COLOR="#111111" CREATED="1474556383089" ID="ID_1008507659" MODIFIED="1474556389368" TEXT="public ImageRequest(String url, Response.Listener&lt;Bitmap&gt; listener, int maxWidth, int maxHeight,ScaleType scaleType, Config decodeConfig, Transformation transformation, Response.ErrorListener errorListener) "/>
</node>
<node COLOR="#111111" CREATED="1474567014833" ID="ID_1775664638" LINK="&#x7f51;&#x7edc;&#x6846;&#x67b6;/Volley/&#x81ea;&#x5b9a;&#x4e49;Request/cache/BitmapCache.java" MODIFIED="1474567036497" TEXT="&#x9644;&#x4ef6; BitmapCache"/>
</node>
<node COLOR="#111111" CREATED="1474555184946" FOLDED="true" ID="ID_232943411" MODIFIED="1529657527966" TEXT="StringRequest">
<node COLOR="#111111" CREATED="1474556238154" FOLDED="true" ID="ID_66452210" MODIFIED="1529657527966" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474556240952" ID="ID_460866037" MODIFIED="1474556254108" TEXT="public StringRequest(int method, String url, Listener&lt;String&gt; listener,ErrorListener errorListener)"/>
<node COLOR="#111111" CREATED="1474556267172" ID="ID_1504635095" MODIFIED="1474556267172" TEXT="public StringRequest(String url, Listener&lt;String&gt; listener, ErrorListener errorListener)"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474555290271" FOLDED="true" ID="ID_979719996" MODIFIED="1529657527966" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474555624967" ID="ID_863143929" MODIFIED="1474555624968" TEXT="public Request(int method, String url, Response.ErrorListener listener)"/>
</node>
<node COLOR="#111111" CREATED="1474555640316" FOLDED="true" ID="ID_1605196959" MODIFIED="1529657527966" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474555643992" FOLDED="true" ID="ID_1784464684" MODIFIED="1529657527966" TEXT="public Request&lt;?&gt; setTag(Object tag)">
<node COLOR="#111111" CREATED="1474555647582" ID="ID_377081667" MODIFIED="1474555667551" TEXT="&#x7ed9;request&#x8bbe;&#x7f6e;&#x4e00;&#x4e2a;tag&#xff0c;&#x7528;&#x6765;&#x6807;&#x8bc6;&#x4e00;&#x4e2a;request"/>
</node>
<node COLOR="#111111" CREATED="1474555675426" ID="ID_354887124" MODIFIED="1474555675426" TEXT="public Object getTag()"/>
<node COLOR="#111111" CREATED="1474555749391" FOLDED="true" ID="ID_230271950" MODIFIED="1529657527966" TEXT="public Request&lt;?&gt; setRetryPolicy(RetryPolicy retryPolicy)">
<node COLOR="#111111" CREATED="1474555760764" FOLDED="true" ID="ID_1408668582" MODIFIED="1529657527966" TEXT="RetryPolicy">
<node COLOR="#111111" CREATED="1474555771382" FOLDED="true" ID="ID_1026874181" MODIFIED="1529657527966" TEXT="?">
<node COLOR="#111111" CREATED="1474555774262" ID="ID_328348833" MODIFIED="1474555774262" TEXT="Retry policy for a request."/>
<node COLOR="#111111" CREATED="1474555820384" ID="ID_1231205705" MODIFIED="1474555825578" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1474555846129" ID="ID_1499736174" MODIFIED="1474555863983" TEXT="&#x7528;&#x6765;&#x5b9a;&#x4e49;&#x91cd;&#x8bd5;&#x7684;&#x89c4;&#x5219;"/>
</node>
<node COLOR="#111111" CREATED="1474555826204" FOLDED="true" ID="ID_1200694969" MODIFIED="1529657527966" TEXT="&#x5b9e;&#x73b0;&#x7c7b;">
<node COLOR="#111111" CREATED="1474555831439" ID="ID_1259430146" MODIFIED="1474555831439" TEXT="DefaultRetryPolicy"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474555906143" ID="ID_1549754678" MODIFIED="1474555906143" TEXT="public void cancel()"/>
<node COLOR="#111111" CREATED="1474555915527" ID="ID_1288337180" MODIFIED="1474555915527" TEXT="public boolean isCanceled()"/>
<node COLOR="#111111" CREATED="1474555945661" ID="ID_1845914555" MODIFIED="1474555945664" TEXT="public Map&lt;String, String&gt; getHeaders() throws AuthFailureError"/>
<node COLOR="#111111" CREATED="1474555959398" ID="ID_856365705" MODIFIED="1474555959399" TEXT="public final Request&lt;?&gt; setShouldCache(boolean shouldCache)"/>
<node COLOR="#111111" CREATED="1474555967724" ID="ID_1286530270" MODIFIED="1474555967724" TEXT="public final boolean shouldCache()"/>
<node COLOR="#111111" CREATED="1474555977899" ID="ID_1616768061" MODIFIED="1474555977899" TEXT="public Priority getPriority()"/>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1474553105727" FOLDED="true" ID="ID_1091663347" MODIFIED="1529657527969" TEXT="okHttp">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1474819327366" FOLDED="true" ID="ID_1399044880" MODIFIED="1529657527969" TEXT="&#x6d89;&#x53ca;&#x7684;&#x7c7b;">
<node COLOR="#111111" CREATED="1474819335328" FOLDED="true" ID="ID_1076100574" MODIFIED="1529657527967" TEXT="OkHttpClient">
<node COLOR="#111111" CREATED="1474819435754" FOLDED="true" ID="ID_852786252" MODIFIED="1529657527967" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474819438662" ID="ID_1982090571" MODIFIED="1474819452021" TEXT=" public OkHttpClient() "/>
</node>
<node COLOR="#111111" CREATED="1474819485465" FOLDED="true" ID="ID_108317779" MODIFIED="1529657527967" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474819491031" ID="ID_105898041" MODIFIED="1474819491031" TEXT="public Call newCall(Request request)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474819515516" FOLDED="true" ID="ID_116989584" MODIFIED="1529657527967" TEXT="Request">
<node COLOR="#111111" CREATED="1474819581568" FOLDED="true" ID="ID_607232990" MODIFIED="1529657527967" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474819585743" ID="ID_896132415" MODIFIED="1474819585744" TEXT="public RequestBody body()"/>
</node>
<node COLOR="#111111" CREATED="1474819587042" FOLDED="true" ID="ID_1031658874" MODIFIED="1529657527967" TEXT="&#x6784;&#x9020;">
<node COLOR="#111111" CREATED="1474820542036" ID="ID_1514157006" MODIFIED="1474820554284" TEXT="&#x901a;&#x8fc7;Builder&#x53bb;&#x6784;&#x9020;"/>
</node>
<node COLOR="#111111" CREATED="1474819615692" FOLDED="true" ID="ID_1014474018" MODIFIED="1529657527967" TEXT="&#x5185;&#x90e8;&#x7c7b;Builder">
<node COLOR="#111111" CREATED="1474819634070" FOLDED="true" ID="ID_1964184265" MODIFIED="1529657527967" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1474819636269" ID="ID_872801874" MODIFIED="1474819636270" TEXT="public Builder()"/>
</node>
<node COLOR="#111111" CREATED="1474819702736" FOLDED="true" ID="ID_1430840299" MODIFIED="1529657527967" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474819645245" ID="ID_926285865" MODIFIED="1474819645246" TEXT="public Builder url(HttpUrl url)"/>
<node COLOR="#111111" CREATED="1474819650457" ID="ID_609169850" MODIFIED="1474819650457" TEXT="public Builder url(String url)"/>
<node COLOR="#111111" CREATED="1474819656952" ID="ID_603960860" MODIFIED="1474819656953" TEXT="public Builder url(URL url)"/>
<node COLOR="#111111" CREATED="1474819691658" ID="ID_997300131" MODIFIED="1474819691658" TEXT="public Builder header(String name, String value)"/>
<node COLOR="#111111" CREATED="1474819733711" ID="ID_497235164" MODIFIED="1474819733712" TEXT="public Builder addHeader(String name, String value)"/>
<node COLOR="#111111" CREATED="1474819740279" ID="ID_1679890154" MODIFIED="1474819740279" TEXT="public Builder removeHeader(String name)"/>
<node COLOR="#111111" CREATED="1474819746745" FOLDED="true" ID="ID_1264389032" MODIFIED="1529657527967" TEXT="public Builder headers(Headers headers)">
<node COLOR="#111111" CREATED="1474819751708" ID="ID_1838566996" MODIFIED="1474819754259" TEXT="Headers"/>
</node>
<node COLOR="#111111" CREATED="1474819780684" FOLDED="true" ID="ID_1585037495" MODIFIED="1529657527967" TEXT="public Builder cacheControl(CacheControl cacheControl)">
<node COLOR="#111111" CREATED="1474819785563" ID="ID_1087357049" MODIFIED="1474819785563" TEXT="CacheControl"/>
</node>
<node COLOR="#111111" CREATED="1474819869702" ID="ID_1580283905" MODIFIED="1474819869703" TEXT="public Builder post(RequestBody body)"/>
<node COLOR="#111111" CREATED="1474819877484" ID="ID_1474497691" MODIFIED="1474819877484" TEXT="public Builder delete(RequestBody body)"/>
<node COLOR="#111111" CREATED="1474819891104" ID="ID_251083638" MODIFIED="1474819891104" TEXT="public Builder put(RequestBody body)"/>
<node COLOR="#111111" CREATED="1474819901550" ID="ID_1330973948" MODIFIED="1474819901550" TEXT="public Builder method(String method, RequestBody body)"/>
<node COLOR="#111111" CREATED="1474819911472" ID="ID_405730649" MODIFIED="1474819916688" TEXT="public Request build()">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474819531636" FOLDED="true" ID="ID_84982762" MODIFIED="1529657527968" TEXT="RequestBody">
<node COLOR="#111111" CREATED="1474819940792" FOLDED="true" ID="ID_1441821277" MODIFIED="1529657527967" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1474819946125" FOLDED="true" ID="ID_1383933390" MODIFIED="1529657527967" TEXT="FormBody">
<node COLOR="#111111" CREATED="1474820135024" FOLDED="true" ID="ID_1836411705" MODIFIED="1529657527967" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474820136475" ID="ID_455357572" MODIFIED="1474820136475" TEXT="public void writeTo(BufferedSink sink)"/>
<node COLOR="#111111" CREATED="1474820156682" ID="ID_1774501707" MODIFIED="1474820156682" TEXT="public String name(int index)"/>
<node COLOR="#111111" CREATED="1474820162447" ID="ID_948187865" MODIFIED="1474820162448" TEXT="public String encodedValue(int index)"/>
<node COLOR="#111111" CREATED="1474820167245" ID="ID_827679639" MODIFIED="1474820167245" TEXT="public String value(int index)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474820466498" FOLDED="true" ID="ID_376411803" MODIFIED="1529657527967" TEXT="MultipartBody">
<node COLOR="#111111" CREATED="1474820478268" FOLDED="true" ID="ID_1641413335" MODIFIED="1529657527967" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474820480104" ID="ID_890256569" MODIFIED="1474820480105" TEXT="public MediaType type()"/>
<node COLOR="#111111" CREATED="1474820490075" ID="ID_1685928245" MODIFIED="1474820490075" TEXT="public List&lt;Part&gt; parts()"/>
<node COLOR="#111111" CREATED="1474820497074" ID="ID_1067017552" MODIFIED="1474820497074" TEXT="public String boundary()"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474819962932" FOLDED="true" ID="ID_871415504" MODIFIED="1529657527967" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474819964523" ID="ID_1884094745" MODIFIED="1474819964523" TEXT="public long contentLength()"/>
<node COLOR="#111111" CREATED="1474819996957" ID="ID_1438582711" MODIFIED="1474819996958" TEXT="public static RequestBody create(MediaType contentType, String content)"/>
<node COLOR="#111111" CREATED="1474820037902" ID="ID_1191059315" MODIFIED="1474820037903" TEXT="public static RequestBody create(final MediaType contentType, final byte[] content)"/>
<node COLOR="#111111" CREATED="1474820073904" ID="ID_701339397" MODIFIED="1474820075330" TEXT="public static RequestBody create(final MediaType contentType, final byte[] content,       final int offset, final int byteCount)"/>
<node COLOR="#111111" CREATED="1474820082907" ID="ID_1953146948" MODIFIED="1474820086855" TEXT="public static RequestBody create(final MediaType contentType, final File file)">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474820043367" FOLDED="true" ID="ID_1912227590" MODIFIED="1529657527968" TEXT="&#x6d89;&#x53ca;&#x7684;&#x7c7b;">
<node COLOR="#111111" CREATED="1474820052426" FOLDED="true" ID="ID_1916328204" MODIFIED="1529657527968" TEXT="MediaType">
<node COLOR="#111111" CREATED="1474820429026" FOLDED="true" ID="ID_529615926" MODIFIED="1529657527968" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1474820431651" ID="ID_610172358" MODIFIED="1474820446943" TEXT="&#x591a;&#x5a92;&#x4f53;&#x7684;&#x7c7b;&#x578b;"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474819538008" FOLDED="true" ID="ID_868930667" MODIFIED="1529657527968" TEXT="Call">
<node COLOR="#111111" CREATED="1474820221546" FOLDED="true" ID="ID_1053769151" MODIFIED="1529657527968" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1474820229345" ID="ID_1392690085" MODIFIED="1474820233683" TEXT="&#x4e00;&#x4e2a;&#x63a5;&#x53e3;"/>
</node>
<node COLOR="#111111" CREATED="1474820239360" FOLDED="true" ID="ID_1127264675" MODIFIED="1529657527968" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1474820243596" ID="ID_325783885" MODIFIED="1474820247641" TEXT="RealCall"/>
</node>
<node COLOR="#111111" CREATED="1474820259070" FOLDED="true" ID="ID_1432580859" MODIFIED="1529657527968" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474820260384" ID="ID_1348365108" MODIFIED="1474820270670" TEXT="public void cancel()">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1474820266753" FOLDED="true" ID="ID_1548923788" MODIFIED="1529657527968" TEXT="public void enqueue(Callback responseCallback)">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1474820273828" ID="ID_1616132646" MODIFIED="1474820309161" TEXT="&#x52a0;&#x5165;&#x961f;&#x5217;&#x6267;&#x884c;&#x8bf7;&#x6c42;&#x7684;&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1474820287644" FOLDED="true" ID="ID_1299735043" MODIFIED="1529657527968" TEXT="public Response execute()">
<node COLOR="#111111" CREATED="1474820290531" ID="ID_833999878" MODIFIED="1474820302524" TEXT="&#x6b64;&#x65b9;&#x6cd5;&#x4f1a;&#x7acb;&#x523b;&#x6267;&#x884c;&#x8bf7;&#x6c42;"/>
</node>
<node COLOR="#111111" CREATED="1474820320012" ID="ID_1881306548" MODIFIED="1474820320013" TEXT="public boolean isCanceled()"/>
<node COLOR="#111111" CREATED="1474820325903" ID="ID_1908976365" MODIFIED="1474820325903" TEXT="public synchronized boolean isExecuted()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474819540713" FOLDED="true" ID="ID_889398268" MODIFIED="1529657527968" TEXT="Callback">
<node COLOR="#111111" CREATED="1474820368549" ID="ID_416679299" MODIFIED="1474820380430" TEXT="&#x4e00;&#x4e2a;&#x6267;&#x884c;&#x540e;&#x7684;&#x56de;&#x8c03;&#x63a5;&#x53e3;&#x7c7b;"/>
<node COLOR="#111111" CREATED="1474820384005" FOLDED="true" ID="ID_420600499" MODIFIED="1529657527968" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474820401074" ID="ID_1251015321" MODIFIED="1474820401074" TEXT="void onFailure(Call call, IOException e)"/>
<node COLOR="#111111" CREATED="1474820410768" ID="ID_1029995673" MODIFIED="1474820410769" TEXT="void onResponse(Call call, Response response) throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474820568518" FOLDED="true" ID="ID_1041741977" MODIFIED="1529657527969" TEXT="Response">
<node COLOR="#111111" CREATED="1474820583776" FOLDED="true" ID="ID_109197021" MODIFIED="1529657527969" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474820587550" ID="ID_738073766" MODIFIED="1474820587551" TEXT="public ResponseBody body()"/>
<node COLOR="#111111" CREATED="1474820594047" ID="ID_399388830" MODIFIED="1474820594047" TEXT="public CacheControl cacheControl()"/>
<node COLOR="#111111" CREATED="1474820600210" ID="ID_489320877" MODIFIED="1474820600210" TEXT="public Response cacheResponse()"/>
<node COLOR="#111111" CREATED="1474820616114" ID="ID_1972876671" MODIFIED="1474820616114" TEXT="public void close()"/>
<node COLOR="#111111" CREATED="1474820668797" ID="ID_1620351954" MODIFIED="1474820668798" TEXT="public String header(String name)"/>
<node COLOR="#111111" CREATED="1474820675231" ID="ID_872163853" MODIFIED="1474820675231" TEXT="public String header(String name, String defaultValue)"/>
<node COLOR="#111111" CREATED="1474820681958" ID="ID_835364611" MODIFIED="1474820681959" TEXT="public Headers headers()"/>
<node COLOR="#111111" CREATED="1474820696637" ID="ID_936889213" MODIFIED="1474820696637" TEXT="public List&lt;String&gt; headers(String name)"/>
<node COLOR="#111111" CREATED="1474820705880" ID="ID_551785978" MODIFIED="1474820705880" TEXT="public boolean isSuccessful()"/>
<node COLOR="#111111" CREATED="1474820711811" FOLDED="true" ID="ID_1968447910" MODIFIED="1529657527968" TEXT="public String message()">
<node COLOR="#111111" CREATED="1474820723317" ID="ID_1427486090" MODIFIED="1474820726488" TEXT="&#xff1f;  Returns the HTTP status message or null if it is unknown"/>
</node>
<node COLOR="#111111" CREATED="1474820737169" FOLDED="true" ID="ID_1804559347" MODIFIED="1529657527968" TEXT="public Response networkResponse()">
<node COLOR="#111111" CREATED="1474820746390" FOLDED="true" ID="ID_4129204" MODIFIED="1529657527968" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1474820747967" ID="ID_469468461" MODIFIED="1474820747967" TEXT="Returns the raw response received from the network"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474820757948" ID="ID_558575008" MODIFIED="1474820757948" TEXT="public Builder newBuilder()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1474820835562" FOLDED="true" ID="ID_903879361" MODIFIED="1529657527969" TEXT="ResponseBody">
<node COLOR="#111111" CREATED="1474820861211" ID="ID_157081029" MODIFIED="1474820868323" TEXT="&#xff1f; &#x8fd4;&#x56de;&#x4f53;"/>
<node COLOR="#111111" CREATED="1474820869339" FOLDED="true" ID="ID_649876584" MODIFIED="1529657527969" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1474820879597" FOLDED="true" ID="ID_826066687" MODIFIED="1529657527969" TEXT="RealResponseBody">
<node COLOR="#111111" CREATED="1474820935050" FOLDED="true" ID="ID_520193564" MODIFIED="1529657527969" TEXT="&#x590d;&#x5199;&#x7684;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474820950125" ID="ID_879547919" MODIFIED="1474820953393" TEXT="public  MediaType contentType()"/>
<node COLOR="#111111" CREATED="1474820990869" ID="ID_556763237" MODIFIED="1474821001007" TEXT="public BufferedSource source()"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474820900964" FOLDED="true" ID="ID_1760633550" MODIFIED="1529657527969" TEXT="&#x516c;&#x5171;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1474820902291" ID="ID_671938567" MODIFIED="1474821135960" TEXT="public final byte[] bytes() throws IOException">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1474820908610" ID="ID_483956799" MODIFIED="1474821135959" TEXT="public final InputStream byteStream()">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1474820919331" ID="ID_146006179" MODIFIED="1474820919331" TEXT="public final Reader charStream()"/>
<node COLOR="#111111" CREATED="1474820924345" ID="ID_1213269873" MODIFIED="1474820924346" TEXT="public void close()"/>
<node COLOR="#111111" CREATED="1474820969497" ID="ID_1971565227" MODIFIED="1474820969498" TEXT="public static ResponseBody create(final MediaType contentType, byte[] content)"/>
<node COLOR="#111111" CREATED="1474820983824" ID="ID_1233761731" MODIFIED="1474820983824" TEXT="public static ResponseBody create(MediaType contentType, String content)"/>
<node COLOR="#111111" CREATED="1474821011312" ID="ID_239626123" MODIFIED="1474821011312" TEXT="public final String string() throws IOException"/>
<node COLOR="#111111" CREATED="1474820937211" ID="ID_1415381523" MODIFIED="1474820941590" TEXT="public long contentLength()"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1474821195591" ID="ID_1267758874" LINK="&#x7f51;&#x7edc;&#x6846;&#x67b6;/okHttp/&#x4f7f;&#x7528;.txt" MODIFIED="1474821388155" TEXT="&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#990000" CREATED="1474553111020" FOLDED="true" ID="ID_1873338248" MODIFIED="1529657527969" TEXT="Retrofit">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1474852083242" ID="ID_466624604" MODIFIED="1474852102573" TEXT="&#x8054;&#x5408;okHttp + Gson"/>
<node COLOR="#111111" CREATED="1474852116767" ID="ID_444148700" MODIFIED="1474852132026" TEXT="&#x5982;&#x679c;&#x8981;&#x5904;&#x7406;&#x56fe;&#x7247;&#xff1a;Glide"/>
<node COLOR="#111111" CREATED="1474852136220" ID="ID_1750580905" MODIFIED="1474852141776" TEXT="GreenDao"/>
<node COLOR="#111111" CREATED="1476066723564" ID="ID_1763793351" MODIFIED="1476066727108" TEXT="RxJava"/>
<node COLOR="#111111" CREATED="1476066727644" ID="ID_1382845511" MODIFIED="1476066730934" TEXT="RxAndroid"/>
</node>
<node COLOR="#990000" CREATED="1474553118551" ID="ID_399067183" MODIFIED="1474553132732" TEXT="AsyncHttpClient">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495763184652" ID="ID_176207693" MODIFIED="1495763193610" TEXT="Tcp/IP">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1499485577921" ID="ID_7190914" MODIFIED="1499485587703" POSITION="right" TEXT="&#x5783;&#x573e;&#x56de;&#x6536;GC">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1499924364030" FOLDED="true" ID="ID_1891724206" MODIFIED="1529657528250" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      I/O &#21644;NIO
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1495273127871" FOLDED="true" ID="ID_127568074" MODIFIED="1529657528237" TEXT="NIO">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1508752584359" FOLDED="true" ID="ID_597584077" MODIFIED="1529657527976" TEXT="Pipe">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508752574509" ID="ID_648725528" MODIFIED="1508752732302">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Pipe&#26377;&#19968;&#20010;source&#36890;&#36947;&#21644;&#19968;&#20010;sink&#36890;&#36947;&#12290;<br />&#25968;&#25454;&#20250;&#34987;&#20889;&#21040;sink&#36890;&#36947;&#65292;&#20174;source&#36890;&#36947;&#35835;&#21462;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1508752612312" FOLDED="true" ID="ID_1228314805" MODIFIED="1529657527970" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1508752616261" ID="ID_1306901289" MODIFIED="1508752619196">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="container">
      <div class="line number1 index0 alt2">
        <code class="java keyword">public</code>&#160;<code class="java keyword">static</code>&#160;<code class="java keyword">void</code>&#160;<code class="java plain">method1(){</code>
      </div>
      <div class="line number2 index1 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">Pipe pipe = </code><code class="java keyword">null</code><code class="java plain">;</code>
      </div>
      <div class="line number3 index2 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">ExecutorService exec = Executors.newFixedThreadPool(</code><code class="java value">2</code><code class="java plain">);</code>
      </div>
      <div class="line number4 index3 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">try</code><code class="java plain">{</code>
      </div>
      <div class="line number5 index4 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">pipe = Pipe.open();</code>
      </div>
      <div class="line number6 index5 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">final</code>&#160; <code class="java plain">Pipe pipeTemp = pipe;</code>
      </div>
      <div class="line number7 index6 alt2">
        &#160;
      </div>
      <div class="line number8 index7 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">exec.submit(</code><code class="java keyword">new</code>&#160; <code class="java plain">Callable&lt;Object&gt;(){</code>
      </div>
      <div class="line number9 index8 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java color1">@Override</code>
      </div>
      <div class="line number10 index9 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">public</code>&#160; <code class="java plain">Object call() </code><code class="java keyword">throws</code>&#160;<code class="java plain">Exception</code>
      </div>
      <div class="line number11 index10 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">{</code>
      </div>
      <div class="line number12 index11 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">Pipe.SinkChannel sinkChannel = pipeTemp.sink();</code><code class="java comments">//&#21521;&#36890;&#36947;&#20013;&#20889;&#25968;&#25454;</code>
      </div>
      <div class="line number13 index12 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">while</code><code class="java plain">(</code><code class="java keyword">true</code><code class="java plain">){</code>
      </div>
      <div class="line number14 index13 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">TimeUnit.SECONDS.sleep(</code><code class="java value">1</code><code class="java plain">);</code>
      </div>
      <div class="line number15 index14 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">String newData = </code><code class="java string">&quot;Pipe Test At Time &quot;</code><code class="java plain">+System.currentTimeMillis();</code>
      </div>
      <div class="line number16 index15 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">ByteBuffer buf = ByteBuffer.allocate(</code><code class="java value">1024</code><code class="java plain">);</code>
      </div>
      <div class="line number17 index16 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.clear();</code>
      </div>
      <div class="line number18 index17 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.put(newData.getBytes());</code>
      </div>
      <div class="line number19 index18 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.flip();</code>
      </div>
      <div class="line number20 index19 alt1">
        &#160;
      </div>
      <div class="line number21 index20 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">while</code><code class="java plain">(buf.hasRemaining()){</code>
      </div>
      <div class="line number22 index21 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">System.out.println(buf);</code>
      </div>
      <div class="line number23 index22 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">sinkChannel.write(buf);</code>
      </div>
      <div class="line number24 index23 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number25 index24 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number26 index25 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number27 index26 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">});</code>
      </div>
      <div class="line number28 index27 alt1">
        &#160;
      </div>
      <div class="line number29 index28 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">exec.submit(</code><code class="java keyword">new</code>&#160; <code class="java plain">Callable&lt;Object&gt;(){</code>
      </div>
      <div class="line number30 index29 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java color1">@Override</code>
      </div>
      <div class="line number31 index30 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">public</code>&#160; <code class="java plain">Object call() </code><code class="java keyword">throws</code>&#160;<code class="java plain">Exception</code>
      </div>
      <div class="line number32 index31 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">{</code>
      </div>
      <div class="line number33 index32 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">Pipe.SourceChannel sourceChannel = pipeTemp.source();</code><code class="java comments">//&#21521;&#36890;&#36947;&#20013;&#35835;&#25968;&#25454;</code>
      </div>
      <div class="line number34 index33 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">while</code><code class="java plain">(</code><code class="java keyword">true</code><code class="java plain">){</code>
      </div>
      <div class="line number35 index34 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">TimeUnit.SECONDS.sleep(</code><code class="java value">1</code><code class="java plain">);</code>
      </div>
      <div class="line number36 index35 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">ByteBuffer buf = ByteBuffer.allocate(</code><code class="java value">1024</code><code class="java plain">);</code>
      </div>
      <div class="line number37 index36 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.clear();</code>
      </div>
      <div class="line number38 index37 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">int</code>&#160; <code class="java plain">bytesRead = sourceChannel.read(buf);</code>
      </div>
      <div class="line number39 index38 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">System.out.println(</code><code class="java string">&quot;bytesRead=&quot;</code><code class="java plain">+bytesRead);</code>
      </div>
      <div class="line number40 index39 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">while</code><code class="java plain">(bytesRead &gt;</code><code class="java value">0</code>&#160;<code class="java plain">){</code>
      </div>
      <div class="line number41 index40 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.flip();</code>
      </div>
      <div class="line number42 index41 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">byte</code>&#160; <code class="java plain">b[] = </code><code class="java keyword">new</code>&#160;<code class="java keyword">byte</code><code class="java plain">[bytesRead];</code>
      </div>
      <div class="line number43 index42 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">int</code>&#160; <code class="java plain">i=</code><code class="java value">0</code><code class="java plain">;</code>
      </div>
      <div class="line number44 index43 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">while</code><code class="java plain">(buf.hasRemaining()){</code>
      </div>
      <div class="line number45 index44 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">b[i]=buf.get();</code>
      </div>
      <div class="line number46 index45 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">System.out.printf(</code><code class="java string">&quot;%X&quot;</code><code class="java plain">,b[i]);</code>
      </div>
      <div class="line number47 index46 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">i++;</code>
      </div>
      <div class="line number48 index47 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number49 index48 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">String s = </code><code class="java keyword">new</code>&#160;<code class="java plain">String(b);</code>
      </div>
      <div class="line number50 index49 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">System.out.println(</code><code class="java string">&quot;=================||&quot;</code><code class="java plain">+s);</code>
      </div>
      <div class="line number51 index50 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">bytesRead = sourceChannel.read(buf);</code>
      </div>
      <div class="line number52 index51 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number53 index52 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number54 index53 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number55 index54 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">});</code>
      </div>
      <div class="line number56 index55 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">catch</code><code class="java plain">(IOException e){</code>
      </div>
      <div class="line number57 index56 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">e.printStackTrace();</code>
      </div>
      <div class="line number58 index57 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">finally</code><code class="java plain">{</code>
      </div>
      <div class="line number59 index58 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">exec.shutdown();</code>
      </div>
      <div class="line number60 index59 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number61 index60 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495274425457" ID="ID_1221281778" MODIFIED="1508752753087" TEXT="Files">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495274428726" ID="ID_535896907" MODIFIED="1508752753087" TEXT="Path">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495274432767" ID="ID_896705164" MODIFIED="1508752753088" TEXT="Paths">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495355216833" ID="ID_52660720" MODIFIED="1508752753088" TEXT="FileLock">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495348457151" FOLDED="true" ID="ID_341880626" MODIFIED="1529657527978">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Channel&#25509;&#21475;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495355055294" FOLDED="true" ID="ID_19391019" MODIFIED="1529657527978">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23376;&#31867;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495348463747" FOLDED="true" ID="ID_958069628" MODIFIED="1529657527977">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FileChannel&#25277;&#35937;&#31867;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495348478422" ID="ID_373025963" MODIFIED="1495348479535" TEXT="&#x4ece;&#x6587;&#x4ef6;&#x4e2d;&#x8bfb;&#x5199;&#x6570;&#x636e;&#x3002;"/>
<node COLOR="#111111" CREATED="1495355129330" FOLDED="true" ID="ID_1737327966" LINK="http://ifeve.com/java-nio-scattergather/" MODIFIED="1529657527977">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495355122606" FOLDED="true" ID="ID_662497471" MODIFIED="1529657527976" TEXT="public final long read(ByteBuffer[] dsts) throws IOException">
<node COLOR="#111111" CREATED="1495355506061" ID="ID_1664262311" MODIFIED="1495355506061" TEXT="Scattering Reads"/>
<node COLOR="#111111" CREATED="1495355512373" ID="ID_1934820220" MODIFIED="1495355512374" TEXT="Scattering Reads&#x662f;&#x6307;&#x6570;&#x636e;&#x4ece;&#x4e00;&#x4e2a;channel&#x8bfb;&#x53d6;&#x5230;&#x591a;&#x4e2a;buffer&#x4e2d;&#x3002;&#x5982;&#x4e0b;&#x56fe;&#x63cf;&#x8ff0;&#xff1a;"/>
<node COLOR="#111111" CREATED="1495355591985" FOLDED="true" ID="ID_933839675" LINK="IO/FileChannel/scattering-reads.png" MODIFIED="1529657527976" TEXT="&#x9644;&#x4ef6;">
<node COLOR="#111111" CREATED="1495355899409" ID="ID_207642884" MODIFIED="1495355921931">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ByteBuffer header = ByteBuffer.allocate(128);
    </p>
    <p>
      ByteBuffer body&#160;&#160;&#160;= ByteBuffer.allocate(1024);
    </p>
    <p>
      ByteBuffer[] bufferArray = { header, body };
    </p>
    <p>
      channel.read(bufferArray);
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495355958967" FOLDED="true" ID="ID_1471000371" MODIFIED="1529657527976" TEXT="&#x6ce8;&#x610f;">
<icon BUILTIN="messagebox_warning"/>
<node COLOR="#111111" CREATED="1495355961388" ID="ID_994995367" MODIFIED="1495355966487" TEXT="buffer&#x9996;&#x5148;&#x88ab;&#x63d2;&#x5165;&#x5230;&#x6570;&#x7ec4;&#xff0c;&#x7136;&#x540e;&#x518d;&#x5c06;&#x6570;&#x7ec4;&#x4f5c;&#x4e3a;channel.read() &#x7684;&#x8f93;&#x5165;&#x53c2;&#x6570;&#x3002;read()&#x65b9;&#x6cd5;&#x6309;&#x7167;buffer&#x5728;&#x6570;&#x7ec4;&#x4e2d;&#x7684;&#x987a;&#x5e8f;&#x5c06;&#x4ece;channel&#x4e2d;&#x8bfb;&#x53d6;&#x7684;&#x6570;&#x636e;&#x5199;&#x5165;&#x5230;buffer&#xff0c;&#x5f53;&#x4e00;&#x4e2a;buffer&#x88ab;&#x5199;&#x6ee1;&#x540e;&#xff0c;channel&#x7d27;&#x63a5;&#x7740;&#x5411;&#x53e6;&#x4e00;&#x4e2a;buffer&#x4e2d;&#x5199;&#x3002;"/>
<node COLOR="#111111" CREATED="1495355996404" ID="ID_1504097746" MODIFIED="1495355996406" TEXT="Scattering Reads&#x5728;&#x79fb;&#x52a8;&#x4e0b;&#x4e00;&#x4e2a;buffer&#x524d;&#xff0c;&#x5fc5;&#x987b;&#x586b;&#x6ee1;&#x5f53;&#x524d;&#x7684;buffer&#xff0c;&#x8fd9;&#x4e5f;&#x610f;&#x5473;&#x7740;&#x5b83;&#x4e0d;&#x9002;&#x7528;&#x4e8e;&#x52a8;&#x6001;&#x6d88;&#x606f;(&#x8bd1;&#x8005;&#x6ce8;&#xff1a;&#x6d88;&#x606f;&#x5927;&#x5c0f;&#x4e0d;&#x56fa;&#x5b9a;)&#x3002;&#x6362;&#x53e5;&#x8bdd;&#x8bf4;&#xff0c;&#x5982;&#x679c;&#x5b58;&#x5728;&#x6d88;&#x606f;&#x5934;&#x548c;&#x6d88;&#x606f;&#x4f53;&#xff0c;&#x6d88;&#x606f;&#x5934;&#x5fc5;&#x987b;&#x5b8c;&#x6210;&#x586b;&#x5145;&#xff08;&#x4f8b;&#x5982; 128byte&#xff09;&#xff0c;Scattering Reads&#x624d;&#x80fd;&#x6b63;&#x5e38;&#x5de5;&#x4f5c;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495355122607" FOLDED="true" ID="ID_1745766524" MODIFIED="1529657527977" TEXT="public final long write(ByteBuffer[] srcs) throws IOException">
<node COLOR="#111111" CREATED="1495356022716" ID="ID_950632473" LINK="IO/FileChannel/gathering-writes.png" MODIFIED="1495356205465" TEXT="Gathering Writes"/>
<node COLOR="#111111" CREATED="1495356064709" FOLDED="true" ID="ID_656202498" MODIFIED="1529657527976" TEXT="&#x4ee3;&#x7801;">
<node COLOR="#111111" CREATED="1495356068118" ID="ID_1846590461" MODIFIED="1508743942183">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="line alt1">
      <table>
        <tr>
          <td class="content">
            ByteBuffer header = ByteBuffer.allocate(128);&#160;&#160;<br />ByteBuffer body&#160;&#160;&#160;= ByteBuffer.allocate(1024); &#160;//write data into buffers<br />&#160;ByteBuffer[] bufferArray = { header, body };<br />channel.write(bufferArray);
          </td>
        </tr>
      </table>
    </div>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495356232095" FOLDED="true" ID="ID_459364797" MODIFIED="1529657527976" TEXT="&#x6ce8;&#x610f;">
<node COLOR="#111111" CREATED="1495356238779" ID="ID_1889481155" MODIFIED="1495356238781" TEXT="buffers&#x6570;&#x7ec4;&#x662f;write()&#x65b9;&#x6cd5;&#x7684;&#x5165;&#x53c2;&#xff0c;write()&#x65b9;&#x6cd5;&#x4f1a;&#x6309;&#x7167;buffer&#x5728;&#x6570;&#x7ec4;&#x4e2d;&#x7684;&#x987a;&#x5e8f;&#xff0c;&#x5c06;&#x6570;&#x636e;&#x5199;&#x5165;&#x5230;channel&#xff0c;&#x6ce8;&#x610f;&#x53ea;&#x6709;position&#x548c;limit&#x4e4b;&#x95f4;&#x7684;&#x6570;&#x636e;&#x624d;&#x4f1a;&#x88ab;&#x5199;&#x5165;&#x3002;&#x56e0;&#x6b64;&#xff0c;&#x5982;&#x679c;&#x4e00;&#x4e2a;buffer&#x7684;&#x5bb9;&#x91cf;&#x4e3a;128byte&#xff0c;&#x4f46;&#x662f;&#x4ec5;&#x4ec5;&#x5305;&#x542b;58byte&#x7684;&#x6570;&#x636e;&#xff0c;&#x90a3;&#x4e48;&#x8fd9;58byte&#x7684;&#x6570;&#x636e;&#x5c06;&#x88ab;&#x5199;&#x5165;&#x5230;channel&#x4e2d;&#x3002;&#x56e0;&#x6b64;&#x4e0e;Scattering Reads&#x76f8;&#x53cd;&#xff0c;Gathering Writes&#x80fd;&#x8f83;&#x597d;&#x7684;&#x5904;&#x7406;&#x52a8;&#x6001;&#x6d88;&#x606f;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495355122612" ID="ID_449198066" MODIFIED="1495355122612" TEXT="public final FileLock lock() throws IOException"/>
<node COLOR="#111111" CREATED="1495355122613" ID="ID_1285525450" MODIFIED="1495355122613" TEXT="public final FileLock tryLock() throws IOException"/>
<node COLOR="#111111" CREATED="1495355156137" FOLDED="true" ID="ID_1264584486" MODIFIED="1529657527977">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25277;&#35937;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495355122608" ID="ID_128102885" MODIFIED="1495355122608" TEXT="public abstract long position() throws IOException"/>
<node COLOR="#111111" CREATED="1495355122605" ID="ID_1591364734" MODIFIED="1495355147536" TEXT="public abstract int read(ByteBuffer dst) throws IOException"/>
<node COLOR="#111111" CREATED="1495355122606" ID="ID_282861757" MODIFIED="1495355147534" TEXT="public abstract int write(ByteBuffer src) throws IOException"/>
<node COLOR="#111111" CREATED="1495355122608" ID="ID_695810020" MODIFIED="1495355122608" TEXT="public abstract FileChannel position(long newPosition) throws IOException"/>
<node COLOR="#111111" CREATED="1495355122609" ID="ID_1777436099" MODIFIED="1495355122609" TEXT="public abstract long size() throws IOException"/>
<node COLOR="#111111" CREATED="1495355122609" ID="ID_708771327" MODIFIED="1495355122609" TEXT="public abstract FileChannel truncate(long size) throws IOException"/>
<node COLOR="#111111" CREATED="1495355122610" ID="ID_486310696" MODIFIED="1495355122610" TEXT="public abstract void force(boolean metaData) throws IOException"/>
<node COLOR="#111111" CREATED="1495355122610" ID="ID_316576555" MODIFIED="1495355122611" TEXT="public abstract int read(ByteBuffer dst, long position) throws IOException"/>
<node COLOR="#111111" CREATED="1495355122611" ID="ID_898068574" MODIFIED="1495355122611" TEXT="public abstract int write(ByteBuffer src, long position) throws IOException"/>
<node COLOR="#111111" CREATED="1495356480742" FOLDED="true" ID="ID_565302873" MODIFIED="1529657527977" TEXT="public abstract long transferTo(long position, long count,WritableByteChannel target)  throws IOException">
<node COLOR="#111111" CREATED="1495357092433" ID="ID_494595600" MODIFIED="1495357119657" TEXT="&#x8fde;&#x63a5;fileChannel&#x5230; target&#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1495356531644" FOLDED="true" ID="ID_1719585951" MODIFIED="1529657527977" TEXT="public abstract long transferFrom(ReadableByteChannel src, long position, long count)  throws IOException">
<node COLOR="#111111" CREATED="1495357125843" ID="ID_260634348" MODIFIED="1495357143493" TEXT="&#x8fde;&#x63a5;src&#x5230;fileChannel&#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1508750629196" FOLDED="true" ID="ID_1758362475" MODIFIED="1529657527977" TEXT="    public abstract MappedByteBuffer map(MapMode mode,  long position, long size)         throws IOException">
<node COLOR="#111111" CREATED="1508750669046" FOLDED="true" ID="ID_618813505" MODIFIED="1529657527977" TEXT="MapMode">
<node COLOR="#111111" CREATED="1508750676631" ID="ID_1669698441" MODIFIED="1508750676631" TEXT="READ_ONLY,&#xff08;&#x53ea;&#x8bfb;&#xff09;&#xff1a; &#x8bd5;&#x56fe;&#x4fee;&#x6539;&#x5f97;&#x5230;&#x7684;&#x7f13;&#x51b2;&#x533a;&#x5c06;&#x5bfc;&#x81f4;&#x629b;&#x51fa; ReadOnlyBufferException.(MapMode.READ_ONLY)"/>
<node COLOR="#111111" CREATED="1508750676638" ID="ID_477815816" MODIFIED="1508750676638" TEXT="READ_WRITE&#xff08;&#x8bfb;/&#x5199;&#xff09;&#xff1a; &#x5bf9;&#x5f97;&#x5230;&#x7684;&#x7f13;&#x51b2;&#x533a;&#x7684;&#x66f4;&#x6539;&#x6700;&#x7ec8;&#x5c06;&#x4f20;&#x64ad;&#x5230;&#x6587;&#x4ef6;&#xff1b;&#x8be5;&#x66f4;&#x6539;&#x5bf9;&#x6620;&#x5c04;&#x5230;&#x540c;&#x4e00;&#x6587;&#x4ef6;&#x7684;&#x5176;&#x4ed6;&#x7a0b;&#x5e8f;&#x4e0d;&#x4e00;&#x5b9a;&#x662f;&#x53ef;&#x89c1;&#x7684;&#x3002; (MapMode.READ_WRITE)"/>
<node COLOR="#111111" CREATED="1508750676644" ID="ID_1010642573" MODIFIED="1508750676645" TEXT="PRIVATE&#xff08;&#x4e13;&#x7528;&#xff09;&#xff1a; &#x5bf9;&#x5f97;&#x5230;&#x7684;&#x7f13;&#x51b2;&#x533a;&#x7684;&#x66f4;&#x6539;&#x4e0d;&#x4f1a;&#x4f20;&#x64ad;&#x5230;&#x6587;&#x4ef6;&#xff0c;&#x5e76;&#x4e14;&#x8be5;&#x66f4;&#x6539;&#x5bf9;&#x6620;&#x5c04;&#x5230;&#x540c;&#x4e00;&#x6587;&#x4ef6;&#x7684;&#x5176;&#x4ed6;&#x7a0b;&#x5e8f;&#x4e5f;&#x4e0d;&#x662f;&#x53ef;&#x89c1;&#x7684;&#xff1b;&#x76f8;&#x53cd;&#xff0c;&#x4f1a;&#x521b;&#x5efa;&#x7f13;&#x51b2;&#x533a;&#x5df2;&#x4fee;&#x6539;&#x90e8;&#x5206;&#x7684;&#x4e13;&#x7528;&#x526f;&#x672c;&#x3002; (MapMode.PRIVATE)"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495355178884" FOLDED="true" ID="ID_1939455962" MODIFIED="1529657527977" TEXT="&#x5185;&#x90e8;&#x7c7b;">
<node COLOR="#111111" CREATED="1495355122612" ID="ID_1070198776" MODIFIED="1495355122612" TEXT="public static class MapMode"/>
</node>
<node COLOR="#111111" CREATED="1508744416260" FOLDED="true" ID="ID_33558563" MODIFIED="1529657527977" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1508744422819" FOLDED="true" ID="ID_207529116" MODIFIED="1529657527977" TEXT="&#x8bfb;">
<node COLOR="#111111" CREATED="1508744470183" ID="ID_158717677" MODIFIED="1508744516808">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <div>
      <font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>public</b></font>&#160;<font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>void</b></font>&#160;<font face="Consolas" size="18pt">read()</font>&#160;<font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>throws</b></font>&#160; <font face="Consolas" size="18pt">Exception {</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;//inPath:&#25991;&#20214;&#36335;&#24452;</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;RandomAccessFile</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">file</font><font face="Consolas" size="18pt">=</font>&#160; <font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>new</b></font>&#160;<font face="Consolas" size="18pt">RandomAccessFile(</font><font face="Consolas" color="rgb(0, 0, 192)" size="18pt"><i>inPath</i></font><font face="Consolas" size="18pt">,</font>&#160;<font face="Consolas" color="rgb(42, 0, 255)" size="18pt">&quot;rw&quot;</font><font face="Consolas" size="18pt">);</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;FileChannel</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">channel</font>&#160; <font face="Consolas" size="18pt">=</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">file</font><font face="Consolas" size="18pt">.getChannel();</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;ByteBuffer</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font>&#160; <font face="Consolas" size="18pt">= ByteBuffer.<i>allocate</i>(1024);</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;StringBuffer</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">stringBuffer</font>&#160; <font face="Consolas" size="18pt">=</font>&#160;<font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>new</b></font>&#160;<font face="Consolas" size="18pt">StringBuffer();</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>while</b></font>&#160;<font face="Consolas" size="18pt">(</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">channel</font><font face="Consolas" size="18pt">.read(</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font><font face="Consolas" size="18pt">) != -1) {</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font><font face="Consolas" size="18pt">.flip();</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>while</b></font>&#160; <font face="Consolas" size="18pt">(</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font><font face="Consolas" size="18pt">.hasRemaining()) {</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">stringBuffer</font><font face="Consolas" size="18pt">.append((</font><font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>char</b></font><font face="Consolas" size="18pt">)</font>&#160; <font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font><font face="Consolas" size="18pt">.get());</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font><font face="Consolas" size="18pt">.clear();</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">file</font><font face="Consolas" size="18pt">.close();</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.</font><font face="Consolas" color="rgb(0, 0, 192)" size="18pt"><b><i>out</i></b></font><font face="Consolas" size="18pt">.println(</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">stringBuffer</font><font face="Consolas" size="18pt">.toString());</font>
    </div>
    <div>
      
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;}</font>
    </div>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1508744521970" FOLDED="true" ID="ID_1936319720" MODIFIED="1529657527977" TEXT="&#x5199;">
<node COLOR="#111111" CREATED="1508744563605" ID="ID_1969187244" MODIFIED="1508744565463">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <div>
      <font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>public</b></font>&#160;<font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>void</b></font>&#160;<font face="Consolas" size="18pt">write()</font>&#160;<font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>throws</b></font>&#160; <font face="Consolas" size="18pt">Exception {</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;//</font><font face="Consolas" size="18pt" color="rgb(0, 0, 192)"><i>outPath: &#25991;&#20214;&#36755;&#20837;&#36335;&#24452;</i></font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;FileOutputStream</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">fos</font>&#160; <font face="Consolas" size="18pt">=</font>&#160;<font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>new</b></font>&#160;<font face="Consolas" size="18pt">FileOutputStream(</font><font face="Consolas" color="rgb(0, 0, 192)" size="18pt"><i>outPath</i></font><font face="Consolas" size="18pt">);</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;FileChannel</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">channel</font>&#160; <font face="Consolas" size="18pt">=</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">fos</font><font face="Consolas" size="18pt">.getChannel();</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;ByteBuffer</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font>&#160; <font face="Consolas" size="18pt">= Charset.<i>defaultCharset</i>().encode(</font><font face="Consolas" color="rgb(42, 0, 255)" size="18pt">&quot;&#35831;&#20320;&#20026;&#25105;&#36896;&#28165;&#27905;&#30340;&#24515;,&#20351;&#25105;&#37324;&#38754;&#37325;&#26032;&#26377;&#27491;&#30452;&#30340;&#28789;&quot;</font><font face="Consolas" size="18pt">);</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(127, 0, 85)" size="18pt"><b>int</b></font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">write</font>&#160; <font face="Consolas" size="18pt">=</font>&#160;<font face="Consolas" color="rgb(106, 62, 62)" size="18pt">channel</font><font face="Consolas" size="18pt">.write(</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">buffer</font><font face="Consolas" size="18pt">);</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.</font><font face="Consolas" color="rgb(0, 0, 192)" size="18pt"><b><i>out</i></b></font><font face="Consolas" size="18pt">.println(</font><font face="Consolas" color="rgb(42, 0, 255)" size="18pt">&quot;write: &quot;</font><font face="Consolas" size="18pt">+</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">write</font><font face="Consolas" size="18pt">);</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font face="Consolas" color="rgb(106, 62, 62)" size="18pt">fos</font><font face="Consolas" size="18pt">.close();</font>
    </div>
    <div>
      <font face="Consolas" size="18pt">&#160;&#160;&#160;&#160;}</font>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495348463752" FOLDED="true" ID="ID_1773550910" MODIFIED="1529657527978" TEXT="DatagramChannel ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1508752653881" FOLDED="true" ID="ID_1141177986" MODIFIED="1529657527978">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495348485553" ID="ID_1459650699" MODIFIED="1495348485553" TEXT="&#x80fd;&#x901a;&#x8fc7;UDP&#x8bfb;&#x5199;&#x7f51;&#x7edc;&#x4e2d;&#x7684;&#x6570;&#x636e;&#x3002;"/>
<node COLOR="#111111" CREATED="1508752651296" ID="ID_334770841" MODIFIED="1508752663688" TEXT="Java NIO&#x4e2d;&#x7684;DatagramChannel&#x662f;&#x4e00;&#x4e2a;&#x80fd;&#x6536;&#x53d1;UDP&#x5305;&#x7684;&#x901a;&#x9053;&#x3002;&#xa;&#x56e0;&#x4e3a;UDP&#x662f;&#x65e0;&#x8fde;&#x63a5;&#x7684;&#x7f51;&#x7edc;&#x534f;&#x8bae;&#xff0c;&#x6240;&#x4ee5;&#x4e0d;&#x80fd;&#x50cf;&#x5176;&#x5b83;&#x901a;&#x9053;&#x90a3;&#x6837;&#x8bfb;&#xa;&#x53d6;&#x548c;&#x5199;&#x5165;&#x3002;&#x5b83;&#x53d1;&#x9001;&#x548c;&#x63a5;&#x6536;&#x7684;&#x662f;&#x6570;&#x636e;&#x5305;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1508752676025" FOLDED="true" ID="ID_1133158357" MODIFIED="1529657527978" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1508752681553" ID="ID_1258896158" MODIFIED="1508752683337">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="container">
      <div class="line number1 index0 alt2">
        <code class="java keyword">public</code>&#160;<code class="java keyword">static</code>&#160;<code class="java keyword">void</code>&#160; <code class="java plain">reveive(){</code>
      </div>
      <div class="line number2 index1 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">DatagramChannel channel = </code><code class="java keyword">null</code><code class="java plain">;</code>
      </div>
      <div class="line number3 index2 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">try</code><code class="java plain">{</code>
      </div>
      <div class="line number4 index3 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">channel = DatagramChannel.open();</code>
      </div>
      <div class="line number5 index4 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">channel.socket().bind(</code><code class="java keyword">new</code>&#160; <code class="java plain">InetSocketAddress(</code><code class="java value">8888</code><code class="java plain">));</code>
      </div>
      <div class="line number6 index5 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">ByteBuffer buf = ByteBuffer.allocate(</code><code class="java value">1024</code><code class="java plain">);</code>
      </div>
      <div class="line number7 index6 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.clear();</code>
      </div>
      <div class="line number8 index7 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">channel.receive(buf);</code>
      </div>
      <div class="line number9 index8 alt2">
        &#160;
      </div>
      <div class="line number10 index9 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.flip();</code>
      </div>
      <div class="line number11 index10 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">while</code><code class="java plain">(buf.hasRemaining()){</code>
      </div>
      <div class="line number12 index11 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">System.out.print((</code><code class="java keyword">char</code><code class="java plain">)buf.get());</code>
      </div>
      <div class="line number13 index12 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number14 index13 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">System.out.println();</code>
      </div>
      <div class="line number15 index14 alt2">
        &#160;
      </div>
      <div class="line number16 index15 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">catch</code><code class="java plain">(IOException e){</code>
      </div>
      <div class="line number17 index16 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">e.printStackTrace();</code>
      </div>
      <div class="line number18 index17 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">finally</code><code class="java plain">{</code>
      </div>
      <div class="line number19 index18 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">try</code><code class="java plain">{</code>
      </div>
      <div class="line number20 index19 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">if</code><code class="java plain">(channel!=</code><code class="java keyword">null</code><code class="java plain">){</code>
      </div>
      <div class="line number21 index20 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">channel.close();</code>
      </div>
      <div class="line number22 index21 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number23 index22 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">catch</code><code class="java plain">(IOException e){</code>
      </div>
      <div class="line number24 index23 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">e.printStackTrace();</code>
      </div>
      <div class="line number25 index24 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number26 index25 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number27 index26 alt2">
        <code class="java spaces">&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number28 index27 alt1">
        &#160;
      </div>
      <div class="line number29 index28 alt2">
        <code class="java spaces">&#160;&#160;&#160;</code><code class="java keyword">public</code>&#160;<code class="java keyword">static</code>&#160;<code class="java keyword">void</code>&#160;<code class="java plain">send(){</code>
      </div>
      <div class="line number30 index29 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">DatagramChannel channel = </code><code class="java keyword">null</code><code class="java plain">;</code>
      </div>
      <div class="line number31 index30 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">try</code><code class="java plain">{</code>
      </div>
      <div class="line number32 index31 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">channel = DatagramChannel.open();</code>
      </div>
      <div class="line number33 index32 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">String info = </code><code class="java string">&quot;I'm the Sender!&quot;</code><code class="java plain">;</code>
      </div>
      <div class="line number34 index33 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">ByteBuffer buf = ByteBuffer.allocate(</code><code class="java value">1024</code><code class="java plain">);</code>
      </div>
      <div class="line number35 index34 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.clear();</code>
      </div>
      <div class="line number36 index35 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.put(info.getBytes());</code>
      </div>
      <div class="line number37 index36 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">buf.flip();</code>
      </div>
      <div class="line number38 index37 alt1">
        &#160;
      </div>
      <div class="line number39 index38 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">int</code>&#160; <code class="java plain">bytesSent = channel.send(buf, </code><code class="java keyword">new</code>&#160;<code class="java plain">InetSocketAddress(</code><code class="java string">&quot;10.10.195.115&quot;</code><code class="java plain">,</code><code class="java value">8888</code><code class="java plain">));</code>
      </div>
      <div class="line number40 index39 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">System.out.println(bytesSent);</code>
      </div>
      <div class="line number41 index40 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">catch</code><code class="java plain">(IOException e){</code>
      </div>
      <div class="line number42 index41 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">e.printStackTrace();</code>
      </div>
      <div class="line number43 index42 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">finally</code><code class="java plain">{</code>
      </div>
      <div class="line number44 index43 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">try</code><code class="java plain">{</code>
      </div>
      <div class="line number45 index44 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java keyword">if</code><code class="java plain">(channel!=</code><code class="java keyword">null</code><code class="java plain">){</code>
      </div>
      <div class="line number46 index45 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">channel.close();</code>
      </div>
      <div class="line number47 index46 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number48 index47 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code><code class="java keyword">catch</code><code class="java plain">(IOException e){</code>
      </div>
      <div class="line number49 index48 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">e.printStackTrace();</code>
      </div>
      <div class="line number50 index49 alt1">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number51 index50 alt2">
        <code class="java spaces">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
      <div class="line number52 index51 alt1">
        <code class="java spaces">&#160;&#160;&#160;</code><code class="java plain">}</code>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495348463755" FOLDED="true" ID="ID_1356249327" MODIFIED="1529657527978" TEXT="SocketChannel ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495348488746" ID="ID_1770643579" MODIFIED="1495348488746" TEXT="&#x80fd;&#x901a;&#x8fc7;TCP&#x8bfb;&#x5199;&#x7f51;&#x7edc;&#x4e2d;&#x7684;&#x6570;&#x636e;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495348463757" FOLDED="true" ID="ID_759323221" MODIFIED="1529657527978" TEXT="ServerSocketChannel">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495348528252" ID="ID_1149622355" MODIFIED="1495348528252" TEXT="&#x53ef;&#x4ee5;&#x76d1;&#x542c;&#x65b0;&#x8fdb;&#x6765;&#x7684;TCP&#x8fde;&#x63a5;&#xff0c;&#x50cf;Web&#x670d;&#x52a1;&#x5668;&#x90a3;&#x6837;&#x3002;&#x5bf9;&#x6bcf;&#x4e00;&#x4e2a;&#x65b0;&#x8fdb;&#x6765;&#x7684;&#x8fde;&#x63a5;&#x90fd;&#x4f1a;&#x521b;&#x5efa;&#x4e00;&#x4e2a;SocketChannel&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495355066927" FOLDED="true" ID="ID_992647364" MODIFIED="1529657527978" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495355070170" ID="ID_1826806285" MODIFIED="1495355070170" TEXT="public boolean isOpen();"/>
<node COLOR="#111111" CREATED="1495355076252" ID="ID_958128954" MODIFIED="1495355076252" TEXT="public void close() throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1508744093052" FOLDED="true" ID="ID_373261543" MODIFIED="1529657527978">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1508744079096" ID="ID_189184664" MODIFIED="1508744089929" TEXT="Channel&#x548c;IO&#x4e2d;&#x7684;Stream(&#x6d41;)&#x662f;&#x5dee;&#x4e0d;&#x591a;&#x4e00;&#x4e2a;&#x7b49;&#x7ea7;&#x7684;&#x3002;&#xa;&#x53ea;&#x4e0d;&#x8fc7;Stream&#x662f;&#x5355;&#x5411;&#x7684;&#xff0c;&#x8b6c;&#x5982;&#xff1a;InputStream, OutputStream.&#xa;&#x800c;Channel&#x662f;&#x53cc;&#x5411;&#x7684;&#xff0c;&#x65e2;&#x53ef;&#x4ee5;&#x7528;&#x6765;&#x8fdb;&#x884c;&#x8bfb;&#x64cd;&#x4f5c;&#xff0c;&#x53c8;&#x53ef;&#x4ee5;&#x7528;&#x6765;&#xa;&#x8fdb;&#x884c;&#x5199;&#x64cd;&#x4f5c;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495350935484" FOLDED="true" ID="ID_1752406375" MODIFIED="1529657528223" TEXT="Buffer&#x62bd;&#x8c61;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508744146084" FOLDED="true" ID="ID_1260708620" MODIFIED="1529657527978" TEXT="?">
<node COLOR="#111111" CREATED="1508744152034" ID="ID_182190425" MODIFIED="1508744157806" TEXT="&#x7f13;&#x51b2;&#x533a;"/>
<node COLOR="#111111" CREATED="1508744924348" FOLDED="true" ID="ID_1773244752" MODIFIED="1529657527978" TEXT="Buffer&#x4e00;&#x822c;&#x9075;&#x5faa;&#x4e0b;&#x9762;&#x51e0;&#x4e2a;&#x6b65;&#x9aa4;">
<node COLOR="#111111" CREATED="1508744934935" ID="ID_1637033277" MODIFIED="1508744951275">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20998;&#37197;&#31354;&#38388;&#65288;&#27604;&#22914;: ByteBuffer buf = ByteBuffer.allocate(1024);<br />&#36824;&#26377;&#19968;&#31181;allocateDirector&#21518;&#38754;&#20877;&#38472;&#36848;&#65289;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1508744934937" ID="ID_928274623" MODIFIED="1508744934937" TEXT="&#x5199;&#x5165;&#x6570;&#x636e;&#x5230;Buffer(int bytesRead = fileChannel.read(buf);)"/>
<node COLOR="#111111" CREATED="1508744934939" ID="ID_44071358" MODIFIED="1508744934939" TEXT="&#x8c03;&#x7528;filp()&#x65b9;&#x6cd5;&#xff08; buf.flip();&#xff09;"/>
<node COLOR="#111111" CREATED="1508744934940" ID="ID_1035210033" MODIFIED="1508744934941" TEXT="&#x4ece;Buffer&#x4e2d;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#xff08;System.out.print((char)buf.get());&#xff09;"/>
<node COLOR="#111111" CREATED="1508744934943" ID="ID_5484433" MODIFIED="1508744934943" TEXT="&#x8c03;&#x7528;clear()&#x65b9;&#x6cd5;&#x6216;&#x8005;compact()&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1508745109363" FOLDED="true" ID="ID_196700701" MODIFIED="1529657527978" TEXT="capacity, position, limit, mark">
<node COLOR="#111111" CREATED="1508745097471" ID="ID_894335493" MODIFIED="1508745097471" TEXT="&#x53ef;&#x4ee5;&#x628a;Buffer&#x7b80;&#x5355;&#x5730;&#x7406;&#x89e3;&#x4e3a;&#x4e00;&#x7ec4;&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x7684;&#x5143;&#x7d20;&#x5217;&#x8868;&#xff0c;&#x5b83;&#x901a;&#x8fc7;&#x51e0;&#x4e2a;&#x53d8;&#x91cf;&#x6765;&#x4fdd;&#x5b58;&#x8fd9;&#x4e2a;&#x6570;&#x636e;&#x7684;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#x72b6;&#x6001;&#xff1a;capacity, position, limit, mark&#xff1a;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495350940607" FOLDED="true" ID="ID_713796354" MODIFIED="1529657527979">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20844;&#20849;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495350944550" FOLDED="true" ID="ID_768763883" MODIFIED="1529657527979" TEXT="public final int capacity()">
<node COLOR="#111111" CREATED="1495350998517" ID="ID_601036021" MODIFIED="1495351147489">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    &#20316;&#20026;&#19968;&#20010;&#20869;&#23384;&#22359;&#65292;Buffer&#26377;&#19968;&#20010;&#22266;&#23450;&#30340;&#22823;&#23567;&#20540;&#65292;&#20063;&#21483;&#8220;capacity&#8221;.&#20320;&#21482;&#33021;&#24448;&#37324;&#20889;capacity&#20010;byte&#12289;long&#65292;char&#31561;&#31867;&#22411;&#12290;&#19968;&#26086;Buffer&#28385;&#20102;&#65292;&#38656;&#35201;&#23558;&#20854;&#28165;&#31354;&#65288;&#36890;&#36807;&#35835;&#25968;&#25454;&#25110;&#32773;&#28165;&#38500;&#25968;&#25454;&#65289;&#25165;&#33021;&#32487;&#32493;&#20889;&#25968;&#25454;&#24448;&#37324;&#20889;&#25968;&#25454;&#12290;
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495351018885" ID="ID_16655446" MODIFIED="1495351018885" TEXT="mark &lt;= position &lt;= limit &lt;= capacity"/>
<node COLOR="#111111" CREATED="1495351088557" FOLDED="true" ID="ID_416684691" MODIFIED="1529657527979" TEXT="&#x9644;&#x4ef6;">
<node COLOR="#111111" CREATED="1495351092228" ID="ID_766206692" MODIFIED="1495351092228">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_5919874930508073679.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495350944553" FOLDED="true" ID="ID_228132226" MODIFIED="1529657527979" TEXT="public final int position()">
<node COLOR="#111111" CREATED="1495351237732" FOLDED="true" ID="ID_164327508" MODIFIED="1529657527979">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20889;&#27169;&#24335;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495351173691" ID="ID_1014849223" MODIFIED="1495351173692" TEXT="&#x5f53;&#x4f60;&#x5199;&#x6570;&#x636e;&#x5230;Buffer&#x4e2d;&#x65f6;&#xff0c;position&#x8868;&#x793a;&#x5f53;&#x524d;&#x7684;&#x4f4d;&#x7f6e;&#x3002;&#x521d;&#x59cb;&#x7684;position&#x503c;&#x4e3a;0.&#x5f53;&#x4e00;&#x4e2a;byte&#x3001;long&#x7b49;&#x6570;&#x636e;&#x5199;&#x5230;Buffer&#x540e;&#xff0c; position&#x4f1a;&#x5411;&#x524d;&#x79fb;&#x52a8;&#x5230;&#x4e0b;&#x4e00;&#x4e2a;&#x53ef;&#x63d2;&#x5165;&#x6570;&#x636e;&#x7684;Buffer&#x5355;&#x5143;&#x3002;position&#x6700;&#x5927;&#x53ef;&#x4e3a;capacity &#x2013; 1"/>
</node>
<node COLOR="#111111" CREATED="1495351247185" FOLDED="true" ID="ID_399663480" MODIFIED="1529657527979">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35835;&#27169;&#24335;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495351232798" ID="ID_251827046" MODIFIED="1495351232799" TEXT="&#x5f53;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#x65f6;&#xff0c;&#x4e5f;&#x662f;&#x4ece;&#x67d0;&#x4e2a;&#x7279;&#x5b9a;&#x4f4d;&#x7f6e;&#x8bfb;&#x3002;&#x5f53;&#x5c06;Buffer&#x4ece;&#x5199;&#x6a21;&#x5f0f;&#x5207;&#x6362;&#x5230;&#x8bfb;&#x6a21;&#x5f0f;&#xff0c;position&#x4f1a;&#x88ab;&#x91cd;&#x7f6e;&#x4e3a;0. &#x5f53;&#x4ece;Buffer&#x7684;position&#x5904;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#x65f6;&#xff0c;position&#x5411;&#x524d;&#x79fb;&#x52a8;&#x5230;&#x4e0b;&#x4e00;&#x4e2a;&#x53ef;&#x8bfb;&#x7684;&#x4f4d;&#x7f6e;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495350944554" FOLDED="true" ID="ID_1469855974" MODIFIED="1529657527979" TEXT="public final Buffer position(int newPosition)">
<node COLOR="#111111" CREATED="1495351259534" ID="ID_1682678573" MODIFIED="1495351265368" TEXT="&#x8bbe;&#x7f6e;&#x65b0;&#x7684;position"/>
</node>
<node COLOR="#111111" CREATED="1495350944557" FOLDED="true" ID="ID_128863145" MODIFIED="1529657527979" TEXT="public final int limit()">
<node COLOR="#111111" CREATED="1495351289450" FOLDED="true" ID="ID_368793210" MODIFIED="1529657527979" TEXT="&#x5199;&#x6a21;&#x5f0f;">
<node COLOR="#111111" CREATED="1495351302414" ID="ID_1734862666" MODIFIED="1495351302414" TEXT="&#x5728;&#x5199;&#x6a21;&#x5f0f;&#x4e0b;&#xff0c;Buffer&#x7684;limit&#x8868;&#x793a;&#x4f60;&#x6700;&#x591a;&#x80fd;&#x5f80;Buffer&#x91cc;&#x5199;&#x591a;&#x5c11;&#x6570;&#x636e;&#x3002; &#x5199;&#x6a21;&#x5f0f;&#x4e0b;&#xff0c;limit&#x7b49;&#x4e8e;Buffer&#x7684;capacity&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495351294526" FOLDED="true" ID="ID_1220122251" MODIFIED="1529657527979" TEXT="&#x8bfb;&#x6a21;&#x5f0f;">
<node COLOR="#111111" CREATED="1495351307304" ID="ID_70163433" MODIFIED="1495351307306" TEXT="&#x5f53;&#x5207;&#x6362;Buffer&#x5230;&#x8bfb;&#x6a21;&#x5f0f;&#x65f6;&#xff0c; limit&#x8868;&#x793a;&#x4f60;&#x6700;&#x591a;&#x80fd;&#x8bfb;&#x5230;&#x591a;&#x5c11;&#x6570;&#x636e;&#x3002;&#x56e0;&#x6b64;&#xff0c;&#x5f53;&#x5207;&#x6362;Buffer&#x5230;&#x8bfb;&#x6a21;&#x5f0f;&#x65f6;&#xff0c;limit&#x4f1a;&#x88ab;&#x8bbe;&#x7f6e;&#x6210;&#x5199;&#x6a21;&#x5f0f;&#x4e0b;&#x7684;position&#x503c;&#x3002;&#x6362;&#x53e5;&#x8bdd;&#x8bf4;&#xff0c;&#x4f60;&#x80fd;&#x8bfb;&#x5230;&#x4e4b;&#x524d;&#x5199;&#x5165;&#x7684;&#x6240;&#x6709;&#x6570;&#x636e;&#xff08;limit&#x88ab;&#x8bbe;&#x7f6e;&#x6210;&#x5df2;&#x5199;&#x6570;&#x636e;&#x7684;&#x6570;&#x91cf;&#xff0c;&#x8fd9;&#x4e2a;&#x503c;&#x5728;&#x5199;&#x6a21;&#x5f0f;&#x4e0b;&#x5c31;&#x662f;position&#xff09;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495350944558" ID="ID_1153069928" MODIFIED="1495350944558" TEXT="public final Buffer limit(int newLimit)"/>
<node COLOR="#111111" CREATED="1495350944559" FOLDED="true" ID="ID_657931616" MODIFIED="1529657527979" TEXT="public final Buffer mark()">
<node COLOR="#111111" CREATED="1495354520300" ID="ID_1662618233" MODIFIED="1495354520301" TEXT="&#x901a;&#x8fc7;&#x8c03;&#x7528;Buffer.mark()&#x65b9;&#x6cd5;&#xff0c;&#x53ef;&#x4ee5;&#x6807;&#x8bb0;Buffer&#x4e2d;&#x7684;&#x4e00;&#x4e2a;&#x7279;&#x5b9a;position&#x3002;&#x4e4b;&#x540e;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;&#x8c03;&#x7528;Buffer.reset()&#x65b9;&#x6cd5;&#x6062;&#x590d;&#x5230;&#x8fd9;&#x4e2a;position"/>
</node>
<node COLOR="#111111" CREATED="1495350944560" FOLDED="true" ID="ID_935765458" MODIFIED="1529657527979" TEXT="public final Buffer reset()">
<node COLOR="#111111" CREATED="1495351702690" ID="ID_1026043429" MODIFIED="1495351702690" TEXT="Resets this buffer&apos;s position to the previously-marked position"/>
</node>
<node COLOR="#111111" CREATED="1495350944561" FOLDED="true" ID="ID_1514091860" MODIFIED="1529657527979" TEXT="public final Buffer clear()">
<node COLOR="#111111" CREATED="1495351672958" ID="ID_39665910" MODIFIED="1495354461631" TEXT="&#x6e05;&#x9664;&#x7f13;&#x5b58;"/>
</node>
<node COLOR="#111111" CREATED="1495350944561" FOLDED="true" ID="ID_1779407040" MODIFIED="1529657527979" TEXT="public final Buffer flip()">
<node COLOR="#111111" CREATED="1495351362602" ID="ID_77635028" MODIFIED="1495351371838" TEXT="&#x5207;&#x6362;&#x8bfb;/&#x5199;&#x6a21;&#x5f0f;"/>
<node COLOR="#111111" CREATED="1495351819141" ID="ID_1160110339" MODIFIED="1495351819142" TEXT="&#x8c03;&#x7528;flip()&#x65b9;&#x6cd5;&#x4f1a;&#x5c06;position&#x8bbe;&#x56de;0&#xff0c;&#x5e76;&#x5c06;limit&#x8bbe;&#x7f6e;&#x6210;&#x4e4b;&#x524d;position&#x7684;&#x503c;&#x3002;"/>
<node COLOR="#111111" CREATED="1495351819143" ID="ID_893941137" MODIFIED="1495351819143" TEXT="&#x6362;&#x53e5;&#x8bdd;&#x8bf4;&#xff0c;position&#x73b0;&#x5728;&#x7528;&#x4e8e;&#x6807;&#x8bb0;&#x8bfb;&#x7684;&#x4f4d;&#x7f6e;&#xff0c;limit&#x8868;&#x793a;&#x4e4b;&#x524d;&#x5199;&#x8fdb;&#x4e86;&#x591a;&#x5c11;&#x4e2a;byte&#x3001;char&#x7b49; &#x2014;&#x2014; &#x73b0;&#x5728;&#x80fd;&#x8bfb;&#x53d6;&#x591a;&#x5c11;&#x4e2a;byte&#x3001;char&#x7b49;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495350944562" FOLDED="true" ID="ID_1706120920" MODIFIED="1529657527979" TEXT="public final Buffer rewind()">
<node COLOR="#111111" CREATED="1495351505020" ID="ID_115720815" MODIFIED="1495351518410" TEXT="&#x56de;&#x9000;,The position is set to zero and the mark is discarded."/>
</node>
<node COLOR="#111111" CREATED="1495350944563" FOLDED="true" ID="ID_1414838684" MODIFIED="1529657527979" TEXT="public final int remaining()">
<node COLOR="#111111" CREATED="1495351533197" ID="ID_633652410" MODIFIED="1495351540845" TEXT="Returns the number of elements between the current position and the limit. "/>
<node COLOR="#111111" CREATED="1495351575120" ID="ID_1540571828" MODIFIED="1495351628214" TEXT="&#x8fd4;&#x56de; &gt;=position&#x5230; &lt;=limit&#x4e4b;&#x95f4;&#x8fd8;&#x5269;&#x591a;&#x5c11;&#x6570;&#x636e;"/>
</node>
<node COLOR="#111111" CREATED="1495350944563" FOLDED="true" ID="ID_715648339" MODIFIED="1529657527979" TEXT="public final boolean hasRemaining()">
<node COLOR="#111111" CREATED="1495351631694" ID="ID_531586615" MODIFIED="1495351667104" TEXT="&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#x5230;limit&#x4e4b;&#x95f4;&#x8fd8;&#x6709;&#x6ca1;&#x6709;"/>
</node>
<node COLOR="#111111" CREATED="1495353771910" ID="ID_440115254" MODIFIED="1495353771910" TEXT="public final boolean hasRemaining()"/>
<node COLOR="#111111" CREATED="1495353771911" ID="ID_1309655290" MODIFIED="1495353771911" TEXT="public abstract boolean isReadOnly()"/>
<node COLOR="#111111" CREATED="1495353771912" FOLDED="true" ID="ID_208912824" MODIFIED="1529657527979" TEXT="public abstract boolean hasArray()">
<node COLOR="#111111" CREATED="1495352461269" ID="ID_1895754374" MODIFIED="1495352466550">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Tells whether or not this buffer is backed by an accessible byte array.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495353771916" ID="ID_1948973835" MODIFIED="1495353771916" TEXT="public abstract Object array()"/>
<node COLOR="#111111" CREATED="1495353771917" FOLDED="true" ID="ID_692785550" MODIFIED="1529657527979" TEXT="public abstract int arrayOffset()">
<node COLOR="#111111" CREATED="1495352523308" ID="ID_1457537167" MODIFIED="1495352547343" TEXT="&#x6570;&#x7ec4;&#x504f;&#x79fb;&#x4f4d;&#x7f6e;"/>
</node>
<node COLOR="#111111" CREATED="1495353771918" ID="ID_631870696" MODIFIED="1495353771918" TEXT="public abstract boolean isDirect()"/>
</node>
<node COLOR="#111111" CREATED="1495350946283" FOLDED="true" ID="ID_12662171" MODIFIED="1529657527983" TEXT="&#x5b50;&#x7c7b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495351319489" FOLDED="true" ID="ID_1589150686" MODIFIED="1529657527981" TEXT="ByteBuffer">
<node COLOR="#111111" CREATED="1508750458232" FOLDED="true" ID="ID_206326264" MODIFIED="1529657527980">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495351928002" FOLDED="true" ID="ID_1031120005" MODIFIED="1529657527979" TEXT="public static ByteBuffer allocateDirect(int capacity)">
<node COLOR="#111111" CREATED="1495352183739" ID="ID_30440229" MODIFIED="1495352205065" TEXT="no backing byte  array"/>
</node>
<node COLOR="#111111" CREATED="1495351928004" FOLDED="true" ID="ID_772927167" MODIFIED="1529657527979" TEXT="public static ByteBuffer allocate(int capacity)">
<node COLOR="#111111" CREATED="1495352192176" ID="ID_418351984" MODIFIED="1495352208806" TEXT="has backing byte  array"/>
</node>
<node COLOR="#111111" CREATED="1495351928005" FOLDED="true" ID="ID_1376575481" MODIFIED="1529657527980" TEXT="public static ByteBuffer wrap(byte[] array)">
<node COLOR="#111111" CREATED="1495352227014" ID="ID_1838457855" MODIFIED="1495352227014" TEXT="Wraps a byte array into a buffer."/>
<node COLOR="#111111" CREATED="1495352229986" ID="ID_1992487" MODIFIED="1495352246003" TEXT="&#x5305;&#x88c5;&#x4e00;&#x4e2a;byte&#x6570;&#x7ec4;&#x4e3a;&#x4e00;&#x4e2a;ByteBuffer"/>
</node>
<node COLOR="#111111" CREATED="1495351928006" FOLDED="true" ID="ID_1536783096" MODIFIED="1529657527980" TEXT="public ByteBuffer get(byte[] dst, int offset, int length)">
<node COLOR="#111111" CREATED="1495352264145" ID="ID_297887324" MODIFIED="1495352295966" TEXT="&#x4ece;byte[ ] &#x4e2d;&#x622a;&#x53d6;&#x4e00;&#x6bb5;&#x5305;&#x88c5;&#x4e3a;ByteBuffer"/>
</node>
<node COLOR="#111111" CREATED="1495351928007" ID="ID_1380906945" MODIFIED="1495351928007" TEXT="public ByteBuffer get(byte[] dst)"/>
<node COLOR="#111111" CREATED="1495351928008" FOLDED="true" ID="ID_1566608122" MODIFIED="1529657527980" TEXT="public ByteBuffer put(ByteBuffer src)">
<node COLOR="#111111" CREATED="1495352303134" ID="ID_182048219" MODIFIED="1495352428765" TEXT="&#x628a;&#x53e6;&#x4e00;ByteBuffer&#x6dfb;&#x52a0;&#x5230;&#x4e00;&#x4e2a;ByteBuffer,&#x53ef;&#x4ee5;&#x7528;&#x6765;&#x8fde;&#x63a5;&#x591a;&#x4e2a;ByteBuffer"/>
</node>
<node COLOR="#111111" CREATED="1495351928008" FOLDED="true" ID="ID_223755072" MODIFIED="1529657527980" TEXT="public ByteBuffer put(byte[] src, int offset, int length)">
<node COLOR="#111111" CREATED="1495352380943" ID="ID_876798280" MODIFIED="1495352410821">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25226;byte[ ] &#28155;&#21152;&#21040;ByteBuffer&#20013;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495351928009" ID="ID_1371064230" MODIFIED="1495351928009" TEXT="public final ByteBuffer put(byte[] src)"/>
<node COLOR="#111111" CREATED="1495351928014" ID="ID_1607330426" MODIFIED="1495351928014" TEXT="public int compareTo(ByteBuffer that)"/>
<node COLOR="#111111" CREATED="1495351928014" FOLDED="true" ID="ID_1807316505" MODIFIED="1529657527980" TEXT="public final ByteOrder order()">
<node COLOR="#111111" CREATED="1495352626013" ID="ID_257427822" MODIFIED="1495352628332">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;public final ByteOrder order() {
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;return bigEndian ? ByteOrder.BIG_ENDIAN : ByteOrder.LITTLE_ENDIAN;
    </p>
    <p>
      &#160;&#160;&#160;&#160;}
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495352631820" ID="ID_544896612" MODIFIED="1495352650068" TEXT="&#x5927;&#x7aef;&#x5b57;&#x8282;&#x548c;&#x5c0f;&#x7aef;&#x5b57;&#x8282;"/>
</node>
<node COLOR="#111111" CREATED="1495351928015" FOLDED="true" ID="ID_1386044" MODIFIED="1529657527980" TEXT="public final ByteBuffer order(ByteOrder bo)">
<node COLOR="#111111" CREATED="1495352671471" ID="ID_1483713331" MODIFIED="1495352671471" TEXT="Modifies this buffer&apos;s byte order."/>
</node>
<node COLOR="#111111" CREATED="1495354592323" FOLDED="true" ID="ID_667275550" MODIFIED="1529657527980" TEXT="public boolean equals(Object ob)">
<node COLOR="#111111" CREATED="1495354605171" ID="ID_1662102226" MODIFIED="1495354605171" TEXT="&#x5f53;&#x6ee1;&#x8db3;&#x4e0b;&#x5217;&#x6761;&#x4ef6;&#x65f6;&#xff0c;&#x8868;&#x793a;&#x4e24;&#x4e2a;Buffer&#x76f8;&#x7b49;&#xff1a;"/>
<node COLOR="#111111" CREATED="1495354605172" ID="ID_720149073" MODIFIED="1495354616363" TEXT="1. &#x6709;&#x76f8;&#x540c;&#x7684;&#x7c7b;&#x578b;&#xff08;byte&#x3001;char&#x3001;int&#x7b49;&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1495354605174" ID="ID_1903820223" MODIFIED="1495354620284" TEXT="2. Buffer&#x4e2d;&#x5269;&#x4f59;&#x7684;byte&#x3001;char&#x7b49;&#x7684;&#x4e2a;&#x6570;&#x76f8;&#x7b49;&#x3002;"/>
<node COLOR="#111111" CREATED="1495354605175" ID="ID_1119286963" MODIFIED="1495354624008" TEXT="3. Buffer&#x4e2d;&#x6240;&#x6709;&#x5269;&#x4f59;&#x7684;byte&#x3001;char&#x7b49;&#x90fd;&#x76f8;&#x540c;&#x3002;"/>
<node COLOR="#111111" CREATED="1495354645474" FOLDED="true" ID="ID_792674839" MODIFIED="1529657527980" TEXT="&#x6ce8;&#x610f;">
<icon BUILTIN="messagebox_warning"/>
<node COLOR="#111111" CREATED="1495354648625" ID="ID_1162703904" MODIFIED="1495354648625" TEXT="equals&#x53ea;&#x662f;&#x6bd4;&#x8f83;Buffer&#x7684;&#x4e00;&#x90e8;&#x5206;&#xff0c;&#x4e0d;&#x662f;&#x6bcf;&#x4e00;&#x4e2a;&#x5728;&#x5b83;&#x91cc;&#x9762;&#x7684;&#x5143;&#x7d20;&#x90fd;&#x6bd4;&#x8f83;&#x3002;&#x5b9e;&#x9645;&#x4e0a;&#xff0c;&#x5b83;&#x53ea;&#x6bd4;&#x8f83;Buffer&#x4e2d;&#x7684;&#x5269;&#x4f59;&#x5143;&#x7d20;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495354677188" FOLDED="true" ID="ID_1054251800" MODIFIED="1529657527980" TEXT="public int compareTo(ByteBuffer that)">
<node COLOR="#111111" CREATED="1495354686231" ID="ID_1961673398" MODIFIED="1495354686231" TEXT="compareTo()&#x65b9;&#x6cd5;&#x6bd4;&#x8f83;&#x4e24;&#x4e2a;Buffer&#x7684;&#x5269;&#x4f59;&#x5143;&#x7d20;(byte&#x3001;char&#x7b49;)&#xff0c; &#x5982;&#x679c;&#x6ee1;&#x8db3;&#x4e0b;&#x5217;&#x6761;&#x4ef6;&#xff0c;&#x5219;&#x8ba4;&#x4e3a;&#x4e00;&#x4e2a;Buffer&#x201c;&#x5c0f;&#x4e8e;&#x201d;&#x53e6;&#x4e00;&#x4e2a;Buffer&#xff1a;"/>
<node COLOR="#111111" CREATED="1495354704888" ID="ID_1974319604" MODIFIED="1495354708266" TEXT="1 .&#x7b2c;&#x4e00;&#x4e2a;&#x4e0d;&#x76f8;&#x7b49;&#x7684;&#x5143;&#x7d20;&#x5c0f;&#x4e8e;&#x53e6;&#x4e00;&#x4e2a;Buffer&#x4e2d;&#x5bf9;&#x5e94;&#x7684;&#x5143;&#x7d20; &#x3002;"/>
<node COLOR="#111111" CREATED="1495354704890" ID="ID_524040113" MODIFIED="1495354711883" TEXT="2. &#x6240;&#x6709;&#x5143;&#x7d20;&#x90fd;&#x76f8;&#x7b49;&#xff0c;&#x4f46;&#x7b2c;&#x4e00;&#x4e2a;Buffer&#x6bd4;&#x53e6;&#x4e00;&#x4e2a;&#x5148;&#x8017;&#x5c3d;(&#x7b2c;&#x4e00;&#x4e2a;Buffer&#x7684;&#x5143;&#x7d20;&#x4e2a;&#x6570;&#x6bd4;&#x53e6;&#x4e00;&#x4e2a;&#x5c11;)&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495353331312" FOLDED="true" ID="ID_1543023689" MODIFIED="1529657527980" TEXT="&#x62bd;&#x8c61;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495353344610" FOLDED="true" ID="ID_1134643891" MODIFIED="1529657527980" TEXT="public abstract ByteBuffer slice()">
<node COLOR="#111111" CREATED="1495353565811" ID="ID_710330871" MODIFIED="1495353572474">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Creates a new byte buffer whose content is a shared subsequence of this buffer's content.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495353344610" ID="ID_705547541" MODIFIED="1495353344611" TEXT="public abstract ByteBuffer duplicate()"/>
<node COLOR="#111111" CREATED="1495353344611" ID="ID_1572185367" MODIFIED="1495353344611" TEXT="public abstract ByteBuffer asReadOnlyBuffer()"/>
<node COLOR="#111111" CREATED="1495353344613" ID="ID_1655653366" MODIFIED="1495353344613" TEXT="public abstract byte get()"/>
<node COLOR="#111111" CREATED="1495353344614" ID="ID_727783309" MODIFIED="1495353344614" TEXT="public abstract ByteBuffer put(byte b)"/>
<node COLOR="#111111" CREATED="1495353344614" ID="ID_1764591114" MODIFIED="1495353344614" TEXT="public abstract byte get(int index)"/>
<node COLOR="#111111" CREATED="1495353344615" ID="ID_1320209326" MODIFIED="1495353344615" TEXT="public abstract ByteBuffer put(int index, byte b)"/>
<node COLOR="#111111" CREATED="1495353353829" FOLDED="true" ID="ID_1015743026" MODIFIED="1529657527980" TEXT="public abstract ByteBuffer compact()">
<arrowlink DESTINATION="ID_1514091860" ENDARROW="Default" ENDINCLINATION="749;0;" ID="Arrow_ID_1616981677" STARTARROW="None" STARTINCLINATION="749;0;"/>
<node COLOR="#111111" CREATED="1495354399941" ID="ID_289021324" MODIFIED="1495354399941" TEXT="&#x5982;&#x679c;Buffer&#x4e2d;&#x4ecd;&#x6709;&#x672a;&#x8bfb;&#x7684;&#x6570;&#x636e;&#xff0c;&#x4e14;&#x540e;&#x7eed;&#x8fd8;&#x9700;&#x8981;&#x8fd9;&#x4e9b;&#x6570;&#x636e;&#xff0c;&#x4f46;&#x662f;&#x6b64;&#x65f6;&#x60f3;&#x8981;&#x5148;&#x5148;&#x5199;&#x4e9b;&#x6570;&#x636e;&#xff0c;&#x90a3;&#x4e48;&#x4f7f;&#x7528;compact()&#x65b9;&#x6cd5;&#x3002;"/>
<node COLOR="#111111" CREATED="1495354399944" ID="ID_1286191183" MODIFIED="1495354399945" TEXT="compact()&#x65b9;&#x6cd5;&#x5c06;&#x6240;&#x6709;&#x672a;&#x8bfb;&#x7684;&#x6570;&#x636e;&#x62f7;&#x8d1d;&#x5230;Buffer&#x8d77;&#x59cb;&#x5904;&#x3002;&#x7136;&#x540e;&#x5c06;position&#x8bbe;&#x5230;&#x6700;&#x540e;&#x4e00;&#x4e2a;&#x672a;&#x8bfb;&#x5143;&#x7d20;&#x6b63;&#x540e;&#x9762;&#x3002;limit&#x5c5e;&#x6027;&#x4f9d;&#x7136;&#x50cf;clear()&#x65b9;&#x6cd5;&#x4e00;&#x6837;&#xff0c;&#x8bbe;&#x7f6e;&#x6210;capacity&#x3002;&#x73b0;&#x5728;Buffer&#x51c6;&#x5907;&#x597d;&#x5199;&#x6570;&#x636e;&#x4e86;&#xff0c;&#x4f46;&#x662f;&#x4e0d;&#x4f1a;&#x8986;&#x76d6;&#x672a;&#x8bfb;&#x7684;&#x6570;&#x636e;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495353353830" ID="ID_1773678936" MODIFIED="1495353353830" TEXT="public abstract boolean isDirect()"/>
<node COLOR="#111111" CREATED="1495353363869" ID="ID_1108157091" MODIFIED="1495353363869" TEXT="public abstract char getChar()"/>
<node COLOR="#111111" CREATED="1495353363870" ID="ID_325927762" MODIFIED="1495353363870" TEXT="public abstract ByteBuffer putChar(char value)"/>
<node COLOR="#111111" CREATED="1495353363871" ID="ID_797036689" MODIFIED="1495353363871" TEXT="public abstract char getChar(int index)"/>
<node COLOR="#111111" CREATED="1495353363873" ID="ID_943276205" MODIFIED="1495353363873" TEXT="public abstract ByteBuffer putChar(int index, char value)"/>
<node COLOR="#111111" CREATED="1495353363875" ID="ID_155625816" MODIFIED="1495353363875" TEXT="public abstract CharBuffer asCharBuffer()"/>
<node COLOR="#111111" CREATED="1495353363878" ID="ID_1213057495" MODIFIED="1495353363878" TEXT="public abstract short getShort()"/>
<node COLOR="#111111" CREATED="1495353363879" ID="ID_1177261455" MODIFIED="1495353363879" TEXT="public abstract ByteBuffer putShort(short value)"/>
<node COLOR="#111111" CREATED="1495353363880" ID="ID_1462663358" MODIFIED="1495353363880" TEXT="public abstract short getShort(int index)"/>
<node COLOR="#111111" CREATED="1495353363882" ID="ID_722188753" MODIFIED="1495353363882" TEXT="public abstract ByteBuffer putShort(int index, short value)"/>
<node COLOR="#111111" CREATED="1495353363886" ID="ID_1361845327" MODIFIED="1495353363886" TEXT="public abstract ShortBuffer asShortBuffer()"/>
<node COLOR="#111111" CREATED="1495353363887" ID="ID_441534355" MODIFIED="1495353363887" TEXT="public abstract int getInt()"/>
<node COLOR="#111111" CREATED="1495353363888" ID="ID_511467254" MODIFIED="1495353363888" TEXT="public abstract ByteBuffer putInt(int value)"/>
<node COLOR="#111111" CREATED="1495353363888" ID="ID_1254270192" MODIFIED="1495353363889" TEXT="public abstract int getInt(int index)"/>
<node COLOR="#111111" CREATED="1495353363889" ID="ID_872733072" MODIFIED="1495353363890" TEXT="public abstract ByteBuffer putInt(int index, int value)"/>
<node COLOR="#111111" CREATED="1495353363890" ID="ID_618498235" MODIFIED="1495353363890" TEXT="public abstract IntBuffer asIntBuffer()"/>
<node COLOR="#111111" CREATED="1495353363891" ID="ID_608286514" MODIFIED="1495353363891" TEXT="public abstract long getLong()"/>
<node COLOR="#111111" CREATED="1495353363893" ID="ID_1608044368" MODIFIED="1495353363894" TEXT="public abstract ByteBuffer putLong(long value)"/>
<node COLOR="#111111" CREATED="1495353363895" ID="ID_1558431707" MODIFIED="1495353363895" TEXT="public abstract long getLong(int index)"/>
<node COLOR="#111111" CREATED="1495353363896" ID="ID_625651284" MODIFIED="1495353363897" TEXT="public abstract ByteBuffer putLong(int index, long value)"/>
<node COLOR="#111111" CREATED="1495353363899" ID="ID_1051330056" MODIFIED="1495353363899" TEXT="public abstract LongBuffer asLongBuffer()"/>
<node COLOR="#111111" CREATED="1495353363899" ID="ID_825443360" MODIFIED="1495353363900" TEXT="public abstract float getFloat()"/>
<node COLOR="#111111" CREATED="1495353363900" ID="ID_923040581" MODIFIED="1495353363901" TEXT="public abstract ByteBuffer putFloat(float value)"/>
<node COLOR="#111111" CREATED="1495353363901" ID="ID_317975272" MODIFIED="1495353363901" TEXT="public abstract float getFloat(int index)"/>
<node COLOR="#111111" CREATED="1495353363902" ID="ID_60869354" MODIFIED="1495353363902" TEXT="public abstract ByteBuffer putFloat(int index, float value)"/>
<node COLOR="#111111" CREATED="1495353363903" ID="ID_289330081" MODIFIED="1495353363903" TEXT="public abstract FloatBuffer asFloatBuffer()"/>
<node COLOR="#111111" CREATED="1495353363905" ID="ID_1625675090" MODIFIED="1495353363905" TEXT="public abstract double getDouble()"/>
<node COLOR="#111111" CREATED="1495353363906" ID="ID_1534679968" MODIFIED="1495353363906" TEXT="public abstract ByteBuffer putDouble(double value)"/>
<node COLOR="#111111" CREATED="1495353363907" ID="ID_1204335567" MODIFIED="1495353363907" TEXT="public abstract double getDouble(int index)"/>
<node COLOR="#111111" CREATED="1495353363908" ID="ID_1487631252" MODIFIED="1495353363908" TEXT="public abstract ByteBuffer putDouble(int index, double value)"/>
<node COLOR="#111111" CREATED="1495353363909" ID="ID_75096363" MODIFIED="1495353363909" TEXT="public abstract DoubleBuffer asDoubleBuffer()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1508750467090" FOLDED="true" ID="ID_1721849013" MODIFIED="1529657527981" TEXT="?">
<node COLOR="#111111" CREATED="1508750467963" ID="ID_813229611" MODIFIED="1508750482190" TEXT="ByteBuffer&#x6709;&#x4e24;&#x79cd;&#x6a21;&#x5f0f;:&#x76f4;&#x63a5;/&#x95f4;&#x63a5;.&#xa;&#x95f4;&#x63a5;&#x6a21;&#x5f0f;&#x6700;&#x5178;&#x578b;(&#x4e5f;&#x53ea;&#x6709;&#x8fd9;&#x4e48;&#x4e00;&#x79cd;)&#x7684;&#x5c31;&#x662f;HeapByteBuffer,&#xa;&#x5373;&#x64cd;&#x4f5c;&#x5806;&#x5185;&#x5b58; (byte[]).&#x4f46;&#x662f;&#x5185;&#x5b58;&#x6bd5;&#x7adf;&#x6709;&#x9650;"/>
</node>
<node COLOR="#111111" CREATED="1495353838843" FOLDED="true" ID="ID_27606523" MODIFIED="1529657527981" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1495351319491" FOLDED="true" ID="ID_1625794239" MODIFIED="1529657527981" TEXT="MappedByteBuffer">
<node COLOR="#111111" CREATED="1495354277781" ID="ID_364989393" MODIFIED="1495354277781" TEXT="public final boolean isLoaded()"/>
<node COLOR="#111111" CREATED="1495354277782" ID="ID_1522178510" MODIFIED="1495354277782" TEXT="public final MappedByteBuffer load()"/>
<node COLOR="#111111" CREATED="1495354277783" ID="ID_1415721545" MODIFIED="1495354277783" TEXT="public final MappedByteBuffer force()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1522095611971" FOLDED="true" ID="ID_1557804087" MODIFIED="1529657527981" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1522095628691" FOLDED="true" ID="ID_1373151331" MODIFIED="1529657527981">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20889;&#25991;&#20214;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1522095616655" ID="ID_1893022264" MODIFIED="1522095676009">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 18.0pt"><font color="#000080"><b>void </b></font>write() <font color="#000080"><b>throws </b></font>IOException {<br />    FileOutputStream fos = <font color="#000080"><b>new </b></font>FileOutputStream(<font color="#660e7a"><b>targetPath</b></font>);<br />    FileChannel channel = fos.getChannel();<br />    ByteBuffer buffer = ByteBuffer.<i>allocate</i>(<font color="#0000ff">64</font>);<br /><br />    <font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>i = <font color="#0000ff">0</font>; i &lt; <font color="#0000ff">10</font>; i++) {<br />        buffer.putInt(i);<br />        buffer.put(<font color="#008000"><b>&quot;hello word &quot;</b></font>.getBytes());<br />        buffer.put(<font color="#008000"><b>&quot;</b></font><b><font color="#000080">\r\n</font><font color="#008000">&quot;</font></b>.getBytes());<br />        buffer.flip(); //&#24517;&#39035;&#20889;&#36825;&#37324;<br />        channel.write(buffer);<br />        buffer.clear();<br />    }<br />    fos.flush();<br />    channel.close();<br />    fos.close();<br />    System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;over&quot;</b></font>);<br />}</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1522095642631" FOLDED="true" ID="ID_1536625712" MODIFIED="1529657527981" TEXT="&#x8bfb;&#x6587;&#x4ef6;">
<node COLOR="#111111" CREATED="1522095646642" ID="ID_1397776499" MODIFIED="1522095691241">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 18.0pt"><font color="#000080"><b>void </b></font>read() <font color="#000080"><b>throws </b></font>IOException {<br />    FileInputStream fis = <font color="#000080"><b>new </b></font>FileInputStream(<font color="#660e7a"><b>sourcePath</b></font>);<br />    FileChannel channel = fis.getChannel();<br />    ByteBuffer buffer = ByteBuffer.<i>allocate</i>(<font color="#0000ff">128</font>);<br />    StringBuilder sb = <font color="#000080"><b>new </b></font>StringBuilder();<br />    <font color="#000080"><b>while </b></font>(channel.read(buffer) != -<font color="#0000ff">1</font>) {<br />        buffer.flip();//&#24517;&#39035;&#20889;<br />        System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;position: &quot;</b></font>+buffer.position()+<font color="#008000"><b>&quot;  limit: &quot;</b></font>+buffer.limit()+<font color="#008000"><b>&quot; capacity: &quot;</b></font>+buffer.capacity());<br />        sb.append(<font color="#000080"><b>new </b></font>String(buffer.array()));<br />        buffer.clear();<br />    }<br />    System.<font color="#660e7a"><b><i>out</i></b></font>.println(sb.toString());<br /><br />}</pre>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495351319493" FOLDED="true" ID="ID_65102118" MODIFIED="1529657527982" TEXT="CharBuffer">
<node COLOR="#111111" CREATED="1495354779738" FOLDED="true" ID="ID_1959575551" MODIFIED="1529657527981">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21253;&#35013;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495353894746" ID="ID_577007504" MODIFIED="1495354774418" TEXT="public static CharBuffer wrap(char[] array)"/>
<node COLOR="#111111" CREATED="1495353894748" ID="ID_1682404986" MODIFIED="1495353894748" TEXT="public static CharBuffer wrap(CharSequence csq, int start, int end)"/>
<node COLOR="#111111" CREATED="1495353894749" ID="ID_507682638" MODIFIED="1495353894749" TEXT="public static CharBuffer wrap(CharSequence csq)"/>
</node>
<node COLOR="#111111" CREATED="1495354789015" FOLDED="true" ID="ID_1479825959" MODIFIED="1529657527981">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33719;&#21462;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495353894759" ID="ID_1262460066" MODIFIED="1495353894759" TEXT="public CharBuffer get(char[] dst, int offset, int length)"/>
<node COLOR="#111111" CREATED="1495353894759" ID="ID_714008935" MODIFIED="1495353894760" TEXT="public CharBuffer get(char[] dst)"/>
</node>
<node COLOR="#111111" CREATED="1495354751093" FOLDED="true" ID="ID_1337602136" MODIFIED="1529657527981">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#28155;&#21152;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495353894760" ID="ID_615203345" MODIFIED="1495353894760" TEXT="public CharBuffer put(CharBuffer src)"/>
<node COLOR="#111111" CREATED="1495353894761" ID="ID_1122885231" MODIFIED="1495353894761" TEXT="public CharBuffer put(char[] src, int offset, int length)"/>
<node COLOR="#111111" CREATED="1495353894761" ID="ID_775123560" MODIFIED="1495353894761" TEXT="public final CharBuffer put(char[] src)"/>
<node COLOR="#111111" CREATED="1495353894762" ID="ID_789535497" MODIFIED="1495353894762" TEXT="public CharBuffer put(String src, int start, int end)"/>
</node>
<node COLOR="#111111" CREATED="1495354812036" FOLDED="true" ID="ID_774641699" MODIFIED="1529657527981">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20854;&#20182;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495353894744" ID="ID_49450993" MODIFIED="1495354808973" TEXT="public static CharBuffer allocate(int capacity)"/>
<node COLOR="#111111" CREATED="1495353894747" ID="ID_1363940201" MODIFIED="1495354808970" TEXT="public int read(CharBuffer target) throws IOException"/>
<node COLOR="#111111" CREATED="1495353894762" ID="ID_1591829417" MODIFIED="1495353894762" TEXT="public final CharBuffer put(String src)"/>
<node COLOR="#111111" CREATED="1495353894771" ID="ID_480372130" MODIFIED="1495353952953" TEXT="public final int length()"/>
<node COLOR="#111111" CREATED="1495353894772" ID="ID_123285123" MODIFIED="1495353952955" TEXT="public final char charAt(int index)"/>
<node COLOR="#111111" CREATED="1495353894781" ID="ID_1212441246" MODIFIED="1495354801589" TEXT="public IntStream chars()"/>
</node>
<node COLOR="#111111" CREATED="1495354739828" FOLDED="true" ID="ID_419223258" MODIFIED="1529657527981">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36861;&#21152;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495353894779" ID="ID_812594598" MODIFIED="1495353952956" TEXT="public CharBuffer append(CharSequence csq)"/>
<node COLOR="#111111" CREATED="1495353894780" ID="ID_1806700561" MODIFIED="1495353952958" TEXT="public CharBuffer append(CharSequence csq, int start, int end)"/>
<node COLOR="#111111" CREATED="1495353894780" ID="ID_615466571" MODIFIED="1495353952959" TEXT="public CharBuffer append(char c)"/>
</node>
<node COLOR="#111111" CREATED="1495353930556" FOLDED="true" ID="ID_1250022645" MODIFIED="1529657527982">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25277;&#35937;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495353894750" ID="ID_919766642" MODIFIED="1495353894750" TEXT="public abstract CharBuffer slice()"/>
<node COLOR="#111111" CREATED="1495353894751" ID="ID_1897656553" MODIFIED="1495353894751" TEXT="public abstract CharBuffer duplicate()"/>
<node COLOR="#111111" CREATED="1495353894752" ID="ID_643835185" MODIFIED="1495353894752" TEXT="public abstract CharBuffer asReadOnlyBuffer()"/>
<node COLOR="#111111" CREATED="1495353894753" ID="ID_19030280" MODIFIED="1495353894753" TEXT="public abstract char get()"/>
<node COLOR="#111111" CREATED="1495353894753" ID="ID_1077638804" MODIFIED="1495353894754" TEXT="public abstract CharBuffer put(char c)"/>
<node COLOR="#111111" CREATED="1495353894756" ID="ID_1642924680" MODIFIED="1495353894756" TEXT="public abstract char get(int index)"/>
<node COLOR="#111111" CREATED="1495353894758" ID="ID_1703057506" MODIFIED="1495353894758" TEXT="public abstract CharBuffer put(int index, char c)"/>
<node COLOR="#111111" CREATED="1495353894766" ID="ID_751430446" MODIFIED="1495353917198" TEXT="public abstract CharBuffer compact()"/>
<node COLOR="#111111" CREATED="1495353894767" ID="ID_93945275" MODIFIED="1495353917199" TEXT="public abstract boolean isDirect()"/>
<node COLOR="#111111" CREATED="1495353894773" ID="ID_1650700053" MODIFIED="1495353917200" TEXT="public abstract CharBuffer subSequence(int start, int end)"/>
<node COLOR="#111111" CREATED="1495353894781" ID="ID_1395143373" MODIFIED="1495353917201" TEXT="public abstract ByteOrder order()"/>
<node COLOR="#111111" CREATED="1495353127086" ID="ID_1282906436" MODIFIED="1495353127086" TEXT="abstract char getUnchecked(int index)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495351319493" ID="ID_65222736" MODIFIED="1495351319493" TEXT="DoubleBuffer"/>
<node COLOR="#111111" CREATED="1495351319494" FOLDED="true" ID="ID_1618309322" MODIFIED="1529657527982" TEXT="FloatBuffer">
<node COLOR="#111111" CREATED="1495354069299" ID="ID_1542751603" MODIFIED="1495354069299" TEXT="public static DoubleBuffer allocate(int capacity)"/>
<node COLOR="#111111" CREATED="1495354069300" ID="ID_15971246" MODIFIED="1495354069300" TEXT="public static DoubleBuffer wrap(double[] array)"/>
<node COLOR="#111111" CREATED="1495354069308" ID="ID_1946067863" MODIFIED="1495354069308" TEXT="public DoubleBuffer get(double[] dst, int offset, int length)"/>
<node COLOR="#111111" CREATED="1495354069311" ID="ID_937305596" MODIFIED="1495354069311" TEXT="public DoubleBuffer get(double[] dst)"/>
<node COLOR="#111111" CREATED="1495354069313" ID="ID_626963602" MODIFIED="1495354069313" TEXT="public DoubleBuffer put(DoubleBuffer src)"/>
<node COLOR="#111111" CREATED="1495354069315" ID="ID_233059057" MODIFIED="1495354069315" TEXT="public DoubleBuffer put(double[] src, int offset, int length)"/>
<node COLOR="#111111" CREATED="1495354069316" ID="ID_1141822964" MODIFIED="1495354069316" TEXT="public final DoubleBuffer put(double[] src)"/>
<node COLOR="#111111" CREATED="1495354069324" ID="ID_687481775" MODIFIED="1495354069324" TEXT="public final int arrayOffset()"/>
<node COLOR="#111111" CREATED="1495354166893" FOLDED="true" ID="ID_1464259204" MODIFIED="1529657527982">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25277;&#35937;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495354069301" ID="ID_1329706602" MODIFIED="1495354164242" TEXT="public abstract DoubleBuffer slice()"/>
<node COLOR="#111111" CREATED="1495354069302" ID="ID_668692364" MODIFIED="1495354164241" TEXT="public abstract DoubleBuffer duplicate()"/>
<node COLOR="#111111" CREATED="1495354069303" ID="ID_83505011" MODIFIED="1495354164239" TEXT="public abstract DoubleBuffer asReadOnlyBuffer()"/>
<node COLOR="#111111" CREATED="1495354069304" ID="ID_1300062412" MODIFIED="1495354164238" TEXT="public abstract double get()"/>
<node COLOR="#111111" CREATED="1495354069305" ID="ID_1131582163" MODIFIED="1495354164236" TEXT="public abstract DoubleBuffer put(double d)"/>
<node COLOR="#111111" CREATED="1495354069307" ID="ID_869798951" MODIFIED="1495354164235" TEXT="public abstract double get(int index)"/>
<node COLOR="#111111" CREATED="1495354069307" ID="ID_439047283" MODIFIED="1495354164233" TEXT="public abstract DoubleBuffer put(int index, double d)"/>
<node COLOR="#111111" CREATED="1495354069325" ID="ID_1593704740" MODIFIED="1495354069325" TEXT="public abstract DoubleBuffer compact()"/>
<node COLOR="#111111" CREATED="1495354069326" ID="ID_1977688608" MODIFIED="1495354069326" TEXT="public abstract boolean isDirect()"/>
<node COLOR="#111111" CREATED="1495354069330" ID="ID_663413686" MODIFIED="1495354069330" TEXT="public abstract ByteOrder order()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495351319494" FOLDED="true" ID="ID_1656044725" MODIFIED="1529657527982" TEXT="IntBuffer">
<node COLOR="#111111" CREATED="1495354223352" ID="ID_1313705230" MODIFIED="1495354227523" TEXT="&#x96f7;&#x540c;"/>
</node>
<node COLOR="#111111" CREATED="1495351319495" FOLDED="true" ID="ID_672114827" MODIFIED="1529657527982" TEXT="LongBuffer">
<node COLOR="#111111" CREATED="1495354223352" ID="ID_218501656" MODIFIED="1495354227523" TEXT="&#x96f7;&#x540c;"/>
</node>
<node COLOR="#111111" CREATED="1495351319496" FOLDED="true" ID="ID_809067698" MODIFIED="1529657527982" TEXT="ShortBuffer">
<node COLOR="#111111" CREATED="1495354223352" ID="ID_1946580582" MODIFIED="1495354227523" TEXT="&#x96f7;&#x540c;"/>
</node>
<node COLOR="#111111" CREATED="1508750348799" FOLDED="true" ID="ID_733918890" MODIFIED="1529657527982" TEXT="MappedByteBuffer">
<node COLOR="#111111" CREATED="1508750400257" FOLDED="true" ID="ID_1618227983" MODIFIED="1529657527982">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1508750390525" ID="ID_1261383096" MODIFIED="1508750522523" TEXT="&#x662f;NIO&#x5f15;&#x5165;&#x7684;&#x6587;&#x4ef6;&#x5185;&#x5b58;&#x6620;&#x5c04;&#x65b9;&#x6848;&#xff0c;&#x8bfb;&#x5199;&#x6027;&#x80fd;&#x6781;&#x9ad8;&#x3002;&#xa;NIO&#x6700;&#x4e3b;&#x8981;&#x7684;&#x5c31;&#x662f;&#x5b9e;&#x73b0;&#x4e86;&#x5bf9;&#x5f02;&#x6b65;&#x64cd;&#x4f5c;&#x7684;&#x652f;&#x6301;&#x3002;&#xa;&#x5176;&#x4e2d;&#x4e00;&#x79cd;&#x901a;&#x8fc7;&#x628a;&#x4e00;&#x4e2a;&#x5957;&#x63a5;&#x5b57;&#x901a;&#x9053;(SocketChannel)&#xa;&#x6ce8;&#x518c;&#x5230;&#x4e00;&#x4e2a;&#x9009;&#x62e9;&#x5668;(Selector)&#x4e2d;,&#x4e0d;&#x65f6;&#x8c03;&#x7528;&#x540e;&#x8005;&#x7684;&#x9009;&#x62e9;&#xa;(select)&#x65b9;&#x6cd5;&#x5c31;&#x80fd;&#x8fd4;&#x56de;&#x6ee1;&#x8db3;&#x7684;&#x9009;&#x62e9;&#x952e;(SelectionKey),&#xa;&#x952e;&#x4e2d;&#x5305;&#x542b;&#x4e86;SOCKET&#x4e8b;&#x4ef6;&#x4fe1;&#x606f;&#x3002;&#x8fd9;&#x5c31;&#x662f;select&#x6a21;&#x578b;"/>
</node>
<node COLOR="#111111" CREATED="1508751258290" FOLDED="true" ID="ID_546349698" MODIFIED="1529657527982" TEXT="&#x6ce8;&#x610f;">
<node COLOR="#111111" CREATED="1508751262769" ID="ID_1261419982" MODIFIED="1508751276586" TEXT="&#x6ce8;&#xff1a;MappedByteBuffer&#x6709;&#x8d44;&#x6e90;&#x91ca;&#x653e;&#x7684;&#x95ee;&#x9898;&#xff1a;&#xa;&#x88ab;MappedByteBuffer&#x6253;&#x5f00;&#x7684;&#x6587;&#x4ef6;&#x53ea;&#x6709;&#x5728;&#x5783;&#x573e;&#xa;&#x6536;&#x96c6;&#x65f6;&#x624d;&#x4f1a;&#x88ab;&#x5173;&#x95ed;&#xff0c;&#x800c;&#x8fd9;&#x4e2a;&#x70b9;&#x662f;&#x4e0d;&#x786e;&#x5b9a;&#x7684;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1508750342766" FOLDED="true" ID="ID_1278703784" MODIFIED="1529657527982" TEXT="&#x5185;&#x5b58;&#x6620;&#x5c04;&#x6587;&#x4ef6;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1508750501728" ID="ID_455107693" MODIFIED="1508751269849">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    ByteBuffer&#26377;&#20004;&#31181;&#27169;&#24335;:&#30452;&#25509;/&#38388;&#25509;.&#38388;&#25509;&#27169;&#24335;&#26368;

    <p>
      <br />
      &#20856;&#22411;(&#20063;&#21482;&#26377;&#36825;&#20040;&#19968;&#31181;)&#30340;&#23601;&#26159;HeapByteBuffer,<br />&#21363;&#25805;&#20316;&#22534;&#20869;&#23384; (byte[]).&#20294;&#26159;&#20869;&#23384;&#27605;&#31455;&#26377;&#38480;,&#22914;&#26524;<br />&#25105;&#35201;&#21457;&#36865;&#19968;&#20010;1G&#30340;&#25991;&#20214;&#24590;&#20040;&#21150;?&#19981;&#21487;&#33021;&#30495;&#30340;&#21435;<br />&#20998;&#37197;1G&#30340;&#20869;&#23384;.&#36825;&#26102;&#23601;&#24517;&#39035;&#20351;&#29992;&#8221;&#30452;&#25509;&#8221;&#27169;&#24335;,&#21363;<br />&#160;MappedByteBuffer,&#25991;&#20214;&#26144;&#23556;.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1508750976380" FOLDED="true" ID="ID_130352409" MODIFIED="1529657527982" TEXT="&#x8303;&#x4f8b;">
<node BACKGROUND_COLOR="#cccccc" COLOR="#111111" CREATED="1508750978764" ID="ID_959210537" MODIFIED="1508751099912">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(127, 0, 85)" face="Consolas"><b>public</b></font><font face="Consolas">&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>class</b></font><font face="Consolas">&#160;MappedBuffer {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;</font><font color="rgb(63, 95, 191)" face="Consolas">/** &#20351;&#29992;ByteBuffer&#35835;&#21462;&#25991;&#20214;:</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>@Title</b></font><font color="rgb(63, 95, 191)" face="Consolas">: readWithByteBuffer</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>@Description</b></font><font color="rgb(63, 95, 191)" face="Consolas">:&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>TODO</b></font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>@return</b></font><font color="rgb(63, 95, 191)" face="Consolas">: void</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*/</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>public</b></font><font face="Consolas">&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>static</b></font><font face="Consolas">&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>void</b></font><font face="Consolas">&#160;readWithByteBuffer() {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;RandomAccessFile&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">;</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;FileChannel&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">;</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>try</b></font><font face="Consolas">&#160;{</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>new</b></font><font face="Consolas">&#160;RandomAccessFile(</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;src/bigFile&quot;</font><font face="Consolas">,&#160;</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;rw&quot;</font><font face="Consolas">);</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">.getChannel();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>long</b></font><font face="Consolas">&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">timeBegin</font><font face="Consolas">&#160;= System.<i>currentTimeMillis</i>();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ByteBuffer&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">buff</font><font face="Consolas">&#160;= ByteBuffer.<i>allocate</i>((</font><font color="rgb(127, 0, 85)" face="Consolas"><b>int</b></font><font face="Consolas">)&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">.length());</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">buff</font><font face="Consolas">.clear();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">.read(</font><font color="rgb(106, 62, 62)" face="Consolas">buff</font><font face="Consolas">);</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>long</b></font><font face="Consolas">&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">timeEnd</font><font face="Consolas">&#160;= System.<i>currentTimeMillis</i>();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.</font><font color="rgb(0, 0, 192)" face="Consolas"><b><i>out</i></b></font><font face="Consolas">.println(</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;Read time: &quot;</font><font face="Consolas">&#160;+ (</font><font color="rgb(106, 62, 62)" face="Consolas">timeEnd</font><font face="Consolas">&#160;-&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">timeBegin</font><font face="Consolas">) +&#160;</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;ms&quot;</font><font face="Consolas">);</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;}&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>catch</b></font><font face="Consolas">&#160;(IOException&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">.printStackTrace();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;}&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>finally</b></font><font face="Consolas">&#160;{</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>try</b></font><font face="Consolas">&#160;{</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>if</b></font><font face="Consolas">&#160;(</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">&#160;!=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">.close();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>if</b></font><font face="Consolas">&#160;(</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">&#160;!=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">.close();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>catch</b></font><font face="Consolas">&#160;(IOException&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">.printStackTrace();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;</font><font color="rgb(63, 95, 191)" face="Consolas">/** &#20351;&#29992;&#20869;&#23384;&#26144;&#23556;&#35835;&#21462;&#22823;&#25991;&#20214;:&#36895;&#24230;&#38750;&#24120;&#24555;,&#25991;&#20214;&#22823;,&#24046;&#36317;&#36234;&#26126;&#26174;</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>@Title</b></font><font color="rgb(63, 95, 191)" face="Consolas">: readWithMappedByteBuffer</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>@Description</b></font><font color="rgb(63, 95, 191)" face="Consolas">:&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>TODO</b></font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*&#160;</font><font color="rgb(127, 159, 191)" face="Consolas"><b>@return</b></font><font color="rgb(63, 95, 191)" face="Consolas">: void</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font color="rgb(63, 95, 191)" face="Consolas">&#160;&#160;&#160;&#160;&#160;*/</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>public</b></font><font face="Consolas">&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>static</b></font><font face="Consolas">&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>void</b></font><font face="Consolas">&#160;readWithMappedByteBuffer() {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;RandomAccessFile&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">;</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;FileChannel&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">;</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>try</b></font><font face="Consolas">&#160;{</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>new</b></font><font face="Consolas">&#160;RandomAccessFile(</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;src/bigFile&quot;</font><font face="Consolas">,&#160;</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;rw&quot;</font><font face="Consolas">);</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">.getChannel();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>long</b></font><font face="Consolas">&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">timeBegin</font><font face="Consolas">&#160;= System.<i>currentTimeMillis</i>();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;MappedByteBuffer&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">mbb</font><font face="Consolas">&#160;=&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">.map(FileChannel.MapMode.</font><font color="rgb(0, 0, 192)" face="Consolas"><b><i>READ_ONLY</i></b></font><font face="Consolas">, 0,&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">.length());</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">.read(</font><font color="rgb(106, 62, 62)" face="Consolas">mbb</font><font face="Consolas">);</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>long</b></font><font face="Consolas">&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">timeEnd</font><font face="Consolas">&#160;= System.<i>currentTimeMillis</i>();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.</font><font color="rgb(0, 0, 192)" face="Consolas"><b><i>out</i></b></font><font face="Consolas">.println(</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;Read time: &quot;</font><font face="Consolas">&#160;+ (</font><font color="rgb(106, 62, 62)" face="Consolas">timeEnd</font><font face="Consolas">&#160;-&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">timeBegin</font><font face="Consolas">) +&#160;</font><font color="rgb(42, 0, 255)" face="Consolas">&quot;ms&quot;</font><font face="Consolas">);</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;}&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>catch</b></font><font face="Consolas">&#160;(IOException&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">.printStackTrace();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;}&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>finally</b></font><font face="Consolas">&#160;{</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>try</b></font><font face="Consolas">&#160;{</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>if</b></font><font face="Consolas">&#160;(</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">&#160;!=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">aFile</font><font face="Consolas">.close();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>if</b></font><font face="Consolas">&#160;(</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">&#160;!=&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>null</b></font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">fc</font><font face="Consolas">.close();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}&#160;</font><font color="rgb(127, 0, 85)" face="Consolas"><b>catch</b></font><font face="Consolas">&#160;(IOException&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">) {</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="rgb(106, 62, 62)" face="Consolas">e</font><font face="Consolas">.printStackTrace();</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; color: rgb(0, 0, 0); font-family: &#x5fae;&#x8f6f;&#x96c5;&#x9ed1;; font-size: medium; font-style: normal; font-variant: normal; font-weight: normal; letter-spacing: normal; line-height: 18px; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; word-spacing: 0px">
      <font face="Consolas">&#160;&#160;&#160;&#160;}</font>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1522093216734" ID="ID_613011003" MODIFIED="1522093216737" TEXT="&#x6ce8;&#x610f;&#xff1a;buffer.flip();&#x4e00;&#x5b9a;&#x5f97;&#x6709;&#xff0c;&#x5982;&#x679c;&#x6ca1;&#x6709;&#xff0c;&#x5c31;&#x662f;&#x4ece;&#x6587;&#x4ef6;&#x6700;&#x540e;&#x5f00;&#x59cb;&#x8bfb;&#x53d6;&#x7684;&#xff0c;&#x5f53;&#x7136;&#x8bfb;&#x51fa;&#x6765;&#x7684;&#x90fd;&#x662f;byte=0&#x65f6;&#x5019;&#x7684;&#x5b57;&#x7b26;&#x3002;&#x901a;&#x8fc7;buffer.flip();&#x8fd9;&#x4e2a;&#x8bed;&#x53e5;&#xff0c;&#x5c31;&#x80fd;&#x628a;buffer&#x7684;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#x66f4;&#x6539;&#x4e3a;buffer&#x7f13;&#x51b2;&#x533a;&#x7684;&#x7b2c;&#x4e00;&#x4e2a;&#x4f4d;&#x7f6e;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1508749618667" FOLDED="true" ID="ID_419173416" MODIFIED="1529657528225" TEXT="SelectionKey">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508750257219" FOLDED="true" ID="ID_1917974291" MODIFIED="1529657528225" TEXT="?">
<node COLOR="#111111" CREATED="1508750258691" FOLDED="true" ID="ID_1308630711" MODIFIED="1529657528224" TEXT="&#x5f53;&#x5411;Selector&#x6ce8;&#x518c;Channel&#x65f6;&#xff0c;&#xa;register()&#x65b9;&#x6cd5;&#x4f1a;&#x8fd4;&#x56de;&#x4e00;&#x4e2a;&#xa;SelectionKey&#x5bf9;&#x8c61;&#x3002;&#xa;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x5305;&#x542b;&#x4e86;&#x4e00;&#x4e9b;&#x4f60;&#x611f;&#x5174;&#x8da3;&#x7684;&#x5c5e;&#x6027;&#xff1a;">
<node COLOR="#111111" CREATED="1508750258697" FOLDED="true" ID="ID_353695764" MODIFIED="1529657528224" TEXT="interest&#x96c6;&#x5408;">
<node COLOR="#111111" CREATED="1508750297698" ID="ID_555898535" MODIFIED="1508750297699" TEXT="&#x5c31;&#x50cf;&#x5411;Selector&#x6ce8;&#x518c;&#x901a;&#x9053;&#x4e00;&#x8282;&#x4e2d;&#x6240;&#x63cf;&#x8ff0;&#x7684;&#xff0c;interest&#x96c6;&#x5408;&#x662f;&#x4f60;&#x6240;&#x9009;&#x62e9;&#x7684;&#x611f;&#x5174;&#x8da3;&#x7684;&#x4e8b;&#x4ef6;&#x96c6;&#x5408;&#x3002;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;SelectionKey&#x8bfb;&#x5199;interest&#x96c6;&#x5408;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1508750258697" FOLDED="true" ID="ID_39372675" MODIFIED="1529657528224" TEXT="ready&#x96c6;&#x5408;">
<node COLOR="#111111" CREATED="1508750314195" ID="ID_273922911" MODIFIED="1508750314195" TEXT="&#x662f;&#x901a;&#x9053;&#x5df2;&#x7ecf;&#x51c6;&#x5907;&#x5c31;&#x7eea;&#x7684;&#x64cd;&#x4f5c;&#x7684;&#x96c6;&#x5408;&#x3002;&#x5728;&#x4e00;&#x6b21;&#x9009;&#x62e9;(Selection)&#x4e4b;&#x540e;&#xff0c;&#x4f60;&#x4f1a;&#x9996;&#x5148;&#x8bbf;&#x95ee;&#x8fd9;&#x4e2a;ready set"/>
</node>
<node COLOR="#111111" CREATED="1508750258698" ID="ID_63415882" MODIFIED="1508750258698" TEXT="Channel"/>
<node COLOR="#111111" CREATED="1508750258700" ID="ID_1648329994" MODIFIED="1508750258700" TEXT="Selector"/>
<node COLOR="#111111" CREATED="1508750258701" ID="ID_1524759858" MODIFIED="1508750258701" TEXT="&#x9644;&#x52a0;&#x7684;&#x5bf9;&#x8c61;&#xff08;&#x53ef;&#x9009;&#xff09;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1508750044041" FOLDED="true" ID="ID_1741600396" MODIFIED="1529657528225" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1508750045644" ID="ID_1306250308" MODIFIED="1508750045644" TEXT="public abstract SelectableChannel channel()"/>
<node COLOR="#111111" CREATED="1508750045644" ID="ID_133112641" MODIFIED="1508750045644" TEXT="public abstract Selector selector()"/>
<node COLOR="#111111" CREATED="1508750045645" ID="ID_181331757" MODIFIED="1508750045645" TEXT="public abstract boolean isValid()"/>
<node COLOR="#111111" CREATED="1508750045645" ID="ID_1722182923" MODIFIED="1508750045645" TEXT="public abstract void cancel()"/>
<node COLOR="#111111" CREATED="1508750045645" ID="ID_803628935" MODIFIED="1508750045645" TEXT="public abstract int interestOps()"/>
<node COLOR="#111111" CREATED="1508750045645" ID="ID_1253785946" MODIFIED="1508750045645" TEXT="public abstract SelectionKey interestOps(int ops)"/>
<node COLOR="#111111" CREATED="1508750045645" ID="ID_106362901" MODIFIED="1508750045645" TEXT="public abstract int readyOps()"/>
<node COLOR="#111111" CREATED="1508750140690" ID="ID_1623845802" MODIFIED="1508750140690" TEXT="public final boolean isReadable()"/>
<node COLOR="#111111" CREATED="1508750140691" ID="ID_831692762" MODIFIED="1508750140691" TEXT="public final boolean isWritable()"/>
<node COLOR="#111111" CREATED="1508750140692" ID="ID_948755598" MODIFIED="1508750140693" TEXT="public final boolean isConnectable()"/>
<node COLOR="#111111" CREATED="1508750140694" ID="ID_561260405" MODIFIED="1508750140694" TEXT="public final boolean isAcceptable()"/>
<node COLOR="#111111" CREATED="1508750140695" ID="ID_482511230" MODIFIED="1508750140696" TEXT="public final Object attach(Object ob)"/>
<node COLOR="#111111" CREATED="1508750140697" ID="ID_480414599" MODIFIED="1508750140697" TEXT="public final Object attachment()"/>
</node>
<node COLOR="#111111" CREATED="1508750050670" FOLDED="true" ID="ID_808450405" MODIFIED="1529657528225" TEXT="&#x5e38;&#x91cf;">
<node COLOR="#111111" CREATED="1508750102008" FOLDED="true" ID="ID_616734499" MODIFIED="1529657528225" TEXT="?">
<node COLOR="#111111" CREATED="1508750103529" ID="ID_1916405593" MODIFIED="1508750103529" TEXT="&#x6765;&#x68c0;&#x6d4b;channel&#x4e2d;&#x4ec0;&#x4e48;&#x4e8b;&#x4ef6;&#x6216;&#x64cd;&#x4f5c;&#x5df2;&#x7ecf;&#x5c31;&#x7eea;"/>
</node>
<node COLOR="#111111" CREATED="1508750066982" ID="ID_1868262714" MODIFIED="1508750066982" TEXT="public static final int OP_READ = 1 &lt;&lt; 0"/>
<node COLOR="#111111" CREATED="1508750066986" ID="ID_430371773" MODIFIED="1508750066986" TEXT="public static final int OP_WRITE = 1 &lt;&lt; 2"/>
<node COLOR="#111111" CREATED="1508750066988" ID="ID_729951437" MODIFIED="1508750066988" TEXT="public static final int OP_CONNECT = 1 &lt;&lt; 3"/>
<node COLOR="#111111" CREATED="1508750066990" ID="ID_737520110" MODIFIED="1508750066990" TEXT="public static final int OP_ACCEPT = 1 &lt;&lt; 4"/>
</node>
</node>
<node COLOR="#990000" CREATED="1508744276512" FOLDED="true" ID="ID_477816000" MODIFIED="1529657528226" TEXT="Selector">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508744293448" FOLDED="true" ID="ID_502704768" MODIFIED="1529657528225">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1508744297292" ID="ID_315541762" MODIFIED="1508744303964" TEXT="&#x8fd0;&#x884c;&#x5355;&#x7ebf;&#x7a0b;&#x5904;&#x7406;&#x591a;&#x4e2a;Channel&#xff0c;&#x5982;&#x679c;&#x4f60;&#x7684;&#x5e94;&#x7528;&#x6253;&#x5f00;&#x4e86;&#xa;&#x591a;&#x4e2a;&#x901a;&#x9053;&#xff0c;&#x4f46;&#x6bcf;&#x4e2a;&#x8fde;&#x63a5;&#x7684;&#x6d41;&#x91cf;&#x90fd;&#x5f88;&#x4f4e;&#xff0c;&#x4f7f;&#x7528;Selector&#xa;&#x5c31;&#x4f1a;&#x5f88;&#x65b9;&#x4fbf;"/>
</node>
<node COLOR="#111111" CREATED="1508749696078" FOLDED="true" ID="ID_1012868127" MODIFIED="1529657528226" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1508749868017" ID="ID_1781406846" MODIFIED="1508749868018" TEXT="public abstract boolean isOpen()"/>
<node COLOR="#111111" CREATED="1508749868020" ID="ID_411634650" MODIFIED="1508749868020" TEXT="public abstract SelectorProvider provider()"/>
<node COLOR="#111111" CREATED="1508749868022" ID="ID_143591428" MODIFIED="1508749868023" TEXT="public abstract Set&lt;SelectionKey&gt; keys()"/>
<node COLOR="#111111" CREATED="1508749868024" ID="ID_1985369725" MODIFIED="1508749868024" TEXT="public abstract Set&lt;SelectionKey&gt; selectedKeys()"/>
<node COLOR="#111111" CREATED="1508749868026" FOLDED="true" ID="ID_1652020566" MODIFIED="1529657528226" TEXT="public abstract int selectNow() throws IOException">
<node COLOR="#111111" CREATED="1508749944126" ID="ID_16573506" MODIFIED="1508749944126" TEXT="&#x4e0d;&#x4f1a;&#x963b;&#x585e;&#xff0c;&#x4e0d;&#x7ba1;&#x4ec0;&#x4e48;&#x901a;&#x9053;&#x5c31;&#x7eea;&#x90fd;&#x7acb;&#x523b;&#x8fd4;&#x56de;&#xff08;&#x8bd1;&#x8005;&#x6ce8;&#xff1a;&#x6b64;&#x65b9;&#x6cd5;&#x6267;&#x884c;&#x975e;&#x963b;&#x585e;&#x7684;&#x9009;&#x62e9;&#x64cd;&#x4f5c;&#x3002;&#x5982;&#x679c;&#x81ea;&#x4ece;&#x524d;&#x4e00;&#x6b21;&#x9009;&#x62e9;&#x64cd;&#x4f5c;&#x540e;&#xff0c;&#x6ca1;&#x6709;&#x901a;&#x9053;&#x53d8;&#x6210;&#x53ef;&#x9009;&#x62e9;&#x7684;&#xff0c;&#x5219;&#x6b64;&#x65b9;&#x6cd5;&#x76f4;&#x63a5;&#x8fd4;&#x56de;&#x96f6;&#x3002;&#xff09;"/>
</node>
<node COLOR="#111111" CREATED="1508749928034" FOLDED="true" ID="ID_1878061230" MODIFIED="1529657528226" TEXT="    public abstract int select(long timeout)         throws IOException">
<node COLOR="#111111" CREATED="1508749935899" ID="ID_1024121212" MODIFIED="1508749935899" TEXT="&#x6700;&#x957f;&#x4f1a;&#x963b;&#x585e;timeout&#x6beb;&#x79d2;(&#x53c2;&#x6570;)"/>
</node>
<node COLOR="#111111" CREATED="1508749868028" FOLDED="true" ID="ID_462261958" MODIFIED="1529657528226" TEXT="public abstract int select() throws IOException">
<node COLOR="#111111" CREATED="1508749894802" ID="ID_61752580" MODIFIED="1508749894802" TEXT="&#x963b;&#x585e;&#x5230;&#x81f3;&#x5c11;&#x6709;&#x4e00;&#x4e2a;&#x901a;&#x9053;&#x5728;&#x4f60;&#x6ce8;&#x518c;&#x7684;&#x4e8b;&#x4ef6;&#x4e0a;&#x5c31;&#x7eea;&#x4e86;"/>
</node>
<node COLOR="#111111" CREATED="1508749868034" ID="ID_1557574721" MODIFIED="1508749868034" TEXT="public abstract Selector wakeup()"/>
<node COLOR="#111111" CREATED="1508749868035" ID="ID_958224969" MODIFIED="1508749868036" TEXT="public abstract void close() throws IOException"/>
</node>
</node>
<node COLOR="#990000" CREATED="1521808598572" FOLDED="true" ID="ID_695552661" MODIFIED="1529657528227">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38754;&#21521;&#32531;&#20914;&#21306;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522091459388" FOLDED="true" ID="ID_639299109" MODIFIED="1529657528227" TEXT="&#x7f13;&#x51b2;&#x533a;&#x7ed3;&#x6784;&#x56fe;">
<node COLOR="#111111" CREATED="1522091470468" FOLDED="true" ID="ID_1692777232" MODIFIED="1529657528226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_7690937703165962756.jpeg" />
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1522091508905" FOLDED="true" ID="ID_1727156765" MODIFIED="1529657528226" TEXT="&#x89e3;&#x6790;">
<node COLOR="#111111" CREATED="1522091511439" ID="ID_1619071156" MODIFIED="1522091511439" TEXT="NIO&#x662f;&#x9762;&#x5411;&#x7f13;&#x51b2;&#x533a;&#x7684;&#xff0c;&#x7f13;&#x51b2;&#x533a;&#x53ef;&#x4ee5;&#x7406;&#x89e3;&#x4e3a;&#x4e00;&#x5757;&#x5185;&#x5b58;&#xff0c;&#x6709;&#x5927;&#x5c0f;&#x3002;&#x7f13;&#x51b2;&#x533a;&#x6709;&#x4f4d;&#x7f6e;&#x3001;&#x754c;&#x9650;&#x3001;&#x5bb9;&#x91cf;&#x51e0;&#x4e2a;&#x6982;&#x5ff5;&#x3002;"/>
<node COLOR="#111111" CREATED="1522091511441" ID="ID_275368087" MODIFIED="1522091511441" TEXT="capacity&#xff1a;&#x5bb9;&#x91cf;&#xff0c;&#x7f13;&#x51b2;&#x533a;&#x7684;&#x5927;&#x5c0f;"/>
<node COLOR="#111111" CREATED="1522091511442" ID="ID_67775118" MODIFIED="1522091511443" TEXT="limit&#xff1a;&#x9650;&#x5236;&#xff0c;&#x8868;&#x793a;&#x6700;&#x5927;&#x7684;&#x53ef;&#x8bfb;&#x5199;&#x7684;&#x6570;&#x91cf;"/>
<node COLOR="#111111" CREATED="1522091511443" ID="ID_1289989789" MODIFIED="1522091511444" TEXT="position&#xff1a;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#xff0c;&#x6bcf;&#x5f53;&#x8bfb;&#x5199;&#xff0c;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#x90fd;&#x4f1a;&#x52a0;&#x4e00;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1522093003294" ID="ID_1993875209" MODIFIED="1522093003295">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_3002627272056886231.jpeg" />
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1522093049902" FOLDED="true" ID="ID_1394522051" MODIFIED="1529657528227" TEXT="&#x89e3;&#x6790;">
<node COLOR="#111111" CREATED="1522093052659" ID="ID_1776306571" MODIFIED="1522093052659" TEXT="Buffer &#x4e2d;&#x7684; flip() &#x65b9;&#x6cd5;&#x6d89;&#x53ca;&#x5230; Buffer &#x4e2d;&#x7684;capacity&#x3001;position&#x3001;limit&#x4e09;&#x4e2a;&#x6982;&#x5ff5;&#x3002;"/>
<node COLOR="#111111" CREATED="1522093052660" ID="ID_839438369" MODIFIED="1522093052660" TEXT="capacity&#xff1a;&#x5728;&#x8bfb;/&#x5199;&#x6a21;&#x5f0f;&#x4e0b;&#x90fd;&#x662f;&#x56fa;&#x5b9a;&#x7684;&#xff0c;&#x5c31;&#x662f;&#x6211;&#x4eec;&#x5206;&#x914d;&#x7684;&#x7f13;&#x51b2;&#x5927;&#x5c0f;&#xff08;&#x5bb9;&#x91cf;&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1522093052660" ID="ID_1611945869" MODIFIED="1522093052661" TEXT="position&#xff1a;&#x7c7b;&#x4f3c;&#x4e8e;&#x8bfb;/&#x5199;&#x6307;&#x9488;&#xff0c;&#x8868;&#x793a;&#x5f53;&#x524d;&#x8bfb;(&#x5199;)&#x5230;&#x4ec0;&#x4e48;&#x4f4d;&#x7f6e;&#x3002;"/>
<node COLOR="#111111" CREATED="1522093052777" FOLDED="true" ID="ID_985634686" MODIFIED="1529657528226" TEXT="limit&#xff1a;&#x5728;&#x5199;&#x6a21;&#x5f0f;&#x4e0b;&#x8868;&#x793a;&#x6700;&#x591a;&#x80fd;&#x5199;&#x5165;&#x591a;&#x5c11;&#x6570;&#x636e;&#xff0c;&#x6b64;&#x65f6;&#x548c;capacity&#x76f8;&#x540c;&#x3002;&#x5728;&#x8bfb;&#x6a21;&#x5f0f;&#x4e0b;&#x8868;&#x793a;&#x6700;&#x591a;&#x80fd;&#x8bfb;&#x591a;&#x5c11;&#x6570;&#x636e;&#xff0c;&#x6b64;&#x65f6;&#x548c;&#x7f13;&#x5b58;&#x4e2d;&#x7684;&#x5b9e;&#x9645;">
<node COLOR="#111111" CREATED="1522093052778" ID="ID_1802388355" MODIFIED="1522093052778" TEXT="&#x6570;&#x636e;&#x5927;&#x5c0f;&#x76f8;&#x540c;&#x3002;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1522091565084" FOLDED="true" ID="ID_570556581" MODIFIED="1529657528227" TEXT="&#x7f13;&#x51b2;&#x533a;&#x5e38;&#x7528;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1522091571118" ID="ID_1312075788" MODIFIED="1522091579276">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      clear()&#65306;&#23558;&#24403;&#21069;&#20301;&#32622;&#35774;&#32622;&#20026;0&#65292;&#38480;&#21046;&#35774;&#32622;&#20026;&#23481;&#37327;&#65292;&#30446;&#30340;&#26159;&#23613;&#26368;&#22823;&#21487;&#33021;&#35753;&#23383;&#33410;&#65292;&#30001;&#36890;&#36947;&#35835;&#21462;&#21040;&#32531;&#20914;&#20013;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1522091571121" ID="ID_1868083137" MODIFIED="1522091584923" TEXT="flip()&#xff1a;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#x7f6e;&#x4e3a;&#x9650;&#x5236;&#xff0c;&#x7136;&#x540e;&#x5c06;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#x7f6e;&#x4e3a;0&#xff0c;&#x76ee;&#x7684;&#x662f;&#x5c06;&#x6709;&#x6570;&#x636e;&#x90e8;&#x5206;&#x7684;&#x5b57;&#x8282;&#xff0c;&#x7531;&#x7f13;&#x51b2;&#x5199;&#x5165;&#x5230;&#x901a;&#x9053;&#x4e2d;&#x3002;&#x901a;&#x5e38;&#x7528;&#x5728;&#x8bfb;&#x4e0e;&#x5199;&#x4e4b;&#x95f4;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1522094722082" ID="ID_1485774529" MODIFIED="1522094722082" TEXT="&#x901a;&#x9053;&#x53ea;&#x63a5;&#x6536; ByteBuffer &#x4f5c;&#x4e3a;&#x53c2;&#x6570;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495155099355" FOLDED="true" ID="ID_276745459" MODIFIED="1529657528249" TEXT="I/O">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495267444254" FOLDED="true" ID="ID_468909955" MODIFIED="1529657528245">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20998;&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495247450455" FOLDED="true" ID="ID_265381859" MODIFIED="1529657528241">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23383;&#33410;&#27969;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495247479525" FOLDED="true" ID="ID_523116621" MODIFIED="1529657528240" TEXT="InputStream&#x62bd;&#x8c61;&#x7c7b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495249428329" FOLDED="true" ID="ID_1612783058" MODIFIED="1529657528239">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23376;&#31867;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495247486355" FOLDED="true" ID="ID_1039343326" MODIFIED="1529657528238" TEXT="FileInputStream">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495248210867" FOLDED="true" ID="ID_1305841948" MODIFIED="1529657528237">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495248128569" ID="ID_594621563" MODIFIED="1495248138485" TEXT="&#x6587;&#x4ef6;&#x8f93;&#x5165;&#x6d41;"/>
<node COLOR="#111111" CREATED="1495251233327" ID="ID_612039174" MODIFIED="1495251233327" TEXT="&#x4e0d;&#x652f;&#x6301;mark/reset&#x64cd;&#x4f5c;"/>
</node>
<node COLOR="#111111" CREATED="1495251949890" FOLDED="true" ID="ID_1694552223" MODIFIED="1529657528237" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495251951958" ID="ID_1169665787" MODIFIED="1495251951958" TEXT="public FileInputStream(String name) throws FileNotFoundException"/>
<node COLOR="#111111" CREATED="1495251951959" ID="ID_1494839453" MODIFIED="1495251951959" TEXT="public FileInputStream(File file) throws FileNotFoundException"/>
<node COLOR="#111111" CREATED="1495251951961" ID="ID_535909149" MODIFIED="1495251951961" TEXT="public FileInputStream(FileDescriptor fdObj)"/>
</node>
<node COLOR="#111111" CREATED="1495251953162" FOLDED="true" ID="ID_1117673027" MODIFIED="1529657528237" TEXT="&#x81ea;&#x5df1;&#x7684;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495251977301" ID="ID_1511202533" MODIFIED="1495251977301" TEXT="public final FileDescriptor getFD() throws IOException"/>
<node COLOR="#111111" CREATED="1495251977302" ID="ID_1484520380" MODIFIED="1495251977302" TEXT="public FileChannel getChannel()"/>
</node>
<node COLOR="#111111" CREATED="1495252008278" FOLDED="true" ID="ID_422890587" MODIFIED="1529657528237" TEXT="&#x76f8;&#x5173;&#x7684;&#x7c7b;">
<node COLOR="#111111" CREATED="1495252011263" FOLDED="true" ID="ID_455163000" MODIFIED="1529657528237" TEXT="FileDescriptor">
<node COLOR="#111111" CREATED="1495252097194" FOLDED="true" ID="ID_916997900" MODIFIED="1529657528237">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495252091054" ID="ID_1544608755" MODIFIED="1495252095694" TEXT="&#x6587;&#x4ef6;&#x63cf;&#x8ff0;&#x7b26;"/>
<node COLOR="#111111" CREATED="1495252287680" ID="ID_719961057" MODIFIED="1495252307121" TEXT="&#x5f88;&#x5c11;&#x7528;,&#x53ef;&#x6682;&#x4e0d;&#x7528;&#x4e86;&#x89e3;"/>
</node>
<node COLOR="#111111" CREATED="1495252023677" FOLDED="true" ID="ID_404094928" MODIFIED="1529657528237" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495252026587" ID="ID_552310029" MODIFIED="1495252030523" TEXT="public  FileDescriptor()"/>
</node>
<node COLOR="#111111" CREATED="1495252114647" FOLDED="true" ID="ID_1584819871" MODIFIED="1529657528237" TEXT="&#x5c5e;&#x6027;">
<node COLOR="#111111" CREATED="1495252117325" ID="ID_684371756" MODIFIED="1495252117325" TEXT="public static final FileDescriptor in"/>
<node COLOR="#111111" CREATED="1495252123296" ID="ID_1503749912" MODIFIED="1495252123296" TEXT="public static final FileDescriptor out"/>
<node COLOR="#111111" CREATED="1495252128497" ID="ID_467852435" MODIFIED="1495252128497" TEXT="public static final FileDescriptor err"/>
</node>
<node COLOR="#111111" CREATED="1495252135272" FOLDED="true" ID="ID_61800899" MODIFIED="1529657528237" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495252137670" ID="ID_311901552" MODIFIED="1495252137671" TEXT="public boolean valid()"/>
<node COLOR="#111111" CREATED="1495252142159" ID="ID_1007635724" MODIFIED="1495252142159" TEXT="public native void sync()"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495247494733" FOLDED="true" ID="ID_354136117" MODIFIED="1529657528238" TEXT="FilterInputStream">
<node COLOR="#111111" CREATED="1495252421312" FOLDED="true" ID="ID_58828935" MODIFIED="1529657528238" TEXT="?">
<node COLOR="#111111" CREATED="1495252424342" ID="ID_198157301" MODIFIED="1495252441637" TEXT="&#x5bf9;&#x8f93;&#x5165;&#x6d41;&#x5305;&#x88c5;,&#x63d0;&#x4f9b;&#x66f4;&#x591a;&#x7684;&#x64cd;&#x4f5c;"/>
</node>
<node COLOR="#111111" CREATED="1495252458557" FOLDED="true" ID="ID_432046395" MODIFIED="1529657528238" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495252464880" ID="ID_261002683" MODIFIED="1495252493783">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21482;&#26159;&#23454;&#29616;&#20102;&#29238;&#31867;&#30340;&#26041;&#27861;&#32780;&#24050;,&#27809;&#26377;&#20854;&#20182;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495252451994" FOLDED="true" ID="ID_151240581" MODIFIED="1529657528238">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23376;&#31867;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495247612882" FOLDED="true" ID="ID_609679749" MODIFIED="1529657528238" TEXT="BufferedInputStream">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495252556109" FOLDED="true" ID="ID_1856044833" MODIFIED="1529657528238" TEXT="?">
<node COLOR="#111111" CREATED="1495252557473" ID="ID_628455348" MODIFIED="1495252573262" TEXT="&#x7f13;&#x51b2;&#x533a;&#x8f93;&#x5165;&#x6d41;"/>
</node>
<node COLOR="#111111" CREATED="1495252536544" FOLDED="true" ID="ID_1390744817" MODIFIED="1529657528238" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495252549028" ID="ID_454745258" MODIFIED="1495252552639" TEXT="public BufferedInputStream(InputStream in)"/>
<node COLOR="#111111" CREATED="1495252538546" ID="ID_1614898792" MODIFIED="1495252538546" TEXT="public BufferedInputStream(InputStream in, int size)"/>
</node>
<node COLOR="#111111" CREATED="1495252589658" FOLDED="true" ID="ID_299598801" MODIFIED="1529657528238" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495252591417" ID="ID_168500300" MODIFIED="1495252607662" TEXT="&#x540c;&#x7236;&#x7c7b;&#x65b9;&#x6cd5;,&#x5b9e;&#x73b0;&#x4e86;&#x81ea;&#x5df1;&#x7684;&#x529f;&#x80fd;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495247628484" FOLDED="true" ID="ID_966318840" MODIFIED="1529657528238" TEXT="DataInputStream">
<node COLOR="#111111" CREATED="1495252669180" FOLDED="true" ID="ID_562671039" MODIFIED="1529657528238" TEXT="?">
<node COLOR="#111111" CREATED="1495252674429" ID="ID_1531827156" MODIFIED="1495252700871">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22788;&#29702;&#22522;&#26412;&#25968;&#25454;&#31867;&#22411;&#21644;&#23383;&#31526;&#20018;&#31867;&#22411;&#30340;&#36755;&#20837;&#27969;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495252671032" FOLDED="true" ID="ID_257300951" MODIFIED="1529657528238" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495252710897" ID="ID_1287228405" MODIFIED="1495252710898" TEXT="public DataInputStream(InputStream in)"/>
</node>
<node COLOR="#111111" CREATED="1495252712389" FOLDED="true" ID="ID_1864110781" MODIFIED="1529657528238" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495252730922" FOLDED="true" ID="ID_767255458" MODIFIED="1529657528238" TEXT="public final void readFully(byte b[]) throws IOException">
<node COLOR="#111111" CREATED="1495252917577" ID="ID_1428570281" MODIFIED="1495252947528" TEXT="Reads some bytes from an input   stream and stores them into the buffer array {@code b}. The number of bytes  read is equal   to the length of  b[ ]"/>
</node>
<node COLOR="#111111" CREATED="1495252730923" ID="ID_1048612340" MODIFIED="1495252730923" TEXT="public final void readFully(byte b[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495252747023" ID="ID_1885465495" MODIFIED="1495252747023" TEXT="public final int skipBytes(int n) throws IOException"/>
<node COLOR="#111111" CREATED="1495252747024" ID="ID_745961279" MODIFIED="1495252747024" TEXT="public final boolean readBoolean() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747025" ID="ID_1469603679" MODIFIED="1495252747025" TEXT="public final byte readByte() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747025" FOLDED="true" ID="ID_26447651" MODIFIED="1529657528238" TEXT="public final int readUnsignedByte() throws IOException">
<node COLOR="#111111" CREATED="1495253068807" ID="ID_1971475193" MODIFIED="1495253110953" TEXT="&#x8fd4;&#x56de;&#x4e0b;&#x4e00;&#x4e2a;&#x5b57;&#x8282;,&#x5e76;&#x4e14;&#x662f;&#x65e0;&#x7b26;&#x53f7;&#x7684;,0-65535&#x4e4b;&#x95f4;"/>
</node>
<node COLOR="#111111" CREATED="1495252747026" ID="ID_1275582750" MODIFIED="1495252747026" TEXT="public final short readShort() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747027" FOLDED="true" ID="ID_897375551" MODIFIED="1529657528238" TEXT="public final int readUnsignedShort() throws IOException">
<node COLOR="#111111" CREATED="1495253202334" ID="ID_83920636" MODIFIED="1495253205524" TEXT="return the next two bytes of this input stream, interpreted as an      *             unsigned 16-bit integer"/>
</node>
<node COLOR="#111111" CREATED="1495252747028" ID="ID_1521321382" MODIFIED="1495252747028" TEXT="public final char readChar() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747028" ID="ID_712980827" MODIFIED="1495252747029" TEXT="public final int readInt() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747030" ID="ID_611637205" MODIFIED="1495252747030" TEXT="public final long readLong() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747032" ID="ID_828407163" MODIFIED="1495252747032" TEXT="public final float readFloat() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747033" ID="ID_1469856628" MODIFIED="1495252747033" TEXT="public final double readDouble() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747033" ID="ID_725797684" MODIFIED="1495252747033" TEXT="public final String readLine() throws IOException"/>
<node COLOR="#111111" CREATED="1495252747034" FOLDED="true" ID="ID_156866591" MODIFIED="1529657528238" TEXT="public final String readUTF() throws IOException">
<node COLOR="#111111" CREATED="1495253260473" ID="ID_506496622" MODIFIED="1495253274747" TEXT="Reads in a string that has been encoded using a modified UTF-8 format"/>
</node>
<node COLOR="#111111" CREATED="1495252747034" ID="ID_77462715" MODIFIED="1495252747035" TEXT="public final static String readUTF(DataInput in) throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495247636917" FOLDED="true" ID="ID_1279015086" MODIFIED="1529657528238">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      PushbackInputStream
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495266807555" FOLDED="true" ID="ID_1503563396" MODIFIED="1529657528238" TEXT="?">
<node COLOR="#111111" CREATED="1495266808613" ID="ID_1831952253" MODIFIED="1495266808615" TEXT="&#x63d0;&#x4f9b;&#x53ef;&#x4ee5;&#x5c06;&#x6570;&#x636e;&#x63d2;&#x5165;&#x5230;&#x8f93;&#x5165;&#x6d41;&#x524d;&#x7aef;&#x7684;&#x80fd;&#x529b;(&#x5f53;&#x7136;&#x4e5f;&#x53ef;&#x4ee5;&#x505a;&#x5176;&#x4ed6;&#x64cd;&#x4f5c;)&#x3002;&#x7b80;&#x800c;&#x8a00;&#x4e4b;PushbackInputStream&#x7c7b;&#x7684;&#x4f5c;&#x7528;&#x5c31;&#x662f;&#x80fd;&#x591f;&#x5728;&#x8bfb;&#x53d6;&#x7f13;&#x51b2;&#x533a;&#x7684;&#x65f6;&#x5019;&#x63d0;&#x524d;&#x77e5;&#x9053;&#x4e0b;&#x4e00;&#x4e2a;&#x5b57;&#x8282;&#x662f;&#x4ec0;&#x4e48;&#xff0c;&#x5176;&#x5b9e;&#x8d28;&#x662f;&#x8bfb;&#x53d6;&#x5230;&#x4e0b;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x540e;&#x56de;&#x9000;&#x7684;&#x505a;&#x6cd5;&#xff0c;&#x8fd9;&#x4e4b;&#x95f4;&#x53ef;&#x4ee5;&#x8fdb;&#x884c;&#x5f88;&#x591a;&#x64cd;&#x4f5c;&#xff0c;&#x8fd9;&#x6709;&#x70b9;&#x5411;&#x4f60;&#x628a;&#x8bfb;&#x53d6;&#x7f13;&#x51b2;&#x533a;&#x7684;&#x8fc7;&#x7a0b;&#x5f53;&#x6210;&#x4e00;&#x4e2a;&#x6570;&#x7ec4;&#x7684;&#x904d;&#x5386;&#xff0c;&#x904d;&#x5386;&#x5230;&#x67d0;&#x4e2a;&#x5b57;&#x7b26;&#x7684;&#x65f6;&#x5019;&#x53ef;&#x4ee5;&#x8fdb;&#x884c;&#x7684;&#x64cd;&#x4f5c;"/>
</node>
<node COLOR="#111111" CREATED="1495266868721" FOLDED="true" ID="ID_1398808743" MODIFIED="1529657528238">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495266865468" ID="ID_1349995047" MODIFIED="1495266865468" TEXT="public PushbackInputStream(InputStream in, int size)"/>
<node COLOR="#111111" CREATED="1495266865469" ID="ID_3588482" MODIFIED="1495266865469" TEXT="public PushbackInputStream(InputStream in)"/>
</node>
<node COLOR="#111111" CREATED="1495266882383" FOLDED="true" ID="ID_975193551" MODIFIED="1529657528238">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495266865470" ID="ID_1585754220" MODIFIED="1495266865470" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495266865471" ID="ID_190892565" MODIFIED="1495266865471" TEXT="public int read(byte[] b, int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495266865472" FOLDED="true" ID="ID_1773755301" MODIFIED="1529657528238" TEXT="public void unread(int b) throws IOException">
<node COLOR="#111111" CREATED="1495267097599" ID="ID_160626128" MODIFIED="1495267121644" TEXT="&#x5c06;&#x4e00;&#x4e2a;&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x7684;&#x63a8;&#x56de;&#x5230;&#x63a8;&#x56de;&#x7f13;&#x51b2;&#x533a;&#x91cc;&#xff0c;&#x4ece;&#x800c;&#x5141;&#x8bb8;&#x91cd;&#x590d;&#x8bfb;&#x53d6;&#x521a;&#x521a;&#x8bfb;&#x53d6;&#x7684;&#x5185;&#x5bb9;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495266865473" FOLDED="true" ID="ID_1855120310" MODIFIED="1529657528238" TEXT="public void unread(byte[] b, int off, int len) throws IOException">
<node COLOR="#111111" CREATED="1495267131022" ID="ID_817524549" MODIFIED="1495267131022" TEXT="&#x5c06;&#x4e00;&#x4e2a;&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x6570;&#x7ec4;&#x91cc;&#x4ece;off&#x5f00;&#x59cb;&#xff0c;&#x957f;&#x5ea6;&#x4e3a;len&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x7684;&#x5185;&#x5bb9;&#x63a8;&#x56de;&#x5230;&#x63a8;&#x56de;&#x7f13;&#x51b2;&#x533a;&#x91cc;&#xff0c;&#x4ece;&#x800c;&#x5141;&#x8bb8;&#x91cd;&#x590d;&#x8bfb;&#x53d6;&#x521a;&#x521a;&#x8bfb;&#x53d6;&#x7684;&#x5185;&#x5bb9;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495266865474" FOLDED="true" ID="ID_1458893061" MODIFIED="1529657528238" TEXT="public void unread(byte[] b) throws IOException">
<node COLOR="#111111" CREATED="1495267139286" ID="ID_1341003657" MODIFIED="1495267139286" TEXT="&#x5c06;&#x4e00;&#x4e2a;&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x6570;&#x7ec4;&#x5185;&#x5bb9;&#x7684;&#x63a8;&#x56de;&#x5230;&#x63a8;&#x56de;&#x7f13;&#x51b2;&#x533a;&#x91cc;&#xff0c;&#x4ece;&#x800c;&#x5141;&#x8bb8;&#x91cd;&#x590d;&#x8bfb;&#x53d6;&#x521a;&#x521a;&#x8bfb;&#x53d6;&#x7684;&#x5185;&#x5bb9;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495266865475" ID="ID_533376860" MODIFIED="1495266865475" TEXT="public int available() throws IOException"/>
<node COLOR="#111111" CREATED="1495266865475" ID="ID_83625321" MODIFIED="1495266865475" TEXT="public long skip(long n) throws IOException"/>
<node COLOR="#111111" CREATED="1495266865477" ID="ID_949055471" MODIFIED="1495266865477" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495266865479" ID="ID_1948700603" MODIFIED="1495266865479" TEXT="public synchronized void mark(int readlimit)"/>
<node COLOR="#111111" CREATED="1495266865480" ID="ID_1697699669" MODIFIED="1495266865480" TEXT="public synchronized void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495266865480" ID="ID_974055607" MODIFIED="1495266865481" TEXT="public synchronized void close() throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495261645238" ID="ID_1823095524" MODIFIED="1495261645238" TEXT="ZipInputStream"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495247507362" FOLDED="true" ID="ID_1250605559" MODIFIED="1529657528239" TEXT="ObjectInputStream">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495259647020" FOLDED="true" ID="ID_326799394" MODIFIED="1529657528239" TEXT="?">
<node COLOR="#111111" CREATED="1495259649178" ID="ID_1659556864" MODIFIED="1495259665793" TEXT="&#x5bf9;&#x8c61;&#x8f93;&#x5165;&#x6d41;,&#x7528;&#x4e8e;&#x8bfb;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1495259667900" FOLDED="true" ID="ID_1666254225" MODIFIED="1529657528239" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495259670929" ID="ID_1494978027" MODIFIED="1495259670929" TEXT="public ObjectInputStream(InputStream in) throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495259671970" FOLDED="true" ID="ID_1261245417" MODIFIED="1529657528239" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495259727226" ID="ID_1333759216" MODIFIED="1495259727226" TEXT="public boolean readBoolean() throws IOException"/>
<node COLOR="#111111" CREATED="1495259727227" ID="ID_706796345" MODIFIED="1495259727227" TEXT="public byte readByte() throws IOException"/>
<node COLOR="#111111" CREATED="1495259727227" ID="ID_673893806" MODIFIED="1495259727228" TEXT="public int readUnsignedByte()  throws IOException"/>
<node COLOR="#111111" CREATED="1495259727228" ID="ID_1946138089" MODIFIED="1495259727228" TEXT="public char readChar()  throws IOException"/>
<node COLOR="#111111" CREATED="1495259727229" ID="ID_889520761" MODIFIED="1495259727229" TEXT="public short readShort()  throws IOException"/>
<node COLOR="#111111" CREATED="1495259727229" ID="ID_860908824" MODIFIED="1495259727230" TEXT="public int readUnsignedShort() throws IOException"/>
<node COLOR="#111111" CREATED="1495259727230" ID="ID_864803989" MODIFIED="1495259727231" TEXT="public int readInt()  throws IOException"/>
<node COLOR="#111111" CREATED="1495259727231" ID="ID_414696114" MODIFIED="1495259727232" TEXT="public long readLong()  throws IOException"/>
<node COLOR="#111111" CREATED="1495259727232" ID="ID_1181841454" MODIFIED="1495259727233" TEXT="public float readFloat() throws IOException"/>
<node COLOR="#111111" CREATED="1495259727233" ID="ID_1717506469" MODIFIED="1495259727234" TEXT="public double readDouble() throws IOException"/>
<node COLOR="#111111" CREATED="1495259727234" FOLDED="true" ID="ID_1577994530" MODIFIED="1529657528239" TEXT="public void readFully(byte[] buf) throws IOException">
<node COLOR="#111111" CREATED="1495252917577" ID="ID_706920341" MODIFIED="1495259796434" TEXT="Reads some bytes from an input   stream and stores them into the buffer array buf[ ]. The number of bytes  read is equal   to the length of  b[ ]"/>
</node>
<node COLOR="#111111" CREATED="1495259727241" ID="ID_935724807" MODIFIED="1495259727241" TEXT="public void readFully(byte[] buf, int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495259727242" ID="ID_465842907" MODIFIED="1495259727242" TEXT="public int skipBytes(int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495259727242" ID="ID_722279805" MODIFIED="1495259727243" TEXT="public String readLine() throws IOException"/>
<node COLOR="#111111" CREATED="1495259727243" ID="ID_974160694" MODIFIED="1495259727243" TEXT="public String readUTF() throws IOException"/>
<node COLOR="#111111" CREATED="1495262770313" FOLDED="true" ID="ID_940579488" MODIFIED="1529657528239" TEXT="public ObjectInputStream.GetField readFields()">
<node COLOR="#111111" CREATED="1495262814608" FOLDED="true" ID="ID_759876520" MODIFIED="1529657528239">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20869;&#37096;&#31867;GetField
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495262827310" FOLDED="true" ID="ID_1202335139" MODIFIED="1529657528239" TEXT="?">
<node COLOR="#111111" CREATED="1495262828460" ID="ID_290349643" MODIFIED="1495262828460" TEXT="Provide access to the persistent fields read from the input stream"/>
<node COLOR="#111111" CREATED="1495262837103" ID="ID_810287380" MODIFIED="1495263030048">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#19968;&#20010;&#20869;&#37096;&#25277;&#35937;&#31867;,&#21487;&#20197;&#36890;&#36807;&#23427;&#25226;ObjectInputStream&#20013;&#30340;&#23545;&#35937;&#30340;&#23646;&#24615;&#36890;&#36807;key/value&#23545;&#20799;&#30340;&#24418;&#24335;&#35835;&#21462;&#20986;&#26469;,&#20174;&#32780;&#19981;&#29992;&#32771;&#34385;&#35835;&#21462;&#23545;&#35937;&#23646;&#24615;&#26102;&#23646;&#24615;&#30340;&#39034;&#24207;&#38382;&#39064;,&#31867;&#20284;&#20110;Json&#26684;&#24335;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495263169677" ID="ID_451319130" MODIFIED="1495263180831" TEXT="&#x5b83;&#x901a;&#x8fc7;&#x79c1;&#x6709;&#x5185;&#x90e8;&#x7c7b;&#x5b9e;&#x73b0;"/>
</node>
<node COLOR="#111111" CREATED="1495263035781" FOLDED="true" ID="ID_1470852746" MODIFIED="1529657528239" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495263166336" ID="ID_53645954" MODIFIED="1495263166336" TEXT="public abstract ObjectStreamClass getObjectStreamClass()"/>
<node COLOR="#111111" CREATED="1495263166340" ID="ID_315005745" MODIFIED="1495263166341" TEXT="public abstract boolean defaulted(String name) throws IOException"/>
<node COLOR="#111111" CREATED="1495263166341" FOLDED="true" ID="ID_1399272872" MODIFIED="1529657528239" TEXT="public abstract byte get(String name, byte val) throws IOException">
<node COLOR="#111111" CREATED="1495263216986" ID="ID_606987278" MODIFIED="1495263241030" TEXT="val the default value,&#x4e0b;&#x9762;&#x7684;&#x65b9;&#x6cd5;&#x7684;&#x53c2;&#x6570;&#x662f;&#x4e00;&#x6837;&#x7684;&#x610f;&#x601d;"/>
</node>
<node COLOR="#111111" CREATED="1495263166342" ID="ID_93424295" MODIFIED="1495263166342" TEXT="public abstract char get(String name, char val) throws IOException"/>
<node COLOR="#111111" CREATED="1495263166343" ID="ID_322858124" MODIFIED="1495263166343" TEXT="public abstract short get(String name, short val) throws IOException"/>
<node COLOR="#111111" CREATED="1495263166343" ID="ID_327080755" MODIFIED="1495263166343" TEXT="public abstract int get(String name, int val) throws IOException"/>
<node COLOR="#111111" CREATED="1495263166344" ID="ID_460521741" MODIFIED="1495263166344" TEXT="public abstract long get(String name, long val) throws IOException"/>
<node COLOR="#111111" CREATED="1495263166344" ID="ID_1951520878" MODIFIED="1495263166345" TEXT="public abstract float get(String name, float val) throws IOException"/>
<node COLOR="#111111" CREATED="1495263166345" ID="ID_743983492" MODIFIED="1495263166345" TEXT="public abstract double get(String name, double val) throws IOException"/>
<node COLOR="#111111" CREATED="1495263166346" ID="ID_373114882" MODIFIED="1495263166346" TEXT="public abstract Object get(String name, Object val) throws IOException"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495247515417" FOLDED="true" ID="ID_252738128" MODIFIED="1529657528239" TEXT="PipeInputStream">
<node COLOR="#111111" CREATED="1495260337087" FOLDED="true" ID="ID_1670211758" MODIFIED="1529657528239" TEXT="?">
<node COLOR="#111111" CREATED="1495260340812" ID="ID_198158830" MODIFIED="1495260369426" TEXT="&#x7ba1;&#x9053;&#x8f93;&#x5165;&#x6d41;,&#x9700;&#x8981;&#x548c;&#x4e00;&#x4e2a;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x7ef4;&#x62a4;&#x7684;&#x7ba1;&#x9053;&#x8f93;&#x51fa;&#x6d41;&#x8054;&#x7cfb;&#x8d77;&#x6765;"/>
</node>
<node COLOR="#111111" CREATED="1495260218497" FOLDED="true" ID="ID_827779871" MODIFIED="1529657528239" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495260221097" ID="ID_1561940154" MODIFIED="1495260221098" TEXT="public PipedInputStream(PipedOutputStream src) throws IOException"/>
<node COLOR="#111111" CREATED="1495260221099" ID="ID_1934965439" MODIFIED="1495260221099" TEXT="public PipedInputStream()"/>
<node COLOR="#111111" CREATED="1495260221100" ID="ID_1957551398" MODIFIED="1495260221100" TEXT="public PipedInputStream(int pipeSize)"/>
</node>
<node COLOR="#111111" CREATED="1495260229760" FOLDED="true" ID="ID_1575418581" MODIFIED="1529657528239" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495260254753" ID="ID_275469120" MODIFIED="1495260254753" TEXT="public void connect(PipedOutputStream src) throws IOException"/>
<node COLOR="#111111" CREATED="1495260254754" ID="ID_187227761" MODIFIED="1495260254755" TEXT="public synchronized int read()  throws IOException"/>
<node COLOR="#111111" CREATED="1495260254756" ID="ID_542553329" MODIFIED="1495260254756" TEXT="public synchronized int read(byte b[], int off, int len)  throws IOException"/>
<node COLOR="#111111" CREATED="1495260254757" ID="ID_1182880540" MODIFIED="1495260254757" TEXT="public synchronized int available() throws IOException"/>
<node COLOR="#111111" CREATED="1495260254758" ID="ID_1569903971" MODIFIED="1495260254758" TEXT="public void close()  throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495247523854" FOLDED="true" ID="ID_129933055" MODIFIED="1529657528239" TEXT="SequenceInputStream">
<node COLOR="#111111" CREATED="1495260459287" FOLDED="true" ID="ID_476276672" MODIFIED="1529657528239" TEXT="&#x5e8f;&#x5217;&#x8f93;&#x5165;&#x6d41;">
<node COLOR="#111111" CREATED="1495260466891" ID="ID_194819139" MODIFIED="1495260466893" TEXT="&#x6709;&#x4e9b;&#x60c5;&#x51b5;&#x4e0b;&#xff0c;&#x5f53;&#x6211;&#x4eec;&#x9700;&#x8981;&#x4ece;&#x591a;&#x4e2a;&#x8f93;&#x5165;&#x6d41;&#x4e2d;&#x5411;&#x7a0b;&#x5e8f;&#x8bfb;&#x5165;&#x6570;&#x636e;&#x3002;&#x6b64;&#x65f6;&#xff0c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;&#x5408;&#x5e76;&#x6d41;&#xff0c;&#x5c06;&#x591a;&#x4e2a;&#x8f93;&#x5165;&#x6d41;&#x5408;&#x5e76;&#x6210;&#x4e00;&#x4e2a;SequenceInputStream&#x6d41;&#x5bf9;&#x8c61;&#x3002;SequenceInputStream&#x4f1a;&#x5c06;&#x4e0e;&#x4e4b;&#x76f8;&#x8fde;&#x63a5;&#x7684;&#x6d41;&#x96c6;&#x7ec4;&#x5408;&#x6210;&#x4e00;&#x4e2a;&#x8f93;&#x5165;&#x6d41;&#x5e76;&#x4ece;&#x7b2c;&#x4e00;&#x4e2a;&#x8f93;&#x5165;&#x6d41;&#x5f00;&#x59cb;&#x8bfb;&#x53d6;&#xff0c;&#x76f4;&#x5230;&#x5230;&#x8fbe;&#x6587;&#x4ef6;&#x672b;&#x5c3e;&#xff0c;&#x63a5;&#x7740;&#x4ece;&#x7b2c;&#x4e8c;&#x4e2a;&#x8f93;&#x5165;&#x6d41;&#x8bfb;&#x53d6;&#xff0c;&#x4f9d;&#x6b21;&#x7c7b;&#x63a8;&#xff0c;&#x76f4;&#x5230;&#x5230;&#x8fbe;&#x5305;&#x542b;&#x7684;&#x6700;&#x540e;&#x4e00;&#x4e2a;&#x8f93;&#x5165;&#x6d41;&#x7684;&#x6587;&#x4ef6;&#x672b;&#x5c3e;&#x4e3a;&#x6b62;&#x3002; &#x5408;&#x5e76;&#x6d41;&#x7684;&#x4f5c;&#x7528;&#x662f;&#x5c06;&#x591a;&#x4e2a;&#x6e90;&#x5408;&#x5e76;&#x5408;&#x4e00;&#x4e2a;&#x6e90;&#x3002;&#x5176;&#x53ef;&#x63a5;&#x6536;&#x679a;&#x4e3e;&#x7c7b;&#x6240;&#x5c01;&#x95ed;&#x7684;&#x591a;&#x4e2a;&#x5b57;&#x8282;&#x6d41;&#x5bf9;&#x8c61;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495260468950" FOLDED="true" ID="ID_1072707030" MODIFIED="1529657528239" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495260539486" ID="ID_1594691442" MODIFIED="1495260539486" TEXT="public SequenceInputStream(Enumeration&lt;? extends InputStream&gt; e)"/>
<node COLOR="#111111" CREATED="1495260539487" ID="ID_1405628537" MODIFIED="1495260539487" TEXT="public SequenceInputStream(InputStream s1, InputStream s2)"/>
</node>
<node COLOR="#111111" CREATED="1495260471391" FOLDED="true" ID="ID_1390436471" MODIFIED="1529657528239" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495260545396" ID="ID_537485447" MODIFIED="1495260545396" TEXT="public int available() throws IOException"/>
<node COLOR="#111111" CREATED="1495260545397" ID="ID_1823832530" MODIFIED="1495260545397" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495260545402" ID="ID_214730217" MODIFIED="1495260545403" TEXT="public int read(byte b[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495260545403" ID="ID_53099350" MODIFIED="1495260545403" TEXT="public void close() throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495247581275" FOLDED="true" ID="ID_535813254" MODIFIED="1529657528239" TEXT="ByteArrayInputStream">
<node COLOR="#111111" CREATED="1495260674609" FOLDED="true" ID="ID_1197287713" MODIFIED="1529657528239" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495260677224" ID="ID_1683096934" MODIFIED="1495260677224" TEXT="public ByteArrayInputStream(byte buf[])"/>
<node COLOR="#111111" CREATED="1495260677224" ID="ID_1281442678" MODIFIED="1495260677225" TEXT="public ByteArrayInputStream(byte buf[], int offset, int length)"/>
</node>
<node COLOR="#111111" CREATED="1495260677871" FOLDED="true" ID="ID_596154013" MODIFIED="1529657528239" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495260684093" ID="ID_1106078648" MODIFIED="1495260684094" TEXT="public synchronized int read()"/>
<node COLOR="#111111" CREATED="1495260684094" ID="ID_1041629316" MODIFIED="1495260684095" TEXT="public synchronized int read(byte b[], int off, int len)"/>
<node COLOR="#111111" CREATED="1495260684095" ID="ID_684544736" MODIFIED="1495260684095" TEXT="public synchronized long skip(long n)"/>
<node COLOR="#111111" CREATED="1495260684096" ID="ID_1496991008" MODIFIED="1495260684096" TEXT="public synchronized int available()"/>
<node COLOR="#111111" CREATED="1495260684097" ID="ID_950398010" MODIFIED="1495260684097" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495260684098" ID="ID_346629573" MODIFIED="1495260684098" TEXT="public void mark(int readAheadLimit)"/>
<node COLOR="#111111" CREATED="1495260684099" ID="ID_1931909905" MODIFIED="1495260684099" TEXT="public synchronized void reset()"/>
<node COLOR="#111111" CREATED="1495260684100" ID="ID_427670754" MODIFIED="1495260684100" TEXT="public void close() throws IOException"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495249429954" FOLDED="true" ID="ID_1642360324" MODIFIED="1529657528240" TEXT="&#x516c;&#x5171;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495249590040" FOLDED="true" ID="ID_617783010" MODIFIED="1529657528240" TEXT="public abstract int read() throws IOException">
<node COLOR="#111111" CREATED="1495249595301" ID="ID_1051651759" MODIFIED="1495249608806" TEXT="&#x4ece;&#x8f93;&#x5165;&#x6d41;&#x4e2d;&#x8bfb;&#x53d6;&#x4e0b;&#x4e00;&#x4e2a;&#x5b57;&#x8282;"/>
<node COLOR="#111111" CREATED="1495249761417" ID="ID_1437334246" MODIFIED="1495249802205" TEXT="&#x8fd4;&#x56de;&#x503c;int &#x4ee3;&#x8868;&#x5f53;&#x6b21;&#x8bfb;&#x53d6;&#x7684;&#x5b57;&#x8282;&#x6570;, -1&#x5219;&#x4ee3;&#x8868;&#x6587;&#x4ef6;&#x672b;&#x5c3e;,&#x6ca1;&#x6709;&#x6570;&#x636e;&#x53ef;&#x8bfb;&#x4e86;"/>
</node>
<node COLOR="#111111" CREATED="1495249451202" FOLDED="true" ID="ID_762771729" MODIFIED="1529657528240" TEXT="public int read(byte b[]) throws IOException">
<node COLOR="#111111" CREATED="1495249655636" ID="ID_1445915673" MODIFIED="1495249701008" TEXT="&#x4ece;&#x8bfb;&#x53d6;&#x548c;&#x53c2;&#x6570; b[ ] &#x957f;&#x5ea6;&#x4e00;&#x81f4;&#x7684;&#x5b57;&#x8282;,&#x5e76;&#x4e14;&#x628a;&#x81ea;&#x5df1;&#x5b58;&#x50a8;&#x5230; b[ ] &#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1495249451203" FOLDED="true" ID="ID_1569758206" MODIFIED="1529657528240" TEXT="public int read(byte b[], int off, int len) throws IOException">
<node COLOR="#111111" CREATED="1495250371804" ID="ID_146502798" MODIFIED="1495250395567" TEXT="&#x4ece; off&#x4f4d;&#x7f6e;&#x5f00;&#x59cb;,&#x8bfb;&#x53d6;len&#x4e2a;&#x5b57;&#x8282;&#x5230; b[] &#x4e2d;"/>
<node COLOR="#111111" CREATED="1495250510786" FOLDED="true" ID="ID_753490280" MODIFIED="1529657528240">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21442;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495250397293" FOLDED="true" ID="ID_432689353" MODIFIED="1529657528240" TEXT="off">
<node COLOR="#111111" CREATED="1495250399953" ID="ID_717173875" MODIFIED="1495250455226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20559;&#31227;&#37327;,&#25226;&#35835;&#21462;&#30340;&#25968;&#25454;&#20174;&#25968;&#32452;b[]&#30340;&#20160;&#20040;&#20301;&#32622;&#24320;&#22987;&#23384;&#25918;&#21040; b[ ]&#20013;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495250457877" FOLDED="true" ID="ID_802095176" MODIFIED="1529657528240" TEXT="len">
<node COLOR="#111111" CREATED="1495250462287" ID="ID_1685194449" MODIFIED="1495250475114" TEXT="&#x5355;&#x6b21;&#x8bfb;&#x53d6;&#x7684;&#x5b57;&#x8282;&#x957f;&#x5ea6;"/>
</node>
<node COLOR="#111111" CREATED="1495250477754" ID="ID_649745768" MODIFIED="1495250503265" TEXT="b[ ] &#x5b58;&#x50a8;&#x4ece;&#x8f93;&#x5165;&#x6d41;&#x4e2d;&#x8bfb;&#x51fa;&#x6765;&#x7684;&#x5b57;&#x8282;&#x7684;&#x6570;&#x7ec4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495249451203" FOLDED="true" ID="ID_1033372249" MODIFIED="1529657528240" TEXT="public long skip(long n) throws IOException">
<node COLOR="#111111" CREATED="1495250607982" ID="ID_1479788005" MODIFIED="1495250641912" TEXT="&#x8df3;&#x8fc7; &#x53c2;&#x6570; n &#x957f;&#x5ea6;&#x7684;&#x6570;&#x636e;,&#x7136;&#x540e;&#x5f00;&#x59cb;&#x8bfb;&#x53d6;"/>
</node>
<node COLOR="#111111" CREATED="1495249451204" FOLDED="true" ID="ID_1599017398" MODIFIED="1529657528240" TEXT="public int available() throws IOException">
<node COLOR="#111111" CREATED="1495250816022" ID="ID_1502638567" MODIFIED="1495250827183" TEXT="&#x8fd4;&#x56de;&#x53ef;&#x8bfb;&#x5b57;&#x8282;&#x7684;&#x6570;&#x91cf;"/>
</node>
<node COLOR="#111111" CREATED="1495249451204" FOLDED="true" ID="ID_1359817570" MODIFIED="1529657528240" TEXT="public synchronized void reset() throws IOException">
<node COLOR="#111111" CREATED="1495251125149" ID="ID_1743141855" MODIFIED="1495251132250" TEXT="&#x6062;&#x590d;&#x6807;&#x8bb0;"/>
<node COLOR="#111111" CREATED="1495251309854" ID="ID_228546097" MODIFIED="1495251333626" TEXT="&#x7136;&#x540e;&#x53ef;&#x4ee5;&#x91cd;&#x65b0;&#x4ece;&#x6807;&#x8bb0;&#x7684;&#x4f4d;&#x7f6e;&#x5f00;&#x59cb;&#x65b0;&#x4e00;&#x8f6e;&#x7684;&#x8bfb;&#x53d6;&#x64cd;&#x4f5c;"/>
<node COLOR="#111111" CREATED="1495251341670" ID="ID_1480206396" MODIFIED="1495251374342" TEXT="&#x5e76;&#x4e0d;&#x662f;&#x6240;&#x6709;InputStream&#x7684;&#x5b50;&#x7c7b;&#x90fd;&#x5177;&#x5907;&#x8be5;&#x529f;&#x80fd;"/>
</node>
<node COLOR="#111111" CREATED="1495249451205" FOLDED="true" ID="ID_878360743" MODIFIED="1529657528240" TEXT="public boolean markSupported()">
<node COLOR="#111111" CREATED="1495251082054" ID="ID_852027019" MODIFIED="1495251108390" TEXT="&#x662f;&#x5426;&#x662f;&#x53ef;&#x6807;&#x8bb0;&#x7684;,&#x53ef;&#x4ee5;&#x7528;&#x8bb0;&#x53f7;&#x6765;&#x6807;&#x8bb0;&#x6d41;&#x4e2d;&#x7684;&#x6570;&#x636e;"/>
<node COLOR="#111111" CREATED="1495251341670" ID="ID_1965791143" MODIFIED="1495251374342" TEXT="&#x5e76;&#x4e0d;&#x662f;&#x6240;&#x6709;InputStream&#x7684;&#x5b50;&#x7c7b;&#x90fd;&#x5177;&#x5907;&#x8be5;&#x529f;&#x80fd;"/>
</node>
<node COLOR="#111111" CREATED="1495250855337" FOLDED="true" ID="ID_1912903413" MODIFIED="1529657528240" TEXT="public void close() throws IOException">
<node COLOR="#111111" CREATED="1495250857072" ID="ID_953597009" MODIFIED="1495250860470" TEXT="&#x5173;&#x95ed;&#x6d41;"/>
</node>
<node COLOR="#111111" CREATED="1495250877604" FOLDED="true" ID="ID_1501260178" MODIFIED="1529657528240" TEXT="public synchronized void mark(int readlimit)">
<node COLOR="#111111" CREATED="1495251217623" ID="ID_1540158863" MODIFIED="1495251217624" TEXT="&#x7528;&#x4e8e;&#x6807;&#x8bb0;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;&#xff1b;&#x5728;&#x8bfb;&#x53d6;&#x4e00;&#x5b9a;&#x6570;&#x91cf;&#x7684;&#x6570;&#x636e;(&#x5c0f;&#x4e8e;readlimit&#x7684;&#x6570;&#x636e;)&#x540e;&#x4f7f;&#x7528;reset&#x53ef;&#x4ee5;&#x56de;&#x5230;mark&#x6807;&#x8bb0;&#x7684;&#x4f4d;&#x7f6e;&#x3002;"/>
<node COLOR="#111111" CREATED="1495251341670" ID="ID_884051879" MODIFIED="1495251374342" TEXT="&#x5e76;&#x4e0d;&#x662f;&#x6240;&#x6709;InputStream&#x7684;&#x5b50;&#x7c7b;&#x90fd;&#x5177;&#x5907;&#x8be5;&#x529f;&#x80fd;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495247681409" FOLDED="true" ID="ID_294412193" MODIFIED="1529657528241" TEXT="OutputStream">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495260916515" FOLDED="true" ID="ID_783073799" MODIFIED="1529657528241">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23376;&#31867;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495248072932" FOLDED="true" ID="ID_189069912" MODIFIED="1529657528240" TEXT="FileOutputStream">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495261026875" FOLDED="true" ID="ID_1422359551" MODIFIED="1529657528240" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495261061771" ID="ID_1875715148" MODIFIED="1495261061771" TEXT="public FileOutputStream(String name) throws FileNotFoundException"/>
<node COLOR="#111111" CREATED="1495261061772" ID="ID_1919314029" MODIFIED="1495261061772" TEXT="public FileOutputStream(File file) throws FileNotFoundException"/>
<node COLOR="#111111" CREATED="1495261061773" ID="ID_1785813648" MODIFIED="1495261061773" TEXT="public FileOutputStream(FileDescriptor fdObj)"/>
</node>
<node COLOR="#111111" CREATED="1495261029589" FOLDED="true" ID="ID_1473333266" MODIFIED="1529657528240" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495261082255" FOLDED="true" ID="ID_857578811" MODIFIED="1529657528240" TEXT="public FileChannel getChannel()">
<node COLOR="#111111" CREATED="1495261085871" ID="ID_1972966239" MODIFIED="1495261096776" TEXT="&#x89c1;NIO&#x7684;FileChannel"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495248082071" FOLDED="true" ID="ID_183584899" MODIFIED="1529657528240" TEXT="FilterOutputStream">
<node COLOR="#111111" CREATED="1495261326062" FOLDED="true" ID="ID_119652688" MODIFIED="1529657528240" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1495261356543" ID="ID_1765452211" MODIFIED="1495530150824" TEXT="BufferedOutputStream">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1495261383072" ID="ID_1154293111" MODIFIED="1495261383072" TEXT="DataOutputStream"/>
<node COLOR="#111111" CREATED="1495261619418" ID="ID_1452897148" MODIFIED="1495261619418" TEXT="ZipOutputStream"/>
</node>
<node COLOR="#111111" CREATED="1495261214022" FOLDED="true" ID="ID_981831473" MODIFIED="1529657528240" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495261216204" ID="ID_604998318" MODIFIED="1495261216204" TEXT="public FilterOutputStream(OutputStream out)"/>
</node>
<node COLOR="#111111" CREATED="1495261234102" ID="ID_808294340" MODIFIED="1495261289167" TEXT="&#x65b9;&#x6cd5;&#x540c;&#x7236;&#x7c7b;&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1495248092904" FOLDED="true" ID="ID_1366736662" MODIFIED="1529657528241" TEXT="ObjectOutputStream">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495261815867" FOLDED="true" ID="ID_1095281836" MODIFIED="1529657528240" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495261817449" ID="ID_1397595350" MODIFIED="1495261817450" TEXT="public ObjectOutputStream(OutputStream out) throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495261843786" FOLDED="true" ID="ID_679033727" MODIFIED="1529657528241" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495261845083" ID="ID_488273358" MODIFIED="1495261845083" TEXT="public void useProtocolVersion(int version) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845084" ID="ID_1583154941" MODIFIED="1495261845084" TEXT="public final void writeObject(Object obj) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845084" FOLDED="true" ID="ID_1341941555" MODIFIED="1529657528240" TEXT="public void writeUnshared(Object obj) throws IOException">
<node COLOR="#111111" CREATED="1495262218338" ID="ID_437359115" MODIFIED="1495262222153" TEXT="&#x5f85;&#x7eed;"/>
</node>
<node COLOR="#111111" CREATED="1495261845085" ID="ID_575516489" MODIFIED="1495261845085" TEXT="public void defaultWriteObject() throws IOException"/>
<node COLOR="#111111" CREATED="1495261845088" FOLDED="true" ID="ID_691685386" MODIFIED="1529657528240" TEXT="public ObjectOutputStream.PutField putFields() throws IOException">
<node COLOR="#111111" CREATED="1495262558523" ID="ID_1892231725" MODIFIED="1495262580930" TEXT="&#x5f97;&#x5230;&#x4e00;&#x4e2a;PutFiled&#x5bf9;&#x8c61;"/>
<node COLOR="#111111" CREATED="1495262689318" ID="ID_1562637366" MODIFIED="1495262689319" TEXT="&#x4e00;&#x822c;&#x7684;&#x5e8f;&#x5217;&#x5316;&#x65b9;&#x6cd5;&#x90fd;&#x662f;&#x901a;&#x8fc7;OjbectOuputStream&#x7684;writeInt/writeObject&#x7b49;&#x65b9;&#x6cd5;&#x6765;&#x5e8f;&#x5217;&#x5316;&#xff0c;&#x7136;&#x540e;&#x5bf9;&#x5e94;&#x7684;readInt/readObject&#x7b49;&#x65b9;&#x6cd5;&#x6765;&#x53cd;&#x5e8f;&#x5217;&#x5316;&#x3002;&#x5e8f;&#x5217;&#x5316;&#x548c;&#x53cd;&#x5e8f;&#x5217;&#x5316;&#x7684;&#x65f6;&#x5019;&#xff0c;&#x8bfb;&#x5199;&#x64cd;&#x4f5c;&#x987a;&#x5e8f;&#x5fc5;&#x987b;&#x4e00;&#x81f4;&#x3002;"/>
<node COLOR="#111111" CREATED="1495262689324" ID="ID_32270029" MODIFIED="1495262689325" TEXT="&#x8fd9;&#x91cc;&#x7684;PutField/GetField&#x63d0;&#x4f9b;&#x4e86;&#x4e00;&#x79cd;key/value&#x7684;&#x5f62;&#x5f0f;&#x6765;&#x5199;&#x5165;/&#x8bfb;&#x51fa;&#x5bf9;&#x5e94;&#x7684;&#x5b57;&#x6bb5;&#x7684;&#x65b9;&#x6cd5;&#x3002;&#x8fd9;&#x6837;&#x5199;&#x5165;&#x8bfb;&#x51fa;&#x7684;&#x65f6;&#x5019;&#xff0c;&#x5c31;&#x53ef;&#x4ee5;&#x4e0d;&#x5fc5;&#x5b8c;&#x5168;&#x4e00;&#x6837;&#x7684;&#x987a;&#x5e8f;&#x3002;"/>
<node COLOR="#111111" CREATED="1495263339997" FOLDED="true" ID="ID_825152033" MODIFIED="1529657528240" TEXT="&#x5185;&#x90e8;&#x7c7b;PutField">
<node COLOR="#111111" CREATED="1495262585624" ID="ID_811711398" MODIFIED="1495263381477" TEXT="PutField&#x53ef;&#x4ee5;&#x901a;&#x8fc7;key/value&#x5bf9;&#x513f;&#x7684;&#x65b9;&#x5f0f;&#x628a;Object&#x7684;&#x5c5e;&#x6027;&#x5b58;&#x5230;&#x7f13;&#x51b2;&#x533a;,&#x7c7b;&#x4f3c;&#x4e8e;Json"/>
<node COLOR="#111111" CREATED="1495263354309" FOLDED="true" ID="ID_1046315394" MODIFIED="1529657528240" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495263357067" ID="ID_834142818" MODIFIED="1495263357067" TEXT="public abstract void put(String name, boolean val)"/>
<node COLOR="#111111" CREATED="1495263357068" ID="ID_324210323" MODIFIED="1495263357068" TEXT="public abstract void put(String name, byte val)"/>
<node COLOR="#111111" CREATED="1495263357068" ID="ID_562153827" MODIFIED="1495263357068" TEXT="public abstract void put(String name, char val)"/>
<node COLOR="#111111" CREATED="1495263357069" ID="ID_71057011" MODIFIED="1495263357069" TEXT="public abstract void put(String name, short val)"/>
<node COLOR="#111111" CREATED="1495263357070" ID="ID_1355588036" MODIFIED="1495263357070" TEXT="public abstract void put(String name, int val)"/>
<node COLOR="#111111" CREATED="1495263357070" ID="ID_1040319730" MODIFIED="1495263357071" TEXT="public abstract void put(String name, long val)"/>
<node COLOR="#111111" CREATED="1495263357074" ID="ID_1645263018" MODIFIED="1495263357074" TEXT="public abstract void put(String name, float val)"/>
<node COLOR="#111111" CREATED="1495263357075" ID="ID_771641646" MODIFIED="1495263357075" TEXT="public abstract void put(String name, double val)"/>
<node COLOR="#111111" CREATED="1495263357076" ID="ID_1259815529" MODIFIED="1495263357076" TEXT="public abstract void put(String name, Object val)"/>
<node COLOR="#111111" CREATED="1495263357076" ID="ID_676468400" MODIFIED="1495263357076" TEXT="public abstract void write(ObjectOutput out) throws IOException"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495261845090" FOLDED="true" ID="ID_615855881" MODIFIED="1529657528240" TEXT="public void writeFields() throws IOException">
<node COLOR="#111111" CREATED="1495262636848" ID="ID_1240218271" MODIFIED="1495262669177" TEXT="&#x628a;PutField&#x4e2d;&#x7684;&#x5c5e;&#x6027;&#x4e00;&#x6b21;&#x6027;&#x5199;&#x5165;&#x5230;&#x6587;&#x4ef6;&#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1495261845091" ID="ID_1914152737" MODIFIED="1495261845091" TEXT="public void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495261845096" ID="ID_1496381067" MODIFIED="1495261845096" TEXT="public void writeBoolean(boolean val) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845097" ID="ID_1861032684" MODIFIED="1495261845097" TEXT="public void writeByte(int val) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845097" ID="ID_863894456" MODIFIED="1495261845098" TEXT="public void writeShort(int val)  throws IOException"/>
<node COLOR="#111111" CREATED="1495261845098" ID="ID_1272652556" MODIFIED="1495261845098" TEXT="public void writeChar(int val)  throws IOException"/>
<node COLOR="#111111" CREATED="1495261845099" ID="ID_1661710112" MODIFIED="1495261845099" TEXT="public void writeInt(int val)  throws IOException"/>
<node COLOR="#111111" CREATED="1495261845099" ID="ID_12619681" MODIFIED="1495261845099" TEXT="public void writeLong(long val)  throws IOException"/>
<node COLOR="#111111" CREATED="1495261845100" ID="ID_250198609" MODIFIED="1495261845100" TEXT="public void writeFloat(float val) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845100" ID="ID_1251992089" MODIFIED="1495261845101" TEXT="public void writeDouble(double val) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845101" ID="ID_1140683919" MODIFIED="1495261845101" TEXT="public void writeBytes(String str) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845102" ID="ID_1748252569" MODIFIED="1495261845102" TEXT="public void writeChars(String str) throws IOException"/>
<node COLOR="#111111" CREATED="1495261845102" ID="ID_1702863311" MODIFIED="1495261845102" TEXT="public void writeUTF(String str) throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495248100580" FOLDED="true" ID="ID_176121380" MODIFIED="1529657528241" TEXT="PipeOutputStream">
<node COLOR="#111111" CREATED="1495260337087" FOLDED="true" ID="ID_688805015" MODIFIED="1529657528241" TEXT="?">
<node COLOR="#111111" CREATED="1495260340812" ID="ID_408213907" MODIFIED="1495263521103" TEXT="&#x7ba1;&#x9053;&#x8f93;&#x51fa;&#x6d41;,&#x9700;&#x8981;&#x548c;&#x4e00;&#x4e2a;&#x5176;&#x4ed6;&#x7ebf;&#x7a0b;&#x7ef4;&#x62a4;&#x7684;&#x7ba1;&#x9053;&#x8f93;&#x4eba;&#x6d41;&#x8054;&#x7cfb;&#x8d77;&#x6765;&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#111111" CREATED="1495263464243" FOLDED="true" ID="ID_1866995817" MODIFIED="1529657528241" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495263466361" ID="ID_220806084" MODIFIED="1495263466361" TEXT="public PipedOutputStream(PipedInputStream snk)  throws IOException"/>
<node COLOR="#111111" CREATED="1495263466362" ID="ID_1182138379" MODIFIED="1495263466362" TEXT="public PipedOutputStream()"/>
</node>
<node COLOR="#111111" CREATED="1495263471672" FOLDED="true" ID="ID_513029827" MODIFIED="1529657528241" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495263472669" ID="ID_1717705330" MODIFIED="1495263472669" TEXT="public synchronized void connect(PipedInputStream snk) throws IOException"/>
<node COLOR="#111111" CREATED="1495263472670" ID="ID_76100200" MODIFIED="1495263472670" TEXT="public void write(int b)  throws IOException"/>
<node COLOR="#111111" CREATED="1495263472671" ID="ID_1197878282" MODIFIED="1495263472671" TEXT="public void write(byte b[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495263472679" ID="ID_863948953" MODIFIED="1495263472679" TEXT="public synchronized void flush() throws IOException"/>
<node COLOR="#111111" CREATED="1495263472680" ID="ID_1257291838" MODIFIED="1495263472680" TEXT="public void close()  throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495248108005" FOLDED="true" ID="ID_1604243661" MODIFIED="1529657528241" TEXT="ByteArrayOutputStream">
<node COLOR="#111111" CREATED="1495263563295" FOLDED="true" ID="ID_128440597" MODIFIED="1529657528241" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495263565567" ID="ID_1916156893" MODIFIED="1495263565567" TEXT="public ByteArrayOutputStream()"/>
<node COLOR="#111111" CREATED="1495263565569" ID="ID_476158030" MODIFIED="1495263565569" TEXT="public ByteArrayOutputStream(int size)"/>
</node>
<node COLOR="#111111" CREATED="1495263572398" FOLDED="true" ID="ID_1700648553" MODIFIED="1529657528241" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495263574022" ID="ID_82992608" MODIFIED="1495263574022" TEXT="public synchronized void write(int b)"/>
<node COLOR="#111111" CREATED="1495263574022" ID="ID_434169045" MODIFIED="1495263574023" TEXT="public synchronized void write(byte b[], int off, int len)"/>
<node COLOR="#111111" CREATED="1495263574023" ID="ID_1569656202" MODIFIED="1495263574023" TEXT="public synchronized void writeTo(OutputStream out) throws IOException"/>
<node COLOR="#111111" CREATED="1495263574027" ID="ID_1908327882" MODIFIED="1495263574027" TEXT="public synchronized void reset()"/>
<node COLOR="#111111" CREATED="1495263574028" ID="ID_284488301" MODIFIED="1495263574028" TEXT="public synchronized byte toByteArray()[]"/>
<node COLOR="#111111" CREATED="1495263574029" ID="ID_438021590" MODIFIED="1495263574029" TEXT="public synchronized int size()"/>
<node COLOR="#111111" CREATED="1495263574029" ID="ID_952274984" MODIFIED="1495263574030" TEXT="public synchronized String toString()"/>
<node COLOR="#111111" CREATED="1495263574030" ID="ID_543032683" MODIFIED="1495263574030" TEXT="public synchronized String toString(int hibyte)"/>
<node COLOR="#111111" CREATED="1495263574031" ID="ID_1311437246" MODIFIED="1495263574031" TEXT="public void close() throws IOException"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495260921402" FOLDED="true" ID="ID_333733601" MODIFIED="1529657528241">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20844;&#20849;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495261263348" ID="ID_682639651" MODIFIED="1495261265623" TEXT="public abstract void write(int b) throws IOException"/>
<node COLOR="#111111" CREATED="1495260925164" ID="ID_209892399" MODIFIED="1495260925164" TEXT="public void write(byte b[]) throws IOException"/>
<node COLOR="#111111" CREATED="1495260925166" ID="ID_1497983823" MODIFIED="1495260925167" TEXT="public void write(byte b[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495260925172" ID="ID_12596566" MODIFIED="1495260925172" TEXT="public void flush() throws IOException"/>
<node COLOR="#111111" CREATED="1495260925173" ID="ID_1297997695" MODIFIED="1495260925173" TEXT="public void close() throws IOException"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495247444346" FOLDED="true" ID="ID_1780706136" MODIFIED="1529657528245" TEXT="&#x5b57;&#x7b26;&#x6d41;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495264950380" FOLDED="true" ID="ID_1040918435" MODIFIED="1529657528243">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Reader&#25277;&#35937;&#31867;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495264953569" FOLDED="true" ID="ID_1419088861" MODIFIED="1529657528242" TEXT="&#x516c;&#x5171;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495264958942" FOLDED="true" ID="ID_1374851873" MODIFIED="1529657528241" TEXT="public int read(java.nio.CharBuffer target) throws IOException">
<node COLOR="#111111" CREATED="1495264981777" ID="ID_1403960262" MODIFIED="1495264995319" TEXT="CharBuffer &#x89c1;NIO&#x8282;&#x70b9;"/>
</node>
<node COLOR="#111111" CREATED="1495264958943" ID="ID_25445268" MODIFIED="1495264958943" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495264958943" ID="ID_115177031" MODIFIED="1495264958943" TEXT="public int read(char cbuf[]) throws IOException"/>
<node COLOR="#111111" CREATED="1495264958944" ID="ID_901033402" MODIFIED="1495264958944" TEXT="public long skip(long n) throws IOException"/>
<node COLOR="#111111" CREATED="1495264958945" ID="ID_88609845" MODIFIED="1495264958945" TEXT="public boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495264958951" ID="ID_938774410" MODIFIED="1495264958951" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495264958953" ID="ID_1583321036" MODIFIED="1495264958953" TEXT="public void mark(int readAheadLimit) throws IOException"/>
<node COLOR="#111111" CREATED="1495264958954" ID="ID_756782640" MODIFIED="1495264958954" TEXT="public void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495264967961" ID="ID_147373417" MODIFIED="1495264967961" TEXT="abstract public void close() throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495265016867" FOLDED="true" ID="ID_1811837223" MODIFIED="1529657528243" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1495265092980" FOLDED="true" ID="ID_1602189794" MODIFIED="1529657528242" TEXT="BufferedReader">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495265100982" FOLDED="true" ID="ID_86718208" MODIFIED="1529657528242" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495265105241" ID="ID_1551330883" MODIFIED="1495265105241" TEXT="public BufferedReader(Reader in, int sz)"/>
<node COLOR="#111111" CREATED="1495265105242" ID="ID_1567582645" MODIFIED="1495265105242" TEXT="public BufferedReader(Reader in)"/>
</node>
<node COLOR="#111111" CREATED="1495265106183" FOLDED="true" ID="ID_1513212270" MODIFIED="1529657528242" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495265112732" ID="ID_686936466" MODIFIED="1495265112732" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495265112732" ID="ID_92368723" MODIFIED="1495265112733" TEXT="public int read(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495265112733" ID="ID_1749132665" MODIFIED="1495592306315" TEXT="public String readLine() throws IOException">
<icon BUILTIN="button_ok"/>
</node>
<node COLOR="#111111" CREATED="1495265112733" ID="ID_180505657" MODIFIED="1495265112733" TEXT="public long skip(long n) throws IOException"/>
<node COLOR="#111111" CREATED="1495265112733" ID="ID_554514853" MODIFIED="1495265112733" TEXT="public boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495265112734" ID="ID_142924503" MODIFIED="1495265112734" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495265112734" ID="ID_1406140703" MODIFIED="1495265112734" TEXT="public void mark(int readAheadLimit) throws IOException"/>
<node COLOR="#111111" CREATED="1495265112734" ID="ID_147446009" MODIFIED="1495265112734" TEXT="public void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495265112734" ID="ID_1736919868" MODIFIED="1495265112734" TEXT="public void close() throws IOException"/>
<node COLOR="#111111" CREATED="1495265112734" FOLDED="true" ID="ID_187917703" MODIFIED="1529657528242" TEXT="public Stream&lt;String&gt; lines()">
<node COLOR="#111111" CREATED="1495265120367" ID="ID_747449073" MODIFIED="1495265130409" TEXT="Stream&#x89c1;NIO&#x7684;Stream"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495265187254" FOLDED="true" ID="ID_1082165531" MODIFIED="1529657528242" TEXT="InputStreamReader">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495265193212" FOLDED="true" ID="ID_1734756075" MODIFIED="1529657528242" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495265194752" ID="ID_615992550" MODIFIED="1495265194752" TEXT="public InputStreamReader(InputStream in)"/>
<node COLOR="#111111" CREATED="1495265194753" ID="ID_1272639728" MODIFIED="1495265194753" TEXT="public InputStreamReader(InputStream in, Charset cs)"/>
<node COLOR="#111111" CREATED="1495265194754" ID="ID_21450978" MODIFIED="1495265194754" TEXT="public InputStreamReader(InputStream in, CharsetDecoder dec)"/>
</node>
<node COLOR="#111111" CREATED="1495265195118" FOLDED="true" ID="ID_700589736" MODIFIED="1529657528242" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495265199627" ID="ID_1154416565" MODIFIED="1495265199627" TEXT="public String getEncoding()"/>
<node COLOR="#111111" CREATED="1495265199628" ID="ID_631730701" MODIFIED="1495265199628" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495265199628" ID="ID_1802802142" MODIFIED="1495265199628" TEXT="public int read(char cbuf[], int offset, int length) throws IOException"/>
<node COLOR="#111111" CREATED="1495265199630" ID="ID_1900908344" MODIFIED="1495265199630" TEXT="public boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495265199630" ID="ID_1617829739" MODIFIED="1495265199630" TEXT="public void close() throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495268750185" FOLDED="true" ID="ID_517984190" MODIFIED="1529657528242" TEXT="CharArrayReader">
<node COLOR="#111111" CREATED="1495268763100" FOLDED="true" ID="ID_720263820" MODIFIED="1529657528242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268758252" ID="ID_1909334796" MODIFIED="1495268758252" TEXT="public CharArrayReader(char buf[])"/>
<node COLOR="#111111" CREATED="1495268758253" ID="ID_393057821" MODIFIED="1495268758253" TEXT="public CharArrayReader(char buf[], int offset, int length)"/>
</node>
<node COLOR="#111111" CREATED="1495268770137" FOLDED="true" ID="ID_375612996" MODIFIED="1529657528242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268758254" ID="ID_374725408" MODIFIED="1495268758254" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495268758254" ID="ID_81521031" MODIFIED="1495268758255" TEXT="public int read(char b[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495268758255" ID="ID_683721943" MODIFIED="1495268758255" TEXT="public long skip(long n) throws IOException"/>
<node COLOR="#111111" CREATED="1495268758256" ID="ID_899320796" MODIFIED="1495268758256" TEXT="public boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495268758257" ID="ID_1228369600" MODIFIED="1495268758257" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495268758258" ID="ID_933405411" MODIFIED="1495268758258" TEXT="public void mark(int readAheadLimit) throws IOException"/>
<node COLOR="#111111" CREATED="1495268758259" ID="ID_126439010" MODIFIED="1495268758259" TEXT="public void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495268758260" ID="ID_853601098" MODIFIED="1495268758261" TEXT="public void close()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495265361198" FOLDED="true" ID="ID_663526019" MODIFIED="1529657528242" TEXT="StringReader">
<node COLOR="#111111" CREATED="1495265375077" FOLDED="true" ID="ID_228208224" MODIFIED="1529657528242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495265371814" ID="ID_1521314484" MODIFIED="1495265371814" TEXT="public StringReader(String s)"/>
</node>
<node COLOR="#111111" CREATED="1495265383648" FOLDED="true" ID="ID_1714784624" MODIFIED="1529657528242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495265371815" ID="ID_506951857" MODIFIED="1495265371815" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495265371816" ID="ID_1106714421" MODIFIED="1495265371816" TEXT="public int read(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495265371817" ID="ID_995659583" MODIFIED="1495265371817" TEXT="public long skip(long ns) throws IOException"/>
<node COLOR="#111111" CREATED="1495265371817" ID="ID_1683906660" MODIFIED="1495265371817" TEXT="public boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495265371818" ID="ID_796199070" MODIFIED="1495265371818" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495265371819" ID="ID_1001690098" MODIFIED="1495265371819" TEXT="public void mark(int readAheadLimit) throws IOException"/>
<node COLOR="#111111" CREATED="1495265371820" ID="ID_1962739310" MODIFIED="1495265371820" TEXT="public void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495265371820" ID="ID_851870360" MODIFIED="1495265371821" TEXT="public void close()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495265433956" FOLDED="true" ID="ID_271713712" MODIFIED="1529657528242" TEXT="PipedReader">
<node COLOR="#111111" CREATED="1495265441261" FOLDED="true" ID="ID_1355384549" MODIFIED="1529657528242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495265438243" ID="ID_1578298488" MODIFIED="1495265438243" TEXT="public PipedReader(PipedWriter src) throws IOException"/>
<node COLOR="#111111" CREATED="1495265438244" ID="ID_1574475280" MODIFIED="1495265438244" TEXT="public PipedReader(PipedWriter src, int pipeSize) throws IOException"/>
<node COLOR="#111111" CREATED="1495265438245" ID="ID_1785328343" MODIFIED="1495265438245" TEXT="public PipedReader()"/>
</node>
<node COLOR="#111111" CREATED="1495265447945" FOLDED="true" ID="ID_1249640255" MODIFIED="1529657528242" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495265455233" ID="ID_1819398236" MODIFIED="1495265455233" TEXT="public void connect(PipedWriter src) throws IOException"/>
<node COLOR="#111111" CREATED="1495265455234" ID="ID_314690566" MODIFIED="1495265455234" TEXT="public synchronized int read()  throws IOException"/>
<node COLOR="#111111" CREATED="1495265455235" ID="ID_1373137698" MODIFIED="1495265455235" TEXT="public synchronized int read(char cbuf[], int off, int len)  throws IOException"/>
<node COLOR="#111111" CREATED="1495265455237" ID="ID_176034439" MODIFIED="1495265455238" TEXT="public synchronized boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495265455238" ID="ID_751076032" MODIFIED="1495265455238" TEXT="public void close()  throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495266517493" FOLDED="true" ID="ID_318796554" MODIFIED="1529657528243" TEXT="FilterReader&#x62bd;&#x8c61;&#x7c7b;">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495266538202" FOLDED="true" ID="ID_886136901" MODIFIED="1529657528242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20844;&#20849;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495266525032" ID="ID_616009870" MODIFIED="1495266525032" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495266525033" ID="ID_1902494283" MODIFIED="1495266525033" TEXT="public int read(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495266525034" ID="ID_1686703259" MODIFIED="1495266525034" TEXT="public long skip(long n) throws IOException"/>
<node COLOR="#111111" CREATED="1495266525035" ID="ID_1986607812" MODIFIED="1495266525035" TEXT="public boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495266525036" ID="ID_237942904" MODIFIED="1495266525036" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495266525037" ID="ID_1855607810" MODIFIED="1495266525037" TEXT="public void mark(int readAheadLimit) throws IOException"/>
<node COLOR="#111111" CREATED="1495266525038" ID="ID_1727996494" MODIFIED="1495266525038" TEXT="public void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495266525039" ID="ID_1304159275" MODIFIED="1495266525039" TEXT="public void close() throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495266559801" FOLDED="true" ID="ID_1810270670" MODIFIED="1529657528243" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1495266603810" FOLDED="true" ID="ID_1893997489" MODIFIED="1529657528243" TEXT="PushbackReader">
<node COLOR="#111111" CREATED="1495266614235" FOLDED="true" ID="ID_784313482" MODIFIED="1529657528242">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495266610497" ID="ID_701435045" MODIFIED="1495266610497" TEXT="public PushbackReader(Reader in, int size)"/>
<node COLOR="#111111" CREATED="1495266610498" ID="ID_1376416443" MODIFIED="1495266610498" TEXT="public PushbackReader(Reader in)"/>
</node>
<node COLOR="#111111" CREATED="1495266610504" ID="ID_590984529" MODIFIED="1495266610504" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495266610505" ID="ID_392755752" MODIFIED="1495266610505" TEXT="public int read(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495267188296" FOLDED="true" ID="ID_575982018" MODIFIED="1529657528243">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22238;&#36864;&#37325;&#22797;&#35835;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495266610506" FOLDED="true" ID="ID_1672975294" MODIFIED="1529657528243" TEXT="public void unread(int c) throws IOException">
<node COLOR="#111111" CREATED="1495267156926" ID="ID_223719810" MODIFIED="1495267156926" TEXT="&#x5c06;&#x4e00;&#x4e2a;&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x7684;&#x63a8;&#x56de;&#x5230;&#x63a8;&#x56de;&#x7f13;&#x51b2;&#x533a;&#x91cc;&#xff0c;&#x4ece;&#x800c;&#x5141;&#x8bb8;&#x91cd;&#x590d;&#x8bfb;&#x53d6;&#x521a;&#x521a;&#x8bfb;&#x53d6;&#x7684;&#x5185;&#x5bb9;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495266610506" FOLDED="true" ID="ID_5728088" MODIFIED="1529657528243" TEXT="public void unread(char cbuf[], int off, int len) throws IOException">
<node COLOR="#111111" CREATED="1495267152682" ID="ID_795402479" MODIFIED="1495267152682" TEXT="&#x5c06;&#x4e00;&#x4e2a;&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x6570;&#x7ec4;&#x91cc;&#x4ece;off&#x5f00;&#x59cb;&#xff0c;&#x957f;&#x5ea6;&#x4e3a;len&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x7684;&#x5185;&#x5bb9;&#x63a8;&#x56de;&#x5230;&#x63a8;&#x56de;&#x7f13;&#x51b2;&#x533a;&#x91cc;&#xff0c;&#x4ece;&#x800c;&#x5141;&#x8bb8;&#x91cd;&#x590d;&#x8bfb;&#x53d6;&#x521a;&#x521a;&#x8bfb;&#x53d6;&#x7684;&#x5185;&#x5bb9;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495266610507" FOLDED="true" ID="ID_1740908104" MODIFIED="1529657528243" TEXT="public void unread(char cbuf[]) throws IOException">
<node COLOR="#111111" CREATED="1495267145090" ID="ID_1633635333" MODIFIED="1495267145090" TEXT="&#x5c06;&#x4e00;&#x4e2a;&#x5b57;&#x8282;/&#x5b57;&#x7b26;&#x6570;&#x7ec4;&#x5185;&#x5bb9;&#x7684;&#x63a8;&#x56de;&#x5230;&#x63a8;&#x56de;&#x7f13;&#x51b2;&#x533a;&#x91cc;&#xff0c;&#x4ece;&#x800c;&#x5141;&#x8bb8;&#x91cd;&#x590d;&#x8bfb;&#x53d6;&#x521a;&#x521a;&#x8bfb;&#x53d6;&#x7684;&#x5185;&#x5bb9;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495266610508" ID="ID_4801557" MODIFIED="1495266610508" TEXT="public boolean ready() throws IOException"/>
<node COLOR="#111111" CREATED="1495266610511" ID="ID_1556119990" MODIFIED="1495266610511" TEXT="public void mark(int readAheadLimit) throws IOException"/>
<node COLOR="#111111" CREATED="1495266610511" ID="ID_1829067410" MODIFIED="1495266610511" TEXT="public void reset() throws IOException"/>
<node COLOR="#111111" CREATED="1495266610512" ID="ID_1508221898" MODIFIED="1495266610512" TEXT="public boolean markSupported()"/>
<node COLOR="#111111" CREATED="1495266610512" ID="ID_672178193" MODIFIED="1495266610512" TEXT="public void close() throws IOException"/>
<node COLOR="#111111" CREATED="1495266610512" ID="ID_1030877219" MODIFIED="1495266610512" TEXT="public long skip(long n) throws IOException"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495267944309" FOLDED="true" ID="ID_1980444948" MODIFIED="1529657528245" TEXT="Writer&#x62bd;&#x8c61;&#x7c7b;">
<node COLOR="#111111" CREATED="1495268476051" FOLDED="true" ID="ID_1277768429" MODIFIED="1529657528243">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20844;&#20849;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495267951767" ID="ID_482961087" MODIFIED="1495267951767" TEXT="public void write(int c) throws IOException"/>
<node COLOR="#111111" CREATED="1495267951768" ID="ID_915362006" MODIFIED="1495267951768" TEXT="public void write(char cbuf[]) throws IOException"/>
<node COLOR="#111111" CREATED="1495267951769" ID="ID_805687860" MODIFIED="1495267951769" TEXT="public void write(String str) throws IOException"/>
<node COLOR="#111111" CREATED="1495267951770" ID="ID_1080164942" MODIFIED="1495267951770" TEXT="public void write(String str, int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495267951771" FOLDED="true" ID="ID_399334835" MODIFIED="1529657528243" TEXT="public Writer append(CharSequence csq) throws IOException">
<node COLOR="#111111" CREATED="1495268033770" FOLDED="true" ID="ID_273934370" MODIFIED="1529657528243" TEXT="CharSequence">
<node COLOR="#111111" CREATED="1495268036302" ID="ID_687762396" MODIFIED="1495268059137" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x63a5;&#x53e3;,&#x5b9a;&#x4e49;&#x4e86;&#x5b57;&#x7b26;&#x5e8f;&#x5217;&#x7684;&#x6839;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495267951772" ID="ID_590569494" MODIFIED="1495267992826" TEXT="public Writer append(CharSequence csq, int start, int end) throws IOException"/>
<node COLOR="#111111" CREATED="1495267951772" ID="ID_1765672660" MODIFIED="1495267992827" TEXT="public Writer append(char c) throws IOException"/>
<node COLOR="#111111" CREATED="1495267951768" ID="ID_1701771272" MODIFIED="1495267967838" TEXT="abstract public void write(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495267951779" ID="ID_738049239" MODIFIED="1495267951779" TEXT="abstract public void flush() throws IOException"/>
<node COLOR="#111111" CREATED="1495267951780" ID="ID_1950600480" MODIFIED="1495267951781" TEXT="abstract public void close() throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495268486560" FOLDED="true" ID="ID_449892670" MODIFIED="1529657528245" TEXT="&#x5b50;&#x7c7b;">
<node COLOR="#111111" CREATED="1495268858611" FOLDED="true" ID="ID_333776293" MODIFIED="1529657528243" TEXT="OutputStreamWriter">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495268866578" FOLDED="true" ID="ID_525323367" MODIFIED="1529657528243">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268863698" ID="ID_852817060" MODIFIED="1495268863698" TEXT="public OutputStreamWriter(OutputStream out)"/>
<node COLOR="#111111" CREATED="1495268863703" ID="ID_808492356" MODIFIED="1495268863703" TEXT="public OutputStreamWriter(OutputStream out, Charset cs)"/>
<node COLOR="#111111" CREATED="1495268863704" ID="ID_546272325" MODIFIED="1495268863704" TEXT="public OutputStreamWriter(OutputStream out, CharsetEncoder enc)"/>
</node>
<node COLOR="#111111" CREATED="1495268877801" FOLDED="true" ID="ID_1596284303" MODIFIED="1529657528243">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268863705" ID="ID_868199788" MODIFIED="1495268863705" TEXT="public String getEncoding()"/>
<node COLOR="#111111" CREATED="1495268863706" ID="ID_1560750745" MODIFIED="1495268863707" TEXT="public void write(int c) throws IOException"/>
<node COLOR="#111111" CREATED="1495268863707" ID="ID_1143921607" MODIFIED="1495268863708" TEXT="public void write(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495268863709" ID="ID_1478875943" MODIFIED="1495268863709" TEXT="public void write(String str, int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495268863710" ID="ID_580551740" MODIFIED="1495268863710" TEXT="public void flush() throws IOException"/>
<node COLOR="#111111" CREATED="1495268863711" ID="ID_1826894603" MODIFIED="1495268863711" TEXT="public void close() throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495268533039" FOLDED="true" ID="ID_1890794319" MODIFIED="1529657528244" TEXT="BufferedWriter">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495268544680" FOLDED="true" ID="ID_1067250167" MODIFIED="1529657528243">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268541830" ID="ID_51593480" MODIFIED="1495268541830" TEXT="public BufferedWriter(Writer out)"/>
<node COLOR="#111111" CREATED="1495268541831" ID="ID_292963536" MODIFIED="1495268541831" TEXT="public BufferedWriter(Writer out, int sz)"/>
</node>
<node COLOR="#111111" CREATED="1495268550837" FOLDED="true" ID="ID_254081033" MODIFIED="1529657528243">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268541832" ID="ID_1917570464" MODIFIED="1495268541832" TEXT="public void write(int c) throws IOException"/>
<node COLOR="#111111" CREATED="1495268541832" ID="ID_1976953852" MODIFIED="1495268541832" TEXT="public void write(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495268541833" ID="ID_1535019769" MODIFIED="1495268541833" TEXT="public void write(String s, int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495268541834" FOLDED="true" ID="ID_168211995" MODIFIED="1529657528243" TEXT="public void newLine() throws IOException">
<node COLOR="#111111" CREATED="1495268622932" ID="ID_557545243" MODIFIED="1495268637180" TEXT="&#x5199;&#x5165;&#x4e00;&#x4e2a;&#x6362;&#x884c;&#x7b26; &apos;\n&apos;"/>
</node>
<node COLOR="#111111" CREATED="1495268541834" ID="ID_1479517472" MODIFIED="1495268541834" TEXT="public void flush() throws IOException"/>
<node COLOR="#111111" CREATED="1495268541835" ID="ID_1774523029" MODIFIED="1495268541835" TEXT="public void close() throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495268675395" FOLDED="true" ID="ID_516089042" MODIFIED="1529657528244" TEXT="CharArrayWriter">
<node COLOR="#111111" CREATED="1495268685408" FOLDED="true" ID="ID_1978441576" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268681734" ID="ID_1410167572" MODIFIED="1495268681734" TEXT="public CharArrayWriter()"/>
<node COLOR="#111111" CREATED="1495268681735" ID="ID_1632500756" MODIFIED="1495268681735" TEXT="public CharArrayWriter(int initialSize)"/>
</node>
<node COLOR="#111111" CREATED="1495268693577" FOLDED="true" ID="ID_1297345036" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26222;&#36890;&#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495268681736" ID="ID_842449873" MODIFIED="1495268681736" TEXT="public void write(int c)"/>
<node COLOR="#111111" CREATED="1495268681736" ID="ID_1972340201" MODIFIED="1495268681736" TEXT="public void write(char c[], int off, int len)"/>
<node COLOR="#111111" CREATED="1495268681737" ID="ID_1236941865" MODIFIED="1495268681737" TEXT="public void write(String str, int off, int len)"/>
<node COLOR="#111111" CREATED="1495268681737" ID="ID_733304541" MODIFIED="1495268681737" TEXT="public void writeTo(Writer out) throws IOException"/>
<node COLOR="#111111" CREATED="1495268681738" ID="ID_1482953585" MODIFIED="1495268681738" TEXT="public CharArrayWriter append(CharSequence csq)"/>
<node COLOR="#111111" CREATED="1495268681739" ID="ID_472438865" MODIFIED="1495268681740" TEXT="public CharArrayWriter append(CharSequence csq, int start, int end)"/>
<node COLOR="#111111" CREATED="1495268681740" ID="ID_108298811" MODIFIED="1495268681741" TEXT="public CharArrayWriter append(char c)"/>
<node COLOR="#111111" CREATED="1495268681748" ID="ID_1800747883" MODIFIED="1495268681748" TEXT="public void reset()"/>
<node COLOR="#111111" CREATED="1495268681749" ID="ID_134050250" MODIFIED="1495268681749" TEXT="public char toCharArray()[]"/>
<node COLOR="#111111" CREATED="1495268681749" ID="ID_209137188" MODIFIED="1495268681749" TEXT="public int size()"/>
<node COLOR="#111111" CREATED="1495268681750" ID="ID_1359554467" MODIFIED="1495268681750" TEXT="public String toString()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495269441431" FOLDED="true" ID="ID_916475059" MODIFIED="1529657528244" TEXT="PrintWriter">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1495269454956" FOLDED="true" ID="ID_960458500" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269448988" ID="ID_1022160525" MODIFIED="1495269448988" TEXT="public PrintWriter (Writer out)"/>
<node COLOR="#111111" CREATED="1495269448989" ID="ID_167365171" MODIFIED="1495269448989" TEXT="public PrintWriter(OutputStream out)"/>
<node COLOR="#111111" CREATED="1495269448990" ID="ID_451634053" MODIFIED="1495269448990" TEXT="public PrintWriter(OutputStream out, boolean autoFlush)"/>
<node COLOR="#111111" CREATED="1495269448990" ID="ID_1154352324" MODIFIED="1495269448991" TEXT="public PrintWriter(String fileName) throws FileNotFoundException"/>
<node COLOR="#111111" CREATED="1495269448991" ID="ID_59316539" MODIFIED="1495269448991" TEXT="public PrintWriter(File file) throws FileNotFoundException"/>
</node>
<node COLOR="#111111" CREATED="1495269448996" ID="ID_1790313649" MODIFIED="1495269448996" TEXT="public void flush()"/>
<node COLOR="#111111" CREATED="1495269449001" ID="ID_1997523077" MODIFIED="1495269449002" TEXT="public void close()"/>
<node COLOR="#111111" CREATED="1495269449002" ID="ID_172168318" MODIFIED="1495269449002" TEXT="public boolean checkError()"/>
<node COLOR="#111111" CREATED="1495269465236" FOLDED="true" ID="ID_711428784" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      write&#20889;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269449003" ID="ID_1643746256" MODIFIED="1495269449003" TEXT="public void write(int c)"/>
<node COLOR="#111111" CREATED="1495269449003" ID="ID_433862400" MODIFIED="1495269449004" TEXT="public void write(char buf[], int off, int len)"/>
<node COLOR="#111111" CREATED="1495269449004" ID="ID_748425585" MODIFIED="1495269449004" TEXT="public void write(char buf[])"/>
<node COLOR="#111111" CREATED="1495269449005" ID="ID_1791831040" MODIFIED="1495269449005" TEXT="public void write(String s, int off, int len)"/>
<node COLOR="#111111" CREATED="1495269449005" ID="ID_26164986" MODIFIED="1495269449005" TEXT="public void write(String s)"/>
</node>
<node COLOR="#111111" CREATED="1495269478362" FOLDED="true" ID="ID_525450439" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20889;print
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269449006" ID="ID_180905278" MODIFIED="1495269449006" TEXT="public void print(boolean b)"/>
<node COLOR="#111111" CREATED="1495269449006" ID="ID_1122754857" MODIFIED="1495269449006" TEXT="public void print(char c)"/>
<node COLOR="#111111" CREATED="1495269449007" ID="ID_1850354234" MODIFIED="1495269449007" TEXT="public void print(int i)"/>
<node COLOR="#111111" CREATED="1495269449007" ID="ID_1791040253" MODIFIED="1495269449007" TEXT="public void print(long l)"/>
<node COLOR="#111111" CREATED="1495269449012" ID="ID_753190938" MODIFIED="1495269449012" TEXT="public void print(float f)"/>
<node COLOR="#111111" CREATED="1495269449015" ID="ID_491891" MODIFIED="1495269449015" TEXT="public void print(double d)"/>
<node COLOR="#111111" CREATED="1495269449016" ID="ID_1140705387" MODIFIED="1495269449016" TEXT="public void print(char s[])"/>
<node COLOR="#111111" CREATED="1495269449016" ID="ID_343043580" MODIFIED="1495269449016" TEXT="public void print(String s)"/>
<node COLOR="#111111" CREATED="1495269449017" ID="ID_265260228" MODIFIED="1495269449017" TEXT="public void print(Object obj)"/>
<node COLOR="#111111" CREATED="1495269449017" ID="ID_1718705763" MODIFIED="1495269449017" TEXT="public void println()"/>
<node COLOR="#111111" CREATED="1495269449018" ID="ID_1883103445" MODIFIED="1495269449018" TEXT="public void println(boolean x)"/>
<node COLOR="#111111" CREATED="1495269449019" ID="ID_186407742" MODIFIED="1495269449019" TEXT="public void println(char x)"/>
<node COLOR="#111111" CREATED="1495269449019" ID="ID_36868932" MODIFIED="1495269449019" TEXT="public void println(int x)"/>
<node COLOR="#111111" CREATED="1495269449020" ID="ID_516615503" MODIFIED="1495269449020" TEXT="public void println(long x)"/>
<node COLOR="#111111" CREATED="1495269449020" ID="ID_166329411" MODIFIED="1495269449020" TEXT="public void println(float x)"/>
<node COLOR="#111111" CREATED="1495269449021" ID="ID_29271479" MODIFIED="1495269449021" TEXT="public void println(double x)"/>
<node COLOR="#111111" CREATED="1495269449021" ID="ID_1696102070" MODIFIED="1495269449021" TEXT="public void println(char x[])"/>
<node COLOR="#111111" CREATED="1495269449022" ID="ID_596454495" MODIFIED="1495269449022" TEXT="public void println(String x)"/>
<node COLOR="#111111" CREATED="1495269449022" ID="ID_147665477" MODIFIED="1495269449022" TEXT="public void println(Object x)"/>
</node>
<node COLOR="#111111" CREATED="1495269497422" FOLDED="true" ID="ID_1740387761" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20889;printf,&#21644;format&#31867;&#20284;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269449022" ID="ID_416875496" MODIFIED="1495269449023" TEXT="public PrintWriter printf(String format, Object ... args)"/>
<node COLOR="#111111" CREATED="1495269449023" ID="ID_171862954" MODIFIED="1495269449023" TEXT="public PrintWriter printf(Locale l, String format, Object ... args)"/>
</node>
<node COLOR="#111111" CREATED="1495269507023" FOLDED="true" ID="ID_530747101" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      format&#26684;&#24335;&#21270;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269449024" ID="ID_1436934052" MODIFIED="1495269449024" TEXT="public PrintWriter format(String format, Object ... args)"/>
<node COLOR="#111111" CREATED="1495269449024" ID="ID_212249259" MODIFIED="1495269449025" TEXT="public PrintWriter format(Locale l, String format, Object ... args)"/>
</node>
<node COLOR="#111111" CREATED="1495269518563" FOLDED="true" ID="ID_1936087463" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36861;&#21152;append
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269449025" ID="ID_466808343" MODIFIED="1495269449025" TEXT="public PrintWriter append(CharSequence csq)"/>
<node COLOR="#111111" CREATED="1495269449026" ID="ID_604092650" MODIFIED="1495269449026" TEXT="public PrintWriter append(CharSequence csq, int start, int end)"/>
<node COLOR="#111111" CREATED="1495269449026" ID="ID_1225269494" MODIFIED="1495269449026" TEXT="public PrintWriter append(char c)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495269765603" FOLDED="true" ID="ID_1400565547" MODIFIED="1529657528244" TEXT="StringWriter">
<node COLOR="#111111" CREATED="1495269772042" FOLDED="true" ID="ID_699029516" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269769304" ID="ID_628028391" MODIFIED="1495269769304" TEXT="public StringWriter()"/>
<node COLOR="#111111" CREATED="1495269769305" ID="ID_1287180779" MODIFIED="1495269769305" TEXT="public StringWriter(int initialSize)"/>
</node>
<node COLOR="#111111" CREATED="1495269790657" FOLDED="true" ID="ID_190879518" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269797831" FOLDED="true" ID="ID_220244700" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20889;write
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269769306" ID="ID_1484278578" MODIFIED="1495269769306" TEXT="public void write(int c)"/>
<node COLOR="#111111" CREATED="1495269769306" ID="ID_1172107127" MODIFIED="1495269769306" TEXT="public void write(char cbuf[], int off, int len)"/>
<node COLOR="#111111" CREATED="1495269769307" ID="ID_146500933" MODIFIED="1495269769307" TEXT="public void write(String str)"/>
<node COLOR="#111111" CREATED="1495269769307" ID="ID_1842666581" MODIFIED="1495269769307" TEXT="public void write(String str, int off, int len)"/>
</node>
<node COLOR="#111111" CREATED="1495269807076" FOLDED="true" ID="ID_1221263694" MODIFIED="1529657528244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      append
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269769308" ID="ID_1686019257" MODIFIED="1495269769308" TEXT="public StringWriter append(CharSequence csq)"/>
<node COLOR="#111111" CREATED="1495269769309" ID="ID_1957463045" MODIFIED="1495269769309" TEXT="public StringWriter append(CharSequence csq, int start, int end)"/>
<node COLOR="#111111" CREATED="1495269769310" ID="ID_1494814930" MODIFIED="1495269769310" TEXT="public StringWriter append(char c)"/>
</node>
<node COLOR="#111111" CREATED="1495269769314" ID="ID_717397177" MODIFIED="1495269769314" TEXT="public String toString()"/>
<node COLOR="#111111" CREATED="1495269769314" ID="ID_1635268283" MODIFIED="1495269769315" TEXT="public StringBuffer getBuffer()"/>
<node COLOR="#111111" CREATED="1495269769315" ID="ID_1490940021" MODIFIED="1495269769315" TEXT="public void flush()"/>
<node COLOR="#111111" CREATED="1495269769316" ID="ID_1090334552" MODIFIED="1495269769316" TEXT="public void close() throws IOException"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495269852510" FOLDED="true" ID="ID_1552527496" MODIFIED="1529657528245" TEXT="PipedWriter">
<node COLOR="#111111" CREATED="1495269861370" FOLDED="true" ID="ID_390222093" MODIFIED="1529657528245">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26500;&#36896;&#20989;&#25968;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495269856765" ID="ID_1791061173" MODIFIED="1495269856766" TEXT="public PipedWriter(PipedReader snk)  throws IOException"/>
<node COLOR="#111111" CREATED="1495269856767" ID="ID_1996397606" MODIFIED="1495269856767" TEXT="public PipedWriter()"/>
</node>
<node COLOR="#111111" CREATED="1495269856768" ID="ID_510429916" MODIFIED="1495269856768" TEXT="public synchronized void connect(PipedReader snk) throws IOException"/>
<node COLOR="#111111" CREATED="1495269856769" ID="ID_512482783" MODIFIED="1495269856769" TEXT="public void write(int c)  throws IOException"/>
<node COLOR="#111111" CREATED="1495269856770" ID="ID_1473979996" MODIFIED="1495269856770" TEXT="public void write(char cbuf[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495269856771" ID="ID_1388906424" MODIFIED="1495269856771" TEXT="public synchronized void flush() throws IOException"/>
<node COLOR="#111111" CREATED="1495269856772" ID="ID_312519951" MODIFIED="1495269856772" TEXT="public void close()  throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495270007491" FOLDED="true" ID="ID_1403758483" MODIFIED="1529657528245">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FilterWriter&#25277;&#35937;&#31867;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495270016729" ID="ID_866463799" MODIFIED="1495270028415" TEXT="&#x6ca1;&#x6709;&#x53ef;&#x7528;&#x7684;public&#x5b50;&#x7c7b;"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495270436605" FOLDED="true" ID="ID_146175895" MODIFIED="1529657528246" TEXT="RandomAccessFile">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495270487076" FOLDED="true" ID="ID_837437860" MODIFIED="1529657528246" TEXT="?">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495270491848" ID="ID_1000296202" MODIFIED="1495270508564">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <p style="margin-left: 30px">
      <font size="18px"><strong>&#8226;RandomAccessFile&#26159;Java&#36755;&#20837;/&#36755;&#20986;&#27969;&#20307;&#31995;&#20013;&#21151;&#33021;&#26368;&#20016;&#23500;&#30340;&#25991;&#20214;&#20869;&#23481;&#35775;&#38382;&#31867;&#65292;&#23427;&#25552;&#20379;&#20102;&#20247;&#22810;&#30340;&#26041;</strong></font>
    </p>
    <p style="margin-left: 30px">
      <font size="18px"><strong>&#27861;&#26469;&#35775;&#38382;&#25991;&#20214;&#20869;&#23481;&#65292;&#23427;&#26082;&#21487;&#20197;&#35835;&#21462;&#25991;&#20214;&#20869;&#23481;&#65292;&#20063;&#21487;&#20197;&#21521;&#25991;&#20214;&#36755;&#20986;&#25968;&#25454;&#12290;&#19982;&#26222;&#36890;&#30340;&#36755;&#20837;/&#36755;&#20837;&#27969;&#19981;&#21516;&#30340;</strong></font>
    </p>
    <p style="margin-left: 30px">
      <font size="18px"><strong>&#26159;&#65292;RandomAccessFile&#25903;&#25345;&#8220;</strong></font><strong><font size="18px" color="#ff0000">&#38543;&#26426;&#35775;&#38382;</font><font size="18px">&#8221;&#30340;&#26041;&#24335;&#65292;&#31243;&#24207;&#21487;&#20197;&#30452;&#25509;&#36339;&#36716;&#21040;&#25991;&#20214;&#30340;&#20219;&#24847;&#22320;&#26041;&#26469;&#35835;&#20889;&#25968;</font></strong>
    </p>
    <p style="margin-left: 30px">
      <font size="18px"><strong>&#25454;&#12290;</strong></font>
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495270543134" FOLDED="true" ID="ID_685061870" MODIFIED="1529657528246" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495270550366" FOLDED="true" ID="ID_1255820440" MODIFIED="1529657528246" TEXT="public RandomAccessFile(String name, String mode)">
<node COLOR="#111111" CREATED="1495270930092" FOLDED="true" ID="ID_705350238" MODIFIED="1529657528246" TEXT="mode">
<node COLOR="#111111" CREATED="1495270933003" ID="ID_243504274" MODIFIED="1495270933003" TEXT="&#x2013;&quot;r&quot;&#xff1a;&#x4ee5;&#x53ea;&#x8bfb;&#x65b9;&#x5f0f;&#x6253;&#x5f00;&#x6307;&#x5b9a;&#x6587;&#x4ef6;&#x3002;&#x5982;&#x679c;&#x8bd5;&#x56fe;&#x5bf9;&#x8be5;RandomAccessFile&#x6267;&#x884c;&#x5199;&#x5165;&#x65b9;&#x6cd5;&#x90fd;&#x5c06;&#x4f1a;&#x629b;&#x51fa; &#x3000;&#x3000;IOException&#x3002;"/>
<node COLOR="#111111" CREATED="1495270933006" ID="ID_1826676307" MODIFIED="1495270933006" TEXT="&#x2013;&quot;rw&quot;&#xff1a;&#x4ee5;&#x8bfb;&#x53d6;&#x3001;&#x5199;&#x5165;&#x65b9;&#x5f0f;&#x6253;&#x5f00;&#x6307;&#x5b9a;&#x6587;&#x4ef6;&#x3002;&#x5982;&#x679c;&#x8be5;&#x6587;&#x4ef6;&#x5c1a;&#x4e0d;&#x5b58;&#x5728;&#xff0c;&#x5219;&#x5c1d;&#x8bd5;&#x521b;&#x5efa;&#x8be5;&#x6587;&#x4ef6;&#x3002;"/>
<node COLOR="#111111" CREATED="1495270933007" ID="ID_168862705" MODIFIED="1495271222283" TEXT="&#x2013;&quot;rws&quot;&#xff1a;&#x4ee5;&#x8bfb;&#x53d6;&#x3001;&#x5199;&#x5165;&#x65b9;&#x5f0f;&#x6253;&#x5f00;&#x6307;&#x5b9a;&#x6587;&#x4ef6;&#x3002;&#x76f8;&#x5bf9;&#x4e8e;&#x5bf9;&#x4e8e; &quot;rw&quot;&#x6a21;&#x5f0f;&#xff0c;&#x8fd8;&#x8981;&#x6c42;&#x5bf9;&#x6587;&#x4ef6;&#x7684;&#x5185;&#x5bb9;&#x6216;&#x5143;&#x6570;&#x636e;&#x7684;&#x6bcf;&#x4e2a;&#x66f4;&#x65b0;&#x90fd;&#x540c;&#x6b65;&#x5199;&#x5165;&#x5230;&#x5e95;&#x5c42;&#x5b58;&#x50a8;&#x8bbe;&#x5907;&#x3002;&#x539f;&#x6587;: Open for reading and writing, as with &lt;tt&gt;&quot;rw&quot;&lt;/tt&gt;, and also&#xa;     *     require that every update to the file&apos;s content or metadata be&#xa;     *     written synchronously to the underlying storage device."/>
<node COLOR="#111111" CREATED="1495270933010" ID="ID_1732013445" MODIFIED="1495271281967" TEXT="&#x2013;&quot;rwd&quot;&#xff1a;&#x4ee5;&#x8bfb;&#x53d6;&#x3001;&#x5199;&#x5165;&#x65b9;&#x5f0f;&#x6253;&#x5f00;&#x6307;&#x5b9a;&#x6587;&#x4ef6;&#x3002;&#x5bf9;&#x4e8e; &quot;rw&quot;&#xff0c;&#x8fd8;&#x8981;&#x6c42;&#x5bf9;&#x6587;&#x4ef6;&#x5185;&#x5bb9;&#x7684;&#x6bcf;&#x4e2a;&#x66f4;&#x65b0;&#x90fd;&#x540c;&#x6b65;&#x5199;&#x5165;&#x5230;&#x5e95;&#x5c42;&#x5b58;&#x50a8;&#x8bbe;&#x5907;&#x3002;&#x539f;&#x6587;: Open for reading and writing, as with &lt;tt&gt;&quot;rw&quot;&lt;/tt&gt;, and also&#xa;     *     require that every update to the file&apos;s content be written&#xa;     *     synchronously to the underlying storage device. "/>
<node COLOR="#111111" CREATED="1495271284080" FOLDED="true" ID="ID_1195776221" MODIFIED="1529657528246" TEXT="rws &#x548c; rws&#x533a;&#x522b;">
<node COLOR="#111111" CREATED="1495271295276" ID="ID_692667632" MODIFIED="1495271304638" TEXT="rws&#x652f;&#x6301;&#x5143;&#x6570;&#x636e;"/>
<node COLOR="#111111" CREATED="1495271305145" ID="ID_1264742589" MODIFIED="1495271311364" TEXT="rwd&#x4e0d;&#x652f;&#x6301;&#x5143;&#x6570;&#x636e;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495270550367" ID="ID_62123828" MODIFIED="1495270555799" TEXT="public RandomAccessFile(File file, String mode)"/>
</node>
<node COLOR="#111111" CREATED="1495270804104" FOLDED="true" ID="ID_67462178" MODIFIED="1529657528246" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495270812214" ID="ID_1465893555" MODIFIED="1495270812214" TEXT="public final FileDescriptor getFD() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812215" ID="ID_1555508304" MODIFIED="1495270812215" TEXT="public final FileChannel getChannel()"/>
<node COLOR="#111111" CREATED="1495270825455" FOLDED="true" ID="ID_334748656" MODIFIED="1529657528246">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      read
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495270812217" ID="ID_1136017311" MODIFIED="1495270812217" TEXT="public int read() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812218" ID="ID_1744537927" MODIFIED="1495270812218" TEXT="public int read(byte b[], int off, int len) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812220" ID="ID_1111260160" MODIFIED="1495270812220" TEXT="public int read(byte b[]) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812220" ID="ID_936958507" MODIFIED="1495270812220" TEXT="public final void readFully(byte b[]) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812221" ID="ID_1510700445" MODIFIED="1495270812221" TEXT="public final void readFully(byte b[], int off, int len) throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495270812222" ID="ID_806130830" MODIFIED="1495270812222" TEXT="public int skipBytes(int n) throws IOException"/>
<node COLOR="#111111" CREATED="1495270838407" FOLDED="true" ID="ID_747892011" MODIFIED="1529657528246">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      write
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495270812223" ID="ID_866993342" MODIFIED="1495270812223" TEXT="public void write(int b) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812225" ID="ID_1698968783" MODIFIED="1495270812225" TEXT="public void write(byte b[]) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812225" ID="ID_503740722" MODIFIED="1495270812225" TEXT="public void write(byte b[], int off, int len) throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495270812226" ID="ID_136852058" MODIFIED="1495270812226" TEXT="public void seek(long pos) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812228" ID="ID_556812512" MODIFIED="1495270812228" TEXT="public void close() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812231" ID="ID_931897515" MODIFIED="1495270812232" TEXT="public final boolean readBoolean() throws IOException"/>
<node COLOR="#111111" CREATED="1495270860554" FOLDED="true" ID="ID_1523153727" MODIFIED="1529657528246">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      read&#31867;&#22411;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495270812232" ID="ID_624630471" MODIFIED="1495270812233" TEXT="public final byte readByte() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812233" ID="ID_1167508503" MODIFIED="1495270812234" TEXT="public final int readUnsignedByte() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812234" ID="ID_1233292494" MODIFIED="1495270812235" TEXT="public final short readShort() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812235" ID="ID_489126791" MODIFIED="1495270812236" TEXT="public final int readUnsignedShort() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812236" ID="ID_348897480" MODIFIED="1495270812237" TEXT="public final char readChar() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812237" ID="ID_516228371" MODIFIED="1495270812239" TEXT="public final int readInt() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812239" ID="ID_1646209858" MODIFIED="1495270812240" TEXT="public final long readLong() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812240" ID="ID_1535387767" MODIFIED="1495270812240" TEXT="public final float readFloat() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812241" ID="ID_1527019237" MODIFIED="1495270812241" TEXT="public final double readDouble() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812242" ID="ID_1551917101" MODIFIED="1495270812242" TEXT="public final String readLine() throws IOException"/>
<node COLOR="#111111" CREATED="1495270812243" ID="ID_323116304" MODIFIED="1495270812243" TEXT="public final String readUTF() throws IOException"/>
</node>
<node COLOR="#111111" CREATED="1495270875070" FOLDED="true" ID="ID_75390550" MODIFIED="1529657528246">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      write&#31867;&#22411;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495270812244" ID="ID_1939770825" MODIFIED="1495270812244" TEXT="public final void writeBoolean(boolean v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812245" ID="ID_543924237" MODIFIED="1495270812245" TEXT="public final void writeByte(int v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812251" ID="ID_252253427" MODIFIED="1495270812251" TEXT="public final void writeShort(int v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812254" ID="ID_259765389" MODIFIED="1495270812254" TEXT="public final void writeChar(int v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812254" ID="ID_489433647" MODIFIED="1495270812254" TEXT="public final void writeInt(int v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812255" ID="ID_475041481" MODIFIED="1495270812255" TEXT="public final void writeLong(long v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812255" ID="ID_1876830860" MODIFIED="1495270812256" TEXT="public final void writeFloat(float v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812256" ID="ID_277353555" MODIFIED="1495270812256" TEXT="public final void writeDouble(double v) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812257" ID="ID_1790202285" MODIFIED="1495270812257" TEXT="public final void writeBytes(String s) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812257" ID="ID_1533277831" MODIFIED="1495270812257" TEXT="public final void writeChars(String s) throws IOException"/>
<node COLOR="#111111" CREATED="1495270812258" ID="ID_1198411221" MODIFIED="1495270812258" TEXT="public final void writeUTF(String str) throws IOException"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495271367314" FOLDED="true" ID="ID_924028286" MODIFIED="1529657528247">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Serializable&#25509;&#21475;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495271516533" FOLDED="true" ID="ID_1251327768" MODIFIED="1529657528246">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495271370137" ID="ID_1735075034" MODIFIED="1495272834018" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x6807;&#x8bb0;&#x63a5;&#x53e3;,&#x6ca1;&#x6709;&#x65b9;&#x6cd5;,&#x9700;&#x8981;&#x5e8f;&#x5217;&#x5316;&#x7684;&#x7c7b;&#x9700;&#x8981;&#x5b9e;&#x73b0;&#x8be5;&#x63a5;&#x53e3;&#x6216;&#x5176;&#x5b50;&#x63a5;&#x53e3;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495272783899" FOLDED="true" ID="ID_1637747226" MODIFIED="1529657528247">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#30693;&#35782;&#28857;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495271407516" ID="ID_492016775" MODIFIED="1495272852732" TEXT="&#x4e00;&#x65e6;&#x67d0;&#x4e2a;&#x7c7b;&#x5b9e;&#x73b0;&#x4e86;Serializable&#x63a5;&#x53e3;&#xff0c;&#x5219;&#x8be5;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;&#x5c31;&#x662f;&#x53ef;&#x5e8f;&#x5217;&#x5316;&#x7684;&#xff0c;&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;&#x5982;&#x4e0b;&#x4e24;&#x4e2a;&#x6b65;&#x9aa4;&#x6765;&#x5e8f;&#x5217;&#x5316;&#x8be5;&#x5bf9;&#x8c61;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-1"/>
</node>
<node COLOR="#111111" CREATED="1495271420849" ID="ID_1743929202" MODIFIED="1495272854455" TEXT="&#x4f7f;&#x7528;ObjectOutputStream&#x6765;&#x5e8f;&#x5217;&#x5316;&#x7c7b;">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-2"/>
</node>
<node COLOR="#111111" CREATED="1495271471131" ID="ID_1585983703" MODIFIED="1495272856773" TEXT="&#x4f7f;&#x7528;ObjectInputStream&#x53cd;&#x5e8f;&#x5217;&#x5316;&#x7c7b; ">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-3"/>
</node>
<node COLOR="#111111" CREATED="1495271535025" FOLDED="true" ID="ID_527718033" MODIFIED="1529657528246">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      transient&#20851;&#38190;&#23383;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-4"/>
<node COLOR="#111111" CREATED="1495271542382" ID="ID_1592259473" MODIFIED="1495271592113" TEXT="&#x901a;&#x8fc7;&#x5728;&#x7c7b;&#x7684;&#x5c5e;&#x6027;&#x524d;&#x6dfb;&#x52a0;&#x8be5;&#x5173;&#x952e;&#x5b57;,&#x53ef;&#x4ee5;&#x907f;&#x514d;&#x8be5;&#x5c5e;&#x6027;&#x88ab;&#x5e8f;&#x5217;&#x5316;,&#x6bd4;&#x5982;&#x5bc6;&#x7801;&#x6bd4;&#x8f83;&#x673a;&#x5bc6;,&#x4e0d;&#x9700;&#x8981;&#x5e8f;&#x5217;&#x5316;"/>
<node COLOR="#111111" CREATED="1495272062998" ID="ID_553799562" MODIFIED="1495272078274" TEXT="&#x548c;Externalizable&#x4f5c;&#x7528;&#x4e00;&#x6837;"/>
</node>
<node COLOR="#111111" CREATED="1495271763163" ID="ID_1749454128" MODIFIED="1495272861204" TEXT="&#x5982;&#x679c;&#x4e00;&#x4e2a;&#x7c7b;&#x7684;&#x5c5e;&#x6027;&#x662f;&#x4e0d;&#x53ef;&#x5e8f;&#x5217;&#x5316;&#x7684;,&#x90a3;&#x4e48;&#x8be5;&#x7c7b;&#x5c31;&#x4e0d;&#x53ef;&#x5e8f;&#x5217;&#x5316;,&#x5fc5;&#x987b;&#x4fdd;&#x8bc1;&#x7c7b;&#x4e2d;&#x7684;&#x5c5e;&#x6027;&#x90fd;&#x53ef;&#x4ee5;&#x5e8f;&#x5217;&#x5316;&#x65f6;,&#x6574;&#x4e2a;&#x7c7b;&#x624d;&#x53ef;&#x4ee5;&#x5e8f;&#x5217;&#x5316;.">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="full-5"/>
</node>
<node COLOR="#111111" CREATED="1495272248234" FOLDED="true" ID="ID_1045076487" MODIFIED="1529657528246" TEXT="&#x5b9e;&#x73b0;&#x4e86;&#x8be5;&#x63a5;&#x53e3;,&#x5fc5;&#x987b;&#x63d0;&#x4f9b;&#x4e00;&#x4e2a;long &#x7c7b;&#x578b; &#x7684;serialVersionUID">
<icon BUILTIN="full-6"/>
<node COLOR="#111111" CREATED="1495272298334" ID="ID_1771627305" MODIFIED="1495272327226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="black" face="&#x5b8b;&#x4f53;">&#24207;&#21015;&#21270;&#26102;&#20026;&#20102;&#20445;&#25345;&#29256;&#26412;&#30340;&#20860;&#23481;&#24615;&#65292;&#21363;&#22312;&#29256;&#26412;&#21319;&#32423;&#26102;&#21453;&#24207;&#21015;&#21270;&#20173;&#20445;&#25345;&#23545;&#35937;&#30340;&#21807;&#19968;&#24615;&#12290;</font><font color="black">&#160;<br style="padding-bottom: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px" /></font><font color="black" face="&#x5b8b;&#x4f53;">&#26377;&#20004;&#31181;&#29983;&#25104;&#26041;&#24335;&#65306;</font><font color="black">&#160;<br style="padding-bottom: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px" /></font><font color="black" face="&#x5b8b;&#x4f53;">&#19968;&#20010;&#26159;&#40664;&#35748;&#30340;</font><font color="black">1L</font><font color="black" face="&#x5b8b;&#x4f53;">&#65292;&#27604;&#22914;&#65306;</font><font color="black">private static final long serialVersionUID = 1L;<br style="padding-bottom: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px" /></font><font color="black" face="&#x5b8b;&#x4f53;">&#19968;&#20010;&#26159;&#26681;&#25454;&#31867;&#21517;&#12289;&#25509;&#21475;&#21517;&#12289;&#25104;&#21592;&#26041;&#27861;&#21450;&#23646;&#24615;&#31561;&#26469;&#29983;&#25104;&#19968;&#20010;</font><font color="black">64</font><font color="black" face="&#x5b8b;&#x4f53;">&#20301;&#30340;&#21704;&#24076;&#23383;&#27573;&#65292;&#27604;&#22914;&#65306;</font><font color="black">&#160;<br style="padding-bottom: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px" />private static final long serialVersionUID = xxxxL;&#160;<br style="padding-bottom: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px" /></font>
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495272360504" FOLDED="true" ID="ID_83320494" MODIFIED="1529657528246" TEXT="&#x751f;&#x6210;&#x65b9;&#x5f0f;">
<node COLOR="#111111" CREATED="1495272370878" ID="ID_1756211527" MODIFIED="1495272396326">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="black" face="&#x5b8b;&#x4f53;">&#26041;&#24335;&#19968;: &#40664;&#35748;&#30340;</font><font color="black">1L</font><font color="black" face="&#x5b8b;&#x4f53;">&#65292;&#27604;&#22914;&#65306;</font><font color="black">private static final long serialVersionUID = 1L;<br style="padding-bottom: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px" /></font>
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495272399207" ID="ID_288910917" MODIFIED="1495272427434" TEXT="&#x65b9;&#x5f0f;&#x4e8c;: &#x4e00;&#x4e2a;&#x662f;&#x6839;&#x636e;&#x7c7b;&#x540d;&#x3001;&#x63a5;&#x53e3;&#x540d;&#x3001;&#x6210;&#x5458;&#x65b9;&#x6cd5;&#x53ca;&#x5c5e;&#x6027;&#x7b49;&#x6765;&#x751f;&#x6210;&#x4e00;&#x4e2a;64&#x4f4d;&#x7684;&#x54c8;&#x5e0c;&#x5b57;&#x6bb5;,&#x6bd4;&#x5982;: private static final long serialVersionUID = xxxxL; "/>
</node>
<node COLOR="#111111" CREATED="1495272328968" ID="ID_925180385" MODIFIED="1495272328968">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font color="black" face="&#x5b8b;&#x4f53;">&#24403;&#20320;&#19968;&#20010;&#31867;&#23454;&#29616;&#20102;</font><font color="black">Serializable</font><font color="black" face="&#x5b8b;&#x4f53;">&#25509;&#21475;&#65292;&#22914;&#26524;&#27809;&#26377;&#23450;&#20041;</font><font color="black">serialVersionUID</font><font color="black" face="&#x5b8b;&#x4f53;">&#65292;</font><font color="black">Eclipse</font><font color="black" face="&#x5b8b;&#x4f53;">&#20250;&#25552;&#20379;&#36825;&#20010;</font><font color="black">&#160;<br style="padding-bottom: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-left: 0px; padding-right: 0px; padding-top: 0px" /></font><font color="black" face="&#x5b8b;&#x4f53;">&#25552;&#31034;&#21151;&#33021;&#21578;&#35785;&#20320;&#21435;&#23450;&#20041;</font><font color="black">&#160;</font><font color="black" face="&#x5b8b;&#x4f53;">&#12290;</font>
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495272534455" FOLDED="true" ID="ID_1986497463" MODIFIED="1529657528246" TEXT="&#x53cd;&#x5e8f;&#x5217;&#x5316;&#x65f6;&#x7684;&#x7236;&#x7c7b;">
<icon BUILTIN="full-7"/>
<node COLOR="#111111" CREATED="1495272618068" ID="ID_1176421778" MODIFIED="1495272720194" TEXT="&#x7236;&#x7c7b;&#x5b9e;&#x73b0;&#x5e8f;&#x5217;&#x5316;&#xff0c;&#x5b50;&#x7c7b;&#x81ea;&#x52a8;&#x5b9e;&#x73b0;&#x5e8f;&#x5217;&#x5316;&#xff0c;&#x5b50;&#x7c7b;&#x4e0d;&#x9700;&#x8981;&#x663e;&#x5f0f;&#x5b9e;&#x73b0;Serializable&#x63a5;&#x53e3;&#xff1b;"/>
<node COLOR="#111111" CREATED="1495272722477" ID="ID_183594878" MODIFIED="1495272768748" TEXT="&#x5b50;&#x7c7b;&#x5b9e;&#x73b0;&#x5e8f;&#x5217;&#x5316;,&#x7236;&#x7c7b;&#x6ca1;&#x6709;&#x5b9e;&#x73b0;&#x5e8f;&#x5217;&#x5316;,&#x7236;&#x7c7b;&#x4e2d;&#x7684;&#x5c5e;&#x6027;&#x4f1a;&#x4e22;&#x5931;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495271994291" FOLDED="true" ID="ID_1934798739" MODIFIED="1529657528247">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23376;&#25509;&#21475;Externalizable
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495272022449" FOLDED="true" ID="ID_357810746" MODIFIED="1529657528247" TEXT="?">
<node COLOR="#111111" CREATED="1495272023910" ID="ID_1941946491" MODIFIED="1495272087654" TEXT="&#x6709;&#x65f6;&#x6211;&#x4eec;&#x4e0d;&#x5e0c;&#x671b;&#x5e8f;&#x5217;&#x5316;&#x90a3;&#x4e48;&#x591a;&#xff0c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;&#x8fd9;&#x4e2a;&#x63a5;&#x53e3;&#xff0c;&#x8fd9;&#x4e2a;&#x63a5;&#x53e3;&#x7684;writeExternal()&#x548c;readExternal()&#x65b9;&#x6cd5;&#x53ef;&#x4ee5;&#x6307;&#x5b9a;&#x5e8f;&#x5217;&#x5316;&#x54ea;&#x4e9b;&#x5c5e;&#x6027;;"/>
</node>
<node COLOR="#111111" CREATED="1495273018979" FOLDED="true" ID="ID_556165409" MODIFIED="1529657528247" TEXT="&#x4f5c;&#x7528;">
<node COLOR="#111111" CREATED="1495273023038" ID="ID_1362162054" MODIFIED="1495273050491" TEXT="&#x7528;&#x4e8e;&#x5e8f;&#x5217;&#x5316;&#x7c7b;&#x7684;&#x90e8;&#x5206;&#x5c5e;&#x6027;"/>
</node>
<node COLOR="#111111" CREATED="1495272152155" FOLDED="true" ID="ID_865262258" MODIFIED="1529657528247">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21644;&#29238;&#31867;Serializable&#30340;&#21306;&#21035;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495272115950" ID="ID_1748434698" MODIFIED="1495272145440" TEXT="Serializable&#x5e8f;&#x5217;&#x5316;&#x65f6;&#x4e0d;&#x4f1a;&#x8c03;&#x7528;&#x9ed8;&#x8ba4;&#x7684;&#x6784;&#x9020;&#x5668;&#xff0c;&#x800c;Externalizable&#x5e8f;&#x5217;&#x5316;&#x65f6;&#x4f1a;&#x8c03;&#x7528;&#x9ed8;&#x8ba4;&#x6784;&#x9020;&#x5668;."/>
</node>
<node COLOR="#111111" CREATED="1495272973211" FOLDED="true" ID="ID_212693630" MODIFIED="1529657528247" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495272989847" FOLDED="true" ID="ID_1989179506" MODIFIED="1529657528247" TEXT="void writeExternal(ObjectOutput out) throws IOException">
<node COLOR="#111111" CREATED="1495273063651" ID="ID_1074681702" MODIFIED="1495273090393" TEXT="&#x5e8f;&#x5217;&#x5316;&#x67d0;&#x4e9b;&#x5c5e;&#x6027;"/>
</node>
<node COLOR="#111111" CREATED="1495272997471" FOLDED="true" ID="ID_1886068167" MODIFIED="1529657528247" TEXT="void readExternal(ObjectInput in) throws IOException, ClassNotFoundException">
<node COLOR="#111111" CREATED="1495273092137" ID="ID_413756256" MODIFIED="1495273100646" TEXT="&#x53cd;&#x5e8f;&#x5217;&#x5316;&#x67d0;&#x4e9b;&#x5c5e;&#x6027;"/>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495274422374" FOLDED="true" ID="ID_1004517876" MODIFIED="1529657528249" TEXT="File">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495328305789" FOLDED="true" ID="ID_1702816516" MODIFIED="1529657528247" TEXT="?">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495328308800" ID="ID_723458074" MODIFIED="1495328318492" TEXT="&#x63cf;&#x8ff0;&#x6587;&#x4ef6;&#x6216;&#x6587;&#x4ef6;&#x5939;&#x7684;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1495328320068" FOLDED="true" ID="ID_1547926851" MODIFIED="1529657528247" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495328325613" ID="ID_1040758660" MODIFIED="1495328325614" TEXT="public File(String pathname)"/>
<node COLOR="#111111" CREATED="1495328325619" ID="ID_575028834" MODIFIED="1495328325619" TEXT="public File(String parent, String child)"/>
<node COLOR="#111111" CREATED="1495328325620" ID="ID_1618330741" MODIFIED="1495328325621" TEXT="public File(File parent, String child)"/>
<node COLOR="#111111" CREATED="1495328325621" ID="ID_71998039" MODIFIED="1495328325621" TEXT="public File(URI uri)"/>
</node>
<node COLOR="#111111" CREATED="1495328340107" FOLDED="true" ID="ID_993646975" MODIFIED="1529657528249" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495328393538" FOLDED="true" ID="ID_1710011821" MODIFIED="1529657528247" TEXT="public String getName()">
<node COLOR="#111111" CREATED="1495328514482" ID="ID_116500707" MODIFIED="1495328761745">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33719;&#21462;&#25991;&#20214;&#21517;,&#21253;&#21547;&#21518;&#32512;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393540" FOLDED="true" ID="ID_1476081913" MODIFIED="1529657528247" TEXT="public String getParent()">
<node COLOR="#111111" CREATED="1495328805556" ID="ID_993405495" MODIFIED="1495328825860" TEXT="&#x8fd4;&#x56de;&#x7236;&#x6587;&#x4ef6;&#x8def;&#x5f84;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1495328393542" FOLDED="true" ID="ID_1729378937" MODIFIED="1529657528247" TEXT="public File getParentFile()">
<node COLOR="#111111" CREATED="1495328829254" ID="ID_1637131390" MODIFIED="1495328833121" TEXT="&#x8fd4;&#x56de;&#x7236;&#x6587;&#x4ef6;"/>
</node>
<node COLOR="#111111" CREATED="1495330369576" FOLDED="true" ID="ID_1916498046" LINK="IO/File/path-absolutePath-canocialPath&#x533a;&#x522b;.png" MODIFIED="1529657528247">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      path
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495328393545" FOLDED="true" ID="ID_39117401" MODIFIED="1529657528247" TEXT="public String getPath()">
<node COLOR="#111111" CREATED="1495328854895" ID="ID_1018030864" MODIFIED="1495328859480" TEXT="&#x83b7;&#x53d6;&#x6587;&#x4ef6;&#x8def;&#x5f84;"/>
</node>
<node COLOR="#111111" CREATED="1495328393550" FOLDED="true" ID="ID_1161180728" MODIFIED="1529657528247" TEXT="public String getCanonicalPath() throws IOException">
<node COLOR="#111111" CREATED="1495329735004" ID="ID_1859056918" MODIFIED="1495329744164" TEXT="&#x6587;&#x4ef6;&#x7684;&#x6807;&#x51c6;&#x8def;&#x5f84;"/>
<node COLOR="#111111" CREATED="1495329771593" FOLDED="true" ID="ID_1216153798" MODIFIED="1529657528247" TEXT="&#x6807;&#x51c6;&#x8def;&#x5f84;">
<node COLOR="#111111" CREATED="1495329775967" ID="ID_1218901703" MODIFIED="1495329796825" TEXT="1.&#x5982;&#x679c;&#x8f93;&#x5165;&#x7684;&#x8def;&#x5f84;&#x662f;&#x5168;&#x8def;&#x5f84;,&#x5219;&#x6807;&#x51c6;&#x8def;&#x5f84;&#x5c31;&#x662f;&#x5168;&#x8def;&#x5f84;"/>
<node COLOR="#111111" CREATED="1495329797656" ID="ID_113787245" MODIFIED="1495329926622" TEXT="2.&#x5982;&#x679c;&#x8f93;&#x5165;&#x7684;&#x8def;&#x5f84;&#x7c7b;&#x4f3c;&#x4e8e;  ..\\abc.txt,&#x5047;&#x8bbe;&#x5728;D&#x76d8;&#x4e0b;&#x7684;Haha&#x6587;&#x4ef6;&#x5939;,&#x5219;&#x6807;&#x51c6;&#x8def;&#x5f84;&#x662f; D:\\Haha\\abc.txt,&#x800c;&#x7edd;&#x5bf9;&#x8def;&#x5f84;&#x662f; D:\\Haha\\..\\abc.txt"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393547" FOLDED="true" ID="ID_341885645" MODIFIED="1529657528247" TEXT="public String getAbsolutePath()">
<node COLOR="#111111" CREATED="1495329713575" ID="ID_1145475070" MODIFIED="1495329726035" TEXT="&#x6587;&#x4ef6;&#x7684;&#x5168;&#x8def;&#x5f84;"/>
</node>
<node COLOR="#111111" CREATED="1495332333055" ID="ID_1610433011" MODIFIED="1495332392502" TEXT="..// : &#x4ee3;&#x8868;&#x7236;&#x6587;&#x4ef6;&#x5939;&#x6240;&#x5728;&#x8def;&#x5f84;,  .// : &#x4ee3;&#x8868;&#x5f53;&#x524d;&#x6587;&#x4ef6;&#x5939;&#x6240;&#x5728;&#x8def;&#x5f84;"/>
</node>
<node COLOR="#111111" CREATED="1495328393546" FOLDED="true" ID="ID_1000179375" MODIFIED="1529657528247" TEXT="public boolean isAbsolute()">
<node COLOR="#111111" CREATED="1495330523975" ID="ID_1649557906" MODIFIED="1495330551114" TEXT="&#x5224;&#x65ad;&#x6587;&#x4ef6;&#x7684;&#x8def;&#x5f84;&#x662f;&#x4e0d;&#x662f;&#x7edd;&#x5bf9;&#x7684;"/>
</node>
<node COLOR="#111111" CREATED="1495328393549" FOLDED="true" ID="ID_639911901" MODIFIED="1529657528247" TEXT="public File getAbsoluteFile()">
<node COLOR="#111111" CREATED="1495330705608" ID="ID_1097099516" MODIFIED="1495330826558" TEXT="&#x83b7;&#x53d6;&#x4ee3;&#x8868;&#x5f53;&#x524d;&#x6587;&#x4ef6;&#x7edd;&#x5bf9;&#x8def;&#x5f84;&#x7684;&#x6587;&#x4ef6;&#x5bf9;&#x8c61;,&#x90fd;&#x662f;&#x5f53;&#x524d;&#x6587;&#x4ef6;&#x81ea;&#x5df1;"/>
</node>
<node COLOR="#111111" CREATED="1495328393552" FOLDED="true" ID="ID_748300340" MODIFIED="1529657528247" TEXT="public File getCanonicalFile() throws IOException">
<node COLOR="#111111" CREATED="1495330784701" ID="ID_1173988158" MODIFIED="1495330817747" TEXT="&#x83b7;&#x53d6;getCanonicalPath&#x8def;&#x5f84;&#x4ee3;&#x8868;&#x7684;&#x6587;&#x4ef6;,&#x90fd;&#x662f;&#x5f53;&#x524d;&#x6587;&#x4ef6;&#x81ea;&#x5df1;"/>
</node>
<node COLOR="#111111" CREATED="1495328393555" FOLDED="true" ID="ID_943169512" MODIFIED="1529657528247" TEXT="public URL toURL() throws MalformedURLException">
<node COLOR="#111111" CREATED="1495331081143" ID="ID_1733127764" MODIFIED="1495331100808">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33719;&#21462;&#25991;&#20214;&#30340;&#32479;&#19968;&#36164;&#28304;&#23450;&#20301;&#31526;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393556" FOLDED="true" ID="ID_152039822" MODIFIED="1529657528248" TEXT="public URI toURI()">
<node COLOR="#111111" CREATED="1495331081143" FOLDED="true" ID="ID_913710672" MODIFIED="1529657528247">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33719;&#21462;&#25991;&#20214;&#30340;&#32479;&#19968;&#36164;&#28304;&#26631;&#35782;&#31526;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495331131502" ID="ID_841181770" LINK="http://www.cnblogs.com/xiaochaohuashengmi/archive/2011/09/13/2175198.html" MODIFIED="1495331149845" TEXT="URI&#x548c;URL&#x53c2;&#x89c1;&#x8fde;&#x63a5;"/>
</node>
<node COLOR="#111111" CREATED="1495331156214" FOLDED="true" ID="ID_1660887836" MODIFIED="1529657528248" TEXT="URI&#x5305;&#x62ec;URL&#x548c;URN">
<node COLOR="#111111" CREATED="1495331167648" FOLDED="true" ID="ID_1616520022" MODIFIED="1529657528247" TEXT="URI&#x4f1a;&#x5728;&#x5168;&#x7403;&#x8303;&#x56f4;&#x5185;&#x5b9a;&#x4e49;&#x4e00;&#x4e2a;&#x8d44;&#x6e90;">
<node COLOR="#111111" CREATED="1522202188888" ID="ID_1043492058" MODIFIED="1522202198659" TEXT="&#x7edf;&#x4e00;&#x8d44;&#x6e90;&#x6807;&#x8bc6;&#x7b26;"/>
</node>
<node COLOR="#111111" CREATED="1495331192605" FOLDED="true" ID="ID_1713011023" MODIFIED="1529657528247" TEXT="URL&#x76f8;&#x5f53;&#x4e8e;&#x4eba;&#x7684;&#x4f4f;&#x5740;">
<node COLOR="#111111" CREATED="1522202174639" ID="ID_1159402364" MODIFIED="1522202180999" TEXT="&#x7edf;&#x4e00;&#x8d44;&#x6e90;&#x5b9a;&#x4f4d;&#x7b26;"/>
</node>
<node COLOR="#111111" CREATED="1495331211973" FOLDED="true" ID="ID_527143911" MODIFIED="1529657528248" TEXT="URN&#x76f8;&#x5f53;&#x4e8e;&#x4eba;&#x7684;&#x540d;&#x5b57;">
<node COLOR="#111111" CREATED="1522202202381" ID="ID_179713909" MODIFIED="1522202223118" TEXT="&#x7ed9;&#x8d44;&#x6e90;&#x8d77;&#x4e2a;&#x540d;&#x5b57;"/>
<node COLOR="#111111" CREATED="1522202310021" ID="ID_897103444" MODIFIED="1522202320370" TEXT="&#x7edf;&#x4e00;&#x8d44;&#x6e90;&#x547d;&#x540d;&#x7b26;"/>
</node>
<node COLOR="#111111" CREATED="1495331232539" ID="ID_386643384" MODIFIED="1495331267096" TEXT="&#x901a;&#x8fc7;URL&#x548c;URN&#x5171;&#x540c;&#x4f5c;&#x7528;(URI)&#x5c31;&#x53ef;&#x4ee5;&#x552f;&#x4e00;&#x5b9a;&#x4f4d;&#x4e00;&#x4e2a;&#x4eba;(&#x8d44;&#x6e90;)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393557" FOLDED="true" ID="ID_352070071" MODIFIED="1529657528248" TEXT="public boolean canRead()">
<node COLOR="#111111" CREATED="1495331569404" ID="ID_392063425" MODIFIED="1495331574598" TEXT="&#x6587;&#x4ef6;&#x662f;&#x5426;&#x53ef;&#x8bfb;"/>
</node>
<node COLOR="#111111" CREATED="1495328393558" FOLDED="true" ID="ID_1893308589" MODIFIED="1529657528248" TEXT="public boolean canWrite()">
<node COLOR="#111111" CREATED="1495331576033" ID="ID_1924377319" MODIFIED="1495331582933" TEXT="&#x6587;&#x4ef6;&#x662f;&#x5426;&#x53ef;&#x5199;"/>
</node>
<node COLOR="#111111" CREATED="1495328393559" FOLDED="true" ID="ID_969252214" MODIFIED="1529657528248" TEXT="public boolean exists()">
<node COLOR="#111111" CREATED="1495331584373" ID="ID_1379138188" MODIFIED="1495331589214" TEXT="&#x6587;&#x4ef6;&#x662f;&#x5426;&#x5b58;&#x5728;"/>
</node>
<node COLOR="#111111" CREATED="1495328393559" FOLDED="true" ID="ID_1984307692" MODIFIED="1529657528248" TEXT="public boolean isDirectory()">
<node COLOR="#111111" CREATED="1495331590508" ID="ID_902832811" MODIFIED="1495331598612" TEXT="&#x6587;&#x4ef6;&#x662f;&#x5426;&#x662f;&#x4e00;&#x4e2a;&#x6587;&#x4ef6;&#x5939;"/>
</node>
<node COLOR="#111111" CREATED="1495328393560" FOLDED="true" ID="ID_438990688" MODIFIED="1529657528248" TEXT="public boolean isFile()">
<node COLOR="#111111" CREATED="1495331599886" ID="ID_939864865" MODIFIED="1495331633730" TEXT="&#x6587;&#x4ef6;&#x662f;&#x5426;&#x662f;&#x4e00;&#x4e2a;&#x5b9e;&#x9645;&#x7684;&#x6587;&#x4ef6;,&#x6bd4;&#x5982;.txt &#x6216; .doc&#x6587;&#x6863;&#x7b49;,&#x4f46;&#x4e0d;&#x662f;&#x6587;&#x4ef6;&#x5939;"/>
</node>
<node COLOR="#111111" CREATED="1495328393561" FOLDED="true" ID="ID_336085123" MODIFIED="1529657528248" TEXT="public boolean isHidden()">
<node COLOR="#111111" CREATED="1495331999955" ID="ID_546724313" MODIFIED="1495332009408" TEXT="&#x5224;&#x65ad;&#x6587;&#x4ef6;&#x662f;&#x5426;&#x88ab;&#x9690;&#x85cf;&#x4e86;"/>
<node COLOR="#111111" CREATED="1495332012649" FOLDED="true" ID="ID_1334653879" MODIFIED="1529657528248">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22914;&#20309;&#38544;&#34255;&#25991;&#20214;/&#25991;&#20214;&#22841;?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495332040445" ID="ID_754706863" MODIFIED="1495332076531">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25171;&#24320;cmd&#38190;&#20837; : attrib +s +h +r C:\Users\haha\Desktop\orginal.txt
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495332087634" ID="ID_1712577061" MODIFIED="1495332102636" TEXT="&#x56de;&#x8f66;&#x540e;&#x5237;&#x65b0;,&#x7136;&#x540e;&#x6587;&#x4ef6;&#x5c31;&#x6d88;&#x5931;&#x4e86;"/>
</node>
<node COLOR="#111111" CREATED="1495332105959" FOLDED="true" ID="ID_189666191" MODIFIED="1529657528248">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22914;&#20309;&#26174;&#31034;&#24050;&#32463;&#38544;&#34255;&#30340;&#25991;&#20214;/&#25991;&#20214;&#22841;?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495332131361" ID="ID_849833738" MODIFIED="1495332226284" TEXT="&#x6253;&#x5f00;cmd&#x952e;&#x5165;: attrib -a -s -h -r C:\Users\haha\Desktop\orginal.txt"/>
<node COLOR="#111111" CREATED="1495332087634" ID="ID_187557509" MODIFIED="1495332253816" TEXT="&#x56de;&#x8f66;&#x540e;&#x5237;&#x65b0;,&#x7136;&#x540e;&#x6587;&#x4ef6;&#x5c31;&#x663e;&#x793a;&#x4e86;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393561" FOLDED="true" ID="ID_1843703691" MODIFIED="1529657528248" TEXT="public long lastModified()">
<node COLOR="#111111" CREATED="1495332422471" ID="ID_1960676295" MODIFIED="1495332524627" TEXT="&#x8fd4;&#x56de;&#x8be5;&#x6587;&#x4ef6;&#x4e0a;&#x6b21;&#x88ab;&#x4fee;&#x6539;&#x7684;&#x65f6;&#x95f4;&#x7684;&#x65f6;&#x95f4;&#x6233;"/>
</node>
<node COLOR="#111111" CREATED="1495328393562" FOLDED="true" ID="ID_1502000658" MODIFIED="1529657528248" TEXT="public long length()">
<node COLOR="#111111" CREATED="1495332550351" ID="ID_1238123964" MODIFIED="1495332575801" TEXT="&#x6587;&#x4ef6;&#x4e2d;&#x6570;&#x636e;&#x7684;&#x5b57;&#x8282;&#x603b;&#x6570;&#x91cf;"/>
</node>
<node COLOR="#111111" CREATED="1495328393563" FOLDED="true" ID="ID_1531729541" MODIFIED="1529657528248" TEXT="public boolean createNewFile() throws IOException">
<node COLOR="#111111" CREATED="1495332579882" ID="ID_1986970665" MODIFIED="1495332602062" TEXT="&#x521b;&#x5efa;&#x5f53;&#x524d;&#x6587;&#x4ef6;&#x5bf9;&#x8c61;&#x6240;&#x4ee3;&#x8868;&#x7684;&#x65b0;&#x6587;&#x4ef6;"/>
<node COLOR="#111111" CREATED="1495332667175" ID="ID_333742258" MODIFIED="1495332738839" TEXT="&#x6ce8;&#x610f;: &#x4e0d;&#x521b;&#x5efa;&#x8def;&#x5f84;&#x4e2d;&#x5305;&#x542b;&#x7684;&#x7236;&#x6587;&#x4ef6;&#x5939;,&#x5982;&#x679c;&#x6ca1;&#x6709;&#x6587;&#x4ef6;&#x5939;&#x5219;&#x62a5;&#x9519;"/>
</node>
<node COLOR="#111111" CREATED="1495328393563" FOLDED="true" ID="ID_507410839" MODIFIED="1529657528248" TEXT="public boolean delete()">
<node COLOR="#111111" CREATED="1495332747231" ID="ID_132666660" MODIFIED="1495333026080" TEXT="&#x5982;&#x679c;&#x662f;&#x6587;&#x4ef6;&#x5219;&#x5220;&#x9664;&#x6587;&#x4ef6;,&#x5220;&#x9664;&#x6210;&#x529f;&#x540e;&#x8fd4;&#x56de;false"/>
<node COLOR="#111111" CREATED="1495332960315" ID="ID_423057697" MODIFIED="1495332996619" TEXT="&#x5982;&#x679c;&#x662f;&#x6587;&#x4ef6;&#x5939;,&#x5219;&#x5148;&#x5224;&#x65ad;&#x6587;&#x4ef6;&#x5939;&#x4e0b;&#x662f;&#x5426;&#x8fd8;&#x6709;&#x6587;&#x4ef6;,&#x5982;&#x679c;&#x6709;&#x5219;&#x4e0d;&#x5220;&#x9664;,&#x8fd4;&#x56de;false"/>
</node>
<node COLOR="#111111" CREATED="1495328393564" FOLDED="true" ID="ID_930957532" MODIFIED="1529657528248" TEXT="public void deleteOnExit()">
<node COLOR="#111111" CREATED="1495333772762" ID="ID_917601670" MODIFIED="1495333837844">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24403;JVM&#36864;&#20986;&#26102;&#35843;&#29992;&#21024;&#38500;&#26041;&#27861;,&#20854;&#20182;&#21644;delete&#26041;&#27861;&#19968;&#26679;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495333964618" FOLDED="true" ID="ID_941847632" MODIFIED="1529657528248" TEXT="&#x53c2;&#x8003;&#x4ee3;&#x7801;">
<node COLOR="#111111" CREATED="1495333973104" ID="ID_266904802" MODIFIED="1495333988632">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      //haha&#26159;&#19968;&#20010;&#25991;&#20214;&#22841;
    </p>
    <p>
      File file = new File(&quot;C:\\Users\\my\\Desktop\\haha&quot;);
    </p>
    <p>
      file.deleteOnExit();
    </p>
    <p>
      System.out.println(file.exists());
    </p>
    <p>
      for (int i = 0; i &lt; 5000000; i++) {
    </p>
    <p>
      &#160;&#160;if (i%1000000==0) {
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;System.out.println(i+&quot;&#160;&#160;&quot;+file.exists());
    </p>
    <p>
      &#160;&#160;}
    </p>
    <p>
      }
    </p>
    <p>
      System.exit(0);//JVM&#22312;&#36864;&#20986;&#26102;&#25165;&#20250;&#21024;&#38500;&#25991;&#20214;,&#30456;&#24403;&#20110;deleteOnExit&#26041;&#27861;&#32473;JVM&#27880;&#20876;&#20102;&#19968;&#20010;&#20107;&#20214;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393565" FOLDED="true" ID="ID_92704969" MODIFIED="1529657528248" TEXT="public String[] list()">
<node COLOR="#111111" CREATED="1495334053629" ID="ID_1158238053" MODIFIED="1495334170778" TEXT="&#x5982;&#x679c;&#x5f53;&#x524d;File&#x662f;&#x4e00;&#x4e2a;&#x6587;&#x4ef6;&#x5939;,&#x5219;&#x83b7;&#x53d6;&#x8be5;&#x6587;&#x4ef6;&#x5939;&#x4e0b;&#x9762;&#x7684;&#x4e00;&#x7ea7;&#x5b50;File&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1495328393565" FOLDED="true" ID="ID_1385320345" MODIFIED="1529657528248" TEXT="public String[] list(FilenameFilter filter)">
<node COLOR="#111111" CREATED="1495334104794" ID="ID_745816458" MODIFIED="1495334201467" TEXT="&#x6839;&#x636e;&#x6587;&#x4ef6;&#x540d;&#x8fc7;&#x6ee4;&#x5668;&#x83b7;&#x53d6;&#x6ee1;&#x8db3;&#x8fc7;&#x6ee4;&#x6761;&#x4ef6;&#x7684;File&#x540d;&#x5b57;"/>
<node COLOR="#111111" CREATED="1495334235146" FOLDED="true" ID="ID_594506709" MODIFIED="1529657528248">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      FilenameFilter
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495334250074" ID="ID_828410948" MODIFIED="1495334260889" TEXT="&#x4e00;&#x4e2a;&#x6587;&#x4ef6;&#x540d;&#x8fc7;&#x6ee4;&#x5668;&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1495334261413" FOLDED="true" ID="ID_1270149330" MODIFIED="1529657528248" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495334268156" FOLDED="true" ID="ID_1429712773" MODIFIED="1529657528248" TEXT="boolean accept(File dir, String name)">
<node COLOR="#111111" CREATED="1495334332026" ID="ID_90151031" MODIFIED="1495334332026" TEXT="@param   dir    the directory in which the file was found."/>
<node COLOR="#111111" CREATED="1495334332031" ID="ID_1296876218" MODIFIED="1495334340884" TEXT="*@param   name   the name of the file."/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393566" FOLDED="true" ID="ID_1807420480" MODIFIED="1529657528248" TEXT="public File[] listFiles()">
<node COLOR="#111111" CREATED="1495334053629" ID="ID_802379315" MODIFIED="1495334189197" TEXT="&#x5982;&#x679c;&#x5f53;&#x524d;File&#x662f;&#x4e00;&#x4e2a;&#x6587;&#x4ef6;&#x5939;,&#x5219;&#x83b7;&#x53d6;&#x8be5;&#x6587;&#x4ef6;&#x5939;&#x4e0b;&#x9762;&#x7684;&#x4e00;&#x7ea7;&#x5b50;File"/>
</node>
<node COLOR="#111111" CREATED="1495328393566" FOLDED="true" ID="ID_153858472" MODIFIED="1529657528248" TEXT="public File[] listFiles(FilenameFilter filter)">
<node COLOR="#111111" CREATED="1495334104794" ID="ID_113885232" MODIFIED="1495334133869" TEXT="&#x6839;&#x636e;&#x6587;&#x4ef6;&#x540d;&#x8fc7;&#x6ee4;&#x5668;&#x83b7;&#x53d6;&#x6ee1;&#x8db3;&#x8fc7;&#x6ee4;&#x6761;&#x4ef6;&#x7684;File"/>
</node>
<node COLOR="#111111" CREATED="1495328393567" FOLDED="true" ID="ID_1205244331" MODIFIED="1529657528249" TEXT="public File[] listFiles(FileFilter filter)">
<node COLOR="#111111" CREATED="1495334104794" ID="ID_814993962" MODIFIED="1495334222437" TEXT="&#x6839;&#x636e;&#x6587;&#x4ef6;&#x8fc7;&#x6ee4;&#x5668;&#x83b7;&#x53d6;&#x6ee1;&#x8db3;&#x8fc7;&#x6ee4;&#x6761;&#x4ef6;&#x7684;File"/>
<node COLOR="#111111" CREATED="1495334381632" FOLDED="true" ID="ID_794826489" MODIFIED="1529657528248" TEXT="FileFilter">
<node COLOR="#111111" CREATED="1495334388129" ID="ID_1593062476" MODIFIED="1495334393300" TEXT="&#x6587;&#x4ef6;&#x8fc7;&#x6ee4;&#x5668;"/>
<node COLOR="#111111" CREATED="1495334396822" FOLDED="true" ID="ID_1842941997" MODIFIED="1529657528248">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495334394462" ID="ID_1994874573" MODIFIED="1495334395131" TEXT="boolean accept(File pathname);"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393568" FOLDED="true" ID="ID_1795017869" MODIFIED="1529657528249" TEXT="public boolean mkdir()">
<node COLOR="#111111" CREATED="1495334508462" ID="ID_1384639018" MODIFIED="1495334531766" TEXT="&#x53ea;&#x4f1a;&#x521b;&#x5efa;&#x6587;&#x4ef6;,&#x4e0d;&#x4f1a;&#x521b;&#x5efa;&#x4e0d;&#x5b58;&#x5728;&#x7684;&#x7236;&#x8def;&#x5f84;"/>
</node>
<node COLOR="#111111" CREATED="1495328393569" FOLDED="true" ID="ID_887193109" MODIFIED="1529657528249" TEXT="public boolean mkdirs()">
<node COLOR="#111111" CREATED="1495334439443" ID="ID_1370612190" MODIFIED="1495334446690">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21407;&#25991;: Creates the directory named by this abstract pathname, including any
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;* necessary but nonexistent parent directories.
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495334448283" ID="ID_906838707" MODIFIED="1495334503212" TEXT="&#x4e2d;&#x6587;: &#x521b;&#x5efa;&#x6587;&#x4ef6;&#x5e76;&#x4e14;&#x521b;&#x5efa;&#x4e0d;&#x5b58;&#x5728;&#x7684;&#x7236;&#x76ee;&#x5f55;"/>
</node>
<node COLOR="#111111" CREATED="1495328393570" FOLDED="true" ID="ID_466633987" MODIFIED="1529657528249" TEXT="public boolean renameTo(File dest)">
<node COLOR="#111111" CREATED="1495335325342" ID="ID_962283379" MODIFIED="1495335363467">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32473;&#25991;&#20214;&#25110;&#25991;&#20214;&#22841;&#37325;&#21629;&#21517;,&#26080;&#35770;&#25991;&#20214;&#22841;&#19979;&#26159;&#21542;&#26377;&#20854;&#20182;&#25991;&#20214;,&#37117;&#21487;&#20197;&#37325;&#21629;&#21517;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393571" FOLDED="true" ID="ID_1485844874" MODIFIED="1529657528249" TEXT="public boolean setLastModified(long time)">
<node COLOR="#111111" CREATED="1495335366725" ID="ID_1949299093" MODIFIED="1495335385677" TEXT="&#x8bbe;&#x7f6e;&#x6700;&#x8fd1;&#x7684;&#x4fee;&#x6539;&#x65f6;&#x95f4;&#x6233;"/>
</node>
<node COLOR="#111111" CREATED="1495328393572" ID="ID_1983857628" MODIFIED="1495336232459" TEXT="public boolean setReadOnly()"/>
<node COLOR="#111111" CREATED="1495328393573" ID="ID_705392473" MODIFIED="1495328393573" TEXT="public boolean setWritable(boolean writable, boolean ownerOnly)"/>
<node COLOR="#111111" CREATED="1495328393573" ID="ID_1519441986" MODIFIED="1495328393573" TEXT="public boolean setWritable(boolean writable)"/>
<node COLOR="#111111" CREATED="1495328393574" FOLDED="true" ID="ID_648159605" MODIFIED="1529657528249" TEXT="public boolean setReadable(boolean readable, boolean ownerOnly)">
<node COLOR="#111111" CREATED="1495335812889" ID="ID_1339808478" MODIFIED="1495337643877" TEXT="&#x6ca1;&#x6709;&#x6548;&#x679c;,&#x901a;&#x5e38;&#x662f;&#x6ca1;&#x6709;&#x6743;&#x9650;"/>
</node>
<node COLOR="#111111" CREATED="1495328393574" ID="ID_1304214350" MODIFIED="1495328393575" TEXT="public boolean setReadable(boolean readable)"/>
<node COLOR="#111111" CREATED="1495328393575" FOLDED="true" ID="ID_1985939922" MODIFIED="1529657528249" TEXT="public boolean setExecutable(boolean executable, boolean ownerOnly)">
<node COLOR="#111111" CREATED="1495335812889" ID="ID_1949031457" MODIFIED="1495337765037" TEXT="&#x6ca1;&#x6709;&#x6548;&#x679c;,&#x901a;&#x5e38;&#x662f;&#x6ca1;&#x6709;&#x6743;&#x9650; "/>
</node>
<node COLOR="#111111" CREATED="1495328393576" ID="ID_252265092" MODIFIED="1495328393576" TEXT="public boolean setExecutable(boolean executable)"/>
<node COLOR="#111111" CREATED="1495328393577" ID="ID_1726319168" MODIFIED="1495328393577" TEXT="public boolean canExecute()"/>
<node COLOR="#111111" CREATED="1495328393578" FOLDED="true" ID="ID_204502587" MODIFIED="1529657528249" TEXT="public static File[] listRoots()">
<node COLOR="#111111" CREATED="1495336637496" FOLDED="true" ID="ID_1627058734" MODIFIED="1529657528249" TEXT="&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x7cfb;&#x7edf;&#x4e0b;&#x7684;&#x6240;&#x6709;&#x6839;&#x76ee;&#x5f55;">
<node COLOR="#111111" CREATED="1495336669959" ID="ID_186970492" MODIFIED="1495336687932" TEXT="&#x5982;:[C:\, D:\, E:\, F:\]"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393578" FOLDED="true" ID="ID_765922747" MODIFIED="1529657528249" TEXT="public long getTotalSpace()">
<node COLOR="#111111" CREATED="1495337975075" ID="ID_363026797" MODIFIED="1495338230052" TEXT="&#x83b7;&#x53d6;&#x6587;&#x4ef6;&#x603b;&#x7684;&#x7a7a;&#x95f4;&#xff0c;&#x6d4b;&#x8bd5;&#x65f6;&#x4e3a;&#x8be5;file&#x6240;&#x5728;&#x6839;&#x76ee;&#x5f55;&#x7684;&#x76d8;&#x7b26;&#x7684;&#x7a7a;&#x95f4;&#x603b;&#x5927;&#x5c0f;"/>
</node>
<node COLOR="#111111" CREATED="1495328393579" FOLDED="true" ID="ID_297374827" MODIFIED="1529657528249" TEXT="public long getFreeSpace()">
<node COLOR="#111111" CREATED="1495338291153" ID="ID_1020409064" MODIFIED="1495338329039" TEXT="&#x83b7;&#x53d6;&#x5269;&#x4f59;&#x53ef;&#x7528;&#x7a7a;&#x95f4;,&#x4e3a;&#x76d8;&#x7b26;&#x4e0b;&#x5269;&#x4f59;&#x7a7a;&#x95f4;"/>
</node>
<node COLOR="#111111" CREATED="1495328393580" FOLDED="true" ID="ID_1060831781" MODIFIED="1529657528249" TEXT="public long getUsableSpace()">
<node COLOR="#111111" CREATED="1495338291153" ID="ID_536888679" MODIFIED="1495338329039" TEXT="&#x83b7;&#x53d6;&#x5269;&#x4f59;&#x53ef;&#x7528;&#x7a7a;&#x95f4;,&#x4e3a;&#x76d8;&#x7b26;&#x4e0b;&#x5269;&#x4f59;&#x7a7a;&#x95f4;"/>
<node COLOR="#111111" CREATED="1495338411621" ID="ID_1382085417" MODIFIED="1495338432672">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27604; getFreeSpace&#26041;&#27861;&#26356;&#31934;&#30830;,&#32771;&#34385;&#20102;&#35835;&#20889;&#26435;&#38480;&#38382;&#39064;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495328393580" FOLDED="true" ID="ID_677520691" MODIFIED="1529657528249" TEXT="public int compareTo(File pathname)">
<node COLOR="#111111" CREATED="1495338470467" ID="ID_1528640277" MODIFIED="1495338480361" TEXT="&#x5bf9;&#x6bd4;&#x6587;&#x4ef6;&#x540d;&#x5b57;&#x7684;&#x5b57;&#x5178;&#x6392;&#x5e8f;"/>
</node>
<node COLOR="#111111" CREATED="1495328393583" ID="ID_274659227" MODIFIED="1495328393583" TEXT="public Path toPath()"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1499924387520" FOLDED="true" ID="ID_666387277" MODIFIED="1529657528250">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20108;&#32773;&#21306;&#21035;&#32852;&#31995;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522091445110" ID="ID_1654828101" MODIFIED="1522091445110" TEXT="NIO&#x662f;&#x9762;&#x5411;&#x7f13;&#x51b2;&#x3001;&#x901a;&#x9053;&#x7684;&#xff1b;&#x4f20;&#x7edf;IO&#x9762;&#x5411;&#x6d41;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522091445133" ID="ID_1374502235" MODIFIED="1522091445133" TEXT="&#x901a;&#x9053;&#x662f;&#x53cc;&#x5411;&#x7684;&#x65e2;&#x53ef;&#x4ee5;&#x5199;&#x3001;&#x4e5f;&#x53ef;&#x4ee5;&#x8bfb;&#xff1b;&#x4f20;&#x7edf;IO&#x53ea;&#x80fd;&#x662f;&#x5355;&#x5411;&#x7684;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522091445134" ID="ID_398506720" MODIFIED="1522091445134" TEXT="NIO&#x53ef;&#x4ee5;&#x8bbe;&#x7f6e;&#x4e3a;&#x5f02;&#x6b65;&#xff1b;&#x4f20;&#x7edf;IO&#x53ea;&#x80fd;&#x662f;&#x963b;&#x585e;&#xff0c;&#x540c;&#x6b65;&#x7684;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522094749225" FOLDED="true" ID="ID_320498029" MODIFIED="1529657528250">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32593;&#22336;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522042137005" ID="ID_822710591" LINK="https://blog.csdn.net/wuxianglong/article/details/6604817" MODIFIED="1522094749236" TEXT="https://blog.csdn.net/wuxianglong/article/details/6604817">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522094745109" ID="ID_1810077015" LINK="https://blog.csdn.net/luming_xml/article/details/51362528" MODIFIED="1522094749241" TEXT="https://blog.csdn.net/luming_xml/article/details/51362528">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522106417864" ID="ID_343015004" LINK="http://www.importnew.com/19816.html" MODIFIED="1522106417865" TEXT="importnew.com &gt; 19816"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522401937384" FOLDED="true" ID="ID_1758076558" LINK="&#x53cd;&#x5c04;.mm" MODIFIED="1529657528254" POSITION="right" TEXT="&#x53cd;&#x5c04;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1488894794198" FOLDED="true" ID="ID_1614113828" MODIFIED="1529657528252" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488894815229" ID="ID_1329822576" MODIFIED="1522401958570" TEXT="JAVA&#x53cd;&#x5c04;&#x673a;&#x5236;&#x662f;&#x5728;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x4e2d;&#xff0c;&#x5bf9;&#x4e8e;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x7c7b;&#xff0c;&#x90fd;&#x80fd;&#x591f;&#x77e5;&#x9053;&#x8fd9;&#x4e2a;&#x7c7b;&#x7684;&#x6240;&#x6709;&#x5c5e;&#x6027;&#x548c;&#x65b9;&#x6cd5;&#xff1b;&#x5bf9;&#x4e8e;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;&#xff0c;&#x90fd;&#x80fd;&#x591f;&#x8c03;&#x7528;&#x5b83;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#xff1b;&#x8fd9;&#x79cd;&#x52a8;&#x6001;&#x83b7;&#x53d6;&#x7684;&#x4fe1;&#x606f;&#x4ee5;&#x53ca;&#x52a8;&#x6001;&#x8c03;&#x7528;&#x5bf9;&#x8c61;&#x7684;&#x65b9;&#x6cd5;&#x7684;&#x529f;&#x80fd;&#x79f0;&#x4e3a;java&#x8bed;&#x8a00;&#x7684;&#x53cd;&#x5c04;&#x673a;&#x5236;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1488894777684" FOLDED="true" ID="ID_495906185" MODIFIED="1529657528252" TEXT="&#x4f5c;&#x7528;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488894791401" ID="ID_1823104282" MODIFIED="1522401958571" TEXT="&#x589e;&#x52a0;&#x7a0b;&#x5e8f;&#x7684;&#x7075;&#x6d3b;&#x6027;&#xff0c;&#x907f;&#x514d;&#x5c06;&#x7a0b;&#x5e8f;&#x5199;&#x6b7b;&#x5230;&#x4ee3;&#x7801;&#x91cc;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="messagebox_warning"/>
</node>
<node COLOR="#990000" CREATED="1488894926455" ID="ID_401853422" MODIFIED="1522401958571" TEXT="Java&#x7684;&#x4ee3;&#x7801;&#x603b;&#x662f;&#x5728;new&#x5bf9;&#x8c61;,&#x4e00;&#x4e2a;&#x7c7b;&#x6301;&#x6709;&#x53e6;&#x4e00;&#x4e2a;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;&#x5c31;&#x628a;&#x8fd9;&#x4e24;&#x4e2a;&#x7c7b;&#x5173;&#x8054;&#x4e86;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488894977556" ID="ID_1136868873" MODIFIED="1522401958571" TEXT="&#x8fd9;&#x6837;&#x5c31;&#x589e;&#x52a0;&#x7684;&#x7c7b;&#x548c;&#x7c7b;&#x4e4b;&#x95f4;&#x7684;&#x8026;&#x5408;&#x6027;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488895014475" ID="ID_1133424343" MODIFIED="1522401958571" TEXT="&#x4f7f;&#x7528;&#x53cd;&#x5c04;&#x53ef;&#x4ee5;&#x4f7f;&#x7c7b;&#x95f4;&#x7684;&#x8026;&#x5408;&#x6027;&#x964d;&#x4f4e;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488895041422" ID="ID_1177645122" MODIFIED="1522401958571" TEXT="&#x6bd4;&#x5982;SpringMvc&#x4e2d;&#x7684;&#x914d;&#x7f6e;&#x6587;&#x4ef6;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1488900082012" FOLDED="true" ID="ID_613025875" MODIFIED="1529657528253" TEXT="&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488900098693" FOLDED="true" ID="ID_194413667" MODIFIED="1529657528252" TEXT="Class">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488900745875" FOLDED="true" ID="ID_1074893572" MODIFIED="1529657528252" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488900699044" FOLDED="true" ID="ID_1414037056" MODIFIED="1529657528252" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1488900701083" FOLDED="true" ID="ID_418467548" MODIFIED="1529657528252" TEXT="public static Class&lt;?&gt; forName(String name, boolean initialize,">
<node COLOR="#111111" CREATED="1488900701086" ID="ID_360274548" MODIFIED="1488900701086" TEXT="ClassLoader loader)"/>
</node>
<node COLOR="#111111" CREATED="1488900713378" ID="ID_464547336" MODIFIED="1488900713378" TEXT="public static Class&lt;?&gt; forName(String className)"/>
</node>
<node COLOR="#111111" CREATED="1488900736907" FOLDED="true" ID="ID_204657207" MODIFIED="1529657528252" TEXT="public T newInstance()">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1488900751574" ID="ID_39053630" MODIFIED="1488900768934" TEXT="&#x5b9e;&#x4f8b;&#x5316;&#x4e00;&#x4e2a;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1488900978795" FOLDED="true" ID="ID_628993965" MODIFIED="1529657528252" TEXT="public native boolean isInstance(Object obj)">
<node COLOR="#111111" CREATED="1488900981374" ID="ID_1012810025" MODIFIED="1488900996639" TEXT="obj&#x662f;&#x5426;&#x662f;&#x8be5;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1488901017011" FOLDED="true" ID="ID_909950778" MODIFIED="1529657528252" TEXT="public String getName()">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1488901092739" ID="ID_1427763793" MODIFIED="1488901109936" TEXT="&#x7c7b;&#x540d;&#x5168;&#x8def;&#x5f84;"/>
</node>
<node COLOR="#111111" CREATED="1488901087636" FOLDED="true" ID="ID_1350893927" MODIFIED="1529657528252" TEXT="public String getSimpleName()">
<node COLOR="#111111" CREATED="1488901112104" ID="ID_1148205454" MODIFIED="1488901123014" TEXT="&#x53ea;&#x662f;&#x7c7b;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1488901032222" FOLDED="true" ID="ID_1711996168" MODIFIED="1529657528252" TEXT="public ClassLoader getClassLoader()">
<node COLOR="#111111" CREATED="1488902235073" ID="ID_853680297" MODIFIED="1488902243655" TEXT="&#x83b7;&#x53d6;&#x7c7b;&#x52a0;&#x8f7d;&#x5668;"/>
</node>
<node COLOR="#111111" CREATED="1488901310793" ID="ID_523041403" MODIFIED="1495606327574" TEXT="public Field[] getFields()">
<icon BUILTIN="stop-sign"/>
</node>
<node COLOR="#111111" CREATED="1488901692847" ID="ID_1062391138" MODIFIED="1488902316241" TEXT="public Field[] getDeclaredFields() "/>
<node COLOR="#111111" CREATED="1488901351376" FOLDED="true" ID="ID_178507509" MODIFIED="1529657528252" TEXT="public Field getField(String name)">
<node COLOR="#111111" CREATED="1488901354001" ID="ID_1269719251" MODIFIED="1488901368446" TEXT="&#x83b7;&#x53d6;&#x4e00;&#x4e2a;&#x5b57;&#x6bb5;,name&#x6307;&#x7684;&#x662f;&#x5b57;&#x6bb5;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1488901340865" ID="ID_1486569889" MODIFIED="1488902280287" TEXT="public Constructor&lt;?&gt;[] getConstructors()"/>
<node COLOR="#111111" CREATED="1488901600880" ID="ID_558921450" MODIFIED="1488902280289" TEXT="public Constructor&lt;?&gt;[] getDeclaredConstructors()"/>
<node COLOR="#111111" CREATED="1488901952210" ID="ID_1460508974" MODIFIED="1488902280290" TEXT="public Constructor&lt;T&gt; getDeclaredConstructor(Class&lt;?&gt;... parameterTypes)"/>
<node COLOR="#111111" CREATED="1488901326412" ID="ID_1582666447" MODIFIED="1488901326412" TEXT="public Method[] getMethods()"/>
<node COLOR="#111111" CREATED="1488902122340" ID="ID_1771012738" MODIFIED="1488902124883" TEXT="public Method[] getDeclaredMethods()"/>
<node COLOR="#111111" CREATED="1488901818272" FOLDED="true" ID="ID_1922799235" MODIFIED="1529657528252" TEXT="public Method getMethod(String name, Class&lt;?&gt;... parameterTypes)">
<node COLOR="#111111" CREATED="1488901827464" ID="ID_520589667" MODIFIED="1488902220333" TEXT="&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x7c7b;&#x5355;&#x4e2a;public&#x65b9;&#x6cd5;Method"/>
</node>
<node COLOR="#111111" CREATED="1488902178503" FOLDED="true" ID="ID_685717267" MODIFIED="1529657528252" TEXT="public Method getDeclaredMethod(String name, Class&lt;?&gt;... parameterTypes)">
<node COLOR="#111111" CREATED="1488901827464" ID="ID_1085462657" MODIFIED="1488902226817" TEXT="&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x7c7b;&#x548c;&#x7236;&#x7c7b;&#x5355;&#x4e2a;&#x4efb;&#x610f;&#x65b9;&#x6cd5;Method"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488901699928" FOLDED="true" ID="ID_85540950" MODIFIED="1529657528252" TEXT="&#x6ce8;&#x610f;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488901736010" FOLDED="true" ID="ID_1134925698" MODIFIED="1529657528252" TEXT="&#x4e0d;&#x5e26;Declared&#x7684;">
<node COLOR="#111111" CREATED="1488901371778" ID="ID_1501061053" MODIFIED="1488901396237" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x7c7b;&#x6240;&#x6709;&#x7684;public&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;"/>
</node>
<node COLOR="#111111" CREATED="1488901711042" FOLDED="true" ID="ID_1560585224" MODIFIED="1529657528252" TEXT="&#x5e26;Declared">
<node COLOR="#111111" CREATED="1488901607464" ID="ID_544185172" MODIFIED="1495607649739" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x7c7b;&#x6240;&#x6709;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;,&#x4e0d;&#x8bba;&#x662f;&#x4ec0;&#x4e48;&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;"/>
</node>
<node COLOR="#111111" CREATED="1488901845272" FOLDED="true" ID="ID_1656888506" MODIFIED="1529657528252" TEXT="parameterTypes">
<node COLOR="#111111" CREATED="1488901854096" ID="ID_1437148163" MODIFIED="1488901895803" TEXT="&#x6307;&#x7684;&#x662f;&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;&#x4e2d;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1488901909745" ID="ID_1812392377" MODIFIED="1488901924816" TEXT="&#x5982;&#x679c;&#x4e0d;&#x5199;&#x5219;&#x4ee3;&#x8868;&#x6ca1;&#x6709;&#x53c2;&#x6570;"/>
<node COLOR="#111111" CREATED="1488901892679" ID="ID_1482889799" MODIFIED="1488901892679" TEXT="&#x6bd4;&#x5982;String.class,Integer.class"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1488900117020" FOLDED="true" ID="ID_770909109" MODIFIED="1529657528252" TEXT="Constructor">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902363509" ID="ID_594104744" MODIFIED="1522401958574" TEXT="public String getName()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1488902384978" ID="ID_418715995" MODIFIED="1522401958574" TEXT="public Class&lt;?&gt;[] getParameterTypes()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1488902431884" FOLDED="true" ID="ID_1234659707" MODIFIED="1529657528252" TEXT="public T newInstance(Object ... initargs)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488902433837" ID="ID_730266254" MODIFIED="1488902459583" TEXT="&#x521d;&#x59cb;&#x5316;&#x5f53;&#x524d;&#x7c7b;,&#x76f8;&#x5f53;&#x4e8e;new &#x8be5;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;"/>
<node COLOR="#111111" CREATED="1488902468753" FOLDED="true" ID="ID_1649031271" MODIFIED="1529657528252" TEXT="initargs">
<node COLOR="#111111" CREATED="1488902470405" ID="ID_426776926" MODIFIED="1488902492239" TEXT="&#x521d;&#x59cb;&#x5316;&#x53c2;&#x6570;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;,&#x591a;&#x4e2a;,&#x6216;&#x8005;&#x6ca1;&#x6709;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1488900104481" FOLDED="true" ID="ID_1617319033" MODIFIED="1529657528252" TEXT="Method">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902527971" ID="ID_1330936457" MODIFIED="1522401958575" TEXT="public String getName()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1488902704915" ID="ID_1605805772" MODIFIED="1522401958575" TEXT="public Class&lt;?&gt; getReturnType()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1488902717070" FOLDED="true" ID="ID_239146134" MODIFIED="1529657528252" TEXT="public int getModifiers()">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488902720369" ID="ID_351701839" MODIFIED="1488902730336" TEXT="&#x8fd4;&#x56de;&#x65b9;&#x6cd5;&#x7684;&#x4fee;&#x9970;&#x7b26;&#x7ea7;&#x522b;"/>
</node>
<node COLOR="#111111" CREATED="1488902764893" FOLDED="true" ID="ID_647766955" MODIFIED="1529657528252" TEXT="public Class&lt;?&gt;[] getParameterTypes()">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488902768351" ID="ID_1345365558" MODIFIED="1488902775117" TEXT="&#x83b7;&#x53d6;&#x65b9;&#x6cd5;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;"/>
</node>
<node COLOR="#111111" CREATED="1488902799472" FOLDED="true" ID="ID_1085664808" MODIFIED="1529657528252" TEXT="public Object invoke(Object obj, Object... args)">
<font NAME="SansSerif" SIZE="12"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="messagebox_warning"/>
<node COLOR="#111111" CREATED="1488902806652" ID="ID_1304226841" MODIFIED="1488902812844" TEXT="&#x8c03;&#x7528;&#x8be5;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1488902819133" FOLDED="true" ID="ID_473524422" MODIFIED="1529657528252" TEXT="obj">
<node COLOR="#111111" CREATED="1488902824954" ID="ID_198946525" MODIFIED="1488902869718" TEXT="&#x5f53;&#x524d;&#x65b9;&#x6cd5;&#x6240;&#x5c5e;&#x7684;&#x5bf9;&#x8c61;&#x7684;&#x5b9e;&#x4f8b;:"/>
<node COLOR="#111111" CREATED="1488902870749" ID="ID_220292571" MODIFIED="1488902870749" TEXT="&#x5982; currentClass.newInstance()"/>
</node>
<node COLOR="#111111" CREATED="1488902872450" FOLDED="true" ID="ID_1280463476" MODIFIED="1529657528252" TEXT="args">
<node COLOR="#111111" CREATED="1488902877077" ID="ID_643923933" MODIFIED="1488902895093" TEXT="&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x5b9e;&#x9645;&#x53c2;&#x6570;&#x5217;&#x8868;"/>
<node COLOR="#111111" CREATED="1488902895702" ID="ID_561438885" MODIFIED="1488902907188" TEXT="&#x5982;&#x679c;&#x65b9;&#x6cd5;&#x6ca1;&#x6709;&#x53c2;&#x6570;&#x5217;&#x8868;,&#x5219;&#x4e0d;&#x5199;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1488900110164" FOLDED="true" ID="ID_399862368" MODIFIED="1529657528253" TEXT="Field">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902527971" ID="ID_106660134" MODIFIED="1522401958575" TEXT="public String getName()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1488902717070" FOLDED="true" ID="ID_359245539" MODIFIED="1529657528253" TEXT="public int getModifiers()">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488902720369" ID="ID_1228526257" MODIFIED="1488902967746" TEXT="&#x8fd4;&#x56de;&#x5b57;&#x6bb5;&#x7684;&#x4fee;&#x9970;&#x7b26;&#x7ea7;&#x522b;"/>
</node>
<node COLOR="#111111" CREATED="1488902986086" ID="ID_215123968" MODIFIED="1522401958575" TEXT="public Class&lt;?&gt; getType()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1488903159491" FOLDED="true" ID="ID_910133906" MODIFIED="1529657528253" TEXT="&#x83b7;&#x53d6;&#x5b57;&#x6bb5;&#x7684;&#x503c;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488903001496" FOLDED="true" ID="ID_1792433076" MODIFIED="1529657528253" TEXT="public Object get(Object obj)">
<node COLOR="#111111" CREATED="1488903004936" ID="ID_209110879" MODIFIED="1488903021345" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x5c5e;&#x6027;&#x7684;&#x503c;"/>
<node COLOR="#111111" CREATED="1488903021910" ID="ID_147670979" MODIFIED="1488903032980" TEXT="&#x8fd4;&#x56de;object&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1488902819133" FOLDED="true" ID="ID_1522677544" MODIFIED="1529657528253" TEXT="obj">
<node COLOR="#111111" CREATED="1488902824954" ID="ID_300779258" MODIFIED="1488902869718" TEXT="&#x5f53;&#x524d;&#x65b9;&#x6cd5;&#x6240;&#x5c5e;&#x7684;&#x5bf9;&#x8c61;&#x7684;&#x5b9e;&#x4f8b;:"/>
<node COLOR="#111111" CREATED="1488902870749" ID="ID_1844653831" MODIFIED="1488902870749" TEXT="&#x5982; currentClass.newInstance()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488903092344" ID="ID_567806640" MODIFIED="1488903092344" TEXT="public boolean getBoolean(Object obj)"/>
<node COLOR="#111111" CREATED="1488903098849" ID="ID_419593487" MODIFIED="1488903098849" TEXT="public byte getByte(Object obj)"/>
<node COLOR="#111111" CREATED="1488903105032" ID="ID_684446452" MODIFIED="1488903105032" TEXT="public char getChar(Object obj)"/>
<node COLOR="#111111" CREATED="1488903110635" ID="ID_764424163" MODIFIED="1488903110635" TEXT="public short getShort(Object obj)"/>
<node COLOR="#111111" CREATED="1488903116790" ID="ID_1179442091" MODIFIED="1488903116790" TEXT="public int getInt(Object obj)"/>
<node COLOR="#111111" CREATED="1488903125419" ID="ID_1514540748" MODIFIED="1488903125419" TEXT="public long getLong(Object obj)"/>
<node COLOR="#111111" CREATED="1488903133754" ID="ID_1215590521" MODIFIED="1488903133754" TEXT="public float getFloat(Object obj)"/>
<node COLOR="#111111" CREATED="1488903142011" ID="ID_751433852" MODIFIED="1488903142011" TEXT="public double getDouble(Object obj)"/>
</node>
<node COLOR="#111111" CREATED="1488903183929" FOLDED="true" ID="ID_1672537611" MODIFIED="1529657528253" TEXT="&#x8bbe;&#x7f6e;&#x5b57;&#x6bb5;&#x7684;&#x503c;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488903153743" ID="ID_518528666" MODIFIED="1488903153743" TEXT="public void set(Object obj, Object value)"/>
<node COLOR="#111111" CREATED="1488903181097" ID="ID_1016808657" MODIFIED="1488903181097" TEXT="public void setBoolean(Object obj, boolean z)"/>
<node COLOR="#111111" CREATED="1488903200675" ID="ID_636952957" MODIFIED="1488903200675" TEXT="public void setByte(Object obj, byte b)"/>
<node COLOR="#111111" CREATED="1488903208173" ID="ID_673957889" MODIFIED="1488903208173" TEXT="public void setChar(Object obj, char c)"/>
<node COLOR="#111111" CREATED="1488903214541" ID="ID_1989008176" MODIFIED="1488903214541" TEXT="public void setShort(Object obj, short s)"/>
<node COLOR="#111111" CREATED="1488903222095" ID="ID_1256397475" MODIFIED="1488903222096" TEXT="public void setInt(Object obj, int i)"/>
<node COLOR="#111111" CREATED="1488903231150" ID="ID_323051938" MODIFIED="1488903231150" TEXT="public void setLong(Object obj, long l)"/>
<node COLOR="#111111" CREATED="1488903237561" ID="ID_525255355" MODIFIED="1488903237561" TEXT="public void setFloat(Object obj, float f)"/>
<node COLOR="#111111" CREATED="1488903243047" ID="ID_1463792592" MODIFIED="1488903243047" TEXT="public void setDouble(Object obj, double d)"/>
</node>
</node>
<node COLOR="#990000" CREATED="1488900582271" FOLDED="true" ID="ID_1393898705" MODIFIED="1529657528253" TEXT="ClassLoader">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488900595415" FOLDED="true" ID="ID_1102400146" MODIFIED="1529657528253" TEXT="?">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1488900600259" ID="ID_140253400" MODIFIED="1488900634675" TEXT="cls.getClass().getClassLoader()"/>
<node COLOR="#111111" CREATED="1488900635170" ID="ID_1508780714" MODIFIED="1488900659335" TEXT="&#x6216; xx.class.getClassLoader()"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1502688170442" FOLDED="true" ID="ID_1683815232" MODIFIED="1529657528254" TEXT="&#x6ce8;&#x89e3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1502688338587" FOLDED="true" ID="ID_528988239" MODIFIED="1529657528254" TEXT="&#x5143;&#x6ce8;&#x89e3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1502688363663" FOLDED="true" ID="ID_1466814333" MODIFIED="1529657528253" TEXT="?">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1502688365566" ID="ID_1503252432" MODIFIED="1502688386529" TEXT="&#x7528;&#x6765;&#x6ce8;&#x89e3;&#x81ea;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x7684;&#x6ce8;&#x89e3;"/>
</node>
<node COLOR="#111111" CREATED="1502688388564" FOLDED="true" ID="ID_735423956" MODIFIED="1529657528254" TEXT="&#x5206;&#x7c7b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1502688390770" FOLDED="true" ID="ID_233717527" MODIFIED="1529657528253" TEXT="@Target">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1502688470866" FOLDED="true" ID="ID_1306965733" MODIFIED="1529657528253">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502688467930" ID="ID_995535722" MODIFIED="1502688467931" TEXT="@Target&#x8bf4;&#x660e;&#x4e86;Annotation&#x6240;&#x4fee;&#x9970;&#x7684;&#x5bf9;&#x8c61;&#x8303;&#x56f4;"/>
</node>
<node COLOR="#111111" CREATED="1502688476975" FOLDED="true" ID="ID_1973276297" MODIFIED="1529657528253">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33539;&#22260;&#30340;&#21462;&#20540;&#26159;&#19968;&#20010;&#26522;&#20030;ElementType
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502688545177" ID="ID_648509303" MODIFIED="1502688551255" TEXT="CONSTRUCTOR:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x6784;&#x9020;&#x5668;"/>
<node COLOR="#111111" CREATED="1502688545195" ID="ID_1656802221" MODIFIED="1502688554873" TEXT="FIELD:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x57df;"/>
<node COLOR="#111111" CREATED="1502688545201" ID="ID_1808959307" MODIFIED="1502688558539" TEXT="LOCAL_VARIABLE:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x5c40;&#x90e8;&#x53d8;&#x91cf;"/>
<node COLOR="#111111" CREATED="1502688545207" ID="ID_723309580" MODIFIED="1502688564653" TEXT="METHOD:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1502688545211" FOLDED="true" ID="ID_1487876722" MODIFIED="1529657528253" TEXT="PACKAGE:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x5305;">
<node COLOR="#111111" CREATED="1502688782463" ID="ID_1692215475" MODIFIED="1502688782464" TEXT="@Target(value=ElementType.PACKAGE)&#x65f6;&#xff0c;&#x5b83;&#x5373;&#x662f;&#x5bf9;&#x5305;&#x7684;&#x4fee;&#x9970;&#x6ce8;&#x91ca;&#x3002;"/>
<node COLOR="#111111" CREATED="1502688795303" FOLDED="true" ID="ID_1191704623" MODIFIED="1529657528253" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1502688956913" FOLDED="true" ID="ID_570438502" MODIFIED="1529657528253" TEXT="&#x6ce8;&#x89e3;">
<node COLOR="#111111" CREATED="1502688970904" ID="ID_751404618" MODIFIED="1502688973723" TEXT="&amp;lt;html&amp;gt;&#xa;  &amp;lt;body&amp;gt;&#xa;    &amp;lt;p align=&amp;quot;left&amp;quot; style=&amp;quot;background-color: rgb(43,; background-position: 43, 43); background-image: null; background-repeat: repeat; background-attachment: scroll&amp;quot;&amp;gt;&#xa;      &amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;@Target&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;(&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#D0D0FF&amp;quot;&amp;gt;value&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;= {ElementType.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;METHOD&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;,&amp;lt;/font&amp;gt;&amp;#xa0;&#xa;      &amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;ElementType.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;PACKAGE&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;,&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;ElementType.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;TYPE&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;})&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;@Retention&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;(RetentionPolicy.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;RUNTIME&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;public&amp;lt;/font&amp;gt;&amp;#xa0;&#xa;      &amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;@&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;interface&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;{&amp;lt;br&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&#xa;      String&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#FFC66D&amp;quot;&amp;gt;names&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;()&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;default&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#6A8759&amp;quot;&amp;gt;&amp;amp;quot;&amp;amp;quot;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;}&amp;lt;/font&amp;gt;&#xa;    &amp;lt;/p&amp;gt;&#xa;    &amp;lt;p&amp;gt;&#xa;      &#xa;    &amp;lt;/p&amp;gt;&#xa;  &amp;lt;/body&amp;gt;&#xa;&amp;lt;/html&amp;gt;"/>
</node>
<node COLOR="#111111" CREATED="1502688979368" FOLDED="true" ID="ID_233698586" MODIFIED="1529657528253" TEXT="&#x6ce8;&#x89e3;&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1502688816503" ID="ID_708448979" MODIFIED="1502688816503" TEXT="&#x6ce8;&#x89e3;&#x4e0d;&#x80fd;&#x76f4;&#x63a5;&#x7528;&#x4e8e;&#x7c7b;&#x4e2d;&#xff0c;&#x5fc5;&#x987b;&#x5728;&#x76f8;&#x5e94;package&#x4e0b;&#x521b;&#x5efa;package-info.java&#x6587;&#x4ef6;&#xff1a;"/>
<node COLOR="#111111" CREATED="1502688831526" ID="ID_87399917" MODIFIED="1502688845383">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #2B2B2B; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null"><font color="#BBB529">@MyAopAnno</font><font color="#A9B7C6">(</font><font color="#D0D0FF">names </font><font color="#A9B7C6">= </font><font color="#6A8759">&quot;&#21704;&#21704;&quot;</font><font color="#A9B7C6">)<br /></font><font color="#CC7832">package </font><font color="#A9B7C6">com.scn7th.model</font><font color="#CC7832">;<br />
import </font><font color="#BBB529">com.scn7th.aop.MyAopAnno</font><font color="#CC7832">;</font>
</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1502688903355" FOLDED="true" ID="ID_1772744809" MODIFIED="1529657528253">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27979;&#35797;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502688947383" ID="ID_1654900529" MODIFIED="1502688950137" TEXT="&amp;lt;html&amp;gt;&#xa;  &amp;lt;body&amp;gt;&#xa;    &amp;lt;pre style=&amp;quot;background-color: #2B2B2B; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null&amp;quot;&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;@Test&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;public void &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#FFC66D&amp;quot;&amp;gt;testPackage&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;() {&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; Package myPackage = Package.&amp;lt;i&amp;gt;getPackage&amp;lt;/i&amp;gt;(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#6A8759&amp;quot;&amp;gt;&amp;amp;quot;com.scn7th.model&amp;amp;quot;&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; if&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;null &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;!= myPackage &amp;amp;amp;&amp;amp;amp; myPackage.isAnnotationPresent(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;.&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;class&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)) {&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;myAopAnno = myPackage.getAnnotation(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;.&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;class&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;System.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;out&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;.println(myAopAnno.names())&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;}&amp;lt;br&amp;gt;&#xa;}&amp;lt;/font&amp;gt;&#xa;&amp;lt;/pre&amp;gt;&#xa;    &amp;lt;p&amp;gt;&#xa;      &#xa;    &amp;lt;/p&amp;gt;&#xa;  &amp;lt;/body&amp;gt;&#xa;&amp;lt;/html&amp;gt;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1502688545218" ID="ID_1516181425" MODIFIED="1502689016294" TEXT="PARAMETER:  &#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x53c2;&#x6570;"/>
<node COLOR="#111111" CREATED="1502688545220" ID="ID_532534527" MODIFIED="1502688580131" TEXT="TYPE:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x7c7b;&#x3001;&#x63a5;&#x53e3;(&#x5305;&#x62ec;&#x6ce8;&#x89e3;&#x7c7b;&#x578b;) &#x6216;enum&#x58f0;&#x660e;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1502688390778" FOLDED="true" ID="ID_890330835" MODIFIED="1529657528253" TEXT="@Retention">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1502689095310" FOLDED="true" ID="ID_770669335" MODIFIED="1529657528253" TEXT="?">
<node COLOR="#111111" CREATED="1502689096739" ID="ID_1424351636" MODIFIED="1502689122911" TEXT="&#x5b9a;&#x4e49;&#x4e86;&#x8be5;Annotation&#x88ab;&#x4fdd;&#x7559;&#x7684;&#x65f6;&#x95f4;&#x957f;&#x77ed;&#xff1a;&#x67d0;&#x4e9b;Annotation&#x4ec5;&#x51fa;&#x73b0;&#x5728;&#x6e90;&#x4ee3;&#x7801;&#x4e2d;&#xff0c;&#x800c;&#x88ab;&#x7f16;&#x8bd1;&#x5668;&#x4e22;&#x5f03;&#xff1b;&#x800c;&#x53e6;&#x4e00;&#x4e9b;&#x5374;&#x88ab;&#x7f16;&#x8bd1;&#x5728;class&#x6587;&#x4ef6;&#x4e2d;&#xff1b;&#x7f16;&#x8bd1;&#x5728;class&#x6587;&#x4ef6;&#x4e2d;&#x7684;Annotation&#x53ef;&#x80fd;&#x4f1a;&#x88ab;&#x865a;&#x62df;&#x673a;&#x5ffd;&#x7565;&#xff0c;&#x800c;&#x53e6;&#x4e00;&#x4e9b;&#x5728;class&#x88ab;&#x88c5;&#x8f7d;&#x65f6;&#x5c06;&#x88ab;&#x8bfb;&#x53d6;&#xff08;&#x8bf7;&#x6ce8;&#x610f;&#x5e76;&#x4e0d;&#x5f71;&#x54cd;class&#x7684;&#x6267;&#x884c;&#xff0c;&#x56e0;&#x4e3a;Annotation&#x4e0e;class&#x5728;&#x4f7f;&#x7528;&#x4e0a;&#x662f;&#x88ab;&#x5206;&#x79bb;&#x7684;&#xff09;&#x3002;&#x4f7f;&#x7528;&#x5b83;&#x53ef;&#x4ee5;&#x5bf9; Annotation&#x7684;&#x201c;&#x751f;&#x547d;&#x5468;&#x671f;&#x201d;&#x9650;&#x5236;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1502689136115" ID="ID_719932032" MODIFIED="1502689136116" TEXT="&#x4f5c;&#x7528;&#xff1a;&#x8868;&#x793a;&#x9700;&#x8981;&#x5728;&#x4ec0;&#x4e48;&#x7ea7;&#x522b;&#x4fdd;&#x5b58;&#x8be5;&#x6ce8;&#x91ca;&#x4fe1;&#x606f;&#xff0c;&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x6ce8;&#x89e3;&#x7684;&#x751f;&#x547d;&#x5468;&#x671f;&#xff08;&#x5373;&#xff1a;&#x88ab;&#x63cf;&#x8ff0;&#x7684;&#x6ce8;&#x89e3;&#x5728;&#x4ec0;&#x4e48;&#x8303;&#x56f4;&#x5185;&#x6709;&#x6548;&#xff09;"/>
<node COLOR="#111111" CREATED="1502689143031" FOLDED="true" ID="ID_252065681" MODIFIED="1529657528253" TEXT="&#x53d6;&#x503c;: &#x679a;&#x4e3e;RetentionPoicy">
<node COLOR="#111111" CREATED="1502689164061" ID="ID_1745035107" MODIFIED="1502689169469" TEXT="SOURCE:&#x5728;&#x6e90;&#x6587;&#x4ef6;&#x4e2d;&#x6709;&#x6548;&#xff08;&#x5373;&#x6e90;&#x6587;&#x4ef6;&#x4fdd;&#x7559;&#xff09;"/>
<node COLOR="#111111" CREATED="1502689164064" ID="ID_1965155446" MODIFIED="1502689174162" TEXT="CLASS:&#x5728;class&#x6587;&#x4ef6;&#x4e2d;&#x6709;&#x6548;&#xff08;&#x5373;class&#x4fdd;&#x7559;&#xff09;"/>
<node COLOR="#111111" CREATED="1502689164065" ID="ID_1324069914" MODIFIED="1502689179418" TEXT="RUNTIME:&#x5728;&#x8fd0;&#x884c;&#x65f6;&#x6709;&#x6548;&#xff08;&#x5373;&#x8fd0;&#x884c;&#x65f6;&#x4fdd;&#x7559;&#xff09;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1502688390780" FOLDED="true" ID="ID_846567275" MODIFIED="1529657528253" TEXT="@Documented">
<node COLOR="#111111" CREATED="1502689225317" ID="ID_1424005277" MODIFIED="1502689229064" TEXT="&#x3000;&#x3000;@Documented&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x5176;&#x5b83;&#x7c7b;&#x578b;&#x7684;annotation&#x5e94;&#x8be5;&#x88ab;&#x4f5c;&#x4e3a;&#x88ab;&#x6807;&#x6ce8;&#x7684;&#x7a0b;&#x5e8f;&#x6210;&#x5458;&#x7684;&#x516c;&#x5171;API&#xff0c;&#x56e0;&#x6b64;&#x53ef;&#x4ee5;&#x88ab;&#x4f8b;&#x5982;javadoc&#x6b64;&#x7c7b;&#x7684;&#x5de5;&#x5177;&#x6587;&#x6863;&#x5316;&#x3002;Documented&#x662f;&#x4e00;&#x4e2a;&#x6807;&#x8bb0;&#x6ce8;&#x89e3;&#xff0c;&#x6ca1;&#x6709;&#x6210;&#x5458;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1502688390784" FOLDED="true" ID="ID_561804300" MODIFIED="1529657528254" TEXT="@Inherited">
<node COLOR="#111111" CREATED="1502689308753" FOLDED="true" ID="ID_1357814103" MODIFIED="1529657528253">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502689260755" ID="ID_942011825" MODIFIED="1502689264347" TEXT="@Inherited &#x5143;&#x6ce8;&#x89e3;&#x662f;&#x4e00;&#x4e2a;&#x6807;&#x8bb0;&#x6ce8;&#x89e3;&#xff0c;@Inherited&#x9610;&#x8ff0;&#x4e86;&#x67d0;&#x4e2a;&#x88ab;&#x6807;&#x6ce8;&#x7684;&#x7c7b;&#x578b;&#x662f;&#x88ab;&#x7ee7;&#x627f;&#x7684;&#x3002;&#x5982;&#x679c;&#x4e00;&#x4e2a;&#x4f7f;&#x7528;&#x4e86;@Inherited&#x4fee;&#x9970;&#x7684;annotation&#x7c7b;&#x578b;&#x88ab;&#x7528;&#x4e8e;&#x4e00;&#x4e2a;class&#xff0c;&#x5219;&#x8fd9;&#x4e2a;annotation&#x5c06;&#x88ab;&#x7528;&#x4e8e;&#x8be5;class&#x7684;&#x5b50;&#x7c7b;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1502689291747" FOLDED="true" ID="ID_62772136" MODIFIED="1529657528254" TEXT="&#x6ce8;&#x610f;&#xff1a;">
<node COLOR="#111111" CREATED="1502689306514" ID="ID_451073848" MODIFIED="1502689306516" TEXT="@Inherited annotation&#x7c7b;&#x578b;&#x662f;&#x88ab;&#x6807;&#x6ce8;&#x8fc7;&#x7684;class&#x7684;&#x5b50;&#x7c7b;&#x6240;&#x7ee7;&#x627f;&#x3002;&#x7c7b;&#x5e76;&#x4e0d;&#x4ece;&#x5b83;&#x6240;&#x5b9e;&#x73b0;&#x7684;&#x63a5;&#x53e3;&#x7ee7;&#x627f;annotation&#xff0c;&#x65b9;&#x6cd5;&#x5e76;&#x4e0d;&#x4ece;&#x5b83;&#x6240;&#x91cd;&#x8f7d;&#x7684;&#x65b9;&#x6cd5;&#x7ee7;&#x627f;annotation&#x3002;"/>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1502689365546" FOLDED="true" ID="ID_990547591" MODIFIED="1529657528254" TEXT="&#x81ea;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1502689393525" FOLDED="true" ID="ID_367035540" MODIFIED="1529657528254" TEXT="?">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1502689394370" ID="ID_185529543" MODIFIED="1502689977799" TEXT="&#x4f7f;&#x7528;@interface&#x81ea;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x65f6;&#xff0c;&#x81ea;&#x52a8;&#x7ee7;&#x627f;&#x4e86;java.lang.annotation.Annotation&#x63a5;&#x53e3;&#xff0c;&#x7531;&#x7f16;&#x8bd1;&#x7a0b;&#x5e8f;&#x81ea;&#x52a8;&#x5b8c;&#x6210;&#x5176;&#x4ed6;&#x7ec6;&#x8282;&#x3002;&#x5728;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x65f6;&#xff0c;&#x4e0d;&#x80fd;&#x7ee7;&#x627f;&#x5176;&#x4ed6;&#x7684;&#x6ce8;&#x89e3;&#x6216;&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1502689413725" ID="ID_1864516889" MODIFIED="1502689413726" TEXT="@interface&#x7528;&#x6765;&#x58f0;&#x660e;&#x4e00;&#x4e2a;&#x6ce8;&#x89e3;&#xff0c;&#x5176;&#x4e2d;&#x7684;&#x6bcf;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#x5b9e;&#x9645;&#x4e0a;&#x662f;&#x58f0;&#x660e;&#x4e86;&#x4e00;&#x4e2a;&#x914d;&#x7f6e;&#x53c2;&#x6570;&#x3002;&#x65b9;&#x6cd5;&#x7684;&#x540d;&#x79f0;&#x5c31;&#x662f;&#x53c2;&#x6570;&#x7684;&#x540d;&#x79f0;&#xff0c;&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;&#x5c31;&#x662f;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;&#xff08;&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;&#x53ea;&#x80fd;&#x662f;&#x57fa;&#x672c;&#x7c7b;&#x578b;&#x3001;Class&#x3001;String&#x3001;enum&#xff09;&#x3002;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;default&#x6765;&#x58f0;&#x660e;&#x53c2;&#x6570;&#x7684;&#x9ed8;&#x8ba4;&#x503c;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1502689419828" FOLDED="true" ID="ID_1599531647" MODIFIED="1529657528254" TEXT="&#x65b9;&#x6cd5;&#x7684;&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1502689442146" FOLDED="true" ID="ID_550352527" MODIFIED="1529657528254" TEXT="&#x57fa;&#x672c;&#x7c7b;&#x578b;">
<node COLOR="#111111" CREATED="1502689503581" ID="ID_1838989072" MODIFIED="1502689503581" TEXT="int,float,boolean,byte,double,char,long,short"/>
</node>
<node COLOR="#111111" CREATED="1502689448928" FOLDED="true" ID="ID_633272878" MODIFIED="1529657528254" TEXT="Class">
<node COLOR="#111111" CREATED="1502689472765" ID="ID_1177935763" MODIFIED="1502689483321" TEXT="&#x6ce8;&#x610f;: &#x662f;Class"/>
</node>
<node COLOR="#111111" CREATED="1502689458395" ID="ID_76553652" MODIFIED="1502689464084" TEXT="String"/>
<node COLOR="#111111" CREATED="1502689465482" ID="ID_1767018824" MODIFIED="1502689469752" TEXT="enum"/>
<node COLOR="#111111" CREATED="1502689521936" ID="ID_251397504" MODIFIED="1502689521937" TEXT="Annotation&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1502689533714" ID="ID_385366670" MODIFIED="1502689533714" TEXT="&#x4ee5;&#x4e0a;&#x6240;&#x6709;&#x7c7b;&#x578b;&#x7684;&#x6570;&#x7ec4;"/>
</node>
<node COLOR="#111111" CREATED="1502689554539" FOLDED="true" ID="ID_1961698605" MODIFIED="1529657528254" TEXT="&#x7ec6;&#x8282;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1502689566459" ID="ID_1432614181" MODIFIED="1502689566460" TEXT="&#x53ea;&#x80fd;&#x7528;public&#x6216;&#x9ed8;&#x8ba4;(default)&#x8fd9;&#x4e24;&#x4e2a;&#x8bbf;&#x95ee;&#x6743;&#x4fee;&#x9970;.&#x4f8b;&#x5982;,String value();&#x8fd9;&#x91cc;&#x628a;&#x65b9;&#x6cd5;&#x8bbe;&#x4e3a;defaul&#x9ed8;&#x8ba4;&#x7c7b;&#x578b;&#xff1b;&#x3000; &#x3000;"/>
<node COLOR="#111111" CREATED="1502689633442" ID="ID_388904547" MODIFIED="1502689633443" TEXT="&#x5982;&#x679c;&#x53ea;&#x6709;&#x4e00;&#x4e2a;&#x53c2;&#x6570;&#x6210;&#x5458;,&#x6700;&#x597d;&#x628a;&#x53c2;&#x6570;&#x540d;&#x79f0;&#x8bbe;&#x4e3a;&quot;value&quot;,&#x540e;&#x52a0;&#x5c0f;&#x62ec;&#x53f7;"/>
<node COLOR="#111111" CREATED="1502689878553" FOLDED="true" ID="ID_775325462" MODIFIED="1529657528254" TEXT="&#x6ce8;&#x89e3;&#x5143;&#x7d20;&#x7684;&#x9ed8;&#x8ba4;&#x503c;&#xff1a;">
<node COLOR="#111111" CREATED="1502689894923" ID="ID_1229029079" MODIFIED="1502689940683" TEXT="&#x6ce8;&#x89e3;&#x5143;&#x7d20;&#x5fc5;&#x987b;&#x6709;&#x786e;&#x5b9a;&#x7684;&#x503c;&#xff0c;&#x8981;&#x4e48;&#x5728;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x7684;&#x9ed8;&#x8ba4;&#x503c;&#x4e2d;&#x6307;&#x5b9a;&#xff0c;&#xa;&#x8981;&#x4e48;&#x5728;&#x4f7f;&#x7528;&#x6ce8;&#x89e3;&#x65f6;&#x6307;&#x5b9a;&#xff0c;&#x975e;&#x57fa;&#x672c;&#x7c7b;&#x578b;&#x7684;&#x6ce8;&#x89e3;&#x5143;&#x7d20;&#x7684;&#x503c;&#x4e0d;&#x53ef;&#x4e3a;null"/>
<node COLOR="#111111" CREATED="1502689917128" ID="ID_1978241729" MODIFIED="1502689933464" TEXT="&#x4f7f;&#x7528;&#x7a7a;&#x5b57;&#x7b26;&#x4e32;&#x6216;0&#x4f5c;&#x4e3a;&#x9ed8;&#x8ba4;&#x503c;&#x662f;&#x4e00;&#x79cd;&#x5e38;&#x7528;&#x7684;&#x505a;&#x6cd5;&#x3002;&#x8fd9;&#x4e2a;&#x7ea6;&#x675f;&#x4f7f;&#x5f97;&#x5904;&#x7406;&#xa;&#x5668;&#x5f88;&#x96be;&#x8868;&#x73b0;&#x4e00;&#x4e2a;&#x5143;&#x7d20;&#x7684;&#x5b58;&#x5728;&#x6216;&#x7f3a;&#x5931;&#x7684;&#x72b6;&#x6001;&#xff0c;&#x56e0;&#x4e3a;&#x6bcf;&#x4e2a;&#x6ce8;&#x89e3;&#x7684;&#x58f0;&#x660e;&#x4e2d;&#xff0c;&#xa;&#x6240;&#x6709;&#x5143;&#x7d20;&#x90fd;&#x5b58;&#x5728;&#xff0c;&#x5e76;&#x4e14;&#x90fd;&#x5177;&#x6709;&#x76f8;&#x5e94;&#x7684;&#x503c;&#xff0c;&#x4e3a;&#x4e86;&#x7ed5;&#x5f00;&#x8fd9;&#x4e2a;&#x7ea6;&#x675f;&#xff0c;&#x6211;&#x4eec;&#xa;&#x53ea;&#x80fd;&#x5b9a;&#x4e49;&#x4e00;&#x4e9b;&#x7279;&#x6b8a;&#x7684;&#x503c;&#xff0c;&#x4f8b;&#x5982;&#x7a7a;&#x5b57;&#x7b26;&#x4e32;&#x6216;&#x8005;&#x8d1f;&#x6570;&#xff0c;&#x4e00;&#x6b21;&#x8868;&#x793a;&#x67d0;&#x4e2a;&#xa;&#x5143;&#x7d20;&#x4e0d;&#x5b58;&#x5728;&#xff0c;&#x5728;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x65f6;&#xff0c;&#x8fd9;&#x5df2;&#x7ecf;&#x6210;&#x4e3a;&#x4e00;&#x4e2a;&#x4e60;&#x60ef;&#x7528;"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1508979837075" FOLDED="true" ID="ID_286170288" MODIFIED="1529657528255" POSITION="right" TEXT="VO/PO/DO/DTO">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1508979869260" FOLDED="true" ID="ID_1826452119" MODIFIED="1529657528254" TEXT="VO&#xff08;View Object&#xff09;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1508979922073" FOLDED="true" ID="ID_1794782277" MODIFIED="1529657528254">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508979878829" ID="ID_196407538" MODIFIED="1508979922087" TEXT="&#x89c6;&#x56fe;&#x5bf9;&#x8c61;&#xff0c;&#x7528;&#x4e8e;&#x5c55;&#x793a;&#x5c42;&#xff0c;&#x5b83;&#x7684;&#x4f5c;&#x7528;&#x662f;&#x628a;&#x67d0;&#x4e2a;&#x6307;&#x5b9a;&#x9875;&#x9762;&#xff08;&#x6216;&#x7ec4;&#x4ef6;&#xff09;&#x7684;&#x6240;&#x6709;&#x6570;&#x636e;&#x5c01;&#x88c5;&#x8d77;&#x6765;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1508979873230" FOLDED="true" ID="ID_1729534140" MODIFIED="1529657528254" TEXT="DTO&#xff08;Data Transfer Object&#xff09;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1508979928828" FOLDED="true" ID="ID_699171192" MODIFIED="1529657528254">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508979885211" ID="ID_1784555395" MODIFIED="1508979970000" TEXT="&#x6570;&#x636e;&#x4f20;&#x8f93;&#x5bf9;&#x8c61;&#xff0c;&#x8fd9;&#x4e2a;&#x6982;&#x5ff5;&#x6765;&#x6e90;&#x4e8e;J2EE&#x7684;&#x8bbe;&#x8ba1;&#x6a21;&#x5f0f;&#xff0c;&#x539f;&#x6765;&#x7684;&#x76ee;&#x7684;&#x662f;&#xa;&#x4e3a;&#x4e86;EJB&#x7684;&#x5206;&#x5e03;&#x5f0f;&#x5e94;&#x7528;&#x63d0;&#x4f9b;&#x7c97;&#x7c92;&#x5ea6;&#x7684;&#x6570;&#x636e;&#x5b9e;&#x4f53;&#xff0c;&#x4ee5;&#x51cf;&#x5c11;&#x5206;&#x5e03;&#x5f0f;&#x8c03;&#x7528;&#xa;&#x7684;&#x6b21;&#x6570;&#xff0c;&#x4ece;&#x800c;&#x63d0;&#x9ad8;&#x5206;&#x5e03;&#x5f0f;&#x8c03;&#x7528;&#x7684;&#x6027;&#x80fd;&#x548c;&#x964d;&#x4f4e;&#x7f51;&#x7edc;&#x8d1f;&#x8f7d;&#xff0c;&#x4f46;&#x5728;&#x8fd9;&#x91cc;&#xff0c;&#xa;&#x6211;&#x6cdb;&#x6307;&#x7528;&#x4e8e;&#x5c55;&#x793a;&#x5c42;&#x4e0e;&#x670d;&#x52a1;&#x5c42;&#x4e4b;&#x95f4;&#x7684;&#x6570;&#x636e;&#x4f20;&#x8f93;&#x5bf9;&#x8c61;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1508979892411" FOLDED="true" ID="ID_1633522371" MODIFIED="1529657528254" TEXT="DO&#xff08;Domain Object&#xff09;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1508979936444" FOLDED="true" ID="ID_685838564" MODIFIED="1529657528254">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508979896880" ID="ID_68056070" MODIFIED="1508979936451" TEXT="&#x9886;&#x57df;&#x5bf9;&#x8c61;&#xff0c;&#x5c31;&#x662f;&#x4ece;&#x73b0;&#x5b9e;&#x4e16;&#x754c;&#x4e2d;&#x62bd;&#x8c61;&#x51fa;&#x6765;&#x7684;&#x6709;&#x5f62;&#x6216;&#x65e0;&#x5f62;&#x7684;&#x4e1a;&#x52a1;&#x5b9e;&#x4f53;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1508979907234" FOLDED="true" ID="ID_1138590604" MODIFIED="1529657528255" TEXT="PO&#xff08;Persistent Object&#xff09;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1508979943719" FOLDED="true" ID="ID_678724923" MODIFIED="1529657528255">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508979912516" ID="ID_1320030052" MODIFIED="1508979962844" TEXT="&#x6301;&#x4e45;&#x5316;&#x5bf9;&#x8c61;&#xff0c;&#x5b83;&#x8ddf;&#x6301;&#x4e45;&#x5c42;&#xff08;&#x901a;&#x5e38;&#x662f;&#x5173;&#x7cfb;&#x578b;&#x6570;&#x636e;&#x5e93;&#xff09;&#x7684;&#x6570;&#x636e;&#x7ed3;&#x6784;&#x5f62;&#x6210;&#x4e00;&#xa;&#x4e00;&#x5bf9;&#x5e94;&#x7684;&#x6620;&#x5c04;&#x5173;&#x7cfb;&#xff0c;&#x5982;&#x679c;&#x6301;&#x4e45;&#x5c42;&#x662f;&#x5173;&#x7cfb;&#x578b;&#x6570;&#x636e;&#x5e93;&#xff0c;&#x90a3;&#x4e48;&#xff0c;&#x6570;&#x636e;&#x8868;&#x4e2d;&#x7684;&#xa;&#x6bcf;&#x4e2a;&#x5b57;&#x6bb5;&#xff08;&#x6216;&#x82e5;&#x5e72;&#x4e2a;&#xff09;&#x5c31;&#x5bf9;&#x5e94;PO&#x7684;&#x4e00;&#x4e2a;&#xff08;&#x6216;&#x82e5;&#x5e72;&#x4e2a;&#xff09;&#x5c5e;&#x6027;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1508979980097" FOLDED="true" ID="ID_1359419123" MODIFIED="1529657528255">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20043;&#38388;&#20851;&#31995;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1508979989842" FOLDED="true" ID="ID_86030600" MODIFIED="1529657528255" TEXT="VO&#x4e0e;DTO">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508980020708" FOLDED="true" ID="ID_1657732647" MODIFIED="1529657528255">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21306;&#21035;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1508980018249" ID="ID_558200250" MODIFIED="1508980018253" TEXT="&#x5927;&#x5bb6;&#x53ef;&#x80fd;&#x4f1a;&#x6709;&#x4e2a;&#x7591;&#x95ee;&#xff08;&#x5728;&#x7b14;&#x8005;&#x53c2;&#x4e0e;&#x7684;&#x9879;&#x76ee;&#x4e2d;&#xff0c;&#x5f88;&#x591a;&#x7a0b;&#x5e8f;&#x5458;&#x4e5f;&#x6709;&#x76f8;&#x540c;&#x7684;&#x7591;&#x60d1;&#xff09;&#xff1a;&#x65e2;&#x7136;DTO&#x662f;&#x5c55;&#x793a;&#x5c42;&#x4e0e;&#x670d;&#x52a1;&#x5c42;&#x4e4b;&#x95f4;&#x4f20;&#x9012;&#x6570;&#x636e;&#x7684;&#x5bf9;&#x8c61;&#xff0c;&#x4e3a;&#x4ec0;&#x4e48;&#x8fd8;&#x9700;&#x8981;&#x4e00;&#x4e2a;VO&#x5462;&#xff1f;&#x5bf9;&#xff01;&#x5bf9;&#x4e8e;&#x7edd;&#x5927;&#x90e8;&#x5206;&#x7684;&#x5e94;&#x7528;&#x573a;&#x666f;&#x6765;&#x8bf4;&#xff0c;DTO&#x548c;VO&#x7684;&#x5c5e;&#x6027;&#x503c;&#x57fa;&#x672c;&#x662f;&#x4e00;&#x81f4;&#x7684;&#xff0c;&#x800c;&#x4e14;&#x4ed6;&#x4eec;&#x901a;&#x5e38;&#x90fd;&#x662f;POJO&#xff0c;&#x56e0;&#x6b64;&#x6ca1;&#x5fc5;&#x8981;&#x591a;&#x6b64;&#x4e00;&#x4e3e;&#xff0c;&#x4f46;&#x4e0d;&#x8981;&#x5fd8;&#x8bb0;&#x8fd9;&#x662f;&#x5b9e;&#x73b0;&#x5c42;&#x9762;&#x7684;&#x601d;&#x7ef4;&#xff0c;&#x5bf9;&#x4e8e;&#x8bbe;&#x8ba1;&#x5c42;&#x9762;&#x6765;&#x8bf4;&#xff0c;&#x6982;&#x5ff5;&#x4e0a;&#x8fd8;&#x662f;&#x5e94;&#x8be5;&#x5b58;&#x5728;VO&#x548c;DTO&#xff0c;&#x56e0;&#x4e3a;&#x4e24;&#x8005;&#x6709;&#x7740;&#x672c;&#x8d28;&#x7684;&#x533a;&#x522b;&#xff0c;DTO&#x4ee3;&#x8868;&#x670d;&#x52a1;&#x5c42;&#x9700;&#x8981;&#x63a5;&#x6536;&#x7684;&#x6570;&#x636e;&#x548c;&#x8fd4;&#x56de;&#x7684;&#x6570;&#x636e;&#xff0c;&#x800c;VO&#x4ee3;&#x8868;&#x5c55;&#x793a;&#x5c42;&#x9700;&#x8981;&#x663e;&#x793a;&#x7684;&#x6570;&#x636e;&#x3002;"/>
<node COLOR="#111111" CREATED="1508980018258" ID="ID_1496155805" MODIFIED="1508980018268" TEXT="&#x7528;&#x4e00;&#x4e2a;&#x4f8b;&#x5b50;&#x6765;&#x8bf4;&#x660e;&#x53ef;&#x80fd;&#x4f1a;&#x6bd4;&#x8f83;&#x5bb9;&#x6613;&#x7406;&#x89e3;&#xff1a;&#x4f8b;&#x5982;&#x670d;&#x52a1;&#x5c42;&#x6709;&#x4e00;&#x4e2a;getUser&#x7684;&#x65b9;&#x6cd5;&#x8fd4;&#x56de;&#x4e00;&#x4e2a;&#x7cfb;&#x7edf;&#x7528;&#x6237;&#xff0c;&#x5176;&#x4e2d;&#x6709;&#x4e00;&#x4e2a;&#x5c5e;&#x6027;&#x662f;gender(&#x6027;&#x522b;)&#xff0c;&#x5bf9;&#x4e8e;&#x670d;&#x52a1;&#x5c42;&#x6765;&#x8bf4;&#xff0c;&#x5b83;&#x53ea;&#x4ece;&#x8bed;&#x4e49;&#x4e0a;&#x5b9a;&#x4e49;&#xff1a;1-&#x7537;&#x6027;&#xff0c;2-&#x5973;&#x6027;&#xff0c;0-&#x672a;&#x6307;&#x5b9a;&#xff0c;&#x800c;&#x5bf9;&#x4e8e;&#x5c55;&#x793a;&#x5c42;&#x6765;&#x8bf4;&#xff0c;&#x5b83;&#x53ef;&#x80fd;&#x9700;&#x8981;&#x7528;&#x201c;&#x5e05;&#x54e5;&#x201d;&#x4ee3;&#x8868;&#x7537;&#x6027;&#xff0c;&#x7528;&#x201c;&#x7f8e;&#x5973;&#x201d;&#x4ee3;&#x8868;&#x5973;&#x6027;&#xff0c;&#x7528;&#x201c;&#x79d8;&#x5bc6;&#x201d;&#x4ee3;&#x8868;&#x672a;&#x6307;&#x5b9a;&#x3002;&#x8bf4;&#x5230;&#x8fd9;&#x91cc;&#xff0c;&#x53ef;&#x80fd;&#x4f60;&#x8fd8;&#x4f1a;&#x53cd;&#x9a73;&#xff0c;&#x5728;&#x670d;&#x52a1;&#x5c42;&#x76f4;&#x63a5;&#x5c31;&#x8fd4;&#x56de;&#x201c;&#x5e05;&#x54e5;&#x7f8e;&#x5973;&#x201d;&#x4e0d;&#x5c31;&#x884c;&#x4e86;&#x5417;&#xff1f;&#x5bf9;&#x4e8e;&#x5927;&#x90e8;&#x5206;&#x5e94;&#x7528;&#x6765;&#x8bf4;&#xff0c;&#x8fd9;&#x4e0d;&#x662f;&#x95ee;&#x9898;&#xff0c;&#x4f46;&#x8bbe;&#x60f3;&#x4e00;&#x4e0b;&#xff0c;&#x5982;&#x679c;&#x9700;&#x6c42;&#x5141;&#x8bb8;&#x5ba2;&#x6237;&#x53ef;&#x4ee5;&#x5b9a;&#x5236;&#x98ce;&#x683c;&#xff0c;&#x800c;&#x4e0d;&#x540c;&#x98ce;&#x683c;&#x5bf9;&#x4e8e;&#x201c;&#x6027;&#x522b;&#x201d;&#x7684;&#x8868;&#x73b0;&#x65b9;&#x5f0f;&#x4e0d;&#x4e00;&#x6837;&#xff0c;&#x53c8;&#x6216;&#x8005;&#x8fd9;&#x4e2a;&#x670d;&#x52a1;&#x540c;&#x65f6;&#x4f9b;&#x591a;&#x4e2a;&#x5ba2;&#x6237;&#x7aef;&#x4f7f;&#x7528;&#xff08;&#x4e0d;&#x540c;&#x95e8;&#x6237;&#xff09;&#xff0c;&#x800c;&#x4e0d;&#x540c;&#x7684;&#x5ba2;&#x6237;&#x7aef;&#x5bf9;&#x4e8e;&#x8868;&#x73b0;&#x5c42;&#x7684;&#x8981;&#x6c42;&#x6709;&#x6240;&#x4e0d;&#x540c;&#xff0c;&#x90a3;&#x4e48;&#xff0c;&#x95ee;&#x9898;&#x5c31;&#x6765;&#x4e86;&#x3002;&#x518d;&#x8005;&#xff0c;&#x56de;&#x5230;&#x8bbe;&#x8ba1;&#x5c42;&#x9762;&#x4e0a;&#x5206;&#x6790;&#xff0c;&#x4ece;&#x804c;&#x8d23;&#x5355;&#x4e00;&#x539f;&#x5219;&#x6765;&#x770b;&#xff0c;&#x670d;&#x52a1;&#x5c42;&#x53ea;&#x8d1f;&#x8d23;&#x4e1a;&#x52a1;&#xff0c;&#x4e0e;&#x5177;&#x4f53;&#x7684;&#x8868;&#x73b0;&#x5f62;&#x5f0f;&#x65e0;&#x5173;&#xff0c;&#x56e0;&#x6b64;&#xff0c;&#x5b83;&#x8fd4;&#x56de;&#x7684;DTO&#xff0c;&#x4e0d;&#x5e94;&#x8be5;&#x51fa;&#x73b0;&#x4e0e;&#x8868;&#x73b0;&#x5f62;&#x5f0f;&#x7684;&#x8026;&#x5408;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1508980025216" FOLDED="true" ID="ID_1931480887" MODIFIED="1529657528255" TEXT="&#x5e94;&#x7528;">
<node COLOR="#111111" CREATED="1508980044844" ID="ID_1028733892" MODIFIED="1508980078936">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <div>
      &#19978;&#38754;&#21482;&#26159;&#29992;&#20102;&#19968;&#20010;&#31616;&#21333;&#30340;&#20363;&#23376;&#26469;&#35828;&#26126;VO&#19982;DTO&#22312;&#27010;&#24565;&#19978;&#30340;&#21306;&#21035;&#65292;&#26412;&#33410;&#23558;&#20250;&#21578;&#35785;&#20320;&#22914;&#20309;&#22312;&#24212;&#29992;&#20013;&#20570;&#20986;&#27491;&#30830;&#30340;&#36873;&#25321;&#12290;
    </div>
    <div>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#22312;&#20197;&#19979;&#25165;&#22330;&#26223;&#20013;&#65292;&#25105;&#20204;&#21487;&#20197;&#32771;&#34385;&#25226;VO&#19982;DTO&#20108;&#21512;&#20026;&#19968;&#65288;&#27880;&#24847;&#65306;&#26159;&#23454;&#29616;&#23618;&#38754;&#65289;&#65306;
    </div>
    <div>
      &#24403;&#38656;&#27714;&#38750;&#24120;&#28165;&#26224;&#31283;&#23450;&#65292;&#32780;&#19988;&#23458;&#25143;&#31471;&#24456;&#26126;&#30830;&#21482;&#26377;&#19968;&#20010;&#30340;&#26102;&#20505;&#65292;&#27809;&#26377;&#24517;&#35201;&#25226;VO&#21644;DTO&#21306;&#20998;&#24320;&#26469;&#65292;&#36825;&#26102;&#20505;VO&#21487;&#20197;&#36864;&#38544;&#65292;&#29992;&#19968;&#20010;DTO&#21363;&#21487;&#65292;&#20026;&#20160;&#20040;&#26159;VO&#36864;&#38544;&#32780;&#19981;&#26159;DTO&#65311;&#22238;&#21040;&#35774;&#35745;&#23618;&#38754;&#65292;&#26381;&#21153;&#23618;&#30340;&#32844;&#36131;&#20381;&#28982;&#19981;&#24212;&#35813;&#19982;&#23637;&#31034;&#23618;&#32806;&#21512;&#65292;&#25152;&#20197;&#65292;&#23545;&#20110;&#21069;&#38754;&#30340;&#20363;&#23376;&#65292;&#20320;&#24456;&#23481;&#26131;&#29702;&#35299;&#65292;DTO&#23545;&#20110;&#8220;&#24615;&#21035;&#8221;&#26469;&#35828;&#65292;&#20381;&#28982;&#19981;&#33021;&#29992;&#8220;&#24069;&#21733;&#32654;&#22899;&#8221;&#65292;&#36825;&#20010;&#36716;&#25442;&#24212;&#35813;&#20381;&#36182;&#20110;&#39029;&#38754;&#30340;&#33050;&#26412;&#65288;&#22914;JavaScript&#65289;&#25110;&#20854;&#20182;&#26426;&#21046;&#65288;JSTL&#12289;EL&#12289;CSS&#65289;
    </div>
    <div style="margin-top: 0; margin-bottom: 0">
      &#21363;&#20351;&#23458;&#25143;&#31471;&#21487;&#20197;&#36827;&#34892;&#23450;&#21046;&#65292;&#25110;&#32773;&#23384;&#22312;&#22810;&#20010;&#19981;&#21516;&#30340;&#23458;&#25143;&#31471;&#65292;&#22914;&#26524;&#23458;&#25143;&#31471;&#33021;&#22815;&#29992;&#26576;&#31181;&#25216;&#26415;&#65288;&#33050;&#26412;&#25110;&#20854;&#20182;&#26426;&#21046;&#65289;&#23454;&#29616;&#36716;&#25442;&#65292;&#21516;&#26679;&#21487;&#20197;&#35753;VO&#36864;&#38544;
    </div>
    <div>
      
    </div>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1508980080302" ID="ID_772481633" MODIFIED="1508980080302">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div>
      &#20197;&#19979;&#22330;&#26223;&#38656;&#35201;&#20248;&#20808;&#32771;&#34385;VO&#12289;DTO&#24182;&#23384;&#65306;
    </div>
    <div>
      &#19978;&#36848;&#22330;&#26223;&#30340;&#21453;&#38754;&#22330;&#26223;
    </div>
    <div>
      &#22240;&#20026;&#26576;&#31181;&#25216;&#26415;&#21407;&#22240;&#65292;&#27604;&#22914;&#26576;&#20010;&#26694;&#26550;&#65288;&#22914;Flex&#65289;&#25552;&#20379;&#33258;&#21160;&#25226;POJO&#36716;&#25442;&#20026;UI&#20013;&#26576;&#20123;Field&#26102;&#65292;&#21487;&#20197;&#32771;&#34385;&#22312;&#23454;&#29616;&#23618;&#38754;&#23450;&#20041;&#20986;VO&#65292;&#36825;&#20010;&#26435;&#34913;&#23436;&#20840;&#21462;&#20915;&#20110;&#20351;&#29992;&#26694;&#26550;&#30340;&#33258;&#21160;&#36716;&#25442;&#33021;&#21147;&#24102;&#26469;&#30340;&#24320;&#21457;&#21644;&#32500;&#25252;&#25928;&#29575;&#25552;&#21319;&#19982;&#35774;&#35745;&#22810;&#19968;&#20010;VO&#25152;&#22810;&#20570;&#30340;&#20107;&#24773;&#24102;&#26469;&#30340;&#24320;&#21457;&#21644;&#32500;&#25252;&#25928;&#29575;&#30340;&#19979;&#38477;&#20043;&#38388;&#30340;&#27604;&#23545;&#12290;
    </div>
    <div style="margin-top: 0; margin-bottom: 0">
      &#22914;&#26524;&#39029;&#38754;&#20986;&#29616;&#19968;&#20010;&#8220;&#22823;&#35270;&#22270;&#8221;&#65292;&#32780;&#32452;&#25104;&#36825;&#20010;&#22823;&#35270;&#22270;&#30340;&#25152;&#26377;&#25968;&#25454;&#38656;&#35201;&#35843;&#29992;&#22810;&#20010;&#26381;&#21153;&#65292;&#36820;&#22238;&#22810;&#20010;DTO&#26469;&#32452;&#35013;&#65288;&#24403;&#28982;&#65292;&#36825;&#21516;&#26679;&#21487;&#20197;&#36890;&#36807;&#26381;&#21153;&#23618;&#25552;&#20379;&#19968;&#27425;&#24615;&#36820;&#22238;&#19968;&#20010;&#22823;&#35270;&#22270;&#30340;DTO&#26469;&#21462;&#20195;&#65292;&#20294;&#22312;&#26381;&#21153;&#23618;&#25552;&#20379;&#19968;&#20010;&#36825;&#26679;&#30340;&#26041;&#27861;&#26159;&#21542;&#21512;&#36866;&#65292;&#38656;&#35201;&#22312;&#35774;&#35745;&#23618;&#38754;&#36827;&#34892;&#26435;&#34913;&#65289;&#12290;
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1508980092363" FOLDED="true" ID="ID_950068323" MODIFIED="1529657528255" TEXT="DTO&#x4e0e;DO">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508980123878" FOLDED="true" ID="ID_242320046" MODIFIED="1529657528255" TEXT="&#x533a;&#x522b;">
<node COLOR="#111111" CREATED="1508980131089" ID="ID_32964122" MODIFIED="1508980131094" TEXT="&#x9996;&#x5148;&#x662f;&#x6982;&#x5ff5;&#x4e0a;&#x7684;&#x533a;&#x522b;&#xff0c;DTO&#x662f;&#x5c55;&#x793a;&#x5c42;&#x548c;&#x670d;&#x52a1;&#x5c42;&#x4e4b;&#x95f4;&#x7684;&#x6570;&#x636e;&#x4f20;&#x8f93;&#x5bf9;&#x8c61;&#xff08;&#x53ef;&#x4ee5;&#x8ba4;&#x4e3a;&#x662f;&#x4e24;&#x8005;&#x4e4b;&#x95f4;&#x7684;&#x534f;&#x8bae;&#xff09;&#xff0c;&#x800c;DO&#x662f;&#x5bf9;&#x73b0;&#x5b9e;&#x4e16;&#x754c;&#x5404;&#x79cd;&#x4e1a;&#x52a1;&#x89d2;&#x8272;&#x7684;&#x62bd;&#x8c61;&#xff0c;&#x8fd9;&#x5c31;&#x5f15;&#x51fa;&#x4e86;&#x4e24;&#x8005;&#x5728;&#x6570;&#x636e;&#x4e0a;&#x7684;&#x533a;&#x522b;&#xff0c;&#x4f8b;&#x5982;UserInfo&#x548c;User&#xff08;&#x5bf9;&#x4e8e;DTO&#x548c;DO&#x7684;&#x547d;&#x540d;&#x89c4;&#x5219;&#xff0c;&#x8bf7;&#x53c2;&#x89c1;&#x7b14;&#x8005;&#x524d;&#x9762;&#x7684;&#x4e00;&#x7bc7;&#x535a;&#x6587;&#xff09;&#xff0c;&#x5bf9;&#x4e8e;&#x4e00;&#x4e2a;getUser&#x65b9;&#x6cd5;&#x6765;&#x8bf4;&#xff0c;&#x672c;&#x8d28;&#x4e0a;&#x5b83;&#x6c38;&#x8fdc;&#x4e0d;&#x5e94;&#x8be5;&#x8fd4;&#x56de;&#x7528;&#x6237;&#x7684;&#x5bc6;&#x7801;&#xff0c;&#x56e0;&#x6b64;UserInfo&#x81f3;&#x5c11;&#x6bd4;User&#x5c11;&#x4e00;&#x4e2a;password&#x7684;&#x6570;&#x636e;&#x3002;&#x800c;&#x5728;&#x9886;&#x57df;&#x9a71;&#x52a8;&#x8bbe;&#x8ba1;&#x4e2d;&#xff0c;&#x6b63;&#x5982;&#x7b2c;&#x4e00;&#x7bc7;&#x7cfb;&#x5217;&#x6587;&#x7ae0;&#x6240;&#x8bf4;&#xff0c;DO&#x4e0d;&#x662f;&#x7b80;&#x5355;&#x7684;POJO&#xff0c;&#x5b83;&#x5177;&#x6709;&#x9886;&#x57df;&#x4e1a;&#x52a1;&#x903b;&#x8f91;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1508980126201" FOLDED="true" ID="ID_1300846079" MODIFIED="1529657528255" TEXT="&#x5e94;&#x7528;">
<node COLOR="#111111" CREATED="1508980143286" ID="ID_902033489" MODIFIED="1508980167085">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <div>
      &#20174;&#19978;&#19968;&#33410;&#30340;&#20363;&#23376;&#20013;&#65292;&#32454;&#24515;&#30340;&#35835;&#32773;&#21487;&#33021;&#20250;&#21457;&#29616;&#38382;&#39064;&#65306;&#26082;&#28982;getUser&#26041;&#27861;&#36820;&#22238;&#30340;UserInfo&#19981;&#24212;&#35813;&#21253;&#21547;password&#65292;&#37027;&#20040;&#23601;&#19981;&#24212;&#35813;&#23384;&#22312;password&#36825;&#20010;&#23646;&#24615;&#23450;&#20041;&#65292;&#20294;&#22914;&#26524;&#21516;&#26102;&#26377;&#19968;&#20010;createUser&#30340;&#26041;&#27861;&#65292;&#20256;&#20837;&#30340;UserInfo&#38656;&#35201;&#21253;&#21547;&#29992;&#25143;&#30340;password&#65292;&#24590;&#20040;&#21150;&#65311;&#22312;&#35774;&#35745;&#23618;&#38754;&#65292;&#23637;&#31034;&#23618;&#21521;&#26381;&#21153;&#23618;&#20256;&#36882;&#30340;DTO&#19982;&#26381;&#21153;&#23618;&#36820;&#22238;&#32473;&#23637;&#31034;&#23618;&#30340;DTO&#22312;&#27010;&#24565;&#19978;&#26159;&#19981;&#21516;&#30340;&#65292;&#20294;&#22312;&#23454;&#29616;&#23618;&#38754;&#65292;&#25105;&#20204;&#36890;&#24120;&#24456;&#23569;&#20250;&#36825;&#26679;&#20570;&#65288;&#23450;&#20041;&#20004;&#20010;UserInfo&#65292;&#29978;&#33267;&#26356;&#22810;&#65289;&#65292;&#22240;&#20026;&#36825;&#26679;&#20570;&#24182;&#19981;&#35265;&#24471;&#24456;&#26126;&#26234;&#65292;&#25105;&#20204;&#23436;&#20840;&#21487;&#20197;&#35774;&#35745;&#19968;&#20010;&#23436;&#20840;&#20860;&#23481;&#30340;DTO&#65292;&#22312;&#26381;&#21153;&#23618;&#25509;&#25910;&#25968;&#25454;&#30340;&#26102;&#20505;&#65292;&#19981;&#35813;&#30001;&#23637;&#31034;&#23618;&#35774;&#32622;&#30340;&#23646;&#24615;&#65288;&#22914;&#35746;&#21333;&#30340;&#24635;&#20215;&#24212;&#35813;&#30001;&#20854;&#21333;&#20215;&#12289;&#25968;&#37327;&#12289;&#25240;&#25187;&#31561;&#20915;&#23450;&#65289;&#65292;&#26080;&#35770;&#23637;&#31034;&#23618;&#26159;&#21542;&#35774;&#32622;&#65292;&#26381;&#21153;&#23618;&#37117;&#19968;&#27010;&#24573;&#30053;&#65292;&#32780;&#22312;&#26381;&#21153;&#23618;&#36820;&#22238;&#25968;&#25454;&#26102;&#65292;&#19981;&#35813;&#36820;&#22238;&#30340;&#25968;&#25454;&#65288;&#22914;&#29992;&#25143;&#23494;&#30721;&#65289;&#65292;&#23601;&#19981;&#35774;&#32622;&#23545;&#24212;&#30340;&#23646;&#24615;&#12290;
    </div>
    <div>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;
    </div>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1508980168912" ID="ID_59431068" MODIFIED="1508980190512">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div>
      &#23545;&#20110;DO&#26469;&#35828;&#65292;&#36824;&#26377;&#19968;&#28857;&#38656;&#35201;&#35828;&#26126;&#65306;&#20026;&#20160;&#20040;&#19981;&#22312;&#26381;&#21153;&#23618;&#20013;&#30452;&#25509;&#36820;&#22238;DO&#21602;&#65311;&#36825;&#26679;&#21487;&#20197;&#30465;&#21435;DTO&#30340;&#32534;&#30721;&#21644;&#36716;&#25442;&#24037;&#20316;&#65292;&#21407;&#22240;&#22914;&#19979;&#65306;
    </div>
    <div>
      &#20004;&#32773;&#22312;&#26412;&#36136;&#19978;&#30340;&#21306;&#21035;&#21487;&#33021;&#23548;&#33268;&#24444;&#27492;&#24182;&#19981;&#19968;&#19968;&#23545;&#24212;&#65292;&#19968;&#20010;DTO&#21487;&#33021;&#23545;&#24212;&#22810;&#20010;DO&#65292;&#21453;&#20043;&#20134;&#28982;&#65292;&#29978;&#33267;&#20004;&#32773;&#23384;&#22312;&#22810;&#23545;&#22810;&#30340;&#20851;&#31995;&#12290;
    </div>
    <div>
      DO&#20855;&#26377;&#19968;&#20123;&#19981;&#24212;&#35813;&#35753;&#23637;&#31034;&#23618;&#30693;&#36947;&#30340;&#25968;&#25454;
    </div>
    <div>
      DO&#20855;&#26377;&#19994;&#21153;&#26041;&#27861;&#65292;&#22914;&#26524;&#30452;&#25509;&#25226;DO&#20256;&#36882;&#32473;&#23637;&#31034;&#23618;&#65292;&#23637;&#31034;&#23618;&#30340;&#20195;&#30721;&#23601;&#21487;&#20197;&#32469;&#36807;&#26381;&#21153;&#23618;&#30452;&#25509;&#35843;&#29992;&#23427;&#19981;&#24212;&#35813;&#35775;&#38382;&#30340;&#25805;&#20316;&#65292;&#23545;&#20110;&#22522;&#20110;AOP&#25318;&#25130;&#26381;&#21153;&#23618;&#26469;&#36827;&#34892;&#35775;&#38382;&#25511;&#21046;&#30340;&#26426;&#21046;&#26469;&#35828;&#65292;&#36825;&#38382;&#39064;&#23588;&#20026;&#31361;&#20986;&#65292;&#32780;&#22312;&#23637;&#31034;&#23618;&#35843;&#29992;DO&#30340;&#19994;&#21153;&#26041;&#27861;&#20063;&#20250;&#22240;&#20026;&#20107;&#21153;&#30340;&#38382;&#39064;&#65292;&#35753;&#20107;&#21153;&#38590;&#20197;&#25511;&#21046;&#12290;
    </div>
    <div>
      &#23545;&#20110;&#26576;&#20123;ORM&#26694;&#26550;&#65288;&#22914;Hibernate&#65289;&#26469;&#35828;&#65292;&#36890;&#24120;&#20250;&#20351;&#29992;&#8220;&#24310;&#36831;&#21152;&#36733;&#8221;&#25216;&#26415;&#65292;&#22914;&#26524;&#30452;&#25509;&#25226;DO&#26292;&#38706;&#32473;&#23637;&#31034;&#23618;&#65292;&#23545;&#20110;&#22823;&#37096;&#20998;&#24773;&#20917;&#65292;&#23637;&#31034;&#23618;&#19981;&#22312;&#20107;&#21153;&#33539;&#22260;&#20043;&#20869;&#65288;Open session in view&#22312;&#22823;&#37096;&#20998;&#24773;&#20917;&#19979;&#19981;&#26159;&#19968;&#31181;&#20540;&#24471;&#25512;&#23815;&#30340;&#35774;&#35745;&#65289;&#65292;&#22914;&#26524;&#20854;&#23581;&#35797;&#22312;Session&#20851;&#38381;&#30340;&#24773;&#20917;&#19979;&#33719;&#21462;&#19968;&#20010;&#26410;&#21152;&#36733;&#30340;&#20851;&#32852;&#23545;&#35937;&#65292;&#20250;&#20986;&#29616;&#36816;&#34892;&#26102;&#24322;&#24120;&#65288;&#23545;&#20110;Hibernate&#26469;&#35828;&#65292;&#23601;&#26159;LazyInitiliaztionException&#65289;&#12290;
    </div>
    <div style="margin-top: 0; margin-bottom: 0">
      &#20174;&#35774;&#35745;&#23618;&#38754;&#26469;&#35828;&#65292;&#23637;&#31034;&#23618;&#20381;&#36182;&#20110;&#26381;&#21153;&#23618;&#65292;&#26381;&#21153;&#23618;&#20381;&#36182;&#20110;&#39046;&#22495;&#23618;&#65292;&#22914;&#26524;&#25226;DO&#26292;&#38706;&#20986;&#21435;&#65292;&#23601;&#20250;&#23548;&#33268;&#23637;&#31034;&#23618;&#30452;&#25509;&#20381;&#36182;&#20110;&#39046;&#22495;&#23618;&#65292;&#36825;&#34429;&#28982;&#20381;&#28982;&#26159;&#21333;&#21521;&#20381;&#36182;&#65292;&#20294;&#36825;&#31181;&#36328;&#23618;&#20381;&#36182;&#20250;&#23548;&#33268;&#19981;&#24517;&#35201;&#30340;&#32806;&#21512;&#12290;
    </div>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1508980194087" ID="ID_1947378418" MODIFIED="1508980194088">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div style="margin-top: 0; margin-bottom: 0">
      
    </div>
    <div style="margin-top: 0; margin-bottom: 0">
      &#23545;&#20110;DTO&#26469;&#35828;&#65292;&#20063;&#26377;&#19968;&#28857;&#24517;&#39035;&#36827;&#34892;&#35828;&#26126;&#65292;&#23601;&#26159;DTO&#24212;&#35813;&#26159;&#19968;&#20010;&#8220;&#25153;&#24179;&#30340;&#20108;&#32500;&#23545;&#35937;&#8221;&#65292;&#20030;&#20010;&#20363;&#23376;&#26469;&#35828;&#26126;&#65306;&#22914;&#26524;User&#20250;&#20851;&#32852;&#33509;&#24178;&#20010;&#20854;&#20182;&#23454;&#20307;&#65288;&#20363;&#22914;Address&#12289;Account&#12289;Region&#31561;&#65289;&#65292;&#37027;&#20040;getUser()&#36820;&#22238;&#30340;UserInfo&#65292;&#26159;&#21542;&#23601;&#38656;&#35201;&#25226;&#20854;&#20851;&#32852;&#30340;&#23545;&#35937;&#30340;DTO&#37117;&#19968;&#24182;&#36820;&#22238;&#21602;&#65311;&#22914;&#26524;&#36825;&#26679;&#30340;&#35805;&#65292;&#24517;&#28982;&#23548;&#33268;&#25968;&#25454;&#20256;&#36755;&#37327;&#30340;&#22823;&#22686;&#65292;&#23545;&#20110;&#20998;&#24067;&#24335;&#24212;&#29992;&#26469;&#35828;&#65292;&#30001;&#20110;&#28041;&#21450;&#25968;&#25454;&#22312;&#32593;&#32476;&#19978;&#30340;&#20256;&#36755;&#12289;&#24207;&#21015;&#21270;&#21644;&#21453;&#24207;&#21015;&#21270;&#65292;&#36825;&#31181;&#35774;&#35745;&#26356;&#19981;&#21487;&#25509;&#21463;&#12290;&#22914;&#26524;getUser&#38500;&#20102;&#35201;&#36820;&#22238;User&#30340;&#22522;&#26412;&#20449;&#24687;&#22806;&#65292;&#36824;&#38656;&#35201;&#36820;&#22238;&#19968;&#20010;AccountId&#12289;AccountName&#12289;RegionId&#12289;RegionName&#65292;&#37027;&#20040;&#65292;&#35831;&#25226;&#36825;&#20123;&#23646;&#24615;&#23450;&#20041;&#21040;UserInfo&#20013;&#65292;&#25226;&#19968;&#20010;&#8220;&#31435;&#20307;&#8221;&#30340;&#23545;&#35937;&#26641;&#8220;&#21387;&#25153;&#8221;&#25104;&#19968;&#20010;&#8220;&#25153;&#24179;&#30340;&#20108;&#32500;&#23545;&#35937;&#8221;&#65292;&#31508;&#32773;&#30446;&#21069;&#21442;&#19982;&#30340;&#39033;&#30446;&#26159;&#19968;&#20010;&#20998;&#24067;&#24335;&#31995;&#32479;&#65292;&#35813;&#31995;&#32479;&#19981;&#31649;&#19977;&#19971;&#20108;&#21313;&#19968;&#65292;&#25226;&#19968;&#20010;&#23545;&#35937;&#30340;&#25152;&#26377;&#20851;&#32852;&#23545;&#35937;&#37117;&#36716;&#25442;&#20026;&#30456;&#21516;&#32467;&#26500;&#30340;DTO&#23545;&#35937;&#26641;&#24182;&#36820;&#22238;&#65292;&#23548;&#33268;&#24615;&#33021;&#38750;&#24120;&#30340;&#24930;&#12290;
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1508980213849" FOLDED="true" ID="ID_324295637" MODIFIED="1529657528255" TEXT="DO&#x4e0e;PO">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1508980216237" FOLDED="true" ID="ID_1671735421" MODIFIED="1529657528255" TEXT="&#x533a;&#x522b;">
<node COLOR="#111111" CREATED="1508980229756" ID="ID_312076518" MODIFIED="1508980229756" TEXT="DO&#x548c;PO&#x5728;&#x7edd;&#x5927;&#x90e8;&#x5206;&#x60c5;&#x51b5;&#x4e0b;&#x662f;&#x4e00;&#x4e00;&#x5bf9;&#x5e94;&#x7684;&#xff0c;PO&#x662f;&#x53ea;&#x542b;&#x6709;get/set&#x65b9;&#x6cd5;&#x7684;POJO&#xff0c;&#x4f46;&#x67d0;&#x4e9b;&#x573a;&#x666f;&#x8fd8;&#x662f;&#x80fd;&#x53cd;&#x6620;&#x51fa;&#x4e24;&#x8005;&#x5728;&#x6982;&#x5ff5;&#x4e0a;&#x5b58;&#x5728;&#x672c;&#x8d28;&#x7684;&#x533a;&#x522b;&#xff1a;"/>
<node COLOR="#111111" CREATED="1508980237622" ID="ID_995596434" MODIFIED="1508980237624" TEXT="DO&#x5728;&#x67d0;&#x4e9b;&#x573a;&#x666f;&#x4e0b;&#x4e0d;&#x9700;&#x8981;&#x8fdb;&#x884c;&#x663e;&#x5f0f;&#x7684;&#x6301;&#x4e45;&#x5316;&#xff0c;&#x4f8b;&#x5982;&#x5229;&#x7528;&#x7b56;&#x7565;&#x6a21;&#x5f0f;&#x8bbe;&#x8ba1;&#x7684;&#x5546;&#x54c1;&#x6298;&#x6263;&#x7b56;&#x7565;&#xff0c;&#x4f1a;&#x884d;&#x751f;&#x51fa;&#x6298;&#x6263;&#x7b56;&#x7565;&#x7684;&#x63a5;&#x53e3;&#x548c;&#x4e0d;&#x540c;&#x6298;&#x6263;&#x7b56;&#x7565;&#x5b9e;&#x73b0;&#x7c7b;&#xff0c;&#x8fd9;&#x4e9b;&#x6298;&#x6263;&#x7b56;&#x7565;&#x5b9e;&#x73b0;&#x7c7b;&#x53ef;&#x4ee5;&#x7b97;&#x662f;DO&#xff0c;&#x4f46;&#x5b83;&#x4eec;&#x53ea;&#x9a7b;&#x7559;&#x5728;&#x9759;&#x6001;&#x5185;&#x5b58;&#xff0c;&#x4e0d;&#x9700;&#x8981;&#x6301;&#x4e45;&#x5316;&#x5230;&#x6301;&#x4e45;&#x5c42;&#xff0c;&#x56e0;&#x6b64;&#xff0c;&#x8fd9;&#x7c7b;DO&#x662f;&#x4e0d;&#x5b58;&#x5728;&#x5bf9;&#x5e94;&#x7684;PO&#x7684;&#x3002;"/>
<node COLOR="#111111" CREATED="1508980244329" ID="ID_1703266689" MODIFIED="1508980244335" TEXT="&#x540c;&#x6837;&#x7684;&#x9053;&#x7406;&#xff0c;&#x67d0;&#x4e9b;&#x573a;&#x666f;&#x4e0b;&#xff0c;PO&#x4e5f;&#x6ca1;&#x6709;&#x5bf9;&#x5e94;&#x7684;DO&#xff0c;&#x4f8b;&#x5982;&#x8001;&#x5e08;Teacher&#x548c;&#x5b66;&#x751f;Student&#x5b58;&#x5728;&#x591a;&#x5bf9;&#x591a;&#x7684;&#x5173;&#x7cfb;&#xff0c;&#x5728;&#x5173;&#x7cfb;&#x6570;&#x636e;&#x5e93;&#x4e2d;&#xff0c;&#x8fd9;&#x79cd;&#x5173;&#x7cfb;&#x9700;&#x8981;&#x8868;&#x73b0;&#x4e3a;&#x4e00;&#x4e2a;&#x4e2d;&#x95f4;&#x8868;&#xff0c;&#x4e5f;&#x5c31;&#x5bf9;&#x5e94;&#x6709;&#x4e00;&#x4e2a;TeacherAndStudentPO&#x7684;PO&#xff0c;&#x4f46;&#x8fd9;&#x4e2a;PO&#x5728;&#x4e1a;&#x52a1;&#x9886;&#x57df;&#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x73b0;&#x5b9e;&#x7684;&#x610f;&#x4e49;&#xff0c;&#x5b83;&#x5b8c;&#x5168;&#x4e0d;&#x80fd;&#x4e0e;&#x4efb;&#x4f55;DO&#x5bf9;&#x5e94;&#x4e0a;&#x3002;&#x8fd9;&#x91cc;&#x8981;&#x7279;&#x522b;&#x58f0;&#x660e;&#xff0c;&#x5e76;&#x4e0d;&#x662f;&#x6240;&#x6709;&#x591a;&#x5bf9;&#x591a;&#x5173;&#x7cfb;&#x90fd;&#x6ca1;&#x6709;&#x4e1a;&#x52a1;&#x542b;&#x4e49;&#xff0c;&#x8fd9;&#x8ddf;&#x5177;&#x4f53;&#x4e1a;&#x52a1;&#x573a;&#x666f;&#x6709;&#x5173;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&#x4e24;&#x4e2a;PO&#x4e4b;&#x95f4;&#x7684;&#x5173;&#x7cfb;&#x4f1a;&#x5f71;&#x54cd;&#x5177;&#x4f53;&#x4e1a;&#x52a1;&#xff0c;&#x5e76;&#x4e14;&#x8fd9;&#x79cd;&#x5173;&#x7cfb;&#x5b58;&#x5728;&#x591a;&#x79cd;&#x7c7b;&#x578b;&#xff0c;&#x90a3;&#x4e48;&#x8fd9;&#x79cd;&#x591a;&#x5bf9;&#x591a;&#x5173;&#x7cfb;&#x4e5f;&#x5e94;&#x8be5;&#x8868;&#x73b0;&#x4e3a;&#x4e00;&#x4e2a;DO&#xff0c;&#x53c8;&#x5982;&#xff1a;&#x201c;&#x89d2;&#x8272;&#x201d;&#x4e0e;&#x201c;&#x8d44;&#x6e90;&#x201d;&#x4e4b;&#x95f4;&#x5b58;&#x5728;&#x591a;&#x5bf9;&#x591a;&#x5173;&#x7cfb;&#xff0c;&#x800c;&#x8fd9;&#x79cd;&#x5173;&#x7cfb;&#x5f88;&#x660e;&#x663e;&#x4f1a;&#x8868;&#x73b0;&#x4e3a;&#x4e00;&#x4e2a;DO&#x2014;&#x2014;&#x201c;&#x6743;&#x9650;&#x201d;&#x3002;"/>
<node COLOR="#111111" CREATED="1508980248592" ID="ID_1196642349" MODIFIED="1508980248601" TEXT="&#x67d0;&#x4e9b;&#x60c5;&#x51b5;&#x4e0b;&#xff0c;&#x4e3a;&#x4e86;&#x67d0;&#x79cd;&#x6301;&#x4e45;&#x5316;&#x7b56;&#x7565;&#x6216;&#x8005;&#x6027;&#x80fd;&#x7684;&#x8003;&#x8651;&#xff0c;&#x4e00;&#x4e2a;PO&#x53ef;&#x80fd;&#x5bf9;&#x5e94;&#x591a;&#x4e2a;DO&#xff0c;&#x53cd;&#x4e4b;&#x4ea6;&#x7136;&#x3002;&#x4f8b;&#x5982;&#x5ba2;&#x6237;Customer&#x6709;&#x5176;&#x8054;&#x7cfb;&#x4fe1;&#x606f;Contacts&#xff0c;&#x8fd9;&#x91cc;&#x662f;&#x4e24;&#x4e2a;&#x4e00;&#x5bf9;&#x4e00;&#x5173;&#x7cfb;&#x7684;DO&#xff0c;&#x4f46;&#x53ef;&#x80fd;&#x51fa;&#x4e8e;&#x6027;&#x80fd;&#x7684;&#x8003;&#x8651;&#xff08;&#x6781;&#x7aef;&#x60c5;&#x51b5;&#xff0c;&#x6743;&#x4f5c;&#x4e3e;&#x4f8b;&#xff09;&#xff0c;&#x4e3a;&#x4e86;&#x51cf;&#x5c11;&#x6570;&#x636e;&#x5e93;&#x7684;&#x8fde;&#x63a5;&#x67e5;&#x8be2;&#x64cd;&#x4f5c;&#xff0c;&#x628a;Customer&#x548c;Contacts&#x4e24;&#x4e2a;DO&#x6570;&#x636e;&#x5408;&#x5e76;&#x5230;&#x4e00;&#x5f20;&#x6570;&#x636e;&#x8868;&#x4e2d;&#x3002;&#x53cd;&#x8fc7;&#x6765;&#xff0c;&#x5982;&#x679c;&#x4e00;&#x672c;&#x56fe;&#x4e66;Book&#xff0c;&#x6709;&#x4e00;&#x4e2a;&#x5c5e;&#x6027;&#x662f;&#x5c01;&#x9762;cover&#xff0c;&#x4f46;&#x8be5;&#x5c5e;&#x6027;&#x662f;&#x4e00;&#x526f;&#x56fe;&#x7247;&#x7684;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x636e;&#xff0c;&#x800c;&#x67d0;&#x4e9b;&#x67e5;&#x8be2;&#x64cd;&#x4f5c;&#x4e0d;&#x5e0c;&#x671b;&#x628a;cover&#x4e00;&#x5e76;&#x52a0;&#x8f7d;&#xff0c;&#x4ece;&#x800c;&#x51cf;&#x8f7b;&#x78c1;&#x76d8;IO&#x5f00;&#x9500;&#xff0c;&#x540c;&#x65f6;&#x5047;&#x8bbe;ORM&#x6846;&#x67b6;&#x4e0d;&#x652f;&#x6301;&#x5c5e;&#x6027;&#x7ea7;&#x522b;&#x7684;&#x5ef6;&#x8fdf;&#x52a0;&#x8f7d;&#xff0c;&#x90a3;&#x4e48;&#x5c31;&#x9700;&#x8981;&#x8003;&#x8651;&#x628a;cover&#x72ec;&#x7acb;&#x5230;&#x4e00;&#x5f20;&#x6570;&#x636e;&#x8868;&#x4e2d;&#x53bb;&#xff0c;&#x8fd9;&#x6837;&#x5c31;&#x5f62;&#x6210;&#x4e00;&#x4e2a;DO&#x5bf9;&#x5e94;&#x5bf9;&#x4e2a;PO&#x7684;&#x60c5;&#x51b5;&#x3002;"/>
<node COLOR="#111111" CREATED="1508980252330" ID="ID_1057132805" MODIFIED="1508980252331" TEXT="PO&#x7684;&#x67d0;&#x4e9b;&#x5c5e;&#x6027;&#x503c;&#x5bf9;&#x4e8e;DO&#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x610f;&#x4e49;&#xff0c;&#x8fd9;&#x4e9b;&#x5c5e;&#x6027;&#x503c;&#x53ef;&#x80fd;&#x662f;&#x4e3a;&#x4e86;&#x89e3;&#x51b3;&#x67d0;&#x4e9b;&#x6301;&#x4e45;&#x5316;&#x7b56;&#x7565;&#x800c;&#x5b58;&#x5728;&#x7684;&#x6570;&#x636e;&#xff0c;&#x4f8b;&#x5982;&#x4e3a;&#x4e86;&#x5b9e;&#x73b0;&#x201c;&#x4e50;&#x89c2;&#x9501;&#x201d;&#xff0c;PO&#x5b58;&#x5728;&#x4e00;&#x4e2a;version&#x7684;&#x5c5e;&#x6027;&#xff0c;&#x8fd9;&#x4e2a;version&#x5bf9;&#x4e8e;DO&#x6765;&#x8bf4;&#x662f;&#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x4e1a;&#x52a1;&#x610f;&#x4e49;&#x7684;&#xff0c;&#x5b83;&#x4e0d;&#x5e94;&#x8be5;&#x5728;DO&#x4e2d;&#x5b58;&#x5728;&#x3002;&#x540c;&#x7406;&#xff0c;DO&#x4e2d;&#x4e5f;&#x53ef;&#x80fd;&#x5b58;&#x5728;&#x4e0d;&#x9700;&#x8981;&#x6301;&#x4e45;&#x5316;&#x7684;&#x5c5e;&#x6027;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1508980220717" FOLDED="true" ID="ID_103507954" MODIFIED="1529657528255" TEXT="&#x5e94;&#x7528;">
<node COLOR="#111111" CREATED="1508980263642" ID="ID_1873521992" MODIFIED="1508980263643" TEXT="&#x7531;&#x4e8e;ORM&#x6846;&#x67b6;&#x7684;&#x529f;&#x80fd;&#x975e;&#x5e38;&#x5f3a;&#x5927;&#x800c;&#x5927;&#x884c;&#x5176;&#x9053;&#xff0c;&#x800c;&#x4e14;JavaEE&#x4e5f;&#x63a8;&#x51fa;&#x4e86;JPA&#x89c4;&#x8303;&#xff0c;&#x73b0;&#x5728;&#x7684;&#x4e1a;&#x52a1;&#x5e94;&#x7528;&#x5f00;&#x53d1;&#xff0c;&#x57fa;&#x672c;&#x4e0a;&#x4e0d;&#x9700;&#x8981;&#x533a;&#x5206;DO&#x4e0e;PO&#xff0c;PO&#x5b8c;&#x5168;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;JPA&#xff0c;Hibernate Annotations/hbm&#x9690;&#x85cf;&#x5728;DO&#x4e4b;&#x4e2d;&#x3002;&#x867d;&#x7136;&#x5982;&#x6b64;&#xff0c;&#x4f46;&#x6709;&#x4e9b;&#x95ee;&#x9898;&#x6211;&#x4eec;&#x8fd8;&#x5fc5;&#x987b;&#x6ce8;&#x610f;&#xff1a;"/>
<node COLOR="#111111" CREATED="1508980270991" ID="ID_1020230394" MODIFIED="1508980280672" TEXT="&#x5bf9;&#x4e8e;DO&#x4e2d;&#x4e0d;&#x9700;&#x8981;&#x6301;&#x4e45;&#x5316;&#x7684;&#x5c5e;&#x6027;&#xff0c;&#x9700;&#x8981;&#x901a;&#x8fc7;ORM&#x663e;&#x5f0f;&#x7684;&#x58f0;&#x660e;&#xff0c;&#x5982;&#xff1a;&#x5728;JPA&#x4e2d;&#xff0c;&#x53ef;&#x4ee5;&#x5229;&#x7528;@Transient&#x58f0;&#x660e;&#x3002;"/>
<node COLOR="#111111" CREATED="1508980271018" ID="ID_424374102" MODIFIED="1508980271022" TEXT="&#x5bf9;&#x4e8e;PO&#x4e2d;&#x4e3a;&#x4e86;&#x67d0;&#x79cd;&#x6301;&#x4e45;&#x5316;&#x7b56;&#x7565;&#x800c;&#x5b58;&#x5728;&#x7684;&#x5c5e;&#x6027;&#xff0c;&#x4f8b;&#x5982;version&#xff0c;&#x7531;&#x4e8e;DO&#x3001;PO&#x5408;&#x5e76;&#x4e86;&#xff0c;&#x5fc5;&#x987b;&#x5728;DO&#x4e2d;&#x58f0;&#x660e;&#xff0c;&#x4f46;&#x7531;&#x4e8e;&#x8fd9;&#x4e2a;&#x5c5e;&#x6027;&#x5bf9;DO&#x662f;&#x6ca1;&#x6709;&#x4efb;&#x4f55;&#x4e1a;&#x52a1;&#x610f;&#x4e49;&#x7684;&#xff0c;&#x9700;&#x8981;&#x8ba9;&#x8be5;&#x5c5e;&#x6027;&#x5bf9;&#x5916;&#x9690;&#x85cf;&#x8d77;&#x6765;&#xff0c;&#x6700;&#x5e38;&#x89c1;&#x7684;&#x505a;&#x6cd5;&#x662f;&#x628a;&#x8be5;&#x5c5e;&#x6027;&#x7684;get/set&#x65b9;&#x6cd5;&#x79c1;&#x6709;&#x5316;&#xff0c;&#x751a;&#x81f3;&#x4e0d;&#x63d0;&#x4f9b;get/set&#x65b9;&#x6cd5;&#xff0c;&#x4f46;&#x5bf9;&#x4e8e;Hibernate&#x6765;&#x8bf4;&#xff0c;&#x8fd9;&#x9700;&#x8981;&#x7279;&#x522b;&#x6ce8;&#x610f;&#xff0c;&#x7531;&#x4e8e;Hibernate&#x4ece;&#x6570;&#x636e;&#x5e93;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#x8f6c;&#x6362;&#x4e3a;DO&#x65f6;&#xff0c;&#x662f;&#x5229;&#x7528;&#x53cd;&#x5c04;&#x673a;&#x5236;&#x5148;&#x8c03;&#x7528;DO&#x7684;&#x7a7a;&#x53c2;&#x6570;&#x6784;&#x9020;&#x51fd;&#x6570;&#x6784;&#x9020;DO&#x5b9e;&#x4f8b;&#xff0c;&#x7136;&#x540e;&#x518d;&#x5229;&#x7528;JavaBean&#x7684;&#x89c4;&#x8303;&#x53cd;&#x5c04;&#x51fa;set&#x65b9;&#x6cd5;&#x6765;&#x4e3a;&#x6bcf;&#x4e2a;&#x5c5e;&#x6027;&#x8bbe;&#x503c;&#xff0c;&#x5982;&#x679c;&#x4e0d;&#x663e;&#x5f0f;&#x58f0;&#x660e;set&#x65b9;&#x6cd5;&#xff0c;&#x6216;&#x628a;set&#x65b9;&#x6cd5;&#x8bbe;&#x7f6e;&#x4e3a;private&#xff0c;&#x90fd;&#x4f1a;&#x5bfc;&#x81f4;Hibernate&#x65e0;&#x6cd5;&#x521d;&#x59cb;&#x5316;DO&#xff0c;&#x4ece;&#x800c;&#x51fa;&#x73b0;&#x8fd0;&#x884c;&#x65f6;&#x5f02;&#x5e38;&#xff0c;&#x53ef;&#x884c;&#x7684;&#x505a;&#x6cd5;&#x662f;&#x628a;&#x5c5e;&#x6027;&#x7684;set&#x65b9;&#x6cd5;&#x8bbe;&#x7f6e;&#x4e3a;protected&#x3002;"/>
<node COLOR="#111111" CREATED="1508980271024" ID="ID_447483085" MODIFIED="1508980271024" TEXT="&#x5bf9;&#x4e8e;&#x4e00;&#x4e2a;DO&#x5bf9;&#x5e94;&#x591a;&#x4e2a;PO&#xff0c;&#x6216;&#x8005;&#x4e00;&#x4e2a;PO&#x5bf9;&#x5e94;&#x591a;&#x4e2a;DO&#x7684;&#x573a;&#x666f;&#xff0c;&#x4ee5;&#x53ca;&#x5c5e;&#x6027;&#x7ea7;&#x522b;&#x7684;&#x5ef6;&#x8fdf;&#x52a0;&#x8f7d;&#xff0c;Hibernate&#x90fd;&#x63d0;&#x4f9b;&#x4e86;&#x5f88;&#x597d;&#x7684;&#x652f;&#x6301;&#xff0c;&#x8bf7;&#x53c2;&#x8003;Hibnate&#x7684;&#x76f8;&#x5173;&#x8d44;&#x6599;&#x3002;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1514443436698" FOLDED="true" ID="ID_1628141909" MODIFIED="1529657528255" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#29983;&#25104;keystore
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1514443446019" FOLDED="true" ID="ID_1453039926" MODIFIED="1529657528255">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22312;windows&#21629;&#20196;&#34892;&#36755;&#20837;:&#160;&#160;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1514443702823" ID="ID_652785644" MODIFIED="1514457958378">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      keytool -genkey -alias server&#160;&#160;-keyalg RSA
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1514443471120" FOLDED="true" ID="ID_1878230701" MODIFIED="1529657528255" TEXT="&#x63a5;&#x4e0b;&#x6765;&#x6309;&#x7167;&#x63d0;&#x793a;&#x64cd;&#x4f5c;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1514443670037" ID="ID_1100317787" MODIFIED="1514457958378" TEXT="&#x522b;&#x5fd8;&#x91cc;&#x628a;&#x5bc6;&#x7801;&#x8bb0;&#x4f4f;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1514443484879" ID="ID_981468931" MODIFIED="1514457958378">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#29983;&#25104;&#30340;.keystore&#20250;&#22312;:&#160;&#160;C:\Users\Administrator&#19979;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1514443510010" ID="ID_850237493" MODIFIED="1514457958378" TEXT="&#x590d;&#x5236;.keystore&#x5230;wildFly&#x7684;domain\configuration&#x4e0b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1517834690590" FOLDED="true" ID="ID_45500573" MODIFIED="1529657528257" POSITION="right" TEXT="JVM">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1517879495996" FOLDED="true" ID="ID_1307185473" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21306;&#22495;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1517834816067" FOLDED="true" ID="ID_1239792682" MODIFIED="1529657528256" TEXT="java&#x865a;&#x62df;&#x673a;&#x6808;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517834839042" ID="ID_25943138" MODIFIED="1517879496049" TEXT="&#x5c31;&#x662f;java&#x65b9;&#x6cd5;&#x6267;&#x884c;&#x7684;&#x5185;&#x5b58;&#x6a21;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1517835954610" FOLDED="true" ID="ID_851012743" MODIFIED="1529657528256" TEXT="&#x5c40;&#x90e8;&#x53d8;&#x91cf;&#x8868;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1517835969043" ID="ID_1127403840" MODIFIED="1517836143646">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23616;&#37096;&#21464;&#37327;&#34920;&#23384;&#25918;&#20102;&#32534;&#35793;&#26399;&#23601;&#24050;&#32463;&#21487;&#30693;&#30340;&#22522;&#26412;&#25968;&#25454;&#31867;&#22411;<br />&#21644;&#23545;&#35937;&#24341;&#29992;.&#20854;&#20013;long&#21644;double&#20250;&#21344;&#29992;2&#20010;&#23616;&#37096;&#21464;&#37327;&#31354;<br />&#38388;(slot),&#20854;&#20182;&#30340;&#21344;&#29992;&#19968;&#20010;.&#23616;&#37096;&#21464;&#37327;&#34920;&#25152;&#38656;&#35201;&#30340;&#31354;&#38388;&#22312;&#32534;&#35793;&#22120;&#23436;&#25104;&#20998;&#37197;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1517836177220" FOLDED="true" ID="ID_824251296" MODIFIED="1529657528255">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36825;&#20010;&#21306;&#22495;&#26377;&#21487;&#33021;&#21457;&#29983;&#30340;&#20004;&#31181;&#24322;&#24120;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1517836193743" ID="ID_1878595382" MODIFIED="1517836586229">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      1. &#22914;&#26524;&#32447;&#31243;&#25152;&#35831;&#27714;&#30340;&#34394;&#25311;&#26426;&#26632;&#30340;&#28145;&#24230;&#22823;&#20110;&#34394;&#25311;&#26426;&#25152;<br />&#20801;&#35768;&#30340;&#28145;&#24230;,&#23558;&#25243;&#20986;StackOverflowError
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1517836317840" ID="ID_1410970779" MODIFIED="1517836401645">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      2. &#22914;&#26524;&#34394;&#25311;&#26426;&#26632;&#21487;&#20197;&#21160;&#24577;&#25193;&#23637;,&#24403;&#25193;&#23637;&#26102;&#26080;&#27861;<br />&#30003;&#35831;&#21040;&#36275;&#22815;&#30340;&#31354;&#38388;&#21017;&#20250;&#25243;&#20986;OutofMemoryError
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1517836655537" FOLDED="true" ID="ID_323150047" MODIFIED="1529657528256" TEXT="&#x672c;&#x5730;&#x65b9;&#x6cd5;&#x6808;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517836675661" ID="ID_308880054" MODIFIED="1517879496051" TEXT="&#x4f5c;&#x7528;&#x7c7b;&#x4f3c;java&#x865a;&#x62df;&#x673a;&#x6808;,&#x4f46;&#x672c;&#x5730;&#x65b9;&#x6cd5;&#x6808;&#x8d1f;&#x8d23;native&#x65b9;&#x6cd5;&#x7684;&#x7ba1;&#x7406;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1517836756650" ID="ID_323047429" MODIFIED="1517879496051" TEXT="&#x540c;&#x6837;&#x6709;&#x53ef;&#x80fd;&#x4f1a;&#x53d1;&#x751f;&#x4e24;&#x4e2a;&#x5f02;&#x5e38;,&#x540c;&#x4e0a;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1517836796618" FOLDED="true" ID="ID_1562402330" MODIFIED="1529657528256" TEXT="java&#x5806;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517836819191" ID="ID_56517348" MODIFIED="1517879496053" TEXT="&#x88ab;&#x6240;&#x6709;&#x7ebf;&#x7a0b;&#x5171;&#x4eab;&#x7684;&#x4e00;&#x5757;&#x533a;&#x57df;,&#x51e0;&#x4e4e;&#x6240;&#x6709;&#x7684;&#x5bf9;&#x8c61;&#x5b9e;&#x4f8b;&#x548c;&#x6570;&#x7ec4;&#x90fd;&#x5728;&#x8fd9;&#x91cc;&#x5206;&#x914d;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1517837081135" FOLDED="true" ID="ID_1293661917" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26041;&#27861;&#21306;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517838661564" FOLDED="true" ID="ID_1320861308" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#65311;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1517837155815" ID="ID_1427303654" MODIFIED="1517838661622">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21508;&#20010;&#32447;&#31243;&#20849;&#20139;&#30340;&#20869;&#23384;&#21306;&#22495;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1517837177528" ID="ID_18128539" MODIFIED="1517838661623">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#29992;&#20110;&#23384;&#20648;&#24050;&#34987;&#34394;&#25311;&#26426;&#21152;&#36733;&#30340;&#31867;&#20449;&#24687;&#12289;&#24120;&#37327;&#12289;<br />&#38745;&#24577;&#21464;&#37327;&#12289;&#21363;&#26102;&#32534;&#35793;&#22120;&#32534;&#35793;&#21518;&#30340;&#20195;&#30721;&#31561;&#25968;&#25454;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1517837545747" ID="ID_1015766184" MODIFIED="1517838661625">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36825;&#20010;&#21306;&#22495;&#30340;&#20869;&#23384;&#22238;&#25910;&#30446;&#26631;&#20027;&#35201;&#26159;&#38024;&#23545;&#24120;&#37327;&#27744;&#30340;&#22238;&#25910;&#21644;&#23545;&#31867;&#22411;&#30340;&#21368;&#36733;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1517838674057" FOLDED="true" ID="ID_367347437" MODIFIED="1529657528256" TEXT="&#x5305;&#x542b;&#x8fd0;&#x884c;&#x65f6;&#x5e38;&#x91cf;&#x6c60;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1517838883483" ID="ID_1998149089" MODIFIED="1517838889045" TEXT="&#x662f;&#x65b9;&#x6cd5;&#x533a;&#x7684;&#x4e00;&#x90e8;&#x5206;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1517839251821" FOLDED="true" ID="ID_1616830240" MODIFIED="1529657528256" TEXT="&#x76f4;&#x63a5;&#x5185;&#x5b58;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517839267311" ID="ID_320915845" MODIFIED="1517879496071">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24182;&#19981;&#26159;&#34394;&#25311;&#26426;&#36816;&#34892;&#26102;&#20869;&#23384;&#30340;&#19968;&#37096;&#20998;&#65292;&#20063;<br />&#19981;&#26159;java&#34394;&#25311;&#26426;&#35268;&#33539;&#20013;&#23450;&#20041;&#30340;&#20869;&#23384;&#21306;&#22495;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1517839326476" FOLDED="true" ID="ID_345684616" MODIFIED="1529657528256" TEXT="&#x4f8b;&#x5982;NIO">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1517839346886" ID="ID_1003889007" MODIFIED="1517839453030">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21487;&#20197;&#30452;&#25509;&#20351;&#29992;native&#30452;&#25509;&#20998;&#37197;&#22534;&#22806;&#20869;&#23384;&#65292;&#28982;&#21518;<br />&#36890;&#36807;channel&#36830;&#25509;&#22534;&#22806;&#20869;&#23384;&#21644;java&#20869;&#30340;buffer&#65292;<br />&#36890;&#36807;&#25805;&#20316;&#24341;&#29992;&#26469;&#25805;&#20316;&#22534;&#22806;&#20869;&#23384;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1517879503528" FOLDED="true" ID="ID_890169406" MODIFIED="1529657528256" TEXT="&#x5bf9;&#x8c61;&#x8bbf;&#x95ee;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1517879523905" FOLDED="true" ID="ID_1019428744" MODIFIED="1529657528256" TEXT="&#x53e5;&#x67c4;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517879623681" FOLDED="true" ID="ID_1102945535" MODIFIED="1529657528256" TEXT="&#x9644;&#x4ef6;">
<node COLOR="#111111" CREATED="1517880025494" ID="ID_1688743590" MODIFIED="1517880025494">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_1783435037823017663.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1517879629691" ID="ID_820832285" MODIFIED="1517879629691" TEXT=""/>
</node>
<node COLOR="#990000" CREATED="1517879529679" FOLDED="true" ID="ID_1953698435" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#30452;&#25509;&#25351;&#38024;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517880006183" FOLDED="true" ID="ID_324852037" MODIFIED="1529657528256" TEXT="&#x9644;&#x4ef6;">
<node COLOR="#111111" CREATED="1517880008303" ID="ID_1078819313" MODIFIED="1517880008303">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_3092663864640886562.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1517880051837" ID="ID_1022906558" MODIFIED="1517880083202">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36895;&#24230;&#26356;&#24555;&#65292;&#33410;&#30465;&#20102;&#19968;&#27425;&#25351;&#38024;&#23450;&#20301;&#30340;&#24320;&#38144;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1517885381777" FOLDED="true" ID="ID_1526216792" MODIFIED="1529657528256" TEXT="&#x65b0;&#x751f;&#x4ee3;&#xff0c;&#x8001;&#x751f;&#x4ee3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1517885409123" FOLDED="true" ID="ID_219618698" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26032;&#29983;&#20195;Young
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517885418102" ID="ID_1303800727" MODIFIED="1517885423314" TEXT="Eden&#x533a;"/>
<node COLOR="#111111" CREATED="1517885423879" FOLDED="true" ID="ID_380837611" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Survivor&#21306;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1517885723073" ID="ID_668390897" MODIFIED="1517885724484" TEXT="from"/>
<node COLOR="#111111" CREATED="1517885724916" ID="ID_1193887387" MODIFIED="1517885725974" TEXT="to"/>
</node>
<node COLOR="#111111" CREATED="1517885495382" FOLDED="true" ID="ID_1662650914" MODIFIED="1529657528256" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1517885497777" ID="ID_919522441" MODIFIED="1517885570426">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Monitor GC&#27599;&#22238;&#25910;&#19968;&#27425;&#23545;&#35937;&#22914;&#26524;&#36824;&#33021;&#23384;&#27963;&#65292;&#24182;&#19988;&#33021;&#37197;survivor<br />&#25509;&#21463;&#21017;&#20854;&#24180;&#40836;&#20250;&#22686;&#21152;1&#65292;&#40664;&#35748;&#21040;15&#26102;&#36827;&#20837;&#32769;&#24180;&#20195;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1517885691787" ID="ID_781473008" MODIFIED="1517885691788" TEXT="&#x5806;&#x5927;&#x5c0f;=&#x65b0;&#x751f;&#x4ee3;+&#x8001;&#x5e74;&#x4ee3;&#xff1b;&#xff08;&#x65b0;&#x751f;&#x4ee3;&#x5360;&#x5806;&#x7a7a;&#x95f4;&#x7684;1/3&#x3001;&#x8001;&#x5e74;&#x4ee3;&#x5360;&#x5806;&#x7a7a;&#x95f4;2/3&#xff09;"/>
<node COLOR="#111111" CREATED="1517885714674" ID="ID_42483807" MODIFIED="1517885714674" TEXT="&#x65b0;&#x751f;&#x4ee3;&#x53c8;&#x88ab;&#x5206;&#x4e3a;&#x4e86;eden&#x3001;from survivor&#x3001;to survivor(8:1:1)&#xff1b;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1517885446469" FOLDED="true" ID="ID_1205622641" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32769;&#24180;&#20195;Old
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517885459747" ID="ID_1459039557" MODIFIED="1517885473366" TEXT="&#x5927;&#x5bf9;&#x8c61;&#x76f4;&#x63a5;&#x5206;&#x914d;&#x5230;&#x8001;&#x5e74;&#x4ee3;"/>
<node COLOR="#111111" CREATED="1517885587761" ID="ID_1115767209" MODIFIED="1517885597694" TEXT="&#x5927;&#x7684;&#x6570;&#x7ec4;&#x5bf9;&#x8c61;&#x4e5f;&#x4f1a;&#x76f4;&#x63a5;&#x5206;&#x914d;&#x5230;&#x8001;&#x5e74;&#x4ee3;"/>
</node>
<node COLOR="#990000" CREATED="1517885832120" FOLDED="true" ID="ID_1543421371" MODIFIED="1529657528256" TEXT="&#xff1f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517885833843" FOLDED="true" ID="ID_1403971721" MODIFIED="1529657528256" TEXT="&#x6587;&#x6863;">
<node COLOR="#111111" CREATED="1517885840865" ID="ID_1769997619" MODIFIED="1517885859411">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div id="article_content" class="article_content csdn-tracking-statistics tracking-click" data-mod="popu_519" data-dsm="post">
      <div class="htmledit_views">
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">Java&#22534;&#20013;&#26159;JVM&#31649;&#29702;&#30340;&#26368;&#22823;&#19968;&#22359;&#20869;&#23384;&#31354;&#38388;&#12290;&#20027;&#35201;&#23384;&#25918;&#23545;&#35937;&#23454;&#20363;&#12290; </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">&#22312;JAVA&#20013;&#22534;&#34987;&#20998;&#20026;&#20004;&#22359;&#21306;&#22495;&#65306;&#26032;&#29983;&#20195;&#65288;young&#65289;&#12289;&#32769;&#24180;&#20195;&#65288;old&#65289;&#12290; </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">&#22534;&#22823;&#23567;=&#26032;&#29983;&#20195;+&#32769;&#24180;&#20195;&#65307;&#65288;&#26032;&#29983;&#20195;&#21344;&#22534;&#31354;&#38388;&#30340;1/3&#12289;&#32769;&#24180;&#20195;&#21344;&#22534;&#31354;&#38388;2/3&#65289;<br size="2" /></font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">&#26032;&#29983;&#20195;&#21448;&#34987;&#20998;&#20026;&#20102;eden&#12289;from survivor&#12289;to survivor(8:1:1)&#65307; </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font color="rgb(255,0,0)" size="2">&#26032;&#29983;&#20195;&#36825;&#26679;&#21010;&#20998;&#26159;&#20026;&#20102;&#26356;&#22909;&#30340;&#31649;&#29702;&#22534;&#20869;&#23384;&#20013;&#30340;&#23545;&#35937;&#65292;&#26041;&#20415;GC&#31639;&#27861;---&#22797;&#21046;&#31639;&#27861;&#26469;&#36827;&#34892;&#22403;&#22334;&#22238;&#25910;&#12290;</font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">JVM&#27599;&#27425;&#21482;&#20250;&#20351;&#29992;eden&#21644;&#20854;&#20013;&#19968;&#22359;survivor&#26469;&#20026;&#23545;&#35937;&#26381;&#21153;&#65292;&#25152;&#20197;&#26080;&#35770;&#20160;&#20040;&#26102;&#20505;&#65292;&#37117;&#20250;&#26377;&#19968;&#22359;survivor&#31354;&#38388;&#65292;&#22240;&#27492;&#26032;&#29983;&#20195;&#23454;&#38469;&#21487;&#29992;&#31354;&#38388;&#21482;&#26377;90%&#12290; </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font color="rgb(255,0,0)" size="2">&#26032;&#29983;&#20195;GC&#65288;minor gc&#65289;----------&#25351;&#21457;&#29983;&#22312;&#26032;&#29983;&#20195;&#30340;&#22403;&#22334;&#22238;&#25910;&#21160;&#20316;&#65292;&#22240;&#20026;JAVA&#23545;&#35937;&#22823;&#22810;&#25968;&#37117;&#26159;&#26397;&#29983;&#22805;&#27515;&#30340;&#29305;&#24615;&#65292;&#25152;&#20197;minor gc&#38750;&#24120;&#24179;&#20961;&#65292;&#20351;&#29992;&#22797;&#21046;&#31639;&#27861;&#24555;&#36895;&#30340;&#22238;&#25910;&#12290;</font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">&#26032;&#29983;&#20195;&#20960;&#20046;&#26159;&#25152;&#26377;JAVA&#23545;&#35937;&#20986;&#29983;&#30340;&#22320;&#26041;&#65292;JAVA&#23545;&#35937;&#30003;&#35831;&#30340;&#20869;&#23384;&#21644;&#23384;&#25918;&#37117;&#26159;&#22312;&#36825;&#20010;&#22320;&#26041;&#12290; </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">&#24403;&#23545;&#35937;&#22312;eden(&#20854;&#20013;&#21253;&#25324;&#19968;&#20010;survivor&#65292;&#20551;&#22914;&#26159;from)&#65292;&#24403;&#27492;&#23545;&#35937;&#32463;&#36807;&#19968;&#27425;minor gc&#21518;&#20173;&#28982;&#23384;&#27963;&#65292;&#24182;&#19988;&#33021;&#22815;&#34987;&#21478;&#22806;&#19968;&#22359;survivor&#25152;&#23481;&#32435;&#65288;&#36825;&#37324;survivor&#21017;&#26159;to&#20102;&#65289;&#65292;&#21017;&#20351;&#29992;&#22797;&#21046;&#31639;&#27861;&#23558;&#36825;&#20123;&#20173;&#28982;&#23384;&#27963;&#30340;&#23545;&#35937;&#22797;&#21046;&#21040;to survior&#21306;&#22495;&#20013;&#65292;&#28982;&#21518;&#28165;&#29702;&#25481;eden&#21644;from survivor&#21306;&#22495;&#65292;&#24182;&#23558;&#36825;&#20123;&#23384;&#27963;&#30340;&#23545;&#35937;&#24180;&#40836;+1&#65292;&#20197;&#21518;&#23545;&#35937;&#22312;survivor&#20013;&#27599;&#29100;&#36807;&#19968;&#27425;gc&#21017;&#22686;&#21152;1&#65292;&#24403;&#24180;&#40836;&#36798;&#21040;&#26576;&#20010;&#20540;&#26102;&#65288;&#40664;&#35748;15&#65292;&#36890;&#36807;&#35774;&#32622;&#21442;&#25968;-xx:maxtenuringThreshold&#26469;&#35774;&#32622;&#65289;&#65292;&#36825;&#20123;&#23545;&#35937;&#23601;&#20250;&#25104;&#20026;&#32769;&#24180;&#20195;&#65281; </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">&#20294;&#26159;&#20063;&#19981;&#19968;&#23450;&#65292;&#24403;&#19968;&#20123;&#36739;&#22823;&#30340;&#23545;&#35937;&#65288;&#38656;&#35201;&#20998;&#37197;&#36830;&#32493;&#30340;&#20869;&#23384;&#31354;&#38388;&#65289;&#21017;&#30452;&#25509;&#36827;&#20837;&#32769;&#24180;&#20195;&#12290; </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2"><br size="2" />
          </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2"><br size="2" />
          </font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font color="rgb(255,0,0)" size="2">&#32769;&#24180;&#20195;GC&#65288;major gc&#65289;----------&#25351;&#21457;&#29983;&#22312;&#32769;&#24180;&#20195;&#30340;&#22403;&#22334;&#22238;&#25910;&#21160;&#20316;&#65292;&#25152;&#37319;&#29992;&#26159;&#30340;&#26631;&#35760;--&#25972;&#29702;&#31639;&#27861;&#12290;</font>
        </div>
        <div style="color: rgb(54,46,43); font-family: Arial; font-size: 14px; line-height: 26px">
          <font size="2">&#32769;&#24180;&#20195;&#20960;&#20046;&#37117;&#26159;&#32463;&#36807;survivor&#29100;&#36807;&#26469;&#30340;&#65292;&#23427;&#20204;&#26159;&#19981;&#20250;&#37027;&#20040;&#23481;&#26131;&#8220;&#27515;&#25481;&#8221;&#65292;&#22240;&#27492;major gc&#19981;&#20250;&#24819;minor gc&#37027;&#26679;&#39057;&#32321;&#12290; </font>
        </div>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1517888866035" FOLDED="true" ID="ID_897681324" MODIFIED="1529657528257">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27979;&#35797;OOM
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1517888871816" FOLDED="true" ID="ID_205334433" MODIFIED="1529657528256" TEXT="&#x4ee3;&#x7801;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517888920958" ID="ID_1733392069" MODIFIED="1517888922576">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #2b2b2b; color: #a9b7c6; font-family: Consolas; font-size: 15.0pt"><font color="#cc7832">public class </font>HeapOOM {<br />    <font color="#cc7832">static class </font>OOMObject{<br /><br />    }<br /><br />    <font color="#cc7832">public static void </font><font color="#ffc66d">main</font>(String[] args) {<br />        List&lt;OOMObject&gt; list = <font color="#cc7832">new </font>ArrayList&lt;&gt;()<font color="#cc7832">;<br />        while </font>(<font color="#cc7832">true</font>) {<br />            list.add(<font color="#cc7832">new </font>OOMObject())<font color="#cc7832">;<br />        </font>}<br />    }<br />}</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1517888875879" FOLDED="true" ID="ID_1614557819" MODIFIED="1529657528256">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36816;&#34892;&#37197;&#32622;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517888884894" ID="ID_1883609095" MODIFIED="1517888884894">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_6099650197055397710.jpeg" />
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1517888901687" ID="ID_200588560" MODIFIED="1517888903441" TEXT="-verbose:gc -Xms20m -Xmx20m -Xmn10m -XX:+PrintGCDetails -XX:SurvivorRatio=8"/>
</node>
<node COLOR="#990000" CREATED="1517888940874" FOLDED="true" ID="ID_486217697" MODIFIED="1529657528256" TEXT="&#x8fd0;&#x884c;&#x7ed3;&#x679c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517888944938" ID="ID_789403151" MODIFIED="1517889002213">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      [GC (Allocation Failure) [PSYoungGen: 8192K-&gt;1016K(9216K)] 8192K-&gt;5105K(19456K), 0.0469669 secs] [Times: user=0.03 sys=0.00, real=0.06 secs]
    </p>
    <p>
      [GC (Allocation Failure) --[PSYoungGen: 9208K-&gt;9208K(9216K)] 13297K-&gt;19440K(19456K), 0.0255316 secs] [Times: user=0.05 sys=0.00, real=0.02 secs]
    </p>
    <p>
      [Full GC (Ergonomics) [PSYoungGen: 9208K-&gt;0K(9216K)] [ParOldGen: 10232K-&gt;9906K(10240K)] 19440K-&gt;9906K(19456K), [Metaspace: 3280K-&gt;3280K(1056768K)], 0.2342489 secs] [Times: user=0.31 sys=0.00, real=0.23 secs]
    </p>
    <p>
      [Full GC (Ergonomics) [PSYoungGen: 7826K-&gt;8176K(9216K)] [ParOldGen: 9906K-&gt;7796K(10240K)] 17733K-&gt;15972K(19456K), [Metaspace: 3280K-&gt;3280K(1056768K)], 0.2000532 secs] [Times: user=0.36 sys=0.00, real=0.20 secs]
    </p>
    <p>
      <font color="#ff3333">[Full GC (Allocation Failure) Exception in thread &quot;main&quot; java.lang.OutOfMemoryError: Java heap space</font>
    </p>
    <p>
      [PSYoungGen: 8176K-&gt;8174K(9216K)] [ParOldGen: 7796K-&gt;7796K(10240K)] 15972K-&gt;15970K(19456K), [Metaspace: 3280K-&gt;3280K(1056768K)], 0.0994295 secs] [Times: user=0.14 sys=0.00, real=0.10 secs]
    </p>
    <p>
      [Full GC (Ergonomics) at java.util.Arrays.copyOf(Arrays.java:3210)
    </p>
    <p>
      [PSYoungGen: 8192K-&gt;0K(9216K)] [ParOldGen: 7796K-&gt;609K(10240K)] 15988K-&gt;609K(19456K), [Metaspace: 3305K-&gt;3305K(1056768K)], 0.0049865 secs] [Times: user=0.00 sys=0.00, real=0.01 secs]
    </p>
    <p>
      at java.util.Arrays.copyOf(Arrays.java:3181)
    </p>
    <p>
      Heap
    </p>
    <p>
      at java.util.ArrayList.grow(ArrayList.java:261)
    </p>
    <p>
      &#160;PSYoungGen&#160;&#160;&#160;&#160;&#160;&#160;total 9216K, used 186K [0x00000000ff600000, 0x0000000100000000, 0x0000000100000000)
    </p>
    <p>
      at java.util.ArrayList.ensureExplicitCapacity(ArrayList.java:235)
    </p>
    <p>
      &#160;&#160;eden space 8192K, 2% used [0x00000000ff600000,0x00000000ff62e8f8,0x00000000ffe00000)
    </p>
    <p>
      at java.util.ArrayList.ensureCapacityInternal(ArrayList.java:227)
    </p>
    <p>
      &#160;&#160;from space 1024K, 0% used [0x00000000ffe00000,0x00000000ffe00000,0x00000000fff00000)
    </p>
    <p>
      at java.util.ArrayList.add(ArrayList.java:458)
    </p>
    <p>
      &#160;&#160;to&#160;&#160;&#160;space 1024K, 0% used [0x00000000fff00000,0x00000000fff00000,0x0000000100000000)
    </p>
    <p>
      at org.lc.HeapOOM.main(HeapOOM.java:20)
    </p>
    <p>
      &#160;ParOldGen&#160;&#160;&#160;&#160;&#160;&#160;&#160;total 10240K, used 609K [0x00000000fec00000, 0x00000000ff600000, 0x00000000ff600000)
    </p>
    <p>
      &#160;&#160;object space 10240K, 5% used [0x00000000fec00000,0x00000000fec987b0,0x00000000ff600000)
    </p>
    <p>
      &#160;Metaspace&#160;&#160;&#160;&#160;&#160;&#160;&#160;used 3312K, capacity 4500K, committed 4864K, reserved 1056768K
    </p>
    <p>
      &#160;&#160;class space&#160;&#160;&#160;&#160;used 363K, capacity 388K, committed 512K, reserved 1048576K
    </p>
    <p>
      
    </p>
    <p>
      Process finished with exit code 1
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1517889047770" FOLDED="true" ID="ID_1307920524" MODIFIED="1529657528257">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27979;&#35797;StackOverflow
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1517889679651" FOLDED="true" ID="ID_911608048" MODIFIED="1529657528257" TEXT="&#x4ee3;&#x7801;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517889689248" ID="ID_822225201" MODIFIED="1517889691276">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #2b2b2b; color: #a9b7c6; font-family: Consolas; font-size: 15.0pt"><font color="#cc7832">public class </font>JavaVMStackSOF {<br />    <font color="#cc7832">private int </font><font color="#9876aa">stackLength </font>= <font color="#6897bb">1</font><font color="#cc7832">;<br /><br />    void </font><font color="#ffc66d">stackLeak</font>() {<br />        <font color="#9876aa">stackLength</font>++<font color="#cc7832">;<br />        </font>System.<font color="#9876aa"><i>out</i></font>.println(<font color="#6a8759">&quot;stack length: &quot; </font>+ <font color="#9876aa">stackLength</font>)<font color="#cc7832">;<br />        </font>stackLeak()<font color="#cc7832">;<br />    </font>}<br /><br />    <font color="#cc7832">public static void </font><font color="#ffc66d">main</font>(String[] args) {<br />        JavaVMStackSOF javaVMStackSOF = <font color="#cc7832">new </font>JavaVMStackSOF()<font color="#cc7832">;<br />        </font>javaVMStackSOF.stackLeak()<font color="#cc7832">;<br /><br />    </font>}<br />}<br /></pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1517889724233" FOLDED="true" ID="ID_432114716" MODIFIED="1529657528257" TEXT="&#x9644;&#x4ef6;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517889726659" ID="ID_156596598" MODIFIED="1517889726659">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="Java&#x8fdb;&#x9636;&#x6280;&#x672f;_4294144991818875695.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1517889771585" FOLDED="true" ID="ID_1032221933" MODIFIED="1529657528257" TEXT="-Xss">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517889778637" ID="ID_1083781358" MODIFIED="1517889786778" TEXT="&#x7528;&#x6765;&#x914d;&#x7f6e;&#x6808;&#x5bb9;&#x91cf;&#x7684;"/>
<node COLOR="#111111" CREATED="1517889787585" FOLDED="true" ID="ID_622271611" MODIFIED="1529657528257" TEXT="&#x5982;: -Xss128k">
<node COLOR="#111111" CREATED="1517889799907" ID="ID_1866343525" MODIFIED="1517889807406" TEXT="&#x6808;&#x5bb9;&#x91cf;&#x4e3a;128k"/>
</node>
</node>
<node COLOR="#990000" CREATED="1517889614805" FOLDED="true" ID="ID_1900060429" MODIFIED="1529657528257" TEXT="&#x8fd0;&#x884c;&#x7ed3;&#x679c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517889625591" ID="ID_1836985618" MODIFIED="1517889663651">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #2b2b2b; color: #a9b7c6; font-family: Consolas; font-size: 15.0pt"><br />

&#30465;&#30053;&#12290;&#12290;&#12290;
&#160;&#160;&#160;&#160;stack length: <font color="#6897bb">965<br />&#160;&#160;&#160; </font>stack length: <font color="#6897bb">966<br />&#160;&#160;&#160; </font>stack length: <font color="#6897bb">967<br />&#160;&#160;&#160; </font>Exception in thread <font color="#6a8759">&quot;main&quot; </font>java.lang.StackOverflowError<br />&#160;&#160;&#160;&#160;at sun.nio.cs.UTF_8.updatePositions(UTF_8.java:<font color="#6897bb">77</font>)<br />&#160;&#160;&#160;&#160;at sun.nio.cs.UTF_8.access$200(UTF_8.java:<font color="#6897bb">57</font>)<br />&#160;&#160;&#160;&#160;at sun.nio.cs.UTF_8$Encoder.encodeArrayLoop(UTF_8.java:<font color="#6897bb">636</font>)<br />&#160;&#160;&#160;&#160;at sun.nio.cs.UTF_8$Encoder.encodeLoop(UTF_8.java:<font color="#6897bb">691</font>)<br />&#160;&#160;&#160;&#160;at java.nio.charset.CharsetEncoder.encode(CharsetEncoder.java:<font color="#6897bb">579</font><br />)<br />&#30465;&#30053;&#12290;&#12290;&#12290;&#12290;</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1517890423447" FOLDED="true" ID="ID_910541119" MODIFIED="1529657528257">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35828;&#26126;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1517890343856" ID="ID_1608843553" MODIFIED="1517890423462">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22914;&#26524;&#32447;&#31243;&#35831;&#27714;&#30340;&#26632;&#28145;&#24230;&#22823;&#20110;&#34394;&#25311;&#26426;&#20801;&#35768;&#30340;&#26368;&#22823;<br />&#28145;&#24230;,&#21017;&#25243;&#20986;StackOverflowError
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1517890429983" ID="ID_938894694" MODIFIED="1517890492152">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22914;&#26524;&#34394;&#25311;&#26426;&#22312;&#25193;&#23637;&#26632;&#26102;&#26080;&#27861;&#30003;&#35831;&#21040;&#36275;&#22815;&#30340;&#20869;&#23384;&#31354;&#38388;,<br />&#21017;&#25243;&#20986;OutOfMemoryError
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1517890519814" FOLDED="true" ID="ID_21810733" MODIFIED="1529657528257" TEXT="&#x8fd9;&#x4e24;&#x79cd;&#x5f02;&#x5e38;&#x7684;&#x53d1;&#x751f;&#x539f;&#x56e0;&#x5177;&#x6709;&#x91cd;&#x53e0;&#x6027;">
<node COLOR="#111111" CREATED="1517890547619" ID="ID_1886349657" MODIFIED="1517892158939">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24403;&#26632;&#31354;&#38388;&#26080;&#27861;&#20998;&#37197;&#26102;&#21040;&#24213;&#26159;&#20869;&#23384;&#22826;&#23567;&#36824;&#26159;&#24050;&#20351;&#29992;&#30340;&#26632;&#31354;&#38388;&#22826;&#22823;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1528263446503" FOLDED="true" ID="ID_1910418658" MODIFIED="1529657528257" POSITION="left" TEXT="&#x9012;&#x5f52;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1528263450159" FOLDED="true" ID="ID_1741255167" MODIFIED="1529657528257" TEXT="&#x9012;&#x5f52;&#x904d;&#x5386;&#x6587;&#x4ef6;&#x5939;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1528263458566" ID="ID_1933225856" MODIFIED="1528263463009">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;
    </p>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 14.0pt"><font color="#000080"><b>private void </b></font>getFile(File file) {<br />    <font color="#000080"><b>if </b></font>(file.isFile()) {<br />        put(file);<br />        Log.<i>v</i>(<font color="#008000"><b>&quot;haha&quot;</b></font>, file.getName());<br />    } <font color="#000080"><b>else </b></font>{<br />        File[] files = file.listFiles();<br />        <font color="#000080"><b>if </b></font>(files != <font color="#000080"><b>null</b></font>) {<br />            <font color="#000080"><b>for </b></font>(File sub : files) {<br />                getFile(sub);<br />            }<br />        }<br />    }<br /><br />}</pre>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
