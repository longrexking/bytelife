package com.longcheng.xmlparsedemo;

import android.util.Log;

import com.longcheng.xmlparsedemo.constants.Tag;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LongWH on 2016/10/3.
 * All Rights Reserved by ZhiYou @2016 - 2017
 */
public class SaxHandler extends DefaultHandler{
    private final String mTag = "haha";
    private List<User> mUsers;
    private User mCurrent;
    private String mPreTag;

    public List<User> getUsers() {
        return mUsers;
    }

    @Override
    public void startDocument() throws SAXException {
        mUsers = new ArrayList<>();
        Log.i(mTag, "====开始文档");
    }

    @Override
    public void endDocument() throws SAXException {
        Log.i(mTag, "=====end");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        if (Tag.user.equals(qName)) {
            mCurrent = new User();
            mCurrent.setId(attributes.getValue(0));
        }
        mPreTag = qName;
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        if (Tag.user.equals(qName)) {
            mUsers.add(mCurrent);
            mCurrent = null;
        }
        mPreTag = null;
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        String value = new String(ch, start, length);
        if (Tag.name.equals(mPreTag)) {
            mCurrent.setName(value);
        } else if (Tag.sex.equals(mPreTag)) {
            mCurrent.setGender(value);
        } else if (Tag.age.equals(mPreTag)) {
            mCurrent.setAge(Integer.parseInt(value));
        }
    }
}

