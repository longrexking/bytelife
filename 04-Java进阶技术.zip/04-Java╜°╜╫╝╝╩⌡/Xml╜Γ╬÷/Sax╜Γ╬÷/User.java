package com.longcheng.xmlparsedemo;

/**
 * Created by LongWH on 2016/10/3.
 * All Rights Reserved by ZhiYou @2016 - 2017
 */
public class User {
    private String mId;
    private String mName;
    private int mAge;
    private String mGender;

    public User() {
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getGender() {
        return mGender;
    }

    public void setGender(String gender) {
        mGender = gender;
    }

    public int getAge() {
        return mAge;
    }

    public void setAge(int age) {
        mAge = age;
    }

    @Override
    public String toString() {
        return "User{" +
                "mId='" + mId + '\'' +
                ", mName='" + mName + '\'' +
                ", mAge=" + mAge +
                ", mGender='" + mGender + '\'' +
                '}';
    }
}
