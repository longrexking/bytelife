<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1472778719120" ID="ID_1305021682" LINK="&#x53cd;&#x5c04;.mm" MODIFIED="1522401947469" TEXT="&#x53cd;&#x5c04;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1488894794198" FOLDED="true" ID="ID_1614113828" MODIFIED="1522401947448" POSITION="right" TEXT="?">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1488894815229" ID="ID_1329822576" MODIFIED="1522401947448" TEXT="JAVA&#x53cd;&#x5c04;&#x673a;&#x5236;&#x662f;&#x5728;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x4e2d;&#xff0c;&#x5bf9;&#x4e8e;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x7c7b;&#xff0c;&#x90fd;&#x80fd;&#x591f;&#x77e5;&#x9053;&#x8fd9;&#x4e2a;&#x7c7b;&#x7684;&#x6240;&#x6709;&#x5c5e;&#x6027;&#x548c;&#x65b9;&#x6cd5;&#xff1b;&#x5bf9;&#x4e8e;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;&#xff0c;&#x90fd;&#x80fd;&#x591f;&#x8c03;&#x7528;&#x5b83;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#xff1b;&#x8fd9;&#x79cd;&#x52a8;&#x6001;&#x83b7;&#x53d6;&#x7684;&#x4fe1;&#x606f;&#x4ee5;&#x53ca;&#x52a8;&#x6001;&#x8c03;&#x7528;&#x5bf9;&#x8c61;&#x7684;&#x65b9;&#x6cd5;&#x7684;&#x529f;&#x80fd;&#x79f0;&#x4e3a;java&#x8bed;&#x8a00;&#x7684;&#x53cd;&#x5c04;&#x673a;&#x5236;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1488894777684" FOLDED="true" ID="ID_495906185" MODIFIED="1522402749824" POSITION="right" TEXT="&#x4f5c;&#x7528;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1488894791401" ID="ID_1823104282" MODIFIED="1522401947453" TEXT="&#x589e;&#x52a0;&#x7a0b;&#x5e8f;&#x7684;&#x7075;&#x6d3b;&#x6027;&#xff0c;&#x907f;&#x514d;&#x5c06;&#x7a0b;&#x5e8f;&#x5199;&#x6b7b;&#x5230;&#x4ee3;&#x7801;&#x91cc;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<icon BUILTIN="messagebox_warning"/>
</node>
<node COLOR="#00b439" CREATED="1488894926455" ID="ID_401853422" MODIFIED="1522401947459" TEXT="Java&#x7684;&#x4ee3;&#x7801;&#x603b;&#x662f;&#x5728;new&#x5bf9;&#x8c61;,&#x4e00;&#x4e2a;&#x7c7b;&#x6301;&#x6709;&#x53e6;&#x4e00;&#x4e2a;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;&#x5c31;&#x628a;&#x8fd9;&#x4e24;&#x4e2a;&#x7c7b;&#x5173;&#x8054;&#x4e86;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1488894977556" ID="ID_1136868873" MODIFIED="1522401947461" TEXT="&#x8fd9;&#x6837;&#x5c31;&#x589e;&#x52a0;&#x7684;&#x7c7b;&#x548c;&#x7c7b;&#x4e4b;&#x95f4;&#x7684;&#x8026;&#x5408;&#x6027;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1488895014475" ID="ID_1133424343" MODIFIED="1522401947462" TEXT="&#x4f7f;&#x7528;&#x53cd;&#x5c04;&#x53ef;&#x4ee5;&#x4f7f;&#x7c7b;&#x95f4;&#x7684;&#x8026;&#x5408;&#x6027;&#x964d;&#x4f4e;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1488895041422" ID="ID_1177645122" MODIFIED="1522401947466" TEXT="&#x6bd4;&#x5982;SpringMvc&#x4e2d;&#x7684;&#x914d;&#x7f6e;&#x6587;&#x4ef6;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1488900082012" FOLDED="true" ID="ID_613025875" MODIFIED="1522401947467" POSITION="right" TEXT="&#x7c7b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1488900098693" FOLDED="true" ID="ID_194413667" MODIFIED="1522401947467" TEXT="Class">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488900745875" FOLDED="true" ID="ID_1074893572" MODIFIED="1522401947467" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488900699044" FOLDED="true" ID="ID_1414037056" MODIFIED="1520498536897" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1488900701083" FOLDED="true" ID="ID_418467548" MODIFIED="1520498536897" TEXT="public static Class&lt;?&gt; forName(String name, boolean initialize,">
<node COLOR="#111111" CREATED="1488900701086" ID="ID_360274548" MODIFIED="1488900701086" TEXT="ClassLoader loader)"/>
</node>
<node COLOR="#111111" CREATED="1488900713378" ID="ID_464547336" MODIFIED="1488900713378" TEXT="public static Class&lt;?&gt; forName(String className)"/>
</node>
<node COLOR="#111111" CREATED="1488900736907" FOLDED="true" ID="ID_204657207" MODIFIED="1520498536897" TEXT="public T newInstance()">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1488900751574" ID="ID_39053630" MODIFIED="1488900768934" TEXT="&#x5b9e;&#x4f8b;&#x5316;&#x4e00;&#x4e2a;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1488900978795" FOLDED="true" ID="ID_628993965" MODIFIED="1520498536897" TEXT="public native boolean isInstance(Object obj)">
<node COLOR="#111111" CREATED="1488900981374" ID="ID_1012810025" MODIFIED="1488900996639" TEXT="obj&#x662f;&#x5426;&#x662f;&#x8be5;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1488901017011" FOLDED="true" ID="ID_909950778" MODIFIED="1520498536897" TEXT="public String getName()">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1488901092739" ID="ID_1427763793" MODIFIED="1488901109936" TEXT="&#x7c7b;&#x540d;&#x5168;&#x8def;&#x5f84;"/>
</node>
<node COLOR="#111111" CREATED="1488901087636" FOLDED="true" ID="ID_1350893927" MODIFIED="1520498536897" TEXT="public String getSimpleName()">
<node COLOR="#111111" CREATED="1488901112104" ID="ID_1148205454" MODIFIED="1488901123014" TEXT="&#x53ea;&#x662f;&#x7c7b;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1488901032222" FOLDED="true" ID="ID_1711996168" MODIFIED="1520498536897" TEXT="public ClassLoader getClassLoader()">
<node COLOR="#111111" CREATED="1488902235073" ID="ID_853680297" MODIFIED="1488902243655" TEXT="&#x83b7;&#x53d6;&#x7c7b;&#x52a0;&#x8f7d;&#x5668;"/>
</node>
<node COLOR="#111111" CREATED="1488901310793" ID="ID_523041403" MODIFIED="1495606327574" TEXT="public Field[] getFields()">
<icon BUILTIN="stop-sign"/>
</node>
<node COLOR="#111111" CREATED="1488901692847" ID="ID_1062391138" MODIFIED="1488902316241" TEXT="public Field[] getDeclaredFields() "/>
<node COLOR="#111111" CREATED="1488901351376" FOLDED="true" ID="ID_178507509" MODIFIED="1520498536897" TEXT="public Field getField(String name)">
<node COLOR="#111111" CREATED="1488901354001" ID="ID_1269719251" MODIFIED="1488901368446" TEXT="&#x83b7;&#x53d6;&#x4e00;&#x4e2a;&#x5b57;&#x6bb5;,name&#x6307;&#x7684;&#x662f;&#x5b57;&#x6bb5;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1488901340865" ID="ID_1486569889" MODIFIED="1488902280287" TEXT="public Constructor&lt;?&gt;[] getConstructors()"/>
<node COLOR="#111111" CREATED="1488901600880" ID="ID_558921450" MODIFIED="1488902280289" TEXT="public Constructor&lt;?&gt;[] getDeclaredConstructors()"/>
<node COLOR="#111111" CREATED="1488901952210" ID="ID_1460508974" MODIFIED="1488902280290" TEXT="public Constructor&lt;T&gt; getDeclaredConstructor(Class&lt;?&gt;... parameterTypes)"/>
<node COLOR="#111111" CREATED="1488901326412" ID="ID_1582666447" MODIFIED="1488901326412" TEXT="public Method[] getMethods()"/>
<node COLOR="#111111" CREATED="1488902122340" ID="ID_1771012738" MODIFIED="1488902124883" TEXT="public Method[] getDeclaredMethods()"/>
<node COLOR="#111111" CREATED="1488901818272" FOLDED="true" ID="ID_1922799235" MODIFIED="1520498536897" TEXT="public Method getMethod(String name, Class&lt;?&gt;... parameterTypes)">
<node COLOR="#111111" CREATED="1488901827464" ID="ID_520589667" MODIFIED="1488902220333" TEXT="&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x7c7b;&#x5355;&#x4e2a;public&#x65b9;&#x6cd5;Method"/>
</node>
<node COLOR="#111111" CREATED="1488902178503" FOLDED="true" ID="ID_685717267" MODIFIED="1520498536897" TEXT="public Method getDeclaredMethod(String name, Class&lt;?&gt;... parameterTypes)">
<node COLOR="#111111" CREATED="1488901827464" ID="ID_1085462657" MODIFIED="1488902226817" TEXT="&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x7c7b;&#x548c;&#x7236;&#x7c7b;&#x5355;&#x4e2a;&#x4efb;&#x610f;&#x65b9;&#x6cd5;Method"/>
</node>
</node>
<node COLOR="#990000" CREATED="1488901699928" FOLDED="true" ID="ID_85540950" MODIFIED="1522401947467" TEXT="&#x6ce8;&#x610f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488901736010" FOLDED="true" ID="ID_1134925698" MODIFIED="1520498536897" TEXT="&#x4e0d;&#x5e26;Declared&#x7684;">
<node COLOR="#111111" CREATED="1488901371778" ID="ID_1501061053" MODIFIED="1488901396237" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x7c7b;&#x6240;&#x6709;&#x7684;public&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;"/>
</node>
<node COLOR="#111111" CREATED="1488901711042" FOLDED="true" ID="ID_1560585224" MODIFIED="1520498536897" TEXT="&#x5e26;Declared">
<node COLOR="#111111" CREATED="1488901607464" ID="ID_544185172" MODIFIED="1495607649739" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x7c7b;&#x6240;&#x6709;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;,&#x4e0d;&#x8bba;&#x662f;&#x4ec0;&#x4e48;&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;"/>
</node>
<node COLOR="#111111" CREATED="1488901845272" FOLDED="true" ID="ID_1656888506" MODIFIED="1520498536897" TEXT="parameterTypes">
<node COLOR="#111111" CREATED="1488901854096" ID="ID_1437148163" MODIFIED="1488901895803" TEXT="&#x6307;&#x7684;&#x662f;&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;&#x4e2d;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1488901909745" ID="ID_1812392377" MODIFIED="1488901924816" TEXT="&#x5982;&#x679c;&#x4e0d;&#x5199;&#x5219;&#x4ee3;&#x8868;&#x6ca1;&#x6709;&#x53c2;&#x6570;"/>
<node COLOR="#111111" CREATED="1488901892679" ID="ID_1482889799" MODIFIED="1488901892679" TEXT="&#x6bd4;&#x5982;String.class,Integer.class"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1488900117020" FOLDED="true" ID="ID_770909109" MODIFIED="1522401947467" TEXT="Constructor">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488902363509" ID="ID_594104744" MODIFIED="1522401947467" TEXT="public String getName()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488902384978" ID="ID_418715995" MODIFIED="1522401947467" TEXT="public Class&lt;?&gt;[] getParameterTypes()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488902431884" FOLDED="true" ID="ID_1234659707" MODIFIED="1522401947467" TEXT="public T newInstance(Object ... initargs)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902433837" ID="ID_730266254" MODIFIED="1488902459583" TEXT="&#x521d;&#x59cb;&#x5316;&#x5f53;&#x524d;&#x7c7b;,&#x76f8;&#x5f53;&#x4e8e;new &#x8be5;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;"/>
<node COLOR="#111111" CREATED="1488902468753" FOLDED="true" ID="ID_1649031271" MODIFIED="1520498536897" TEXT="initargs">
<node COLOR="#111111" CREATED="1488902470405" ID="ID_426776926" MODIFIED="1488902492239" TEXT="&#x521d;&#x59cb;&#x5316;&#x53c2;&#x6570;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;,&#x591a;&#x4e2a;,&#x6216;&#x8005;&#x6ca1;&#x6709;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1488900104481" FOLDED="true" ID="ID_1617319033" MODIFIED="1522401947468" TEXT="Method">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488902527971" ID="ID_1330936457" MODIFIED="1522401947468" TEXT="public String getName()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488902704915" ID="ID_1605805772" MODIFIED="1522401947468" TEXT="public Class&lt;?&gt; getReturnType()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488902717070" FOLDED="true" ID="ID_239146134" MODIFIED="1522401947468" TEXT="public int getModifiers()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902720369" ID="ID_351701839" MODIFIED="1488902730336" TEXT="&#x8fd4;&#x56de;&#x65b9;&#x6cd5;&#x7684;&#x4fee;&#x9970;&#x7b26;&#x7ea7;&#x522b;"/>
</node>
<node COLOR="#990000" CREATED="1488902764893" FOLDED="true" ID="ID_647766955" MODIFIED="1522401947468" TEXT="public Class&lt;?&gt;[] getParameterTypes()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902768351" ID="ID_1345365558" MODIFIED="1488902775117" TEXT="&#x83b7;&#x53d6;&#x65b9;&#x6cd5;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;"/>
</node>
<node COLOR="#990000" CREATED="1488902799472" FOLDED="true" ID="ID_1085664808" MODIFIED="1522401947468" TEXT="public Object invoke(Object obj, Object... args)">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="messagebox_warning"/>
<node COLOR="#111111" CREATED="1488902806652" ID="ID_1304226841" MODIFIED="1488902812844" TEXT="&#x8c03;&#x7528;&#x8be5;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1488902819133" FOLDED="true" ID="ID_473524422" MODIFIED="1520498536897" TEXT="obj">
<node COLOR="#111111" CREATED="1488902824954" ID="ID_198946525" MODIFIED="1488902869718" TEXT="&#x5f53;&#x524d;&#x65b9;&#x6cd5;&#x6240;&#x5c5e;&#x7684;&#x5bf9;&#x8c61;&#x7684;&#x5b9e;&#x4f8b;:"/>
<node COLOR="#111111" CREATED="1488902870749" ID="ID_220292571" MODIFIED="1488902870749" TEXT="&#x5982; currentClass.newInstance()"/>
</node>
<node COLOR="#111111" CREATED="1488902872450" FOLDED="true" ID="ID_1280463476" MODIFIED="1520498536897" TEXT="args">
<node COLOR="#111111" CREATED="1488902877077" ID="ID_643923933" MODIFIED="1488902895093" TEXT="&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x5b9e;&#x9645;&#x53c2;&#x6570;&#x5217;&#x8868;"/>
<node COLOR="#111111" CREATED="1488902895702" ID="ID_561438885" MODIFIED="1488902907188" TEXT="&#x5982;&#x679c;&#x65b9;&#x6cd5;&#x6ca1;&#x6709;&#x53c2;&#x6570;&#x5217;&#x8868;,&#x5219;&#x4e0d;&#x5199;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1488900110164" FOLDED="true" ID="ID_399862368" MODIFIED="1522401947468" TEXT="Field">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488902527971" ID="ID_106660134" MODIFIED="1522401947468" TEXT="public String getName()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488902717070" FOLDED="true" ID="ID_359245539" MODIFIED="1522401947468" TEXT="public int getModifiers()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902720369" ID="ID_1228526257" MODIFIED="1488902967746" TEXT="&#x8fd4;&#x56de;&#x5b57;&#x6bb5;&#x7684;&#x4fee;&#x9970;&#x7b26;&#x7ea7;&#x522b;"/>
</node>
<node COLOR="#990000" CREATED="1488902986086" ID="ID_215123968" MODIFIED="1522401947468" TEXT="public Class&lt;?&gt; getType()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488903159491" FOLDED="true" ID="ID_910133906" MODIFIED="1522401947468" TEXT="&#x83b7;&#x53d6;&#x5b57;&#x6bb5;&#x7684;&#x503c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488903001496" FOLDED="true" ID="ID_1792433076" MODIFIED="1520498536897" TEXT="public Object get(Object obj)">
<node COLOR="#111111" CREATED="1488903004936" ID="ID_209110879" MODIFIED="1488903021345" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x5c5e;&#x6027;&#x7684;&#x503c;"/>
<node COLOR="#111111" CREATED="1488903021910" ID="ID_147670979" MODIFIED="1488903032980" TEXT="&#x8fd4;&#x56de;object&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1488902819133" FOLDED="true" ID="ID_1522677544" MODIFIED="1520498536897" TEXT="obj">
<node COLOR="#111111" CREATED="1488902824954" ID="ID_300779258" MODIFIED="1488902869718" TEXT="&#x5f53;&#x524d;&#x65b9;&#x6cd5;&#x6240;&#x5c5e;&#x7684;&#x5bf9;&#x8c61;&#x7684;&#x5b9e;&#x4f8b;:"/>
<node COLOR="#111111" CREATED="1488902870749" ID="ID_1844653831" MODIFIED="1488902870749" TEXT="&#x5982; currentClass.newInstance()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488903092344" ID="ID_567806640" MODIFIED="1488903092344" TEXT="public boolean getBoolean(Object obj)"/>
<node COLOR="#111111" CREATED="1488903098849" ID="ID_419593487" MODIFIED="1488903098849" TEXT="public byte getByte(Object obj)"/>
<node COLOR="#111111" CREATED="1488903105032" ID="ID_684446452" MODIFIED="1488903105032" TEXT="public char getChar(Object obj)"/>
<node COLOR="#111111" CREATED="1488903110635" ID="ID_764424163" MODIFIED="1488903110635" TEXT="public short getShort(Object obj)"/>
<node COLOR="#111111" CREATED="1488903116790" ID="ID_1179442091" MODIFIED="1488903116790" TEXT="public int getInt(Object obj)"/>
<node COLOR="#111111" CREATED="1488903125419" ID="ID_1514540748" MODIFIED="1488903125419" TEXT="public long getLong(Object obj)"/>
<node COLOR="#111111" CREATED="1488903133754" ID="ID_1215590521" MODIFIED="1488903133754" TEXT="public float getFloat(Object obj)"/>
<node COLOR="#111111" CREATED="1488903142011" ID="ID_751433852" MODIFIED="1488903142011" TEXT="public double getDouble(Object obj)"/>
</node>
<node COLOR="#990000" CREATED="1488903183929" FOLDED="true" ID="ID_1672537611" MODIFIED="1522401947468" TEXT="&#x8bbe;&#x7f6e;&#x5b57;&#x6bb5;&#x7684;&#x503c;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488903153743" ID="ID_518528666" MODIFIED="1488903153743" TEXT="public void set(Object obj, Object value)"/>
<node COLOR="#111111" CREATED="1488903181097" ID="ID_1016808657" MODIFIED="1488903181097" TEXT="public void setBoolean(Object obj, boolean z)"/>
<node COLOR="#111111" CREATED="1488903200675" ID="ID_636952957" MODIFIED="1488903200675" TEXT="public void setByte(Object obj, byte b)"/>
<node COLOR="#111111" CREATED="1488903208173" ID="ID_673957889" MODIFIED="1488903208173" TEXT="public void setChar(Object obj, char c)"/>
<node COLOR="#111111" CREATED="1488903214541" ID="ID_1989008176" MODIFIED="1488903214541" TEXT="public void setShort(Object obj, short s)"/>
<node COLOR="#111111" CREATED="1488903222095" ID="ID_1256397475" MODIFIED="1488903222096" TEXT="public void setInt(Object obj, int i)"/>
<node COLOR="#111111" CREATED="1488903231150" ID="ID_323051938" MODIFIED="1488903231150" TEXT="public void setLong(Object obj, long l)"/>
<node COLOR="#111111" CREATED="1488903237561" ID="ID_525255355" MODIFIED="1488903237561" TEXT="public void setFloat(Object obj, float f)"/>
<node COLOR="#111111" CREATED="1488903243047" ID="ID_1463792592" MODIFIED="1488903243047" TEXT="public void setDouble(Object obj, double d)"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1488900582271" FOLDED="true" ID="ID_1393898705" MODIFIED="1522401947468" TEXT="ClassLoader">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488900595415" FOLDED="true" ID="ID_1102400146" MODIFIED="1522401947468" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488900600259" ID="ID_140253400" MODIFIED="1488900634675" TEXT="cls.getClass().getClassLoader()"/>
<node COLOR="#111111" CREATED="1488900635170" ID="ID_1508780714" MODIFIED="1488900659335" TEXT="&#x6216; xx.class.getClassLoader()"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1502688170442" FOLDED="true" ID="ID_1683815232" MODIFIED="1522401947469" POSITION="right" TEXT="&#x6ce8;&#x89e3;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1502688338587" FOLDED="true" ID="ID_528988239" MODIFIED="1522401947469" TEXT="&#x5143;&#x6ce8;&#x89e3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1502688363663" FOLDED="true" ID="ID_1466814333" MODIFIED="1522401947469" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1502688365566" ID="ID_1503252432" MODIFIED="1502688386529" TEXT="&#x7528;&#x6765;&#x6ce8;&#x89e3;&#x81ea;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x7684;&#x6ce8;&#x89e3;"/>
</node>
<node COLOR="#990000" CREATED="1502688388564" FOLDED="true" ID="ID_735423956" MODIFIED="1522401947469" TEXT="&#x5206;&#x7c7b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1502688390770" FOLDED="true" ID="ID_233717527" MODIFIED="1520498536898" TEXT="@Target">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1502688470866" FOLDED="true" ID="ID_1306965733" MODIFIED="1520498536898">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502688467930" ID="ID_995535722" MODIFIED="1502688467931" TEXT="@Target&#x8bf4;&#x660e;&#x4e86;Annotation&#x6240;&#x4fee;&#x9970;&#x7684;&#x5bf9;&#x8c61;&#x8303;&#x56f4;"/>
</node>
<node COLOR="#111111" CREATED="1502688476975" FOLDED="true" ID="ID_1973276297" MODIFIED="1520498536898">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33539;&#22260;&#30340;&#21462;&#20540;&#26159;&#19968;&#20010;&#26522;&#20030;ElementType
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502688545177" ID="ID_648509303" MODIFIED="1502688551255" TEXT="CONSTRUCTOR:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x6784;&#x9020;&#x5668;"/>
<node COLOR="#111111" CREATED="1502688545195" ID="ID_1656802221" MODIFIED="1502688554873" TEXT="FIELD:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x57df;"/>
<node COLOR="#111111" CREATED="1502688545201" ID="ID_1808959307" MODIFIED="1502688558539" TEXT="LOCAL_VARIABLE:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x5c40;&#x90e8;&#x53d8;&#x91cf;"/>
<node COLOR="#111111" CREATED="1502688545207" ID="ID_723309580" MODIFIED="1502688564653" TEXT="METHOD:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1502688545211" FOLDED="true" ID="ID_1487876722" MODIFIED="1520498536898" TEXT="PACKAGE:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x5305;">
<node COLOR="#111111" CREATED="1502688782463" ID="ID_1692215475" MODIFIED="1502688782464" TEXT="@Target(value=ElementType.PACKAGE)&#x65f6;&#xff0c;&#x5b83;&#x5373;&#x662f;&#x5bf9;&#x5305;&#x7684;&#x4fee;&#x9970;&#x6ce8;&#x91ca;&#x3002;"/>
<node COLOR="#111111" CREATED="1502688795303" FOLDED="true" ID="ID_1191704623" MODIFIED="1520498536898" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1502688956913" FOLDED="true" ID="ID_570438502" MODIFIED="1520498536898" TEXT="&#x6ce8;&#x89e3;">
<node COLOR="#111111" CREATED="1502688970904" ID="ID_751404618" MODIFIED="1502688973723" TEXT="&amp;lt;html&amp;gt;&#xa;  &amp;lt;body&amp;gt;&#xa;    &amp;lt;p align=&amp;quot;left&amp;quot; style=&amp;quot;background-color: rgb(43,; background-position: 43, 43); background-image: null; background-repeat: repeat; background-attachment: scroll&amp;quot;&amp;gt;&#xa;      &amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;@Target&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;(&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#D0D0FF&amp;quot;&amp;gt;value&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;= {ElementType.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;METHOD&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;,&amp;lt;/font&amp;gt;&amp;#xa0;&#xa;      &amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;ElementType.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;PACKAGE&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;,&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;ElementType.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;TYPE&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;})&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;@Retention&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;(RetentionPolicy.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;RUNTIME&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;public&amp;lt;/font&amp;gt;&amp;#xa0;&#xa;      &amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;@&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;interface&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;{&amp;lt;br&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&#xa;      String&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#FFC66D&amp;quot;&amp;gt;names&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;()&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;default&amp;lt;/font&amp;gt;&amp;#xa0;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#6A8759&amp;quot;&amp;gt;&amp;amp;quot;&amp;amp;quot;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font face=&amp;quot;&amp;#x5b8b;&amp;#x4f53;&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;}&amp;lt;/font&amp;gt;&#xa;    &amp;lt;/p&amp;gt;&#xa;    &amp;lt;p&amp;gt;&#xa;      &#xa;    &amp;lt;/p&amp;gt;&#xa;  &amp;lt;/body&amp;gt;&#xa;&amp;lt;/html&amp;gt;"/>
</node>
<node COLOR="#111111" CREATED="1502688979368" FOLDED="true" ID="ID_233698586" MODIFIED="1520498536898" TEXT="&#x6ce8;&#x89e3;&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1502688816503" ID="ID_708448979" MODIFIED="1502688816503" TEXT="&#x6ce8;&#x89e3;&#x4e0d;&#x80fd;&#x76f4;&#x63a5;&#x7528;&#x4e8e;&#x7c7b;&#x4e2d;&#xff0c;&#x5fc5;&#x987b;&#x5728;&#x76f8;&#x5e94;package&#x4e0b;&#x521b;&#x5efa;package-info.java&#x6587;&#x4ef6;&#xff1a;"/>
<node COLOR="#111111" CREATED="1502688831526" ID="ID_87399917" MODIFIED="1502688845383">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #2B2B2B; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null"><font color="#BBB529">@MyAopAnno</font><font color="#A9B7C6">(</font><font color="#D0D0FF">names </font><font color="#A9B7C6">= </font><font color="#6A8759">&quot;&#21704;&#21704;&quot;</font><font color="#A9B7C6">)<br /></font><font color="#CC7832">package </font><font color="#A9B7C6">com.scn7th.model</font><font color="#CC7832">;<br />
import </font><font color="#BBB529">com.scn7th.aop.MyAopAnno</font><font color="#CC7832">;</font>
</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1502688903355" FOLDED="true" ID="ID_1772744809" MODIFIED="1520498536898">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27979;&#35797;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502688947383" ID="ID_1654900529" MODIFIED="1502688950137" TEXT="&amp;lt;html&amp;gt;&#xa;  &amp;lt;body&amp;gt;&#xa;    &amp;lt;pre style=&amp;quot;background-color: #2B2B2B; background-image: null; background-repeat: repeat; background-attachment: scroll; background-position: null&amp;quot;&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;@Test&amp;lt;br&amp;gt;&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;public void &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#FFC66D&amp;quot;&amp;gt;testPackage&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;() {&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; Package myPackage = Package.&amp;lt;i&amp;gt;getPackage&amp;lt;/i&amp;gt;(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#6A8759&amp;quot;&amp;gt;&amp;amp;quot;com.scn7th.model&amp;amp;quot;&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; if&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;null &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;!= myPackage &amp;amp;amp;&amp;amp;amp; myPackage.isAnnotationPresent(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;.&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;class&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)) {&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;myAopAnno = myPackage.getAnnotation(&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#BBB529&amp;quot;&amp;gt;MyAopAnno&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;.&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;class&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;)&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;System.&amp;lt;/font&amp;gt;&amp;lt;i&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#9876AA&amp;quot;&amp;gt;out&amp;lt;/font&amp;gt;&amp;lt;/i&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;.println(myAopAnno.names())&amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#CC7832&amp;quot;&amp;gt;;&amp;lt;br&amp;gt;&#xa;&amp;#xa0;&amp;lt;wbr&amp;gt;&amp;#xa0;&amp;lt;wbr&amp;gt; &amp;lt;/font&amp;gt;&amp;lt;font size=&amp;quot;10.5pt&amp;quot; color=&amp;quot;#A9B7C6&amp;quot;&amp;gt;}&amp;lt;br&amp;gt;&#xa;}&amp;lt;/font&amp;gt;&#xa;&amp;lt;/pre&amp;gt;&#xa;    &amp;lt;p&amp;gt;&#xa;      &#xa;    &amp;lt;/p&amp;gt;&#xa;  &amp;lt;/body&amp;gt;&#xa;&amp;lt;/html&amp;gt;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1502688545218" ID="ID_1516181425" MODIFIED="1502689016294" TEXT="PARAMETER:  &#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x53c2;&#x6570;"/>
<node COLOR="#111111" CREATED="1502688545220" ID="ID_532534527" MODIFIED="1502688580131" TEXT="TYPE:&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x7c7b;&#x3001;&#x63a5;&#x53e3;(&#x5305;&#x62ec;&#x6ce8;&#x89e3;&#x7c7b;&#x578b;) &#x6216;enum&#x58f0;&#x660e;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1502688390778" FOLDED="true" ID="ID_890330835" MODIFIED="1520498536898" TEXT="@Retention">
<icon BUILTIN="button_ok"/>
<node COLOR="#111111" CREATED="1502689095310" FOLDED="true" ID="ID_770669335" MODIFIED="1520498536898" TEXT="?">
<node COLOR="#111111" CREATED="1502689096739" ID="ID_1424351636" MODIFIED="1502689122911" TEXT="&#x5b9a;&#x4e49;&#x4e86;&#x8be5;Annotation&#x88ab;&#x4fdd;&#x7559;&#x7684;&#x65f6;&#x95f4;&#x957f;&#x77ed;&#xff1a;&#x67d0;&#x4e9b;Annotation&#x4ec5;&#x51fa;&#x73b0;&#x5728;&#x6e90;&#x4ee3;&#x7801;&#x4e2d;&#xff0c;&#x800c;&#x88ab;&#x7f16;&#x8bd1;&#x5668;&#x4e22;&#x5f03;&#xff1b;&#x800c;&#x53e6;&#x4e00;&#x4e9b;&#x5374;&#x88ab;&#x7f16;&#x8bd1;&#x5728;class&#x6587;&#x4ef6;&#x4e2d;&#xff1b;&#x7f16;&#x8bd1;&#x5728;class&#x6587;&#x4ef6;&#x4e2d;&#x7684;Annotation&#x53ef;&#x80fd;&#x4f1a;&#x88ab;&#x865a;&#x62df;&#x673a;&#x5ffd;&#x7565;&#xff0c;&#x800c;&#x53e6;&#x4e00;&#x4e9b;&#x5728;class&#x88ab;&#x88c5;&#x8f7d;&#x65f6;&#x5c06;&#x88ab;&#x8bfb;&#x53d6;&#xff08;&#x8bf7;&#x6ce8;&#x610f;&#x5e76;&#x4e0d;&#x5f71;&#x54cd;class&#x7684;&#x6267;&#x884c;&#xff0c;&#x56e0;&#x4e3a;Annotation&#x4e0e;class&#x5728;&#x4f7f;&#x7528;&#x4e0a;&#x662f;&#x88ab;&#x5206;&#x79bb;&#x7684;&#xff09;&#x3002;&#x4f7f;&#x7528;&#x5b83;&#x53ef;&#x4ee5;&#x5bf9; Annotation&#x7684;&#x201c;&#x751f;&#x547d;&#x5468;&#x671f;&#x201d;&#x9650;&#x5236;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1502689136115" ID="ID_719932032" MODIFIED="1502689136116" TEXT="&#x4f5c;&#x7528;&#xff1a;&#x8868;&#x793a;&#x9700;&#x8981;&#x5728;&#x4ec0;&#x4e48;&#x7ea7;&#x522b;&#x4fdd;&#x5b58;&#x8be5;&#x6ce8;&#x91ca;&#x4fe1;&#x606f;&#xff0c;&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x6ce8;&#x89e3;&#x7684;&#x751f;&#x547d;&#x5468;&#x671f;&#xff08;&#x5373;&#xff1a;&#x88ab;&#x63cf;&#x8ff0;&#x7684;&#x6ce8;&#x89e3;&#x5728;&#x4ec0;&#x4e48;&#x8303;&#x56f4;&#x5185;&#x6709;&#x6548;&#xff09;"/>
<node COLOR="#111111" CREATED="1502689143031" FOLDED="true" ID="ID_252065681" MODIFIED="1520498536898" TEXT="&#x53d6;&#x503c;: &#x679a;&#x4e3e;RetentionPoicy">
<node COLOR="#111111" CREATED="1502689164061" ID="ID_1745035107" MODIFIED="1502689169469" TEXT="SOURCE:&#x5728;&#x6e90;&#x6587;&#x4ef6;&#x4e2d;&#x6709;&#x6548;&#xff08;&#x5373;&#x6e90;&#x6587;&#x4ef6;&#x4fdd;&#x7559;&#xff09;"/>
<node COLOR="#111111" CREATED="1502689164064" ID="ID_1965155446" MODIFIED="1502689174162" TEXT="CLASS:&#x5728;class&#x6587;&#x4ef6;&#x4e2d;&#x6709;&#x6548;&#xff08;&#x5373;class&#x4fdd;&#x7559;&#xff09;"/>
<node COLOR="#111111" CREATED="1502689164065" ID="ID_1324069914" MODIFIED="1502689179418" TEXT="RUNTIME:&#x5728;&#x8fd0;&#x884c;&#x65f6;&#x6709;&#x6548;&#xff08;&#x5373;&#x8fd0;&#x884c;&#x65f6;&#x4fdd;&#x7559;&#xff09;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1502688390780" FOLDED="true" ID="ID_846567275" MODIFIED="1520498536898" TEXT="@Documented">
<node COLOR="#111111" CREATED="1502689225317" ID="ID_1424005277" MODIFIED="1502689229064" TEXT="&#x3000;&#x3000;@Documented&#x7528;&#x4e8e;&#x63cf;&#x8ff0;&#x5176;&#x5b83;&#x7c7b;&#x578b;&#x7684;annotation&#x5e94;&#x8be5;&#x88ab;&#x4f5c;&#x4e3a;&#x88ab;&#x6807;&#x6ce8;&#x7684;&#x7a0b;&#x5e8f;&#x6210;&#x5458;&#x7684;&#x516c;&#x5171;API&#xff0c;&#x56e0;&#x6b64;&#x53ef;&#x4ee5;&#x88ab;&#x4f8b;&#x5982;javadoc&#x6b64;&#x7c7b;&#x7684;&#x5de5;&#x5177;&#x6587;&#x6863;&#x5316;&#x3002;Documented&#x662f;&#x4e00;&#x4e2a;&#x6807;&#x8bb0;&#x6ce8;&#x89e3;&#xff0c;&#x6ca1;&#x6709;&#x6210;&#x5458;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1502688390784" FOLDED="true" ID="ID_561804300" MODIFIED="1520498536898" TEXT="@Inherited">
<node COLOR="#111111" CREATED="1502689308753" FOLDED="true" ID="ID_1357814103" MODIFIED="1520498536898">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1502689260755" ID="ID_942011825" MODIFIED="1502689264347" TEXT="@Inherited &#x5143;&#x6ce8;&#x89e3;&#x662f;&#x4e00;&#x4e2a;&#x6807;&#x8bb0;&#x6ce8;&#x89e3;&#xff0c;@Inherited&#x9610;&#x8ff0;&#x4e86;&#x67d0;&#x4e2a;&#x88ab;&#x6807;&#x6ce8;&#x7684;&#x7c7b;&#x578b;&#x662f;&#x88ab;&#x7ee7;&#x627f;&#x7684;&#x3002;&#x5982;&#x679c;&#x4e00;&#x4e2a;&#x4f7f;&#x7528;&#x4e86;@Inherited&#x4fee;&#x9970;&#x7684;annotation&#x7c7b;&#x578b;&#x88ab;&#x7528;&#x4e8e;&#x4e00;&#x4e2a;class&#xff0c;&#x5219;&#x8fd9;&#x4e2a;annotation&#x5c06;&#x88ab;&#x7528;&#x4e8e;&#x8be5;class&#x7684;&#x5b50;&#x7c7b;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1502689291747" FOLDED="true" ID="ID_62772136" MODIFIED="1520498536898" TEXT="&#x6ce8;&#x610f;&#xff1a;">
<node COLOR="#111111" CREATED="1502689306514" ID="ID_451073848" MODIFIED="1502689306516" TEXT="@Inherited annotation&#x7c7b;&#x578b;&#x662f;&#x88ab;&#x6807;&#x6ce8;&#x8fc7;&#x7684;class&#x7684;&#x5b50;&#x7c7b;&#x6240;&#x7ee7;&#x627f;&#x3002;&#x7c7b;&#x5e76;&#x4e0d;&#x4ece;&#x5b83;&#x6240;&#x5b9e;&#x73b0;&#x7684;&#x63a5;&#x53e3;&#x7ee7;&#x627f;annotation&#xff0c;&#x65b9;&#x6cd5;&#x5e76;&#x4e0d;&#x4ece;&#x5b83;&#x6240;&#x91cd;&#x8f7d;&#x7684;&#x65b9;&#x6cd5;&#x7ee7;&#x627f;annotation&#x3002;"/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1502689365546" FOLDED="true" ID="ID_990547591" MODIFIED="1522401947469" TEXT="&#x81ea;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1502689393525" FOLDED="true" ID="ID_367035540" MODIFIED="1522401947469" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1502689394370" ID="ID_185529543" MODIFIED="1502689977799" TEXT="&#x4f7f;&#x7528;@interface&#x81ea;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x65f6;&#xff0c;&#x81ea;&#x52a8;&#x7ee7;&#x627f;&#x4e86;java.lang.annotation.Annotation&#x63a5;&#x53e3;&#xff0c;&#x7531;&#x7f16;&#x8bd1;&#x7a0b;&#x5e8f;&#x81ea;&#x52a8;&#x5b8c;&#x6210;&#x5176;&#x4ed6;&#x7ec6;&#x8282;&#x3002;&#x5728;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x65f6;&#xff0c;&#x4e0d;&#x80fd;&#x7ee7;&#x627f;&#x5176;&#x4ed6;&#x7684;&#x6ce8;&#x89e3;&#x6216;&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1502689413725" ID="ID_1864516889" MODIFIED="1502689413726" TEXT="@interface&#x7528;&#x6765;&#x58f0;&#x660e;&#x4e00;&#x4e2a;&#x6ce8;&#x89e3;&#xff0c;&#x5176;&#x4e2d;&#x7684;&#x6bcf;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#x5b9e;&#x9645;&#x4e0a;&#x662f;&#x58f0;&#x660e;&#x4e86;&#x4e00;&#x4e2a;&#x914d;&#x7f6e;&#x53c2;&#x6570;&#x3002;&#x65b9;&#x6cd5;&#x7684;&#x540d;&#x79f0;&#x5c31;&#x662f;&#x53c2;&#x6570;&#x7684;&#x540d;&#x79f0;&#xff0c;&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;&#x5c31;&#x662f;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;&#xff08;&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;&#x53ea;&#x80fd;&#x662f;&#x57fa;&#x672c;&#x7c7b;&#x578b;&#x3001;Class&#x3001;String&#x3001;enum&#xff09;&#x3002;&#x53ef;&#x4ee5;&#x901a;&#x8fc7;default&#x6765;&#x58f0;&#x660e;&#x53c2;&#x6570;&#x7684;&#x9ed8;&#x8ba4;&#x503c;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1502689419828" FOLDED="true" ID="ID_1599531647" MODIFIED="1522401947469" TEXT="&#x65b9;&#x6cd5;&#x7684;&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1502689442146" FOLDED="true" ID="ID_550352527" MODIFIED="1520498536898" TEXT="&#x57fa;&#x672c;&#x7c7b;&#x578b;">
<node COLOR="#111111" CREATED="1502689503581" ID="ID_1838989072" MODIFIED="1502689503581" TEXT="int,float,boolean,byte,double,char,long,short"/>
</node>
<node COLOR="#111111" CREATED="1502689448928" FOLDED="true" ID="ID_633272878" MODIFIED="1520498536898" TEXT="Class">
<node COLOR="#111111" CREATED="1502689472765" ID="ID_1177935763" MODIFIED="1502689483321" TEXT="&#x6ce8;&#x610f;: &#x662f;Class"/>
</node>
<node COLOR="#111111" CREATED="1502689458395" ID="ID_76553652" MODIFIED="1502689464084" TEXT="String"/>
<node COLOR="#111111" CREATED="1502689465482" ID="ID_1767018824" MODIFIED="1502689469752" TEXT="enum"/>
<node COLOR="#111111" CREATED="1502689521936" ID="ID_251397504" MODIFIED="1502689521937" TEXT="Annotation&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1502689533714" ID="ID_385366670" MODIFIED="1502689533714" TEXT="&#x4ee5;&#x4e0a;&#x6240;&#x6709;&#x7c7b;&#x578b;&#x7684;&#x6570;&#x7ec4;"/>
</node>
<node COLOR="#990000" CREATED="1502689554539" FOLDED="true" ID="ID_1961698605" MODIFIED="1522401947469" TEXT="&#x7ec6;&#x8282;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1502689566459" ID="ID_1432614181" MODIFIED="1502689566460" TEXT="&#x53ea;&#x80fd;&#x7528;public&#x6216;&#x9ed8;&#x8ba4;(default)&#x8fd9;&#x4e24;&#x4e2a;&#x8bbf;&#x95ee;&#x6743;&#x4fee;&#x9970;.&#x4f8b;&#x5982;,String value();&#x8fd9;&#x91cc;&#x628a;&#x65b9;&#x6cd5;&#x8bbe;&#x4e3a;defaul&#x9ed8;&#x8ba4;&#x7c7b;&#x578b;&#xff1b;&#x3000; &#x3000;"/>
<node COLOR="#111111" CREATED="1502689633442" ID="ID_388904547" MODIFIED="1502689633443" TEXT="&#x5982;&#x679c;&#x53ea;&#x6709;&#x4e00;&#x4e2a;&#x53c2;&#x6570;&#x6210;&#x5458;,&#x6700;&#x597d;&#x628a;&#x53c2;&#x6570;&#x540d;&#x79f0;&#x8bbe;&#x4e3a;&quot;value&quot;,&#x540e;&#x52a0;&#x5c0f;&#x62ec;&#x53f7;"/>
<node COLOR="#111111" CREATED="1502689878553" FOLDED="true" ID="ID_775325462" MODIFIED="1520498536898" TEXT="&#x6ce8;&#x89e3;&#x5143;&#x7d20;&#x7684;&#x9ed8;&#x8ba4;&#x503c;&#xff1a;">
<node COLOR="#111111" CREATED="1502689894923" ID="ID_1229029079" MODIFIED="1502689940683" TEXT="&#x6ce8;&#x89e3;&#x5143;&#x7d20;&#x5fc5;&#x987b;&#x6709;&#x786e;&#x5b9a;&#x7684;&#x503c;&#xff0c;&#x8981;&#x4e48;&#x5728;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x7684;&#x9ed8;&#x8ba4;&#x503c;&#x4e2d;&#x6307;&#x5b9a;&#xff0c;&#xa;&#x8981;&#x4e48;&#x5728;&#x4f7f;&#x7528;&#x6ce8;&#x89e3;&#x65f6;&#x6307;&#x5b9a;&#xff0c;&#x975e;&#x57fa;&#x672c;&#x7c7b;&#x578b;&#x7684;&#x6ce8;&#x89e3;&#x5143;&#x7d20;&#x7684;&#x503c;&#x4e0d;&#x53ef;&#x4e3a;null"/>
<node COLOR="#111111" CREATED="1502689917128" ID="ID_1978241729" MODIFIED="1502689933464" TEXT="&#x4f7f;&#x7528;&#x7a7a;&#x5b57;&#x7b26;&#x4e32;&#x6216;0&#x4f5c;&#x4e3a;&#x9ed8;&#x8ba4;&#x503c;&#x662f;&#x4e00;&#x79cd;&#x5e38;&#x7528;&#x7684;&#x505a;&#x6cd5;&#x3002;&#x8fd9;&#x4e2a;&#x7ea6;&#x675f;&#x4f7f;&#x5f97;&#x5904;&#x7406;&#xa;&#x5668;&#x5f88;&#x96be;&#x8868;&#x73b0;&#x4e00;&#x4e2a;&#x5143;&#x7d20;&#x7684;&#x5b58;&#x5728;&#x6216;&#x7f3a;&#x5931;&#x7684;&#x72b6;&#x6001;&#xff0c;&#x56e0;&#x4e3a;&#x6bcf;&#x4e2a;&#x6ce8;&#x89e3;&#x7684;&#x58f0;&#x660e;&#x4e2d;&#xff0c;&#xa;&#x6240;&#x6709;&#x5143;&#x7d20;&#x90fd;&#x5b58;&#x5728;&#xff0c;&#x5e76;&#x4e14;&#x90fd;&#x5177;&#x6709;&#x76f8;&#x5e94;&#x7684;&#x503c;&#xff0c;&#x4e3a;&#x4e86;&#x7ed5;&#x5f00;&#x8fd9;&#x4e2a;&#x7ea6;&#x675f;&#xff0c;&#x6211;&#x4eec;&#xa;&#x53ea;&#x80fd;&#x5b9a;&#x4e49;&#x4e00;&#x4e9b;&#x7279;&#x6b8a;&#x7684;&#x503c;&#xff0c;&#x4f8b;&#x5982;&#x7a7a;&#x5b57;&#x7b26;&#x4e32;&#x6216;&#x8005;&#x8d1f;&#x6570;&#xff0c;&#x4e00;&#x6b21;&#x8868;&#x793a;&#x67d0;&#x4e2a;&#xa;&#x5143;&#x7d20;&#x4e0d;&#x5b58;&#x5728;&#xff0c;&#x5728;&#x5b9a;&#x4e49;&#x6ce8;&#x89e3;&#x65f6;&#xff0c;&#x8fd9;&#x5df2;&#x7ecf;&#x6210;&#x4e3a;&#x4e00;&#x4e2a;&#x4e60;&#x60ef;&#x7528;"/>
</node>
</node>
</node>
</node>
</node>
</map>
