/**
 * 
 */
package org.lc.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.lc.constants.HttpKeys;
import org.lc.utils.WorkPool;

/**
 * @author longWH
 *
 */
public class ChatServer {
	private ServerSocket serverSocket;
	private List<WrapSocket> list = new ArrayList<>();
	private int num;

	public static void main(String[] args) throws Exception {
		System.out.println("����������....");
		ChatServer server = new ChatServer();
		server.init();
		server.start();
	}

	/**
	 * @throws IOException
	 * @throws UnknownHostException
	 * 
	 */
	private void init() throws Exception {
		serverSocket = new ServerSocket(HttpKeys.remotePort, 50, InetAddress.getLocalHost());
	}

	/**
	 * @throws IOException
	 */
	private void start() throws IOException {
		while (true) {
			Socket client = serverSocket.accept();
			WrapSocket wrap = new WrapSocket(client, "account" + ++num);
			list.add(wrap);
			WorkPool.instance.service().execute(new ReadTask(wrap));
		}
	}

	class ReadTask implements Runnable {
		private WrapSocket wrapSocket;
		private PrintWriter writer;

		/**
		 * @param socket
		 */
		public ReadTask(WrapSocket socket) {
			super();
			this.wrapSocket = socket;
		}

		@Override
		public void run() {
			Socket socket = wrapSocket.getSocket();
			InputStreamReader in;
			String msg;
			try {
				in = new InputStreamReader(socket.getInputStream());
				BufferedReader reader = new BufferedReader(in);
				String account = wrapSocket.getAccount();
				welcome(socket);
				while (true) {
					msg = reader.readLine();
					msg = account + ": " + msg;
					transmitMsg(msg, account);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * @param account
		 * @throws IOException
		 */
		private void welcome(Socket socket) throws IOException {
			writer = new PrintWriter(socket.getOutputStream());
			writer.println("welcome u");
			writer.flush();
		}

		/**
		 * @param msg
		 * @param account
		 * @throws IOException
		 */
		public void transmitMsg(String msg, String account) throws IOException {
			for (WrapSocket wrapSocket : list) {
				if (!account.equals(wrapSocket.getAccount())) {
					writer = new PrintWriter(wrapSocket.getSocket().getOutputStream());
					writer.println(msg);
					writer.flush();
				}
			}

		}

	}

}
