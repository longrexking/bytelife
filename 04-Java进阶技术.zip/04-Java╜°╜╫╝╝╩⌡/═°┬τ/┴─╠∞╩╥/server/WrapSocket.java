/**
 * 
 */
package org.lc.server;

import java.net.Socket;

/**
 * @author longWH
 *
 */
public class WrapSocket {
	private Socket socket;
	private String account;

	/**
	 * @param socket
	 * @param account
	 */
	public WrapSocket(Socket socket, String account) {
		super();
		this.socket = socket;
		this.account = account;
	}

	/**
	 * @return the socket
	 */
	public Socket getSocket() {
		return socket;
	}

	/**
	 * @param socket
	 *            the socket to set
	 */
	public void setSocket(Socket socket) {
		this.socket = socket;
	}

	/**
	 * @return the account
	 */
	public String getAccount() {
		return account;
	}

	/**
	 * @param account
	 *            the account to set
	 */
	public void setAccount(String account) {
		this.account = account;
	}

}
