/**
 * 
 */
package org.lc.constants;

/**
 * @author longWH
 *
 */
public interface HttpKeys {
	int remotePort = 9999;
	int localPortStart = 10000;
	int localPort1 = localPortStart + 1;
	int localPort2 = localPortStart + 2;
	String url = "192.168.1.148";
}
