/**
 * 
 */
package org.lc.client;

import java.net.Socket;

import org.lc.constants.HttpKeys;
import org.lc.utils.WorkPool;

/**
 * @author longWH
 *
 */
public class Client01 {
	private Socket socket;

	public static void main(String[] args) {
		Client01 client01 = new Client01();
		System.out.println("client01 ����...");
		try {
			client01.init();
			ReadTask readTask = new ReadTask(client01.socket);
			WorkPool.instance.service().execute(readTask);
			WriteTask writeTask = new WriteTask(client01.socket);
			WorkPool.instance.service().execute(writeTask);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @throws Exception @throws
	 * 
	 */
	private void init() throws Exception {
		socket = new Socket(HttpKeys.url, HttpKeys.remotePort);
	}

}
	