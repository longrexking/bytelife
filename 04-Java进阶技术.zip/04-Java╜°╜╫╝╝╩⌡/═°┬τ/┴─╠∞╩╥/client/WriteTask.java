/**
 * 
 */
package org.lc.client;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * @author longWH
 *
 */
public class WriteTask implements Runnable {
	private Socket socket;

	/**
	 * @param socket
	 */
	public WriteTask(Socket socket) {
		super();
		this.socket = socket;
	}

	@Override
	public void run() {
		PrintWriter writer = null;
		OutputStreamWriter oWriter = null;
		Scanner scanner = new Scanner(System.in);
		try {
			oWriter = new OutputStreamWriter(socket.getOutputStream());
			writer = new PrintWriter(oWriter);
			while (scanner.hasNext()) {
				String input = scanner.nextLine();
				writer.println(input);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			scanner.close();
			try {
				if (oWriter != null) {
					oWriter.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (writer != null) {
				writer.close();
			}
		}

	}

}
