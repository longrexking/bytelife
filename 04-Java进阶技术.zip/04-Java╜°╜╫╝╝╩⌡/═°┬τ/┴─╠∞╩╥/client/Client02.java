/**
 * 
 */
package org.lc.client;

import java.net.Socket;

import org.lc.constants.HttpKeys;
import org.lc.utils.WorkPool;

/**
 * @author longWH
 *
 */
public class Client02 {
	private Socket socket;

	public static void main(String[] args) {
		Client02 client02 = new Client02();
		System.out.println("client02 ����...");
		try {
			client02.init();
			ReadTask readTask = new ReadTask(client02.socket);
			WorkPool.instance.service().execute(readTask);
			WriteTask writeTask = new WriteTask(client02.socket);
			WorkPool.instance.service().execute(writeTask);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @throws Exception
	 * 			@throws
	 * 
	 */
	private void init() throws Exception {
		socket = new Socket(HttpKeys.url, HttpKeys.remotePort);
	}


}
