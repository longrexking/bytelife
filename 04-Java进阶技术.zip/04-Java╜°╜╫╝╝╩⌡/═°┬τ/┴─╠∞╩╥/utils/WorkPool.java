/**
 * 
 */
package org.lc.utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author longWH
 *
 */
public enum WorkPool {
	instance;
	private ExecutorService service;

	private WorkPool() {
		service = Executors.newCachedThreadPool();
	}

	public ExecutorService service() {
		return service;
	}
}
