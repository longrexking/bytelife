<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1491461098707" ID="ID_1839088564" MODIFIED="1522566933946" TEXT="xml">
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1491461529614" FOLDED="true" ID="ID_460386974" MODIFIED="1522566933942" POSITION="left" TEXT="&#x8f6c;&#x4e49;&#x5b57;&#x7b26;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491461533317" ID="ID_1626441629" MODIFIED="1491461533317" TEXT="&amp;lt;         &lt;         &#x5c0f;&#x4e8e;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1491461533318" ID="ID_162303372" MODIFIED="1491461533318" TEXT="&amp;gt;         &gt;         &#x5927;&#x4e8e;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1491461533319" ID="ID_792223194" MODIFIED="1491461533319" TEXT="&amp;amp;         &amp;         &#x548c;&#x53f7;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1491461533319" ID="ID_1905076134" MODIFIED="1491461533319" TEXT="&amp;apos;         &apos;         &#x5355;&#x5f15;&#x53f7;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1491461533320" ID="ID_1853688064" MODIFIED="1491461533320" TEXT="&amp;quot;         &quot;         &#x5f15;&#x53f7;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522467320669" FOLDED="true" ID="ID_37146912" MODIFIED="1522468099242" POSITION="right" TEXT="&#xff1f;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font BOLD="true" NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1522468078322" ID="ID_506136458" MODIFIED="1522468083914" TEXT="xml&#x662f;&#x4e92;&#x8054;&#x7f51;&#x6570;&#x636e;&#x4f20;&#x8f93;&#x7684;&#x91cd;&#x8981;&#x5de5;&#x5177;&#xff0c;&#x5b83;&#x53ef;&#x4ee5;&#x8de8;&#x8d8a;&#x4e92;&#x8054;&#x7f51;&#x4efb;&#x4f55;&#x7684;&#x5e73;&#x53f0;&#xff0c;&#x4e0d;&#x53d7;&#x7f16;&#x7a0b;&#x8bed;&#x8a00;&#x548c;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x7684;&#x9650;&#x5236;&#xff0c;&#x53ef;&#x4ee5;&#x8bf4;&#x5b83;&#x662f;&#x4e00;&#x4e2a;&#x62e5;&#x6709;&#x4e92;&#x8054;&#x7f51;&#x6700;&#x9ad8;&#x7ea7;&#x522b;&#x901a;&#x884c;&#x8bc1;&#x7684;&#x6570;&#x636e;&#x643a;&#x5e26;&#x8005;&#x3002;xml&#x662f;&#x5f53;&#x524d;&#x5904;&#x7406;&#x7ed3;&#x6784;&#x5316;&#x6587;&#x6863;&#x4fe1;&#x606f;&#x4e2d;&#x76f8;&#x5f53;&#x7ed9;&#x529b;&#x7684;&#x6280;&#x672f;&#xff0c;xml&#x6709;&#x52a9;&#x4e8e;&#x5728;&#x670d;&#x52a1;&#x5668;&#x4e4b;&#x95f4;&#x7a7f;&#x68ad;&#x7ed3;&#x6784;&#x5316;&#x6570;&#x636e;&#xff0c;&#x8fd9;&#x4f7f;&#x5f97;&#x5f00;&#x53d1;&#x4eba;&#x5458;&#x66f4;&#x52a0;&#x5f97;&#x5fc3;&#x5e94;&#x624b;&#x7684;&#x63a7;&#x5236;&#x6570;&#x636e;&#x7684;&#x5b58;&#x50a8;&#x548c;&#x4f20;&#x8f93;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522467335651" ID="ID_1614442427" MODIFIED="1522467335652" TEXT="&#x53ef;&#x6269;&#x5c55;&#x6807;&#x8bb0;&#x8bed;&#x8a00;&#xff08;&#x6807;&#x51c6;&#x901a;&#x7528;&#x6807;&#x8bb0;&#x8bed;&#x8a00;&#x7684;&#x5b50;&#x96c6;&#xff09;&#x662f;&#x4e00;&#x79cd;&#x7b80;&#x5355;&#x7684;&#x6570;&#x636e;&#x5b58;&#x50a8;&#x8bed;&#x8a00;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522467374801" ID="ID_170506068" MODIFIED="1522467944038" TEXT="&#x7528;&#x6765;&#x5728;&#x7f51;&#x7edc;&#x4e2d;&#x4f20;&#x8f93;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522468029664" ID="ID_1808537148" MODIFIED="1522468034609" TEXT="IBM&#x4ece;60&#x5e74;&#x4ee3;&#x5c31;&#x5f00;&#x59cb;&#x53d1;&#x5c55;&#x7684;&#x901a;&#x7528;&#x6807;&#x8bb0;&#x8bed;&#x8a00;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491461780537" FOLDED="true" ID="ID_639990914" MODIFIED="1522467315053" POSITION="right" TEXT="&#x7ea6;&#x675f;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491461786447" FOLDED="true" ID="ID_1564244445" MODIFIED="1522566933943" TEXT="Schema &#x7ea6;&#x675f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491461804344" ID="ID_1942084361" MODIFIED="1491461804344" TEXT="&#x7528;&#x4e8e;&#x5b9a;&#x4e49;&#x548c;&#x63cf;&#x8ff0; XML &#x6587;&#x6863;&#x7ed3;&#x6784;&#x4e0e;&#x5185;&#x5bb9;&#x7684;&#x6a21;&#x5f0f;&#x8bed;&#x8a00;&#xff0c;&#x5176;&#x51fa;&#x73b0;&#x76ee;&#x7684;&#x662f;&#x4e3a;&#x4e86;&#x514b;&#x670d; DTD &#x7684;&#x5c40;&#x9650;&#x6027;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491462626964" FOLDED="true" ID="ID_695438031" MODIFIED="1522566933943" TEXT="&#x5b9a;&#x4e49;&#x7b80;&#x6613;&#x5143;&#x7d20;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491462631680" ID="ID_1601290267" MODIFIED="1491462631681" TEXT="xs:string"/>
<node COLOR="#111111" CREATED="1491462631681" ID="ID_920903441" MODIFIED="1491462631682" TEXT="xs:decimal"/>
<node COLOR="#111111" CREATED="1491462631682" ID="ID_1517989793" MODIFIED="1491462631682" TEXT="xs:integer"/>
<node COLOR="#111111" CREATED="1491462631683" ID="ID_94800491" MODIFIED="1491462631683" TEXT="xs:boolean"/>
<node COLOR="#111111" CREATED="1491462631684" ID="ID_1251814068" MODIFIED="1491462631684" TEXT="xs:date"/>
<node COLOR="#111111" CREATED="1491462631685" ID="ID_854995680" MODIFIED="1491462631685" TEXT="xs:time"/>
<node COLOR="#111111" CREATED="1491462654849" FOLDED="true" ID="ID_722812333" MODIFIED="1522566933943" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1491462659452" ID="ID_95239730" MODIFIED="1491462667391" TEXT="&lt;xs:element name=&quot;lastname&quot; type=&quot;xs:string&quot;/&gt; &#xa;&lt;xs:element name=&quot;age&quot; type=&quot;xs:integer&quot;/&gt;&#xa; &lt;xs:element name=&quot;dateborn&quot; type=&quot;xs:date&quot;/&gt; "/>
</node>
</node>
<node COLOR="#990000" CREATED="1491462744268" FOLDED="true" ID="ID_688078615" MODIFIED="1522566933943" TEXT="&#x5982;&#x4f55;&#x58f0;&#x660e;&#x5c5e;&#x6027;&#xff1f;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491462750372" FOLDED="true" ID="ID_1569233254" MODIFIED="1522566933943" TEXT="&#x8bed;&#x6cd5;">
<node COLOR="#111111" CREATED="1491462754764" ID="ID_1515058522" MODIFIED="1491462754764" TEXT="&lt;xs:attribute name=&quot;xxx&quot; type=&quot;yyy&quot;/&gt;"/>
</node>
<node COLOR="#111111" CREATED="1491462761732" FOLDED="true" ID="ID_1415614866" MODIFIED="1522566933943" TEXT="&#x53ef;&#x9009;&#x7684;&#x7c7b;&#x578b;&#x662f;">
<node COLOR="#111111" CREATED="1491462766648" ID="ID_1003381864" MODIFIED="1491462766648" TEXT="xs:string"/>
<node COLOR="#111111" CREATED="1491462766649" ID="ID_249393102" MODIFIED="1491462766649" TEXT="xs:decimal"/>
<node COLOR="#111111" CREATED="1491462766650" ID="ID_1614151981" MODIFIED="1491462766650" TEXT="xs:integer"/>
<node COLOR="#111111" CREATED="1491462766650" ID="ID_1116769847" MODIFIED="1491462766650" TEXT="xs:boolean"/>
<node COLOR="#111111" CREATED="1491462766651" ID="ID_61748901" MODIFIED="1491462766651" TEXT="xs:date"/>
<node COLOR="#111111" CREATED="1491462766652" ID="ID_1756331251" MODIFIED="1491462766652" TEXT="xs:time"/>
</node>
<node COLOR="#111111" CREATED="1491462795789" FOLDED="true" ID="ID_171794206" MODIFIED="1522566933943" TEXT="&#x53ef;&#x9009;&#x7684;&#x548c;&#x5fc5;&#x9700;&#x7684;&#x5c5e;&#x6027;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1491462814576" ID="ID_1479573862" MODIFIED="1491462822084" TEXT="&#x4f7f;&#x7528;&quot;use&quot;&#x5c5e;&#x6027;"/>
<node COLOR="#111111" CREATED="1491462804242" ID="ID_720752250" MODIFIED="1491462828266" TEXT="&#x8303;&#x4f8b;:  &lt;xs:attribute name=&quot;lang&quot; type=&quot;xs:string&quot; use=&quot;required&quot;/&gt;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1491462864723" FOLDED="true" ID="ID_1654310723" MODIFIED="1496153932794" TEXT="&#x5bf9;&#x503c;&#x7684;&#x9650;&#x5b9a;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491462938419" FOLDED="true" ID="ID_1332338453" MODIFIED="1522566933943" TEXT="&#x5355;&#x4e2a;">
<node COLOR="#111111" CREATED="1491462883613" ID="ID_550467684" MODIFIED="1491462915483" TEXT="&lt;xs:element name=&quot;age&quot;&gt;&#xa;  &lt;xs:simpleType&gt;&#xa;   &lt;xs:restriction base=&quot;xs:integer&quot;&gt;&#xa;     &lt;xs:minInclusive value=&quot;0&quot;/&gt;&#xa;     &lt;xs:maxInclusive value=&quot;120&quot;/&gt;&#xa;   &lt;/xs:restriction&gt;&#xa; &lt;/xs:simpleType&gt;&#xa;&lt;/xs:element&gt; "/>
</node>
<node COLOR="#111111" CREATED="1491462945752" FOLDED="true" ID="ID_88277113" MODIFIED="1522566933943" TEXT="&#x591a;&#x4e2a;">
<node COLOR="#111111" CREATED="1491462963085" ID="ID_1094215278" MODIFIED="1491462985280" TEXT="&lt;xs:element name=&quot;car&quot;&gt;&#xa;  &lt;xs:simpleType&gt;&#xa;   &lt;xs:restriction base=&quot;xs:string&quot;&gt;&#xa;     &lt;xs:enumeration value=&quot;Audi&quot;/&gt;&#xa;     &lt;xs:enumeration value=&quot;Golf&quot;/&gt;&#xa;     &lt;xs:enumeration value=&quot;BMW&quot;/&gt;&#xa;   &lt;/xs:restriction&gt;&#xa; &lt;/xs:simpleType&gt;&#xa;&lt;/xs:element&gt; "/>
</node>
<node COLOR="#111111" CREATED="1491463032683" ID="ID_1811768878" LINK="http://www.w3school.com.cn/schema/schema_facets.asp" MODIFIED="1491463048825" TEXT="&#x4e00;&#x7cfb;&#x5217;"/>
<node COLOR="#111111" CREATED="1491463065402" ID="ID_1706721184" LINK="http://www.w3school.com.cn/schema/schema_facets.asp" MODIFIED="1491463074279" TEXT="&#x5bf9;&#x7a7a;&#x767d;&#x5b57;&#x7b26;&#x7684;&#x9650;&#x5b9a;"/>
<node COLOR="#111111" CREATED="1491463082760" ID="ID_1735893931" MODIFIED="1491463082760" TEXT="&#x5bf9;&#x957f;&#x5ea6;&#x7684;&#x9650;&#x5b9a;"/>
<node COLOR="#111111" CREATED="1491463089607" FOLDED="true" ID="ID_1458195156" MODIFIED="1491463096683" TEXT="&#x6570;&#x636e;&#x7c7b;&#x578b;&#x7684;&#x9650;&#x5b9a;">
<node COLOR="#111111" CREATED="1491463095517" ID="ID_1378080102" MODIFIED="1491463095517" TEXT="enumeration         &#x5b9a;&#x4e49;&#x53ef;&#x63a5;&#x53d7;&#x503c;&#x7684;&#x4e00;&#x4e2a;&#x5217;&#x8868;"/>
<node COLOR="#111111" CREATED="1491463095518" ID="ID_1645554575" MODIFIED="1491463095518" TEXT="fractionDigits         &#x5b9a;&#x4e49;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x6700;&#x5927;&#x7684;&#x5c0f;&#x6570;&#x4f4d;&#x6570;&#x3002;&#x5fc5;&#x987b;&#x5927;&#x4e8e;&#x7b49;&#x4e8e;0&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095523" ID="ID_965267250" MODIFIED="1491463095523" TEXT="length         &#x5b9a;&#x4e49;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x5b57;&#x7b26;&#x6216;&#x8005;&#x5217;&#x8868;&#x9879;&#x76ee;&#x7684;&#x7cbe;&#x786e;&#x6570;&#x76ee;&#x3002;&#x5fc5;&#x987b;&#x5927;&#x4e8e;&#x6216;&#x7b49;&#x4e8e;0&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095526" ID="ID_1360368894" MODIFIED="1491463095527" TEXT="maxExclusive         &#x5b9a;&#x4e49;&#x6570;&#x503c;&#x7684;&#x4e0a;&#x9650;&#x3002;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x503c;&#x5fc5;&#x987b;&#x5c0f;&#x4e8e;&#x6b64;&#x503c;&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095528" ID="ID_1785501188" MODIFIED="1491463095528" TEXT="maxInclusive         &#x5b9a;&#x4e49;&#x6570;&#x503c;&#x7684;&#x4e0a;&#x9650;&#x3002;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x503c;&#x5fc5;&#x987b;&#x5c0f;&#x4e8e;&#x6216;&#x7b49;&#x4e8e;&#x6b64;&#x503c;&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095529" ID="ID_780278980" MODIFIED="1491463095529" TEXT="maxLength         &#x5b9a;&#x4e49;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x5b57;&#x7b26;&#x6216;&#x8005;&#x5217;&#x8868;&#x9879;&#x76ee;&#x7684;&#x6700;&#x5927;&#x6570;&#x76ee;&#x3002;&#x5fc5;&#x987b;&#x5927;&#x4e8e;&#x6216;&#x7b49;&#x4e8e;0&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095532" ID="ID_799640212" MODIFIED="1491463095532" TEXT="minExclusive         &#x5b9a;&#x4e49;&#x6570;&#x503c;&#x7684;&#x4e0b;&#x9650;&#x3002;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x503c;&#x5fc5;&#x9700;&#x5927;&#x4e8e;&#x6b64;&#x503c;&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095533" ID="ID_925960091" MODIFIED="1491463095533" TEXT="minInclusive         &#x5b9a;&#x4e49;&#x6570;&#x503c;&#x7684;&#x4e0b;&#x9650;&#x3002;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x503c;&#x5fc5;&#x9700;&#x5927;&#x4e8e;&#x6216;&#x7b49;&#x4e8e;&#x6b64;&#x503c;&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095539" ID="ID_1567230932" MODIFIED="1491463095539" TEXT="minLength         &#x5b9a;&#x4e49;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x5b57;&#x7b26;&#x6216;&#x8005;&#x5217;&#x8868;&#x9879;&#x76ee;&#x7684;&#x6700;&#x5c0f;&#x6570;&#x76ee;&#x3002;&#x5fc5;&#x987b;&#x5927;&#x4e8e;&#x6216;&#x7b49;&#x4e8e;0&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095540" ID="ID_1388305789" MODIFIED="1491463095541" TEXT="pattern         &#x5b9a;&#x4e49;&#x53ef;&#x63a5;&#x53d7;&#x7684;&#x5b57;&#x7b26;&#x7684;&#x7cbe;&#x786e;&#x5e8f;&#x5217;&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095541" ID="ID_248966811" MODIFIED="1491463095542" TEXT="totalDigits         &#x5b9a;&#x4e49;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x963f;&#x62c9;&#x4f2f;&#x6570;&#x5b57;&#x7684;&#x7cbe;&#x786e;&#x4f4d;&#x6570;&#x3002;&#x5fc5;&#x987b;&#x5927;&#x4e8e;0&#x3002;"/>
<node COLOR="#111111" CREATED="1491463095542" ID="ID_998161406" MODIFIED="1491463095543" TEXT="whiteSpace         &#x5b9a;&#x4e49;&#x7a7a;&#x767d;&#x5b57;&#x7b26;&#xff08;&#x6362;&#x884c;&#x3001;&#x56de;&#x8f66;&#x3001;&#x7a7a;&#x683c;&#x4ee5;&#x53ca;&#x5236;&#x8868;&#x7b26;&#xff09;&#x7684;&#x5904;&#x7406;&#x65b9;&#x5f0f;&#x3002;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491462468630" ID="ID_1168125273" MODIFIED="1491462472679" TEXT="DTD">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522468100449" FOLDED="true" ID="ID_1879082985" MODIFIED="1522557739197" POSITION="right" TEXT="&#x7279;&#x70b9;&#xff1a;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1522468111725" ID="ID_1745764624" MODIFIED="1522556806900" TEXT=" xml&#x4e0e;&#x64cd;&#x4f5c;&#x7cfb;&#x7edf;&#x3001;&#x7f16;&#x7a0b;&#x8bed;&#x8a00;&#x7684;&#x5f00;&#x53d1;&#x5e73;&#x53f0;&#x90fd;&#x65e0;&#x5173;&#xff1b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522468111737" ID="ID_1860832659" MODIFIED="1522556803308" TEXT="&#x5b9e;&#x73b0;&#x4e0d;&#x540c;&#x7cfb;&#x7edf;&#x4e4b;&#x95f4;&#x7684;&#x6570;&#x636e;&#x4ea4;&#x4e92;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522468116537" FOLDED="true" ID="ID_1476358875" MODIFIED="1522556814277" POSITION="right" TEXT="&#x4f5c;&#x7528;&#xff1a;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1522468122751" ID="ID_1955256413" MODIFIED="1522468126691" TEXT="v &#x914d;&#x7f6e;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x548c;&#x7f51;&#x7ad9;&#xff1b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522468122764" ID="ID_1994371853" MODIFIED="1522468126700" TEXT="v &#x6570;&#x636e;&#x4ea4;&#x4e92;&#xff1b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522468122769" ID="ID_1382884684" MODIFIED="1522468126702" TEXT="v Ajax&#x57fa;&#x77f3;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522468184508" FOLDED="true" ID="ID_1397324552" MODIFIED="1522557737538" POSITION="right" TEXT="&#x7ed3;&#x6784;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1522557489847" ID="ID_1972323960" MODIFIED="1522557525745" TEXT="XML &#x6587;&#x6863;&#x5f62;&#x6210;&#x4e86;&#x4e00;&#x79cd;&#x6811;&#x7ed3;&#x6784;&#xff0c;&#x5b83;&#x4ece;&#x201c;&#x6839;&#x90e8;&#x201d;&#x5f00;&#x59cb;&#xff0c;&#x7136;&#x540e;&#x6269;&#x5c55;&#x5230;&#x201c;&#x679d;&#x53f6;&#x201d;&#x3002;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522557130658" ID="ID_1106277434" MODIFIED="1522557521144">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      <font size="4">&lt;?xml version=&quot;1.0&quot; encoding=&quot;ISO-8859-1&quot;?&gt; </font>
    </p>
    <p>
      <font size="4">&lt;root field=value&gt; </font>
    </p>
    <p>
      <font size="4">&#160;&#160;&#160;&#160;&lt;child field1=value,field2=value [... fieldN]&gt; </font>
    </p>
    <p>
      <font size="4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;subChild field&gt; </font>
    </p>
    <p>
      <font size="4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;!--&#23376;&#33410;&#28857;--&gt; </font>
    </p>
    <p>
      <font size="4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&lt;/subChild&gt; </font>
    </p>
    <p>
      <font size="4">&#160;&#160;&#160;&lt;/child&gt; </font>
    </p>
    <p>
      <font size="4">&lt;/root&gt;</font>
    </p>
  </body>
</html>
</richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1522557326828" ID="ID_73898135" MODIFIED="1522557606442">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      0&#65292;&#31532;&#19968;&#34892;&#26159; XML &#22768;&#26126;&#12290;&#23427;&#23450;&#20041; XML &#30340;&#29256;&#26412; (1.0) &#21644;&#25152;&#20351;&#29992;&#30340;&#32534;&#30721;
    </p>
    <p>
      1.&#26377;&#19988;&#20165;&#26377;&#19968;&#20010;&#26681;&#33410;&#28857;<br />2.&#21487;&#20197;&#26377;0&#20010;&#25110;&#22810;&#20010;&#23646;&#24615;<br />3.&#21487;&#20197;&#23884;&#22871;n&#32423;<br />4.&#32467;&#26463;&#33410;&#28857;&#35201;&#21152;&#8220;/&#8221;
    </p>
  </body>
</html>
</richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522557742549" FOLDED="true" ID="ID_569010341" MODIFIED="1522561490571" POSITION="right" TEXT="&#x547d;&#x540d;&#x7a7a;&#x95f4;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1522557832186" FOLDED="true" ID="ID_1216641684" MODIFIED="1522566933943" TEXT="&#x5f53;&#x4e0d;&#x540c;&#x6587;&#x6863;&#x7684;&#x76f8;&#x540c;&#x6807;&#x7b7e;&#x4ea7;&#x751f;&#x51b2;&#x7a81;&#x65f6;&#x5c31;&#x65e0;&#x6cd5;&#x6b63;&#x786e;&#x8bc6;&#x522b;&#x6807;&#x7b7e;&#x7684;&#x542b;&#x4e49;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522557999147" FOLDED="true" ID="ID_683785733" MODIFIED="1522566933943">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24320;&#21457;&#32773;A
    </p>
  </body>
</html>
</richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522557941649" ID="ID_764973954" MODIFIED="1522557999168">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;table&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;tr&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;td&gt;Apples&lt;/td&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;td&gt;Bananas&lt;/td&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;/tr&gt;
    </p>
    <p>
      &lt;/table&gt;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1522557986519" FOLDED="true" ID="ID_1141251845" MODIFIED="1522566933943" TEXT="&#x5f00;&#x53d1;&#x8005;B">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522557992782" ID="ID_1981974074" MODIFIED="1522557994854">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;table&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;name&gt;African Coffee Table&lt;/name&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;width&gt;80&lt;/width&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;length&gt;120&lt;/length&gt;
    </p>
    <p>
      &lt;/table&gt;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1522557870085" FOLDED="true" ID="ID_1617626654" MODIFIED="1522558402265">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35299;&#20915;&#26041;&#26696;1:
    </p>
    <p>
      <span style="color: #990000; font-size: 116%; font-family: SansSerif, sans-serif"><font color="#990000" size="116%" face="SansSerif, sans-serif">&#28155;&#21152;&#21069;&#32512;</font></span>
    </p>
  </body>
</html>
</richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522558337404" FOLDED="true" ID="ID_765929060" MODIFIED="1522558380870">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24320;&#21457;&#32773;A
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522557906543" ID="ID_577259895" MODIFIED="1522557909091">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;h:table&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;h:tr&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;h:td&gt;Apples&lt;/h:td&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;h:td&gt;Bananas&lt;/h:td&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;/h:tr&gt;
    </p>
    <p>
      &lt;/h:table&gt;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1522558299302" FOLDED="true" ID="ID_1448122302" MODIFIED="1522558380871" TEXT="&#x5f00;&#x53d1;&#x8005;B">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522558306727" ID="ID_1163430670" MODIFIED="1522558317967">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;f:table&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;f:name&gt;African Coffee Table&lt;/f:name&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;f:width&gt;80&lt;/f:width&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;f:length&gt;120&lt;/f:length&gt;
    </p>
    <p>
      &lt;/f:table&gt;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1522558382880" FOLDED="true" ID="ID_322213719" MODIFIED="1522559591699">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35299;&#20915;&#26041;&#26696;2:&#20351;&#29992;&#21629;&#21517;&#31354;&#38388;
    </p>
  </body>
</html>
</richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522558468611" FOLDED="true" ID="ID_67318738" MODIFIED="1522566933943" TEXT="&#x5f00;&#x53d1;&#x8005;A">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522558475310" ID="ID_683679070" MODIFIED="1522558487891">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;h:table xmlns:h=&quot;http://www.w3.org/TR/html4/&quot;&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;h:tr&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;h:td&gt;Apples&lt;/h:td&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;h:td&gt;Bananas&lt;/h:td&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;/h:tr&gt;
    </p>
    <p>
      &lt;/h:table&gt;
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#111111" CREATED="1522558537754" ID="ID_177789078" MODIFIED="1522558582173" TEXT="xmlns&#x4e2d;&#x7684;&#x5185;&#x5bb9;&#x662f;&#x4e00;&#x4e2a;&#x8def;&#x5f84;,&#x53ef;&#x4ee5;&#x552f;&#x4e00;&#x7684;&#x6807;&#x8bc6;&#x51fa;&#x5f00;&#x53d1;&#x8005;A&#x7684;&#x6587;&#x6863;"/>
</node>
<node COLOR="#990000" CREATED="1522558594331" FOLDED="true" ID="ID_1017990016" MODIFIED="1522566933943" TEXT="&#x5f00;&#x53d1;&#x8005;b">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522558601800" ID="ID_15655801" MODIFIED="1522558615798">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;f:table xmlns:f=&quot;http://www.lc.com.cn/furniture&quot;&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;f:name&gt;African Coffee Table&lt;/f:name&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;f:width&gt;80&lt;/f:width&gt;
    </p>
    <p>
      &#160;&#160;&#160;&lt;f:length&gt;120&lt;/f:length&gt;
    </p>
    <p>
      &lt;/f:table&gt;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1522558701535" FOLDED="true" ID="ID_436905345" MODIFIED="1522566933943" TEXT="&#x8bed;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522558707367" ID="ID_358582331" MODIFIED="1522558707367" TEXT="xmlns:namespace-prefix=&quot;namespaceURI&quot;"/>
<node COLOR="#111111" CREATED="1522558894635" FOLDED="true" ID="ID_17998950" MODIFIED="1522566933943" TEXT="xmlns">
<node COLOR="#111111" CREATED="1522558900571" ID="ID_232857956" MODIFIED="1522558934498" TEXT="XML Namespaces&#x7684;&#x7f29;&#x5199;,&#x56fa;&#x5b9a;&#x7684;&#x5199;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1522558910773" FOLDED="true" ID="ID_1606941221" MODIFIED="1522566933943" TEXT="namespace-prefix">
<node COLOR="#111111" CREATED="1522558914700" ID="ID_1636115466" MODIFIED="1522558928321" TEXT="&#x524d;&#x7f00;,&#x81ea;&#x5df1;&#x5b9a;&#x4e49;&#x7684;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522561497757" FOLDED="true" ID="ID_846923242" MODIFIED="1522566933945" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32422;&#26463;
    </p>
  </body>
</html>
</richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1522561662864" FOLDED="true" ID="ID_270214093" MODIFIED="1522566933943" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522561667974" ID="ID_657549438" MODIFIED="1522561667974" TEXT="&#x56e0;&#x4e3a;xml&#x6587;&#x6863;&#x662f;&#x53ef;&#x4ee5;&#x81ea;&#x5b9a;&#x4e49;&#x5143;&#x7d20;&#x7684;&#xff0c;&#x8fd9;&#x4f1a;&#x8ba9;&#x4f7f;&#x7528;xml&#x6587;&#x6863;&#x7684;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x65e0;&#x6cd5;&#x77e5;&#x9053;xml&#x6587;&#x6863;&#x7684;&#x771f;&#x5b9e;&#x7ed3;&#x6784;&#x3002;&#x901a;&#x5e38;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x90fd;&#x4f1a;&#x8981;&#x6c42;xml&#x6587;&#x4ef6;&#x7684;&#x7ed3;&#x6784;&#x662f;&#x56fa;&#x5b9a;&#x7684;&#xff0c;&#x4ee5;&#x6ee1;&#x8db3;&#x81ea;&#x5df1;&#x7684;&#x9700;&#x6c42;&#xff0c;&#x8fd9;&#x5c31;&#x8bf4;&#x660e;&#xff0c;&#x4e0d;&#x540c;&#x7684;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x8981;&#x6c42;&#x81ea;&#x5df1;&#x7684;xml&#x6587;&#x6863;&#x5fc5;&#x987b;&#x7b26;&#x5408;&#x4e00;&#x5b9a;&#x7684;&#x8981;&#x6c42;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1522561710345" FOLDED="true" ID="ID_284678922" MODIFIED="1522566933944">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20998;&#31867;
    </p>
  </body>
</html>
</richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522559598572" FOLDED="true" ID="ID_390228475" MODIFIED="1522566669473" TEXT="DTD">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522559605758" ID="ID_344425311" MODIFIED="1522561710380">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Document Type Definition &#25991;&#26723;&#31867;&#22411;&#23450;&#20041;,&#34920;&#31034;&#23450;&#20041;&#19968;&#20010;&#25991;&#26723;&#32467;&#26500;,&#22914;:
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522559983816" FOLDED="true" ID="ID_322153333" MODIFIED="1522566933944">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="para-title level-2" label-module="para-title">
      <h2 class="title-text">
        &#25991;&#26723;&#31867;&#22411;&#22768;&#26126;
      </h2>
    </div>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1522559845985" FOLDED="true" ID="ID_326671966" MODIFIED="1522561852765" TEXT="&#x5185;&#x90e8;&#x58f0;&#x660e;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1522560057677" FOLDED="true" ID="ID_1484527687" MODIFIED="1522566933943">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33539;&#20363;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1522559733583" ID="ID_1242734914" MODIFIED="1522559983836">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="container">
      <div class="line number1 index0 alt2">
        <code class="xml plain">&lt;?</code><code class="xml color1">xml&#160;&#160;version</code><code class="xml plain">=</code><code class="xml string">&quot;1.0&quot;</code><code class="xml plain">?&gt;</code>
      </div>
      <div class="line number2 index1 alt1">
        <code class="xml plain">&lt;!</code><code class="xml keyword">DOCTYPE</code>&#160;<code class="xml plain">note&#160;[</code>
      </div>
      <div class="line number3 index2 alt2">
        <code class="xml plain">&lt;!ELEMENT&#160;note&#160;(to,from,heading,body)&gt;</code>
      </div>
      <div class="line number4 index3 alt1">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">to&#160;(#PCDATA)&gt;</code>
      </div>
      <div class="line number5 index4 alt2">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">from&#160;(#PCDATA)&gt;</code>
      </div>
      <div class="line number6 index5 alt1">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">heading&#160;(#PCDATA)&gt;</code>
      </div>
      <div class="line number7 index6 alt2">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">body&#160;(#PCDATA)&gt;</code>
      </div>
      <div class="line number8 index7 alt1">
        <code class="xml plain">]&gt;</code>
      </div>
      <div class="line number9 index8 alt2">
        <code class="xml plain">&lt;</code><code class="xml keyword">note</code><code class="xml plain">&gt;</code>
      </div>
      <div class="line number10 index9 alt1">
        <code class="xml plain">&lt;</code><code class="xml keyword">to</code><code class="xml plain">&gt;Tove&lt;/</code><code class="xml keyword">to</code><code class="xml plain">&gt;</code>
      </div>
      <div class="line number11 index10 alt2">
        <code class="xml plain">&lt;</code><code class="xml keyword">from</code><code class="xml plain">&gt;Jani&lt;/</code><code class="xml keyword">from</code><code class="xml plain">&gt;</code>
      </div>
      <div class="line number12 index11 alt1">
        <code class="xml plain">&lt;</code><code class="xml keyword">heading</code><code class="xml plain">&gt;Reminder&lt;/</code><code class="xml keyword">heading</code><code class="xml plain">&gt;</code>
      </div>
      <div class="line number13 index12 alt2">
        <code class="xml plain">&lt;</code><code class="xml keyword">body</code><code class="xml plain">&gt;Don't&#160;forget&#160;me&#160;this&#160;weekend&lt;/</code><code class="xml keyword">body</code><code class="xml plain">&gt;</code>
      </div>
      <div class="line number14 index13 alt1">
        <code class="xml plain">&lt;/</code><code class="xml keyword">note</code><code class="xml plain">&gt;</code>
      </div>
    </div>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522559784035" FOLDED="true" ID="ID_510881094" MODIFIED="1522566933943" TEXT="&#x89e3;&#x91ca;: ">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1522559787566" ID="ID_342986816" MODIFIED="1522559862745" TEXT="!DOCTYPE note (&#x7b2c;&#x4e8c;&#x884c;)&#x5b9a;&#x4e49;&#x6b64;&#x6587;&#x6863;&#x662f; note &#x7c7b;&#x578b;&#x7684;&#x6587;&#x6863;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522559787573" ID="ID_564496353" MODIFIED="1522559862745" TEXT="!ELEMENT note (&#x7b2c;&#x4e09;&#x884c;)&#x5b9a;&#x4e49; note &#x5143;&#x7d20;&#x6709;&#x56db;&#x4e2a;&#x5143;&#x7d20;&#xff1a;&quot;to&#x3001;from&#x3001;heading,&#x3001;body&quot;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522559787579" ID="ID_599292147" MODIFIED="1522559862746" TEXT="!ELEMENT to (&#x7b2c;&#x56db;&#x884c;)&#x5b9a;&#x4e49; to &#x5143;&#x7d20;&#x4e3a; &quot;#PCDATA&quot; &#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522559787580" ID="ID_1818836240" MODIFIED="1522559862746" TEXT="!ELEMENT from (&#x7b2c;&#x4e94;&#x884c;)&#x5b9a;&#x4e49; from &#x5143;&#x7d20;&#x4e3a; &quot;#PCDATA&quot; &#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522559787581" ID="ID_833123637" MODIFIED="1522559862746" TEXT="!ELEMENT heading (&#x7b2c;&#x516d;&#x884c;)&#x5b9a;&#x4e49; heading &#x5143;&#x7d20;&#x4e3a; &quot;#PCDATA&quot; &#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522559787582" ID="ID_1902467404" MODIFIED="1522559862746" TEXT="!ELEMENT body (&#x7b2c;&#x4e03;&#x884c;)&#x5b9a;&#x4e49; body &#x5143;&#x7d20;&#x4e3a; &quot;#PCDATA&quot; &#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1522560064310" ID="ID_1420914730" MODIFIED="1522560135489" TEXT="&#x6587;&#x6863;&#x7684;&#x5b9a;&#x4e49;&#x548c;&#x5bf9;&#x8be5;&#x6587;&#x6863;&#x7684;&#x4f7f;&#x7528;&#x653e;&#x5728;&#x4e00;&#x4e2a;xml&#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1522559870148" FOLDED="true" ID="ID_19502225" MODIFIED="1522561497790" TEXT="&#x5916;&#x90e8;&#x58f0;&#x660e;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1522560087529" ID="ID_1045173574" MODIFIED="1522560108526" TEXT="&#x6587;&#x6863;&#x7684;&#x4f7f;&#x7528;&#x548c;&#x5b9a;&#x4e49;&#x5206;&#x5f00;"/>
<node COLOR="#111111" CREATED="1522560376483" FOLDED="true" ID="ID_1805294504" MODIFIED="1522566933944">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33539;&#20363;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1522560339748" FOLDED="true" ID="ID_1276155156" MODIFIED="1522566933944">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      dtd&#25991;&#26723;&#23450;&#20041;&#30340;&#20869;&#23481;: note.dtd&#25991;&#20214;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1522560358893" ID="ID_242596223" MODIFIED="1522560361102">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="container">
      <div class="line number1 index0 alt2">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">note&#160;(to,from,heading,body)&gt;</code>
      </div>
      <div class="line number2 index1 alt1">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">to&#160;(#PCDATA)&gt;</code>
      </div>
      <div class="line number3 index2 alt2">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">from&#160;(#PCDATA)&gt;</code>
      </div>
      <div class="line number4 index3 alt1">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">heading&#160;(#PCDATA)&gt;</code>
      </div>
      <div class="line number5 index4 alt2">
        <code class="xml plain">&lt;!</code><code class="xml keyword">ELEMENT</code>&#160;<code class="xml plain">body&#160;(#PCDATA)&gt;</code>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1522560325020" FOLDED="true" ID="ID_1088791839" MODIFIED="1522566933944" TEXT="&#x4f7f;&#x7528;&#x7684;&#x5730;&#x65b9;">
<node COLOR="#111111" CREATED="1522560331819" ID="ID_944658766" MODIFIED="1522560417660">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="line number1 index0 alt2">
      <code class="xml plain">&lt;?</code><code class="xml color1">xmlversion</code><code class="xml plain">=</code><code class="xml string">&quot;1.0&quot;</code><code class="xml plain">?&gt;</code>
    </div>
    <div class="line number2 index1 alt1">
      <code class="xml plain">&lt;!</code><code class="xml keyword">DOCTYPE</code>&#160;<code class="xml plain">note&#160;SYSTEM&quot;note.dtd&quot;&gt; </code>
    </div>
    <div class="line number3 index2 alt2">
      <code class="xml plain">&lt;</code><code class="xml keyword">note</code><code class="xml plain">&gt;</code>
    </div>
    <div class="line number4 index3 alt1">
      <code class="xml plain">&lt;</code><code class="xml keyword">to</code><code class="xml plain">&gt;Tove&lt;/</code><code class="xml keyword">to</code><code class="xml plain">&gt;</code>
    </div>
    <div class="line number5 index4 alt2">
      <code class="xml plain">&lt;</code><code class="xml keyword">from</code><code class="xml plain">&gt;Jani&lt;/</code><code class="xml keyword">from</code><code class="xml plain">&gt;</code>
    </div>
    <div class="line number6 index5 alt1">
      <code class="xml plain">&lt;</code><code class="xml keyword">heading</code><code class="xml plain">&gt;Reminder&lt;/</code><code class="xml keyword">heading</code><code class="xml plain">&gt;</code>
    </div>
    <div class="line number7 index6 alt2">
      <code class="xml plain">&lt;</code><code class="xml keyword">body</code><code class="xml plain">&gt;Don't&#160;forget&#160;me&#160;this&#160;weekend!&lt;/</code><code class="xml keyword">body</code><code class="xml plain">&gt;</code>
    </div>
    <div class="line number8 index7 alt1">
      <code class="xml plain">&lt;/</code><code class="xml keyword">note</code><code class="xml plain">&gt;</code>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1522561856351" FOLDED="true" ID="ID_698023422" MODIFIED="1522566933944" TEXT="&#x8bed;&#x6cd5;">
<node COLOR="#111111" CREATED="1522561861299" FOLDED="true" ID="ID_496193307" MODIFIED="1522561888627" TEXT="&#x5b50;&#x5143;&#x7d20;&#x51fa;&#x73b0;&#x6b21;&#x6570;">
<node COLOR="#111111" CREATED="1522561865795" ID="ID_976553553" MODIFIED="1522561865795" TEXT="&#x53ef;&#x4ee5;&#x4f7f;&#x7528;&#x201c;?&#x201d;&#x3001;&#x201c;*&#x201d;&#x3001;&#x201c;+&#x201d;&#x6765;&#x6307;&#x5b9a;&#x5b50;&#x5143;&#x7d20;&#x7684;&#x51fa;&#x73b0;&#x6b21;&#x6570;"/>
<node COLOR="#111111" CREATED="1522561865802" ID="ID_1577945958" MODIFIED="1522561865802" TEXT="&lt;!ELEMENT stu (name?)&gt;&#x8868;&#x793a;stu&#x5143;&#x7d20;&#x53ef;&#x4ee5;&#x6709;0~1&#x4e2a;name&#x5b50;&#x5143;&#x7d20;&#xff0c;&#x5373;name&#x5b50;&#x5143;&#x7d20;&#x53ef;&#x6709;&#x53ef;&#x65e0;&#x3002;"/>
<node COLOR="#111111" CREATED="1522561865807" ID="ID_694377982" MODIFIED="1522561865807" TEXT="&lt;!ELEMENT stu(name*)&gt;&#x8868;&#x793a;stu&#x5143;&#x7d20;&#x53ef;&#x4ee5;&#x6709;0~n&#x4e2a;name&#x5b50;&#x5143;&#x7d20;&#xff1b;"/>
<node COLOR="#111111" CREATED="1522561865812" ID="ID_1468998340" MODIFIED="1522561865812" TEXT="&lt;!ELEMENT stu(name+)&gt;&#x8868;&#x793a;stu&#x5143;&#x7d20;&#x53ef;&#x4ee5;&#x6709;1~n&#x4e2a;name&#x5b50;&#x5143;&#x7d20;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1522561878326" FOLDED="true" ID="ID_57826372" MODIFIED="1522566933944" TEXT="&#x5143;&#x7d20;&#x5185;&#x5bb9;">
<node COLOR="#111111" CREATED="1522561890746" ID="ID_1165916686" MODIFIED="1522561890747" TEXT="&#x5143;&#x7d20;&#x5185;&#x5bb9;&#x53ef;&#x4ee5;&#x662f;&#x6587;&#x672c;&#x6570;&#x636e;&#xff0c;&#x4e5f;&#x53ef;&#x4ee5;&#x662f;&#x5b50;&#x5143;&#x7d20;"/>
<node COLOR="#111111" CREATED="1522561890748" ID="ID_1412349496" MODIFIED="1522561890748" TEXT="&lt;!ELEMENT stu (#PCDATA)&gt;&#x8868;&#x793a;stu&#x5143;&#x7d20;&#x5185;&#x5bb9;&#x4e3a;&#x6587;&#x672c;&#xff0c;&#x4f8b;&#x5982;&#xff1a;&lt;stu&gt;hello&lt;/stu&gt;"/>
</node>
<node COLOR="#111111" CREATED="1522561902733" FOLDED="true" ID="ID_1834898830" MODIFIED="1522566933944" TEXT="&#x591a;&#x4e2a;&#x5b50;&#x5143;&#x7d20;">
<node COLOR="#111111" CREATED="1522561908019" ID="ID_1348427140" MODIFIED="1522561908019" TEXT="&lt;!ELEMENT stu (name,age,sex)&gt;&#x8868;&#x793a;stu&#x5fc5;&#x987b;&#x6709;&#x4e09;&#x4e2a;&#x5b50;&#x5143;&#x7d20;&#xff0c;&#x5206;&#x522b;&#x662f;name&#x3001;age&#x3001;sex&#xff0c;&#x5e76;&#x4e14;&#x5b50;&#x5143;&#x7d20;&#x51fa;&#x73b0;&#x7684;&#x987a;&#x5e8f;&#x4e5f;&#x8981;&#x4e0e;&#x58f0;&#x660e;&#x7684;&#x987a;&#x5e8f;&#x4e00;&#x81f4;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1522562047066" FOLDED="true" ID="ID_849525381" MODIFIED="1522566933944" TEXT="DTD &#x7684;&#x5c40;&#x9650;&#x6027;">
<node COLOR="#111111" CREATED="1522562053912" ID="ID_229724933" MODIFIED="1522562053913" TEXT="DTD&#x4e0d;&#x9075;&#x5b88;XML&#x8bed;&#x6cd5;&#xff08;&#x5199;XML&#x6587;&#x6863;&#x5b9e;&#x4f8b;&#x65f6;&#x5019;&#x7528;&#x4e00;&#x79cd;&#x8bed;&#x6cd5;&#xff0c;&#x5199;DTD&#x7684;&#x65f6;&#x5019;&#x7528;&#x53e6;&#x5916;&#x4e00;&#x79cd;&#x8bed;&#x6cd5;&#xff09;"/>
<node COLOR="#111111" CREATED="1522562053939" ID="ID_257843346" MODIFIED="1522562053940" TEXT="DTD&#x6570;&#x636e;&#x7c7b;&#x578b;&#x6709;&#x9650;&#xff08;&#x4e0e;&#x6570;&#x636e;&#x5e93;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x4e0d;&#x4e00;&#x81f4;&#xff09;"/>
<node COLOR="#111111" CREATED="1522562053941" ID="ID_575419338" MODIFIED="1522562053941" TEXT="DTD&#x4e0d;&#x53ef;&#x6269;&#x5c55;"/>
<node COLOR="#111111" CREATED="1522562053942" ID="ID_987192519" MODIFIED="1522562053942" TEXT="DTD&#x4e0d;&#x652f;&#x6301;&#x547d;&#x540d;&#x7a7a;&#x95f4;&#xff08;&#x547d;&#x540d;&#x51b2;&#x7a81;&#xff09;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1522561512520" FOLDED="true" ID="ID_892747614" MODIFIED="1522566667388" TEXT="schema">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522562110561" ID="ID_1207590640" MODIFIED="1522562110869" TEXT="XSDL&#xff08;XML Schema&#x5b9a;&#x4e49;&#x8bed;&#x8a00;&#xff09;&#x7531;&#x5143;&#x7d20;&#x3001;&#x5c5e;&#x6027;&#x3001;&#x547d;&#x540d;&#x7a7a;&#x95f4;&#x548c;XML&#x6587;&#x6863;&#x79cd;&#x7684;&#x5176;&#x4ed6;&#x8282;&#x70b9;&#x6784;&#x6210;&#x7684;&#x3002;"/>
<node COLOR="#111111" CREATED="1522562202453" ID="ID_1970287474" MODIFIED="1522562202793" TEXT="XML Schema&#x4e5f;&#x662f;&#x4e00;&#x79cd;&#x7528;&#x4e8e;&#x5b9a;&#x4e49;&#x548c;&#x63cf;&#x8ff0;XML&#x6587;&#x6863;&#x7ed3;&#x6784;&#x4e0e;&#x5185;&#x5bb9;&#x7684;&#x6a21;&#x5f0f;&#x8bed;&#x8a00;&#xff0c;&#x5176;&#x51fa;&#x73b0;&#x662f;&#x4e3a;&#x4e86;&#x514b;&#x670d;DTD&#x7684;&#x5c40;&#x9650;&#x6027; "/>
<node COLOR="#111111" CREATED="1522561596798" FOLDED="true" ID="ID_560377869" MODIFIED="1522562113100">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35268;&#21017;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1522561553145" ID="ID_527862966" MODIFIED="1522561596822" TEXT="XML Schema&#x7b26;&#x5408;XML&#x8bed;&#x6cd5;&#x7ed3;&#x6784;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522561553149" ID="ID_861730803" MODIFIED="1522561596835" TEXT="&#x3000;&#x3000;DOM&#x3001;SAX&#x7b49;XML API&#x5f88;&#x5bb9;&#x6613;&#x89e3;&#x6790;&#x51fa;XML Schema&#x6587;&#x6863;&#x4e2d;&#x7684;&#x5185;&#x5bb9;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522561553156" ID="ID_1367418302" MODIFIED="1522561596841" TEXT="&#x3000;&#x3000;&#x4e00;&#x4e2a;XML&#x4e2d;&#x4e2a;&#x53ef;&#x4ee5;&#x6709;&#x591a;&#x4e2a;schema&#xff0c;&#x591a;&#x4e2a;Schema&#x4f7f;&#x7528;&#x540d;&#x79f0;&#x7a7a;&#x95f4;&#xff08;&#x7c7b;&#x4f3c;&#x4e8e;Java&#x7684;&#x5305;&#x540d;&#xff09;&#x8fdb;&#x884c;&#x533a;&#x5206;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522561553174" ID="ID_60373273" MODIFIED="1522561596849" TEXT="&#x3000;&#x3000;XML Schema&#x6bd4;XML DTD&#x652f;&#x6301;&#x66f4;&#x591a;&#x7684;&#x6570;&#x636e;&#x7c7b;&#x578b;&#xff0c;&#x5e76;&#x652f;&#x6301;&#x7528;&#x6237;&#x81ea;&#x5b9a;&#x4e49;&#x65b0;&#x7684;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522561553186" ID="ID_1849552383" MODIFIED="1522561596854" TEXT="&#x3000;&#x3000;XML Schema&#x5b9a;&#x4e49;&#x7ea6;&#x675f;&#x7684;&#x80fd;&#x529b;&#x975e;&#x5e38;&#x5f3a;&#x5927;&#xff0c;&#x53ef;&#x4ee5;&#x5bf9;XML&#x5b9e;&#x4f8b;&#x6587;&#x6863;&#x505a;&#x51fa;&#x7ec6;&#x81f4;&#x7684;&#x8bed;&#x4e49;&#x9650;&#x5236;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522561553207" ID="ID_752555936" MODIFIED="1522561596860" TEXT="&#x3000;&#x3000;XML Schema&#x4e0d;&#x80fd;&#x50cf;DTD&#x4e00;&#x6837;&#x5b9a;&#x4e49;&#x5b9e;&#x4f53;&#xff0c;&#x6bd4;DTD&#x66f4;&#x590d;&#x6742;&#xff0c;&#x4f46;XML Schema&#x73b0;&#x5728;&#x5df2;&#x7ecf;&#x662f;w3c&#x7ec4;&#x7ec7;&#x7684;&#x6807;&#x51c6;&#xff0c;&#x6b63;&#x9010;&#x6b65;&#x53d6;&#x4ee3;DTD">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1522561553237" ID="ID_326445053" MODIFIED="1522561596866" TEXT="&#x540e;&#x7f00;&#x540d;&#x4e3a;&#xff1a;*.xsd&#xff0c;&#x5fc5;&#x987b;&#x6709;&#x4e00;&#x4e2a;&lt;schema&gt;&#x6839;&#x8282;&#x70b9;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1522562114495" FOLDED="true" ID="ID_591997343" MODIFIED="1522566933944" TEXT="&#x7ed3;&#x6784;">
<node COLOR="#111111" CREATED="1522562213744" FOLDED="true" ID="ID_1234543228" MODIFIED="1522566933944">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26681;&#20803;&#32032;
    </p>
  </body>
</html>
</richcontent>
<node COLOR="#111111" CREATED="1522562227525" ID="ID_110576119" MODIFIED="1522562229773">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;xsd:schema xmlns:xsd=&#8220;http://www.w3.org/2001/XMLSchema&#8221;&gt;
    </p>
    <p>
      &#8230;
    </p>
    <p>
      &lt;/xsd:schema&gt;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1522562241179" FOLDED="true" ID="ID_1656051662" MODIFIED="1522566933944" TEXT="&#x5143;&#x7d20;">
<node COLOR="#111111" CREATED="1522562275446" ID="ID_1879592956" MODIFIED="1522562289081" TEXT="&lt;xsd:element name=&#x201d;&#x81ea;&#x5b9a;&#x4e49;&#x201d; type=&#x201d;xsd:&#x6570;&#x636e;&#x7c7b;&#x578b;&#x201d; /&gt;"/>
<node COLOR="#111111" CREATED="1522562333626" FOLDED="true" ID="ID_456398466" MODIFIED="1522566933944" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1522562346907" ID="ID_1838626248" MODIFIED="1522562363764">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &lt;xsd:schema xmlns:xsd=&#8220;http://www.w3.org/2001/XMLSchema&#8221;&gt;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&lt;xsd:element name=&#8221;userName&#8221; type=&#8221;xsd:string&#8221; /&gt;
    </p>
    <p>
      &lt;/xsd:schema&gt;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522560529766" FOLDED="true" ID="ID_1727706665" MODIFIED="1522561489030" POSITION="right" TEXT="CDATA&#x548c;PCDATA">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1522560564004" FOLDED="true" ID="ID_959532168" MODIFIED="1522561243630" TEXT="CDATA">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522560570101" ID="ID_433005499" MODIFIED="1522560570102" TEXT="&#x672f;&#x8bed; CDATA &#x6307;&#x7684;&#x662f;&#x4e0d;&#x5e94;&#x7531; XML &#x89e3;&#x6790;&#x5668;&#x8fdb;&#x884c;&#x89e3;&#x6790;&#x7684;&#x6587;&#x672c;&#x6570;&#x636e;&#xff08;Unparsed Character Data&#xff09;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522560625880" ID="ID_1330003886" MODIFIED="1522560625880" TEXT="CDATA &#x90e8;&#x5206;&#x4e2d;&#x7684;&#x6240;&#x6709;&#x5185;&#x5bb9;&#x90fd;&#x4f1a;&#x88ab;&#x89e3;&#x6790;&#x5668;&#x5ffd;&#x7565;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522561118095" FOLDED="true" ID="ID_912768576" MODIFIED="1522561241772" TEXT="CDATA &#x90e8;&#x5206;&#x7531;    &quot;&lt;![CDATA[&quot;    &#x5f00;&#x59cb;&#xff0c;&#x7531;   &quot;]]&gt;&quot;   &#x7ed3;&#x675f;&#xff1a;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522561210351" ID="ID_469399571" MODIFIED="1522561239182">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="white-space: pre-wrap">&lt;script&gt;
&lt;![CDATA[
function match(a,b)
{
if (a &lt; b &amp;&amp; a &lt; 0) 
  {
  return 1;
  }
else
  {
  return 0;
  }
}
]]&gt;
&lt;/script&gt;</pre>
  </body>
</html>
</richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1522561146766" FOLDED="true" ID="ID_1591773979" MODIFIED="1522566933945" TEXT="CDATA &#x90e8;&#x5206;&#x7684;&#x6ce8;&#x91ca;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1522561154267" ID="ID_1514719438" MODIFIED="1522561154267" TEXT="CDATA &#x90e8;&#x5206;&#x4e0d;&#x80fd;&#x5305;&#x542b;&#x5b57;&#x7b26;&#x4e32; &quot;]]&gt;&quot;&#x3002;&#x4e5f;&#x4e0d;&#x5141;&#x8bb8;&#x5d4c;&#x5957;&#x7684; CDATA &#x90e8;&#x5206;&#x3002;"/>
<node COLOR="#111111" CREATED="1522561163254" ID="ID_577559847" MODIFIED="1522561163254" TEXT="&#x6807;&#x8bb0; CDATA &#x90e8;&#x5206;&#x7ed3;&#x5c3e;&#x7684; &quot;]]&gt;&quot; &#x4e0d;&#x80fd;&#x5305;&#x542b;&#x7a7a;&#x683c;&#x6216;&#x6298;&#x884c;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1522560609770" FOLDED="true" ID="ID_1371095980" MODIFIED="1522566933945" TEXT="PCDATA">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1522561254847" ID="ID_211289568" MODIFIED="1522561254847" TEXT="PCDATA &#x6307;&#x7684;&#x662f;&#x88ab;&#x89e3;&#x6790;&#x7684;&#x5b57;&#x7b26;&#x6570;&#x636e;&#xff08;Parsed Character Data&#xff09;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522561262799" ID="ID_1069740253" MODIFIED="1522561262800" TEXT="XML &#x89e3;&#x6790;&#x5668;&#x901a;&#x5e38;&#x4f1a;&#x89e3;&#x6790; XML &#x6587;&#x6863;&#x4e2d;&#x6240;&#x6709;&#x7684;&#x6587;&#x672c;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522561262803" ID="ID_589265219" MODIFIED="1522561262803" TEXT="&#x5f53;&#x67d0;&#x4e2a; XML &#x5143;&#x7d20;&#x88ab;&#x89e3;&#x6790;&#x65f6;&#xff0c;&#x5176;&#x6807;&#x7b7e;&#x4e4b;&#x95f4;&#x7684;&#x6587;&#x672c;&#x4e5f;&#x4f1a;&#x88ab;&#x89e3;&#x6790;&#xff1a;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1522561268271" ID="ID_546014337" MODIFIED="1522561268271" TEXT="&lt;message&gt;&#x6b64;&#x6587;&#x672c;&#x4e5f;&#x4f1a;&#x88ab;&#x89e3;&#x6790;&lt;/message&gt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1522566761074" FOLDED="true" ID="ID_1244071024" MODIFIED="1522566922926" POSITION="right" TEXT="&#x89e3;&#x6790;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1475455252490" FOLDED="true" ID="ID_1458987641" MODIFIED="1522566933945" TEXT="Dom">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1475455637166" FOLDED="true" ID="ID_1596107139" MODIFIED="1522566771861" TEXT="&#x7279;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455265543" ID="ID_1441315000" MODIFIED="1475455278122" TEXT="&#x52a0;&#x8f7d;&#x6574;&#x4e2a;&#x6587;&#x6863;&#x6811;&#x5230;&#x5185;&#x5b58;&#x4e2d;"/>
<node COLOR="#111111" CREATED="1475455278507" ID="ID_1212642177" MODIFIED="1475455282529" TEXT="&#x975e;&#x5e38;&#x8017;&#x8d39;&#x5185;&#x5b58;"/>
<node COLOR="#111111" CREATED="1475455482189" ID="ID_817948610" MODIFIED="1475455482189" TEXT="DOM&#x89e3;&#x6790;&#x5668;&#x5e38;&#x7528;&#x4e8e;XML&#x6587;&#x6863;&#x9700;&#x8981;&#x9891;&#x7e41;&#x7684;&#x6539;&#x53d8;&#x7684;&#x670d;&#x52a1;&#x4e2d;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475455631246" FOLDED="true" ID="ID_13584926" MODIFIED="1522566766894" TEXT="&#x4f18;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455661960" ID="ID_374097413" MODIFIED="1475455661960" TEXT="&#x2460;&#x5141;&#x8bb8;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x5bf9;&#x6570;&#x636e;&#x548c;&#x7ed3;&#x6784;&#x505a;&#x51fa;&#x66f4;&#x6539;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455661961" ID="ID_1738742114" MODIFIED="1475455661961" TEXT="&#x2461;&#x8bbf;&#x95ee;&#x662f;&#x53cc;&#x5411;&#x7684;&#xff0c;&#x53ef;&#x4ee5;&#x5728;&#x4efb;&#x4f55;&#x65f6;&#x5019;&#x5728;&#x6811;&#x4e2d;&#x4e0a;&#x4e0b;&#x5bfc;&#x822a;&#xff0c;&#x83b7;&#x53d6;&#x548c;&#x64cd;&#x4f5c;&#x4efb;&#x610f;&#x90e8;&#x5206;&#x7684;&#x6570;&#x636e;&#xff08;&#x589e;&#x5220;&#x6539;&#x67e5;&#x7684;&#x64cd;&#x4f5c;&#x6bd4;&#x8f83;&#x5bb9;&#x6613;&#xff09;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475455680523" FOLDED="true" ID="ID_1957569322" MODIFIED="1522566766894" TEXT="&#x7f3a;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455688519" ID="ID_563910924" MODIFIED="1475455688520" TEXT="&#x2460;&#x901a;&#x5e38;&#x9700;&#x8981;&#x52a0;&#x8f7d;&#x6574;&#x4e2a;XML&#x6587;&#x6863;&#x6765;&#x6784;&#x9020;&#x5c42;&#x6b21;&#x7ed3;&#x6784;&#xff0c;&#x9700;&#x8981;&#x5c06;&#x6574;&#x4e2a;xml&#x6587;&#x6863;&#x5148;&#x62f7;&#x8d1d;&#x5230;&#x5185;&#x5b58;&#x4e2d;&#xff0c;&#x5982;&#x679c;xml&#x6587;&#x4ef6;&#x8f83;&#x5927;&#x7684;&#x8bdd;&#xff0c;&#x6d88;&#x8017;&#x8d44;&#x6e90;&#x662f;&#x5f88;&#x5927;        &#x7684;&#xff0c;&#x8fd9;&#x4e2a;&#x5bf9;&#x4e8e;Android&#x6765;&#x8bf4;&#x771f;&#x662f;&#x4e2a;&#x5669;&#x68a6;&#x5440;&#xff0c;&#x56e0;&#x4e3a;&#x6709;OOM&#x7684;&#x6050;&#x60e7;&#xff01;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1475455881712" FOLDED="true" ID="ID_429226049" MODIFIED="1522566933945" TEXT="JDOM(Java-based Document Object Model)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1475455971220" FOLDED="true" ID="ID_343258397" MODIFIED="1522566933945" TEXT="&#x7279;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455897860" ID="ID_1889689259" MODIFIED="1475455897861" TEXT="JDOM&#x7684;&#x76ee;&#x7684;&#x662f;&#x6210;&#x4e3a;Java&#x7279;&#x5b9a;&#x6587;&#x6863;&#x6a21;&#x578b;&#xff0c;&#x5b83;&#x7b80;&#x5316;&#x4e0e;XML&#x7684;&#x4ea4;&#x4e92;&#x5e76;&#x4e14;&#x6bd4;&#x4f7f;&#x7528;DOM&#x5b9e;&#x73b0;&#x66f4;&#x5feb;&#x3002;&#x7531;&#x4e8e;&#x662f;&#x7b2c;&#x4e00;&#x4e2a;Java&#x7279;&#x5b9a;&#x6a21;&#x578b;&#xff0c;JDOM&#x4e00;&#x76f4;&#x5f97;&#x5230;&#x5927;&#x529b;&#x63a8;&#x5e7f;&#x548c;&#x4fc3;&#x8fdb;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455903780" FOLDED="true" ID="ID_1313793118" MODIFIED="1522566933945" TEXT="JDOM&#x4e0e;DOM&#x4e3b;&#x8981;&#x6709;&#x4e24;&#x65b9;&#x9762;&#x4e0d;&#x540c;">
<node COLOR="#111111" CREATED="1475455915448" ID="ID_1273549716" MODIFIED="1475455922631" TEXT="&#x9996;&#x5148;&#xff0c;JDOM&#x4ec5;&#x4f7f;&#x7528;&#x5177;&#x4f53;&#x7c7b;&#x800c;&#x4e0d;&#x4f7f;&#x7528;&#x63a5;&#x53e3;&#x3002;&#x8fd9;&#x5728;&#x67d0;&#x4e9b;&#x65b9;&#x9762;&#x7b80;&#x5316;&#x4e86;API&#xff0c;&#x4f46;&#x662f;&#x4e5f;&#x9650;&#x5236;&#x4e86;&#x7075;&#x6d3b;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455923756" ID="ID_1863369520" MODIFIED="1475455923756" TEXT="&#x7b2c;&#x4e8c;&#xff0c;API&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;Collections&#x7c7b;&#xff0c;&#x7b80;&#x5316;&#x4e86;&#x90a3;&#x4e9b;&#x5df2;&#x7ecf;&#x719f;&#x6089;&#x8fd9;&#x4e9b;&#x7c7b;&#x7684;Java&#x5f00;&#x53d1;&#x8005;&#x7684;&#x4f7f;&#x7528;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1475455940472" ID="ID_232292463" MODIFIED="1475455940474" TEXT="JDOM&#x81ea;&#x8eab;&#x4e0d;&#x5305;&#x542b;&#x89e3;&#x6790;&#x5668;&#x3002;&#x5b83;&#x901a;&#x5e38;&#x4f7f;&#x7528;SAX2&#x89e3;&#x6790;&#x5668;&#x6765;&#x89e3;&#x6790;&#x548c;&#x9a8c;&#x8bc1;&#x8f93;&#x5165;XML&#x6587;&#x6863;&#xff08;&#x5c3d;&#x7ba1;&#x5b83;&#x8fd8;&#x53ef;&#x4ee5;&#x5c06;&#x4ee5;&#x524d;&#x6784;&#x9020;&#x7684;DOM&#x8868;&#x793a;&#x4f5c;&#x4e3a;&#x8f93;&#x5165;&#xff09;&#x3002;&#x5b83;&#x5305;&#x542b;&#x4e00;&#x4e9b;&#x8f6c;&#x6362;&#x5668;&#x4ee5;&#x5c06;JDOM&#x8868;&#x793a;&#x8f93;&#x51fa;&#x6210;SAX2&#x4e8b;&#x4ef6;&#x6d41;&#x3001;DOM&#x6a21;&#x578b;&#x6216;XML&#x6587;&#x672c;&#x6587;&#x6863;&#x3002;JDOM&#x662f;&#x5728;Apache&#x8bb8;&#x53ef;&#x8bc1;&#x53d8;&#x4f53;&#x4e0b;&#x53d1;&#x5e03;&#x7684;&#x5f00;&#x653e;&#x6e90;&#x7801;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475455961426" FOLDED="true" ID="ID_684155745" MODIFIED="1522566933945" TEXT="&#x3010;&#x4f18;&#x70b9;&#x3011;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455961428" ID="ID_231393196" MODIFIED="1475455961428" TEXT="&#x2460;&#x4f7f;&#x7528;&#x5177;&#x4f53;&#x7c7b;&#x800c;&#x4e0d;&#x662f;&#x63a5;&#x53e3;&#xff0c;&#x7b80;&#x5316;&#x4e86;DOM&#x7684;API&#x3002;"/>
<node COLOR="#111111" CREATED="1475455961429" ID="ID_1336915696" MODIFIED="1475455961429" TEXT="&#x2461;&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;Java&#x96c6;&#x5408;&#x7c7b;&#xff0c;&#x65b9;&#x4fbf;&#x4e86;Java&#x5f00;&#x53d1;&#x4eba;&#x5458;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475455961434" FOLDED="true" ID="ID_1918140215" MODIFIED="1522566766907" TEXT="&#x3010;&#x7f3a;&#x70b9;&#x3011;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455961435" ID="ID_229291248" MODIFIED="1475455961435" TEXT="&#x2460;&#x6ca1;&#x6709;&#x8f83;&#x597d;&#x7684;&#x7075;&#x6d3b;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455961436" ID="ID_1966113509" MODIFIED="1475455961437" TEXT="&#x2461;&#x6027;&#x80fd;&#x8f83;&#x5dee;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1475456132171" FOLDED="true" ID="ID_522350125" MODIFIED="1522566791603" TEXT="DOM4J(Document Object Model for Java)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1475456279231" FOLDED="true" ID="ID_1007260771" MODIFIED="1522566933945" TEXT="&#x7279;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475456281784" ID="ID_1673815015" MODIFIED="1475456281784" TEXT="DOM4J&#x4f7f;&#x7528;&#x63a5;&#x53e3;&#x548c;&#x62bd;&#x8c61;&#x57fa;&#x672c;&#x7c7b;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1475456288843" ID="ID_510446781" MODIFIED="1475456288844" TEXT="DOM4J&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;API&#x4e2d;&#x7684;Collections&#x7c7b;&#xff0c;&#x4f46;&#x662f;&#x5728;&#x8bb8;&#x591a;&#x60c5;&#x51b5;&#x4e0b;&#xff0c;&#x5b83;&#x8fd8;&#x63d0;&#x4f9b;&#x4e00;&#x4e9b;&#x66ff;&#x4ee3;&#x65b9;&#x6cd5;&#x4ee5;&#x5141;&#x8bb8;&#x66f4;&#x597d;&#x7684;&#x6027;&#x80fd;&#x6216;&#x66f4;&#x76f4;&#x63a5;&#x7684;&#x7f16;&#x7801;&#x65b9;&#x6cd5;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456293320" ID="ID_259119446" MODIFIED="1475456293320" TEXT="&#x76f4;&#x63a5;&#x597d;&#x5904;&#x662f;&#xff0c;&#x867d;&#x7136;DOM4J&#x4ed8;&#x51fa;&#x4e86;&#x66f4;&#x590d;&#x6742;&#x7684;API&#x7684;&#x4ee3;&#x4ef7;&#xff0c;&#x4f46;&#x662f;&#x5b83;&#x63d0;&#x4f9b;&#x4e86;&#x6bd4;JDOM&#x5927;&#x5f97;&#x591a;&#x7684;&#x7075;&#x6d3b;&#x6027;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456301864" ID="ID_1171180701" MODIFIED="1475456301864" TEXT="&#x9488;&#x5bf9;Java&#x5f00;&#x53d1;&#x8005;&#x7684;&#x6613;&#x7528;&#x6027;&#x548c;&#x76f4;&#x89c2;&#x64cd;&#x4f5c;"/>
<node COLOR="#111111" CREATED="1475456315182" ID="ID_1769394429" MODIFIED="1475456315182" TEXT="&#x6027;&#x80fd;&#x4f18;&#x5f02;&#x3001;&#x529f;&#x80fd;&#x5f3a;&#x5927;&#x548c;&#x6781;&#x7aef;&#x6613;&#x7528;&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#990000" CREATED="1475456340907" FOLDED="true" ID="ID_1306631359" MODIFIED="1522566766910" TEXT="&#x3010;&#x4f18;&#x70b9;&#x3011;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475456340908" ID="ID_1053035929" MODIFIED="1475456340909" TEXT="&#x2460;&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;Java&#x96c6;&#x5408;&#x7c7b;&#xff0c;&#x65b9;&#x4fbf;Java&#x5f00;&#x53d1;&#x4eba;&#x5458;&#xff0c;&#x540c;&#x65f6;&#x63d0;&#x4f9b;&#x4e00;&#x4e9b;&#x63d0;&#x9ad8;&#x6027;&#x80fd;&#x7684;&#x66ff;&#x4ee3;&#x65b9;&#x6cd5;&#x3002;"/>
<node COLOR="#111111" CREATED="1475456340910" ID="ID_724667680" MODIFIED="1475456340910" TEXT="&#x2461;&#x652f;&#x6301;XPath&#x3002;"/>
<node COLOR="#111111" CREATED="1475456340912" ID="ID_555153337" MODIFIED="1475456340912" TEXT="&#x2462;&#x6709;&#x5f88;&#x597d;&#x7684;&#x6027;&#x80fd;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475456340914" FOLDED="true" ID="ID_418049357" MODIFIED="1522566766911" TEXT="&#x3010;&#x7f3a;&#x70b9;&#x3011;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475456340916" ID="ID_696706490" MODIFIED="1475456340916" TEXT="&#x2460;&#x5927;&#x91cf;&#x4f7f;&#x7528;&#x4e86;&#x63a5;&#x53e3;&#xff0c;API&#x8f83;&#x4e3a;&#x590d;&#x6742;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1475455283828" FOLDED="true" ID="ID_1105730063" MODIFIED="1522566920224" TEXT="SAX&#xff08;Simple API for XML)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1475455312497" FOLDED="true" ID="ID_1684694345" MODIFIED="1522566933945" TEXT="&#x7279;&#x70b9;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455520547" ID="ID_1927407012" MODIFIED="1475455756558" TEXT="SAX&#x5bf9;&#x5185;&#x5b58;&#x7684;&#x8981;&#x6c42;&#x901a;&#x5e38;&#x4f1a;&#x6bd4;&#x8f83;&#x4f4e;&#xff0c;"/>
<node COLOR="#111111" CREATED="1475455734075" ID="ID_888383028" MODIFIED="1475455765349" TEXT="&#x5206;&#x6790;&#x80fd;&#x591f;&#x7acb;&#x5373;&#x5f00;&#x59cb;&#xff0c;&#x800c;&#x4e0d;&#x662f;&#x7b49;&#x5f85;&#x6240;&#x6709;&#x7684;&#x6570;&#x636e;&#x88ab;&#x5904;&#x7406;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455316669" ID="ID_43850009" MODIFIED="1475455744357" TEXT="SAX&#x5904;&#x7406;&#x7684;&#x4f18;&#x70b9;&#x975e;&#x5e38;&#x7c7b;&#x4f3c;&#x4e8e;&#x6d41;&#x5a92;&#x4f53;&#x7684;&#x4f18;&#x70b9;&#x3002;&#x4e8b;&#x5b9e;&#x4e0a;&#xff0c;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x751a;&#x81f3;&#x4e0d;&#x5fc5;&#x89e3;&#x6790;&#x6574;&#x4e2a;&#x6587;&#x6863;&#xff1b;&#x5b83;&#x53ef;&#x4ee5;&#x5728;&#x67d0;&#x4e2a;&#x6761;&#x4ef6;&#x5f97;&#x5230;&#x6ee1;&#x8db3;&#x65f6;&#x505c;&#x6b62;&#x89e3;&#x6790;&#x3002;&#x4e00;&#x822c;&#x6765;&#x8bf4;&#xff0c;SAX&#x8fd8;&#x6bd4;&#x5b83;&#x7684;&#x66ff;&#x4ee3;&#x8005;DOM&#x5feb;&#x8bb8;&#x591a;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455746084" ID="ID_1462401119" MODIFIED="1475455746084" TEXT="&#x800c;&#x4e14;&#xff0c;&#x7531;&#x4e8e;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x53ea;&#x662f;&#x5728;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#x65f6;&#x68c0;&#x67e5;&#x6570;&#x636e;&#xff0c;&#x56e0;&#x6b64;&#x4e0d;&#x9700;&#x8981;&#x5c06;&#x6570;&#x636e;&#x5b58;&#x50a8;&#x5728;&#x5185;&#x5b58;&#x4e2d;&#x3002;&#x8fd9;&#x5bf9;&#x4e8e;&#x5927;&#x578b;&#x6587;&#x6863;&#x6765;&#x8bf4;&#x662f;&#x4e2a;&#x5de8;&#x5927;&#x7684;&#x4f18;&#x70b9;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475455571261" FOLDED="true" ID="ID_325246949" MODIFIED="1522566933945" TEXT="&#x4f18;&#x52bf;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475455577072" ID="ID_1146195659" MODIFIED="1475455577072" TEXT="&#x2460;&#x4e0d;&#x9700;&#x8981;&#x7b49;&#x5f85;&#x6240;&#x6709;&#x6570;&#x636e;&#x90fd;&#x88ab;&#x5904;&#x7406;&#xff0c;&#x5206;&#x6790;&#x5c31;&#x80fd;&#x7acb;&#x5373;&#x5f00;&#x59cb;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455577072" ID="ID_660175869" MODIFIED="1475455577072" TEXT="&#x2461;&#x53ea;&#x5728;&#x8bfb;&#x53d6;&#x6570;&#x636e;&#x65f6;&#x68c0;&#x67e5;&#x6570;&#x636e;&#xff0c;&#x4e0d;&#x9700;&#x8981;&#x4fdd;&#x5b58;&#x5728;&#x5185;&#x5b58;&#x4e2d;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455577072" ID="ID_634862777" MODIFIED="1475455577072" TEXT="&#x2462;&#x53ef;&#x4ee5;&#x5728;&#x67d0;&#x4e2a;&#x6761;&#x4ef6;&#x5f97;&#x5230;&#x6ee1;&#x8db3;&#x65f6;&#x505c;&#x6b62;&#x89e3;&#x6790;&#xff0c;&#x4e0d;&#x5fc5;&#x89e3;&#x6790;&#x6574;&#x4e2a;&#x6587;&#x6863;&#x3002;"/>
<node COLOR="#111111" CREATED="1475455577072" ID="ID_4389442" MODIFIED="1475455577072" TEXT="&#x2463;&#x6548;&#x7387;&#x548c;&#x6027;&#x80fd;&#x8f83;&#x9ad8;&#xff0c;&#x80fd;&#x89e3;&#x6790;&#x5927;&#x4e8e;&#x7cfb;&#x7edf;&#x5185;&#x5b58;&#x7684;&#x6587;&#x6863;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1475460578176" FOLDED="true" ID="ID_1914887527" MODIFIED="1522566933945" TEXT="&#x4f7f;&#x7528;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1475460580959" ID="ID_576198971" LINK="Xml&#x89e3;&#x6790;/Sax&#x89e3;&#x6790;/test.xml" MODIFIED="1475464227788" TEXT="&#x88ab;&#x89e3;&#x6790;&#x7684;&#x6587;&#x4ef6;"/>
<node COLOR="#111111" CREATED="1475460585390" FOLDED="true" ID="ID_1668149420" MODIFIED="1522566822225" TEXT="&#x89e3;&#x6790;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475460676938" ID="ID_982956586" LINK="Xml&#x89e3;&#x6790;/Sax&#x89e3;&#x6790;/User.java" MODIFIED="1475460696973" TEXT="bean"/>
<node COLOR="#111111" CREATED="1475460911472" ID="ID_239030100" LINK="Xml&#x89e3;&#x6790;/Sax&#x89e3;&#x6790;/SaxHandler.java" MODIFIED="1475460921974" TEXT="SaxHandler"/>
</node>
<node COLOR="#111111" CREATED="1475460934733" FOLDED="true" ID="ID_1992845282" MODIFIED="1522566824053" TEXT="&#x6ce8;&#x610f;">
<node COLOR="#111111" CREATED="1475460951667" ID="ID_1569859347" MODIFIED="1475460988013" TEXT="DefaultHandler &#x7684;&#x88ab;&#x590d;&#x5199;&#x7684;&#x65b9;&#x6cd5;&#x4e0d;&#x80fd;&#x88ab;super"/>
<node COLOR="#111111" CREATED="1475460988713" ID="ID_829206997" MODIFIED="1475461019477" TEXT="mPreTag&#x9700;&#x8981;&#x8d4b;&#x503c;null"/>
</node>
<node COLOR="#111111" CREATED="1475462526604" FOLDED="true" ID="ID_503146182" MODIFIED="1520498536820" TEXT="&#x76f8;&#x5173;&#x7684;&#x7c7b;">
<node COLOR="#111111" CREATED="1475462531528" FOLDED="true" ID="ID_838378583" MODIFIED="1520498536816" TEXT="SAXParserFactory">
<node COLOR="#111111" CREATED="1475462652538" FOLDED="true" ID="ID_162795646" MODIFIED="1520498536816" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475462654249" ID="ID_246685273" MODIFIED="1475462654249" TEXT="SAXParserFactory.newInstance()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475462559976" FOLDED="true" ID="ID_1284027830" MODIFIED="1520498536817" TEXT="SAXParser">
<node COLOR="#111111" CREATED="1475462707942" FOLDED="true" ID="ID_1782049014" MODIFIED="1520498536816" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475462710398" ID="ID_834966432" MODIFIED="1475462710398" TEXT="public void reset()"/>
<node COLOR="#111111" CREATED="1475462754394" ID="ID_857111125" MODIFIED="1475462754394" TEXT="public void parse(InputStream is, DefaultHandler dh)"/>
<node COLOR="#111111" CREATED="1475462804420" ID="ID_409084750" MODIFIED="1475462804421" TEXT="public void parse(String uri, DefaultHandler dh)"/>
<node COLOR="#111111" CREATED="1475462813722" ID="ID_534546775" MODIFIED="1475462813722" TEXT="public void parse(File f, DefaultHandler dh)"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475462569641" FOLDED="true" ID="ID_1829574667" MODIFIED="1520498536818" TEXT="DefaultHandler">
<node COLOR="#111111" CREATED="1475463002956" FOLDED="true" ID="ID_1344631521" MODIFIED="1520498536817" TEXT="public void startDocument ()">
<node COLOR="#111111" CREATED="1475463115186" ID="ID_778132691" MODIFIED="1475463119417" TEXT="&#x5f00;&#x59cb;&#x6587;&#x6863;"/>
</node>
<node COLOR="#111111" CREATED="1475463014050" FOLDED="true" ID="ID_301847611" MODIFIED="1520498536817" TEXT="public void endDocument ()">
<node COLOR="#111111" CREATED="1475463121077" ID="ID_167058343" MODIFIED="1475463124722" TEXT="&#x7ed3;&#x675f;&#x6587;&#x6863;"/>
</node>
<node COLOR="#111111" CREATED="1475463023418" FOLDED="true" ID="ID_1946670941" MODIFIED="1520498536818" TEXT="public void startElement (String uri, String localName,String qName, Attributes attributes) ">
<node COLOR="#111111" CREATED="1475463106119" ID="ID_444294205" MODIFIED="1475463112220" TEXT="&#x5f00;&#x59cb;&#x89e3;&#x6790;&#x5355;&#x4e2a;&#x5143;&#x7d20;"/>
</node>
<node COLOR="#111111" CREATED="1475463031356" FOLDED="true" ID="ID_1137940450" MODIFIED="1520498536818" TEXT="public void endElement (String uri, String localName, String qName)">
<node COLOR="#111111" CREATED="1475463092341" ID="ID_242806088" MODIFIED="1475463103535" TEXT="&#x89e3;&#x6790;&#x5355;&#x4e2a;&#x5143;&#x7d20;&#x7ed3;&#x675f;"/>
</node>
<node COLOR="#111111" CREATED="1475463038483" FOLDED="true" ID="ID_1658715699" MODIFIED="1520498536818" TEXT="public void characters (char ch[], int start, int length)">
<node COLOR="#111111" CREATED="1475463068568" ID="ID_1914914435" MODIFIED="1475463088151" TEXT="&#x5b9e;&#x9645;&#x7684;&#x503c;&#xff0c;&#x5b57;&#x7b26;&#x4e32;&#x7c7b;&#x578b;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1475462592087" FOLDED="true" ID="ID_859864422" MODIFIED="1520498536820" TEXT="AssetManager">
<node COLOR="#111111" CREATED="1475463804807" FOLDED="true" ID="ID_1878297018" MODIFIED="1520498536819" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1475463807556" ID="ID_1902929858" MODIFIED="1475463828069" TEXT="&#x7528;&#x6765;&#x8bfb;assets&#x6587;&#x4ef6;&#x5939;&#x4e0b;&#x7684;&#x6587;&#x4ef6;&#x7684;&#x5de5;&#x5177;"/>
</node>
<node COLOR="#111111" CREATED="1475463796703" FOLDED="true" ID="ID_1974017653" MODIFIED="1520498536820" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1475463376183" ID="ID_993061851" MODIFIED="1475463386091" TEXT="&#x83b7;&#x53d6;&#x5b9e;&#x4f8b;&#xff1a;AssetManager am = context.getAssets();"/>
<node COLOR="#111111" CREATED="1475463392602" FOLDED="true" ID="ID_746625933" MODIFIED="1520498536819" TEXT="&#x5217;&#x51fa;assets&#x76ee;&#x5f55;&#x4e0b;&#x6240;&#x6709;&#x6587;&#x4ef6;">
<node COLOR="#111111" CREATED="1475463392605" ID="ID_683656026" MODIFIED="1475463392605" TEXT="String[] filePathList = am.list(&quot;&quot;);"/>
</node>
<node COLOR="#111111" CREATED="1475463399812" ID="ID_804403482" MODIFIED="1475463406320" TEXT="&#x6253;&#x5f00;&#x67d0;&#x4e2a;&#x6587;&#x4ef6; : InputStream is = am.open(&quot;test.txt&quot;);"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
