/**
 * 
 */
package com.zhiyou.js;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author longWH
 *
 */
public class Test2 {
	public static void main(String[] args) {
//		String input = "n1ame:.ja1ck4.\r";
//		findGroup(input, "\\r|\\.|n");
		
		String input = "he123 he ha";
		findGroup(input, "(?=ha)");
	}
	
	static void findGroup(String input,String regex){
		System.out.println(input);
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
//		String value = matcher.replaceAll("=");
//		System.out.println(value);
		while (matcher.find()) {
			System.out.println(matcher.group());
		}
	}
	
}
