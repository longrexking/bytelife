<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1491398671195" ID="ID_408007542" LINK="&#x6b63;&#x5219;.mm" MODIFIED="1529923628000" TEXT="&#x6b63;&#x5219;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1491396415076" FOLDED="true" ID="ID_993231406" MODIFIED="1500709869415" POSITION="right" TEXT="?">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491396417094" ID="ID_245455496" MODIFIED="1491460653414" TEXT="&#x5339;&#x914d;&#x6a21;&#x5f0f;&#xff0c;&#x63cf;&#x8ff0;&#x7684;&#x662f;&#x4e00;&#x4e32;&#x6587;&#x672c;&#x7684;&#x7279;&#x5f81;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491396553438" FOLDED="true" ID="ID_488344417" MODIFIED="1508893412845" POSITION="right" TEXT="&#x6784;&#x6210;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491396575427" FOLDED="true" ID="ID_1648769220" MODIFIED="1508831914550" TEXT="&#x6587;&#x672c;&#x5b57;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396579779" ID="ID_1307715250" MODIFIED="1491460653415" TEXT="&#x5982;: &quot;haha&quot;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396558838" FOLDED="true" ID="ID_1510212889" MODIFIED="1508831914551" TEXT="&#x5143;&#x5b57;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396666999" FOLDED="true" ID="ID_1506886192" MODIFIED="1508831914550" TEXT="? &#x6b63;&#x5219;&#x4e2d;&#x5b9a;&#x4e49;&#x7684;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491396565036" ID="ID_1834888100" MODIFIED="1491396616783" TEXT="&#x5982;: &quot;^&quot;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491396699485" FOLDED="true" ID="ID_478437898" MODIFIED="1508893410869" POSITION="right" TEXT=" [&#x2026;] &#x5b57;&#x7b26;&#x7ec4;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491396708633" FOLDED="true" ID="ID_1527648858" MODIFIED="1508831914551" TEXT="[abc]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708633" ID="ID_1454376297" MODIFIED="1491460653416" TEXT="&#x8868;&#x793a;&#x201c;a&#x201d;&#x6216;&#x201c;b&#x201d;&#x6216;&#x201c;c&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708634" FOLDED="true" ID="ID_158723101" MODIFIED="1508831914551" TEXT="[0-9]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708635" ID="ID_1035501331" MODIFIED="1491460653417" TEXT="&#x8868;&#x793a;0~9&#x4e2d;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x6570;&#x5b57;&#xff0c;&#x7b49;&#x4ef7;&#x4e8e;[0123456789]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708636" FOLDED="true" ID="ID_1052940951" MODIFIED="1508831914551" TEXT="[\u4e00-\u9fa5]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708637" ID="ID_722742299" MODIFIED="1491460653419" TEXT="&#x8868;&#x793a;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x6c49;&#x5b57;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708638" FOLDED="true" ID="ID_781405845" MODIFIED="1508831914551" TEXT="[^a1&lt;]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708638" ID="ID_1271976457" MODIFIED="1491460653419" TEXT="&#x8868;&#x793a;&#x9664;&#x201c;a&#x201d;&#x3001;&#x201c;1&#x201d;&#x3001;&#x201c;&lt;&#x201d;&#x5916;&#x7684;&#x5176;&#x5b83;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708639" FOLDED="true" ID="ID_1995979316" MODIFIED="1508831914551" TEXT="[^a-z]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708640" ID="ID_575565309" MODIFIED="1491460653420" TEXT="&#x8868;&#x793a;&#x9664;&#x5c0f;&#x5199;&#x5b57;&#x6bcd;&#x5916;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398082155" FOLDED="true" ID="ID_1274564890" MODIFIED="1529923628000" POSITION="right" TEXT="&#x5e38;&#x89c1;&#x5b57;&#x7b26;&#x8303;&#x56f4;&#x7f29;&#x5199;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398161174" FOLDED="true" ID="ID_220921351" MODIFIED="1529923628000" TEXT="\d">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161175" ID="ID_5686301" MODIFIED="1491460653420" TEXT="&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x6570;&#x5b57;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[0-9]&#xff0c;&#x5373;0~9 &#x4e2d;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161180" FOLDED="true" ID="ID_1223499989" MODIFIED="1529923628000" TEXT="\D">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161180" ID="ID_21353384" MODIFIED="1491460653420" TEXT="&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x975e;&#x6570;&#x5b57;&#x5b57;&#x7b26;&#xff0c;\d&#x53d6;&#x53cd;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[^0-9]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161177" FOLDED="true" ID="ID_798106645" MODIFIED="1508831914560" TEXT="\w">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161178" ID="ID_308789046" MODIFIED="1491460653420" TEXT="&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x6bcd;&#x6216;&#x6570;&#x5b57;&#x6216;&#x4e0b;&#x5212;&#x7ebf;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[a-zA-Z0-9_]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161181" FOLDED="true" ID="ID_41650726" MODIFIED="1508831914563" TEXT="\W">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161182" ID="ID_1987833336" MODIFIED="1491460653421" TEXT="\w&#x53d6;&#x53cd;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[^a-zA-Z0-9_]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161179" FOLDED="true" ID="ID_1002946637" MODIFIED="1529923628000" TEXT="\s">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161179" FOLDED="true" ID="ID_803430624" MODIFIED="1529923628000" TEXT="&#x4efb;&#x610f;&#x7a7a;&#x767d;&#x5b57;&#x7b26;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[ \r\n\f\t\v]">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500703944709" ID="ID_1120502954" MODIFIED="1500704002867" TEXT="\r :    &#x56de;&#x8f66;"/>
<node COLOR="#111111" CREATED="1500703952726" ID="ID_1070601000" MODIFIED="1500704004793" TEXT="\n:    &#x6362;&#x884c;"/>
<node COLOR="#111111" CREATED="1500703992104" ID="ID_1419120376" MODIFIED="1500704007519" TEXT="\f:   &#x6362;&#x9875;"/>
<node COLOR="#111111" CREATED="1500704009175" ID="ID_1762765808" MODIFIED="1500704033992" TEXT="\v :    &#x5782;&#x76f4;&#x5236;&#x8868;&#x7b26;"/>
<node COLOR="#111111" CREATED="1500704034437" ID="ID_556878555" MODIFIED="1500704043731" TEXT="\t : &#x6c34;&#x5e73;&#x5236;&#x8868;&#x7b26;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161182" FOLDED="true" ID="ID_301709334" MODIFIED="1521268603403" TEXT="\S">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161182" ID="ID_702203489" MODIFIED="1491460653421" TEXT="&#x4efb;&#x610f;&#x975e;&#x7a7a;&#x767d;&#x5b57;&#x7b26;&#xff0c;\s&#x53d6;&#x53cd;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[^ \r\n\f\t\v]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398236335" FOLDED="true" ID="ID_260339544" MODIFIED="1508894092755" POSITION="right" TEXT=". &#x5c0f;&#x6570;&#x70b9;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398257526" FOLDED="true" ID="ID_1787038034" MODIFIED="1508893401408" TEXT=".">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398257528" ID="ID_161941561" MODIFIED="1491460653421" TEXT="&#x5339;&#x914d;&#x9664;&#x4e86;&#x6362;&#x884c;&#x7b26; \n &#x4ee5;&#x5916;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500704618823" FOLDED="true" ID="ID_726913049" MODIFIED="1508831914574" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500704629707" ID="ID_1847730971" MODIFIED="1500704680048">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      String regex = &quot;.&quot;;//&#21305;&#37197;&#38500;&#20102;\n&#20197;&#22806;&#30340;&#20219;&#24847;&#23383;&#31526;
    </p>
    <p>
      String input = &quot;&#21621;1[&#21621;hell_o88.77&#21628;\r \n \f \t&quot;;
    </p>
    <p>
      Matcher matcher = Pattern.compile(regex).matcher(input);
    </p>
    <p>
      
    </p>
    <p>
      while (matcher.find()) {
    </p>
    <p>
      &#160;&#160;&#160;&#160;System.out.println(matcher.group());
    </p>
    <p>
      }
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1500704693762" ID="ID_453869581" MODIFIED="1500704731975">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32467;&#26524;&#26159;&#21076;&#38500; \r&#160; \f \t
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398271553" FOLDED="true" ID="ID_1445213562" MODIFIED="1508893404024" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ^$&#31561;
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398277039" FOLDED="true" ID="ID_1293010356" MODIFIED="1508831914574" TEXT="^">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398277040" ID="ID_1275620647" MODIFIED="1500705497472" TEXT="&#x5339;&#x914d;&#x5b57;&#x7b26;&#x4e32;&#x5f00;&#x59cb;&#x7684;&#x4f4d;&#x7f6e;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500705030297" ID="ID_1266178037" MODIFIED="1500705541260">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24847;&#24605;&#23601;&#26159;&#21305;&#37197;&#25972;&#20010;&#23383;&#31526;&#20018;&#30340;&#36215;&#22987;&#20301;&#32622;,
    </p>
    <p>
      &#22914;&#26524;&#33021;&#21305;&#37197;&#21017;&#25226;&#21305;&#37197;&#30340;&#32467;&#26524;&#20445;&#23384;&#36215;&#26469;,&#28982;&#21518;&#25972;&#20010;&#36807;&#31243;&#32467;&#26463;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500705146228" FOLDED="true" ID="ID_602651753" MODIFIED="1500975538350" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500705148941" ID="ID_1697612594" MODIFIED="1500705193182">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;String</font>&#160;<font color="#6A3E3E" face="Consolas">input</font>&#160;<font face="Consolas">=</font>&#160;<font color="#2A00FF" face="Consolas">&quot;hello world 1he she&quot;</font><font face="Consolas">;</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;String</font>&#160;<font color="#6A3E3E" face="Consolas">regex</font>&#160;<font face="Consolas">=</font>&#160; <font color="#2A00FF" face="Consolas">&quot;^he&quot;</font><font face="Consolas">;</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;Matcher</font>&#160;<font color="#6A3E3E" face="Consolas">matcher</font>&#160;<font face="Consolas">= Pattern.<i>compile</i>(</font><font color="#6A3E3E" face="Consolas">regex</font><font face="Consolas">).matcher(</font><font color="#6A3E3E" face="Consolas">input</font><font face="Consolas">);</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas"><b>while</b></font>&#160;<font face="Consolas">(</font><font color="#6A3E3E" face="Consolas">matcher</font><font face="Consolas">.find()) {</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.</font><font color="#0000C0" face="Consolas"><b><i>out</i></b></font><font face="Consolas">.println(</font><font color="#6A3E3E" face="Consolas">matcher</font><font face="Consolas">.group());</font>
    </div>
    <div align="left">
      <div>
        <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;} </font>&#36755;&#20986;&#32467;&#26524;&#20026;: he
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398277041" FOLDED="true" ID="ID_229930170" MODIFIED="1501035234570" TEXT="$">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398277042" ID="ID_1073289297" MODIFIED="1500705494858" TEXT="&#x5339;&#x914d;&#x5b57;&#x7b26;&#x4e32;&#x7ed3;&#x675f;&#x7684;&#x4f4d;&#x7f6e;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500705500516" ID="ID_1141518872" MODIFIED="1500705526245">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24847;&#24605;&#23601;&#26159;&#21305;&#37197;&#25972;&#20010;&#23383;&#31526;&#20018;&#30340;&#32467;&#26463;&#20301;&#32622;,
    </p>
    <p>
      &#22914;&#26524;&#33021;&#21305;&#37197;&#21017;&#25226;&#21305;&#37197;&#30340;&#32467;&#26524;&#20445;&#23384;&#36215;&#26469;,&#28982;&#21518;&#25972;&#20010;&#36807;&#31243;&#32467;&#26463;&#160;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500705440318" FOLDED="true" ID="ID_1818649228" MODIFIED="1500975604141" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500705442905" ID="ID_1951046811" MODIFIED="1500705457983">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;String</font>&#160;<font color="#6A3E3E" face="Consolas">input</font>&#160;<font face="Consolas">=</font>&#160; <font color="#2A00FF" face="Consolas">&quot;hello world 1he s he&quot;</font><font face="Consolas">;</font>
    </div>
    <div align="left">
      <div>
        <font color="#3F7F5F" face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;//&#160;&#160;&#160;&#160;String</font><font color="#3F7F5F" face="Consolas" size="5">&#160; </font><font color="#3F7F5F" face="Consolas"><u>regex</u></font><font color="#3F7F5F" face="Consolas" size="5">&#160;</font><font color="#3F7F5F" face="Consolas">= &quot;^he&quot;;//&#21305;&#37197;&#25972;&#20010;&#23383;&#31526;&#20018;&#30340;&#36215;&#22987;&#20301;&#32622;,&#21305;&#37197;&#23436;&#27605; &#160;&#160;&#160;&#21518;&#23601;&#32467;&#26463;&#20102;</font>
      </div>
    </div>
    <div align="left">
      <div>
        <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;String</font>&#160;<font color="#6A3E3E" face="Consolas">regex</font>&#160;<font face="Consolas">=</font>&#160; <font color="#2A00FF" face="Consolas">&quot;he$&quot;</font><font face="Consolas">;// $&#35201;&#20889;&#22312;&#38656;&#35201;&#21305;&#37197;&#30340;&#23383;&#31526;&#21518;&#38754;</font>
      </div>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;Matcher</font><font face="Consolas" size="5">&#160;</font><font face="Consolas"><u>matcher</u></font><font face="Consolas" size="5">&#160; </font><font face="Consolas">= Pattern.<i>compile</i>(</font><font color="#6A3E3E" face="Consolas">regex</font><font face="Consolas">).matcher(</font><font color="#6A3E3E" face="Consolas">input</font><font face="Consolas">);</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas"><b>while</b></font>&#160;<font face="Consolas">(</font><font color="#6A3E3E" face="Consolas">matcher</font><font face="Consolas">.find()) {</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.</font><font color="#0000C0" face="Consolas"><b><i>out</i></b></font><font face="Consolas">.println(</font><font color="#6A3E3E" face="Consolas">matcher</font><font face="Consolas">.group());</font>
    </div>
    <div align="left">
      <div>
        <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;}</font>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398277042" FOLDED="true" ID="ID_1239610098" MODIFIED="1501034229854" TEXT="\b">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398277043" ID="ID_1274509013" MODIFIED="1500704774495" TEXT="&#x5339;&#x914d;&#x5355;&#x8bcd;&#x8fb9;&#x754c;&#xff0c;&#x4e0d;&#x5339;&#x914d;&#x4efb;&#x4f55;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491450417436" FOLDED="true" ID="ID_14798150" MODIFIED="1508831914574" TEXT="&#x4ec0;&#x4e48;&#x662f;&#x5355;&#x8bcd;&#x8fb9;&#x754c;?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491450427522" ID="ID_1318059995" MODIFIED="1491450487486" TEXT="&#x7a7a;&#x683c;,&#x6807;&#x70b9;,&#x5176;&#x4ed6;&#x7b26;&#x53f7;&#x628a;&#x5355;&#x8bcd;&#x5206;&#x5f00;,&#x8fd9;&#x4e9b;&#x7b26;&#x53f7;&#x5c31;&#x662f;&#x5355;&#x8bcd;&#x7684;&#x8fb9;&#x754c;"/>
</node>
<node COLOR="#990000" CREATED="1500706854550" FOLDED="true" ID="ID_1670940262" MODIFIED="1500975700244" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500706861374" ID="ID_264170876" MODIFIED="1500706907226">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;StringBuilder</font>&#160;<font color="#6A3E3E" face="Consolas">input</font>&#160;<font face="Consolas">=</font>&#160;<font color="#7F0055" face="Consolas"><b>new</b></font>&#160; <font face="Consolas">StringBuilder(</font><font color="#2A00FF" face="Consolas">&quot;hello,work hard and hard.she&quot;</font><font face="Consolas">);</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;String</font>&#160;<font color="#6A3E3E" face="Consolas">regex</font>&#160;<font face="Consolas">=</font>&#160; <font color="#2A00FF" face="Consolas">&quot;\\bhard\\b&quot;</font><font face="Consolas">;</font><font color="#3F7F5F" face="Consolas">//&#21305;&#37197;&#21333;&#35789;hard</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;Matcher</font>&#160;<font color="#6A3E3E" face="Consolas">matcher</font>&#160;<font face="Consolas">= Pattern.<i>compile</i>(</font><font color="#6A3E3E" face="Consolas">regex</font><font face="Consolas">).matcher(</font><font color="#6A3E3E" face="Consolas">input</font><font face="Consolas">);</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas"><b>while</b></font>&#160;<font face="Consolas">(</font><font color="#6A3E3E" face="Consolas">matcher</font><font face="Consolas">.find()) {</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.</font><font color="#0000C0" face="Consolas"><b><i>out</i></b></font><font face="Consolas">.println(</font><font color="#6A3E3E" face="Consolas">matcher</font><font face="Consolas">.group());</font>
    </div>
    <div align="left">
      <div>
        <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;}</font>
      </div>
    </div>
    <p>
      
    </p>
    <p>
      &#32467;&#26524;&#26159;:
    </p>
    <p>
      hard&#160;
    </p>
    <p>
      hard
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491449308520" FOLDED="true" ID="ID_479502688" MODIFIED="1500975729332" TEXT="\B">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491449310152" ID="ID_247755873" MODIFIED="1491460653423" TEXT="&#x5339;&#x914d;&#x975e;&#x5b57;&#x7b26;&#x8fb9;&#x754c;,&#x4e0d;&#x5339;&#x914d;&#x4efb;&#x4f55;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398305035" FOLDED="true" ID="ID_666986448" MODIFIED="1508894092756" POSITION="right" TEXT="&#x8f6c;&#x4e49;&#x5b57;&#x7b26;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398311927" FOLDED="true" ID="ID_869613697" MODIFIED="1508831914574" TEXT="\r">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398311928" ID="ID_45069173" MODIFIED="1491460653423" TEXT="&#x56de;&#x8f66;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_939614596" MODIFIED="1491460653423" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\r">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491444181085" FOLDED="true" ID="ID_438071668" MODIFIED="1508831914575" TEXT="\n">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491444189400" ID="ID_997558096" MODIFIED="1491460653423" TEXT="&#x6362;&#x884c;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_1413684773" MODIFIED="1491460653423" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\n">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398311929" FOLDED="true" ID="ID_195894000" MODIFIED="1508831914575" TEXT="\\">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398311930" ID="ID_224658764" MODIFIED="1491460653423" TEXT="&#x5339;&#x914d;&#x201c;\&#x201d;&#x672c;&#x8eab;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457255157" ID="ID_1644355747" MODIFIED="1491460653423" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\\\">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457157254" ID="ID_403052534" MODIFIED="1491617144006" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398311931" FOLDED="true" ID="ID_1918321223" MODIFIED="1500639122052" TEXT="\^">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398311931" ID="ID_724573584" MODIFIED="1491460653424" TEXT="&#x5339;&#x914d;&#x201c;^&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_1330201560" MODIFIED="1491460653424" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\^">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491444200871" FOLDED="true" ID="ID_973353950" MODIFIED="1508894092755" TEXT="\$">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491444219942" ID="ID_957019210" MODIFIED="1491460653424" TEXT="&#x5339;&#x914d;&#x201c;$&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_280122265" MODIFIED="1491460653424" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\$">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491444206598" FOLDED="true" ID="ID_1719289646" MODIFIED="1508831914575" TEXT="\.">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491444228311" ID="ID_233838305" MODIFIED="1491460653424" TEXT="&#x5339;&#x914d;&#x201c;.&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_77920369" MODIFIED="1491460653424" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\.">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398341198" FOLDED="true" ID="ID_763891548" MODIFIED="1508894092758" POSITION="right" TEXT="&#x91cf;&#x8bcd;&#xff08;Quantifier&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398349489" FOLDED="true" ID="ID_242671704" MODIFIED="1508831914576" TEXT="{m}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349490" FOLDED="true" ID="ID_1596859857" MODIFIED="1508831914575" TEXT="?  ">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495378493416" ID="ID_100561671" MODIFIED="1495378493416" TEXT="&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;m&#x6b21;"/>
</node>
<node COLOR="#990000" CREATED="1491398376249" FOLDED="true" ID="ID_373959171" MODIFIED="1508831914576" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491398349490" ID="ID_535463928" MODIFIED="1491398362864" TEXT="&#x201c;(abc){2}&#x201d;&#x76f8;&#x5f53;&#x4e8e;&#x201c;abcabc&#x201d;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1491398349490" ID="ID_1413264533" MODIFIED="1491398364465" TEXT="&#x201c;\d{3}&#x201d;&#x76f8;&#x5f53;&#x4e8e;&#x201c;\d\d\d &#x201d;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349491" FOLDED="true" ID="ID_535130564" MODIFIED="1508831914577" TEXT="{m,n}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349492" FOLDED="true" ID="ID_985096784" MODIFIED="1500639122052" TEXT="?  ">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495378501503" ID="ID_409417378" MODIFIED="1495378501504" TEXT="&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;&#x6700;&#x5c11;m&#x6b21;&#xff0c;&#x6700;&#x591a;n&#x6b21;"/>
</node>
<node COLOR="#990000" CREATED="1491398349493" ID="ID_711246737" MODIFIED="1491460653425" TEXT="&#x8303;&#x4f8b;:  &#x201c;\d{2,3}&#x201d;&#x53ef;&#x4ee5;&#x5339;&#x914d;&#x201c;12&#x201d;&#x6216;&#x201c;321&#x201d;&#x7b49;2&#x5230;3&#x4f4d;&#x7684;&#x6570;&#x5b57;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349494" FOLDED="true" ID="ID_1760243577" MODIFIED="1500713165734" TEXT="{m,}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349495" FOLDED="true" ID="ID_1924348674" MODIFIED="1500713165734" TEXT="?  ">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495378507928" ID="ID_1172274113" MODIFIED="1495378507928" TEXT="&#x8868;&#x8fbe;&#x5f0f;&#x81f3;&#x5c11;&#x5339;&#x914d;m&#x6b21;"/>
</node>
<node COLOR="#990000" CREATED="1491398349497" ID="ID_633232653" MODIFIED="1491460653425" TEXT="&#x8303;&#x4f8b;:    &#x201c;[a-z]{8,}&#x201d;&#x8868;&#x793a;&#x81f3;&#x5c11;8&#x4f4d;&#x4ee5;&#x4e0a;&#x7684;&#x5b57;&#x6bcd;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349499" FOLDED="true" ID="ID_1297461724" MODIFIED="1508831914578" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349501" FOLDED="true" ID="ID_1643153180" MODIFIED="1508831914577" TEXT="  ?  ">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495378584750" ID="ID_214009445" MODIFIED="1495378584750" TEXT="&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;0&#x6b21;&#x6216;1&#x6b21;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;{0,1}"/>
</node>
<node COLOR="#990000" CREATED="1491398349503" ID="ID_818373297" MODIFIED="1495693507919" TEXT="&#x8303;&#x4f8b;:   &#x201c;ab?&#x201d;&#x53ef;&#x4ee5;&#x5339;&#x914d;&quot;ab&quot;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349504" FOLDED="true" ID="ID_793740830" MODIFIED="1508894092757" TEXT="*">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349505" FOLDED="true" ID="ID_992885037" MODIFIED="1508894092757" TEXT="?    ">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495378578048" ID="ID_796603399" MODIFIED="1495378578048" TEXT="&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;0&#x6b21;&#x6216;&#x4efb;&#x610f;&#x591a;&#x6b21;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;{0,}"/>
</node>
<node COLOR="#990000" CREATED="1491398349506" ID="ID_729296639" MODIFIED="1491460653426" TEXT="&#x8303;&#x4f8b;:   &#x201c;&lt;[^&gt;]*&gt;&#x201d;&#x4e2d;&#x201c;[^&gt;]*&#x201d;&#x8868;&#x793a;0&#x4e2a;&#x6216;&#x4efb;&#x610f;&#x591a;&#x4e2a;&#x4e0d;&#x662f;&#x201c;&gt;&#x201d;&#x7684;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349510" FOLDED="true" ID="ID_218112820" MODIFIED="1508831914579" TEXT="+">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349511" FOLDED="true" ID="ID_106924927" MODIFIED="1508831914579" TEXT="?   ">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495378571098" ID="ID_518076436" MODIFIED="1500695798875" TEXT="&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;1&#x6b21;&#x6216;1&#x6b21;&#x4ee5;&#x4e0a;&#xff0c;&#x81f3;&#x5c11;1&#x6b21;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;{1,}"/>
</node>
<node COLOR="#990000" CREATED="1491398349512" ID="ID_1472847004" MODIFIED="1491460653426" TEXT="&#x8303;&#x4f8b;:   &#x201c;\d\s+\d&#x201d;&#x8868;&#x793a;&#x4e24;&#x4e2a;&#x6570;&#x5b57;&#x4e2d;&#x95f4;&#xff0c;&#x81f3;&#x5c11;&#x6709;&#x4e00;&#x4e2a;&#x4ee5;&#x4e0a;&#x7684;&#x7a7a;&#x767d;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491439975582" FOLDED="true" ID="ID_1604898321" MODIFIED="1500976396652" POSITION="left" TEXT="&#x975e;&#x6355;&#x83b7;&#x7ec4;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491439991544" FOLDED="true" ID="ID_1147191995" MODIFIED="1500713165739" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439993650" ID="ID_508903028" MODIFIED="1500686092058" TEXT="&#x4e00;&#x4e9b;&#x8868;&#x8fbe;&#x5f0f;&#x4e2d;&#xff0c;&#x4e0d;&#x5f97;&#x4e0d;&#x4f7f;&#x7528;( )&#xff0c;&#x4f46;&#x53c8;&#x4e0d;&#x9700;&#x8981;&#x4fdd;&#x5b58;( )&#xa;&#x4e2d;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#xff0c;&#x8fd9;&#x65f6;&#x53ef;&#x4ee5;&#x7528;&#x975e;&#x6355;&#x83b7;&#x7ec4;&#x6765;&#xa;&#x62b5;&#x6d88;&#x4f7f;&#x7528;( )&#x5e26;&#x6765;&#x7684;&#x526f;&#x4f5c;&#x7528;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491440001894" FOLDED="true" ID="ID_39643493" MODIFIED="1500976395229" TEXT="(?:Expression) ">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491440015156" ID="ID_805997306" MODIFIED="1500686104542" TEXT="&#x8fdb;&#x884c;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;Expression&#x7684;&#x5339;&#x914d;&#xff0c;&#x5e76;&#x5c06;&#x5339;&#x914d;&#xa;&#x5185;&#x5bb9;&#x4fdd;&#x5b58;&#x5230;&#x6700;&#x7ec8;&#x7684;&#x6574;&#x4e2a;&#x8868;&#x8fbe;&#x5f0f;&#x7684;&#x533a;&#x914d;&#x7ed3;&#x679c;&#x4e2d;&#xff0c;&#xa;&#x4f46;Expression&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#x4e0d;&#x5355;&#x72ec;&#x4fdd;&#x5b58;&#x5230;&#x4e00;&#x4e2a;&#x7ec4;&#x5185;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491440052447" FOLDED="true" ID="ID_1202514374" MODIFIED="1500705099000" POSITION="left" TEXT="&#x53cd;&#x5411;&#x5f15;&#x7528;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491457673475" ID="ID_197078900" MODIFIED="1500686080172">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21453;&#21521;&#24341;&#29992;&#30340;&#20316;&#29992;&#36890;&#24120;&#26159;&#29992;
    </p>
    <p>
      &#26469;&#26597;&#25214;&#25110;&#38480;&#23450;&#37325;&#22797;&#12289;&#26597;&#25214;
    </p>
    <p>
      &#25110;&#38480;&#23450;&#25351;&#23450;&#26631;&#35782;&#37197;&#23545;&#20986;&#29616;&#31561;&#31561;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1491460143803" FOLDED="true" ID="ID_161001068" MODIFIED="1500713165739" TEXT="&#x5982;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491460146163" FOLDED="true" ID="ID_1412439911" MODIFIED="1500713165739" TEXT="\1&#xff0c;\2">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491460146164" ID="ID_839841713" MODIFIED="1491460146164" TEXT="&#x5bf9;&#x5e8f;&#x53f7;&#x4e3a;1&#x548c;2&#x7684;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x53cd;&#x5411;&#x5f15;&#x7528;"/>
</node>
<node COLOR="#990000" CREATED="1491460146164" FOLDED="true" ID="ID_710092574" MODIFIED="1500713165739" TEXT="\k&lt;name&gt;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491460146164" ID="ID_1662305557" MODIFIED="1491460146164" TEXT="&#x5bf9;&#x547d;&#x540d;&#x4e3a;name&#x7684;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x53cd;&#x5411;&#x5f15;&#x7528;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491458652167" FOLDED="true" ID="ID_998536512" MODIFIED="1500713165743" POSITION="left" TEXT="&#x73af;&#x89c6;&#xff08;Look Around&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491458663935" FOLDED="true" ID="ID_816332645" MODIFIED="1500713165739" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458665309" ID="ID_1988901546" MODIFIED="1491460653463" TEXT="&#x53ea;&#x8fdb;&#x884c;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x7684;&#x5339;&#x914d;&#xff0c;&#x5339;&#x914d;&#x5185;&#x5bb9;&#x4e0d;&#x8ba1;&#x5165;&#x6700;&#x7ec8;&#x7684;&#x5339;&#x914d;&#x7ed3;&#x679c;&#xff0c;&#x662f;&#x96f6;&#x5bbd;&#x5ea6;&#x7684;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491458893194" ID="ID_983330351" MODIFIED="1500709572095" TEXT="&#x73af;&#x89c6;&#x6309;&#x7167;&#x65b9;&#x5411;&#x5212;&#x5206;&#x6709;&#x987a;&#x5e8f;&#x548c;&#x9006;&#x5e8f;&#x4e24;&#x79cd;&#xff0c;&#x6309;&#x7167;&#x662f;&#x5426;&#x5339;&#x914d;&#x6709;&#x80af;&#xa;&#x5b9a;&#x548c;&#x5426;&#x5b9a;&#x4e24;&#x79cd;&#xff0c;&#x7ec4;&#x5408;&#x8d77;&#x6765;&#x5c31;&#x6709;&#x56db;&#x79cd;&#x73af;&#x89c6;&#x3002;&#x73af;&#x89c6;&#x76f8;&#x5f53;&#x4e8e;&#x5bf9;&#x6240;&#xa;&#x5728;&#x4f4d;&#x7f6e;&#x52a0;&#x4e86;&#x4e00;&#x4e2a;&#x9644;&#x52a0;&#x6761;&#x4ef6;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851528" FOLDED="true" ID="ID_1829553006" MODIFIED="1500713165740" TEXT="(?&lt;=Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851531" ID="ID_1251435275" MODIFIED="1500709541035" TEXT="&#x9006;&#x5e8f;&#x80af;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x5de6;&#x4fa7;&#x80fd;&#x591f;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491459966704" ID="ID_1375086076" MODIFIED="1500709552503" TEXT="&#x5982;: (?&lt;=haha),&#x8868;&#x793a;&#x5de6;&#x4fa7;&#x5fc5;&#x987b;&#x662f; haha">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851533" FOLDED="true" ID="ID_632724205" MODIFIED="1500713165740" TEXT="(?&lt;!Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851534" ID="ID_111905169" MODIFIED="1500709651808" TEXT="&#x9006;&#x5e8f;&#x5426;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x5de6;&#x4fa7;&#x4e0d;&#x80fd;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491459966704" ID="ID_1443135730" MODIFIED="1500709656077" TEXT="&#x5982;: (?&lt;!haha),&#x8868;&#x793a;&#x5de6;&#x4fa7;&#x4e0d;&#x80fd;&#x662f; haha">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851536" FOLDED="true" ID="ID_898357624" MODIFIED="1500713165740" TEXT="(?=Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851541" ID="ID_1196840228" MODIFIED="1500709663348" TEXT="&#x987a;&#x5e8f;&#x80af;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x53f3;&#x4fa7;&#x80fd;&#x591f;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491459966704" ID="ID_1171461616" MODIFIED="1500709666693" TEXT="&#x5982;: (?=haha),&#x8868;&#x793a;&#x53f3;&#x4fa7;&#x5fc5;&#x987b;&#x662f; haha">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851543" FOLDED="true" ID="ID_325297760" MODIFIED="1500713165741" TEXT="(?!Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851544" ID="ID_1759813612" MODIFIED="1500709673639" TEXT="&#x987a;&#x5e8f;&#x5426;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x53f3;&#x4fa7;&#x4e0d;&#x80fd;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491459966704" ID="ID_1595176530" MODIFIED="1500709675971" TEXT="&#x5982;: (?!=haha),&#x8868;&#x793a;&#x53f3;&#x4fa7;&#x4e0d;&#x80fd;&#x662f; haha">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495673963378" FOLDED="true" ID="ID_412653771" MODIFIED="1500713165741">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      (?:Expression)
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495673971402" ID="ID_1888519766" MODIFIED="1495673983755" TEXT="&#x8868;&#x793a;&#x4e0d;&#x60f3;&#x88ab;&#x6355;&#x83b7;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1495673441435" FOLDED="true" ID="ID_1776990824" MODIFIED="1500709887214" POSITION="left" TEXT="&#x9644;&#x4ef6;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1495673445307" ID="ID_301113981" LINK="Test.java" MODIFIED="1495673455711" TEXT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1495673447153" ID="ID_962313229" LINK="Test2.java" MODIFIED="1495673451251" TEXT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1495690246474" FOLDED="true" ID="ID_157671657" MODIFIED="1500709885370" TEXT="&#x624b;&#x673a;&#x53f7;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495690252797" ID="ID_203898125" MODIFIED="1495690252797" TEXT="&#x3000;&#x79fb;&#x52a8;&#xff1a;134&#x3001;135&#x3001;136&#x3001;137&#x3001;138&#x3001;139&#x3001;150&#x3001;151&#x3001;157(TD)&#x3001;158&#x3001;159&#x3001;187&#x3001;188">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495690252799" ID="ID_982807824" MODIFIED="1495690252800" TEXT="&#x3000;&#x3000;&#x8054;&#x901a;&#xff1a;130&#x3001;131&#x3001;132&#x3001;152&#x3001;155&#x3001;156&#x3001;185&#x3001;186">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495690252800" ID="ID_228445510" MODIFIED="1495690252800" TEXT="&#x3000;&#x3000;&#x7535;&#x4fe1;&#xff1a;133&#x3001;153&#x3001;180&#x3001;189&#x3001;&#xff08;1349&#x536b;&#x901a;&#xff09;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495690270958" FOLDED="true" ID="ID_1082325376" MODIFIED="1500639122052" TEXT="&#x6b63;&#x5219;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495690273458" ID="ID_1727538332" MODIFIED="1495690273458" TEXT="^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491439493841" FOLDED="true" ID="ID_1018307250" MODIFIED="1501038857618" POSITION="right" TEXT="&#x5206;&#x652f;&#x7ed3;&#x6784;&#xff08;Alternation&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491439508928" FOLDED="true" ID="ID_909563740" MODIFIED="1508831914580" TEXT="?  ">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439546850" ID="ID_1527205939" MODIFIED="1491460653430" TEXT="&#x5f53;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x67d0;&#x4e00;&#x5b50;&#x4e32;&#x5177;&#x6709;&#x591a;&#x79cd;&#x53ef;&#x80fd;&#x65f6;&#xff0c;&#x91c7;&#x7528;&#x5206;&#x652f;&#x7ed3;&#x6784;&#x6765;&#x5339;&#x914d;&#xff0c;&#x201c;|&#x201d;&#x8868;&#x793a;&#x591a;&#x4e2a;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x4e4b;&#x95f4;&#x201c;&#x6216;&#x201d;&#x7684;&#x5173;&#x7cfb;&#xff0c;&#x201c;|&#x201d;&#x662f;&#x4ee5;()&#x9650;&#x5b9a;&#x8303;&#x56f4;&#x7684;&#xff0c;&#x5982;&#x679c;&#x5728;&#x201c;|&#x201d;&#x7684;&#x5de6;&#x53f3;&#x4e24;&#x4fa7;&#x6ca1;&#x6709;()&#x6765;&#x9650;&#x5b9a;&#x8303;&#x56f4;&#xff0c;&#x90a3;&#x4e48;&#x5b83;&#x7684;&#x4f5c;&#x7528;&#x8303;&#x56f4;&#x5373;&#x4e3a;&#x201c;|&#x201d;&#x5de6;&#x53f3;&#x4e24;&#x4fa7;&#x6574;&#x4f53;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439532957" FOLDED="true" ID="ID_930692148" MODIFIED="1500713165744" TEXT="|">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439532957" ID="ID_1083375070" MODIFIED="1491460653433" TEXT="&#x591a;&#x4e2a;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x4e4b;&#x95f4;&#x53d6;&#x201c;&#x6216;&#x201d;&#x7684;&#x5173;&#x7cfb;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439678357" FOLDED="true" ID="ID_1106646959" MODIFIED="1508831914580" TEXT="&#x8303;&#x4f8b;1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439691426" ID="ID_1808652019" MODIFIED="1491460653435" TEXT="&#x201c;^(aa|b)$&#x201d;&#x5728;&#x533a;&#x914d;&#x201c;cccb&#x201d;&#x65f6;&#xff0c;&#x662f;&#x5339;&#x914d;&#x5931;&#x8d25;&#x7684;&#xff0c;&#x56e0;&#x4e3a;&#x8fd9;&#x4e2a;&#x8868;&#x8fbe;&#x5f0f;&#x8868;&#x793a;&#x5728;&#x201c;&#x5f00;&#x59cb;&#x201d;&#x548c;&#x201c;&#x7ed3;&#x675f;&#x201d;&#x4f4d;&#x7f6e;&#x4e4b;&#x95f4;&#x53ea;&#x80fd;&#x662f;&#x201c;aa&#x201d;&#x6216;&#x201c;b&#x201d;&#xff0c;&#x800c;&#x201c;cccb&#x201d;&#x663e;&#x7136;&#x662f;&#x4e0d;&#x6ee1;&#x8db3;&#x7684;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439710129" FOLDED="true" ID="ID_482722708" MODIFIED="1508831914580" TEXT="&#x8303;&#x4f8b;2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439713135" ID="ID_402482231" MODIFIED="1491460653440" TEXT="&#x201c;^aa|b$&#x201d;&#x5728;&#x5339;&#x914d;&#x201c;cccb&#x201d;&#x65f6;&#xff0c;&#x662f;&#x53ef;&#x4ee5;&#x5339;&#x914d;&#x6210;&#x529f;&#x7684;&#xff0c;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x662f;&#x201c;b&#x201d;&#xff0c;&#x56e0;&#x4e3a;&#x8fd9;&#x4e2a;&#x8868;&#x8fbe;&#x5f0f;&#x8868;&#x793a;&#x5339;&#x914d;&#x201c;^aa&#x201d;&#x6216;&#x201c;b&#x201d;&#xff0c;&#x800c;&#x201c;b &#x201d;&#x5728;&#x5339;&#x914d;&#x201c;cccb &#x201d;&#x65f6;&#x662f;&#x53ef;&#x4ee5;&#x5339;&#x914d;&#x6210;&#x529f;&#x7684;&#x3002;&#xa;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491450674866" FOLDED="true" ID="ID_1468643323" MODIFIED="1500709469608" POSITION="right" TEXT="java&#x4e2d;&#x76f8;&#x5173;&#x7684;&#x7c7b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491450687764" FOLDED="true" ID="ID_1520379001" MODIFIED="1500639122052" TEXT="Pattern">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491450725351" FOLDED="true" ID="ID_979161846" MODIFIED="1500639122052" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491450726737" ID="ID_1807574085" MODIFIED="1491450726737" TEXT="public static boolean matches(String regex, CharSequence input)"/>
<node COLOR="#111111" CREATED="1491450738957" ID="ID_844087668" MODIFIED="1491450738957" TEXT="public static Pattern compile(String regex)"/>
<node COLOR="#111111" CREATED="1491450758736" FOLDED="true" ID="ID_739223555" MODIFIED="1500639122052" TEXT="public Matcher matcher(CharSequence input)">
<node COLOR="#111111" CREATED="1491450846288" ID="ID_984676687" MODIFIED="1491450861285" TEXT="&#x901a;&#x8fc7;&#x5339;&#x914d;&#x5f97;&#x5230;Matcher&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1491450875153" ID="ID_607849954" MODIFIED="1491450878718" TEXT="public String[] split(CharSequence input)"/>
<node COLOR="#111111" CREATED="1491450811862" FOLDED="true" ID="ID_1499850066" MODIFIED="1500639122052" TEXT="public String[] split(CharSequence input, int limit)">
<node COLOR="#111111" CREATED="1491450813696" ID="ID_1242499760" MODIFIED="1491450836771" TEXT="&#x628a;&#x5339;&#x914d;&#x5230;&#x7684;&#x7ed3;&#x679c;&#x653e;&#x5230;&#x6570;&#x7ec4;&#x4e2d;&#x5e76;&#x4e14;&#x8fd4;&#x56de;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491450695039" FOLDED="true" ID="ID_318693313" MODIFIED="1500643853563" TEXT="Matcher">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491451297862" FOLDED="true" ID="ID_1946849948" MODIFIED="1500643853563" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491451299313" ID="ID_352320590" MODIFIED="1491451299313" TEXT="public Pattern pattern()"/>
<node COLOR="#111111" CREATED="1491451333257" ID="ID_1500239782" MODIFIED="1491451333257" TEXT="public MatchResult toMatchResult()"/>
<node COLOR="#111111" CREATED="1491451364706" FOLDED="true" ID="ID_1415381234" MODIFIED="1500639122052" TEXT="public Matcher reset()">
<node COLOR="#111111" CREATED="1491455584605" ID="ID_943183143" MODIFIED="1491455673449" TEXT="&#x91cd;&#x7f6e;,&#x8fd8;&#x662f;&#x4e4b;&#x524d;&#x7684;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491455604345" FOLDED="true" ID="ID_830857019" MODIFIED="1500639122068" TEXT="public Matcher reset(CharSequence input)">
<node COLOR="#111111" CREATED="1491455638655" ID="ID_368759937" MODIFIED="1491455656216" TEXT="&#x91cd;&#x7f6e;&#x9700;&#x8981;&#x5339;&#x914d;&#x7684;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491451384472" FOLDED="true" ID="ID_1113596639" MODIFIED="1500639122068" TEXT="public Matcher reset(CharSequence input)">
<node COLOR="#111111" CREATED="1491451390377" ID="ID_979874014" MODIFIED="1491451390377" TEXT="Resets this matcher with a new input sequence."/>
</node>
<node COLOR="#111111" CREATED="1491451404832" FOLDED="true" ID="ID_1518058961" MODIFIED="1500643853563" TEXT="public int start()">
<node COLOR="#111111" CREATED="1491451410161" ID="ID_350843810" MODIFIED="1491451410161" TEXT="Returns the start index of the previous match."/>
</node>
<node COLOR="#111111" CREATED="1491451421921" FOLDED="true" ID="ID_1081495647" MODIFIED="1500639122068" TEXT="public int start(int group)">
<node COLOR="#111111" CREATED="1491451432884" ID="ID_1808169310" MODIFIED="1491453595032" TEXT="&#x5339;&#x914d;&#x5230;&#x7684;&#x6bcf;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;"/>
<node COLOR="#111111" CREATED="1491453609467" ID="ID_423001262" MODIFIED="1491453652634" TEXT="group :  &#x7ec4;&#x7684;&#x7d22;&#x5f15;"/>
</node>
<node COLOR="#111111" CREATED="1491451453795" FOLDED="true" ID="ID_1036779373" MODIFIED="1500639122068" TEXT="public int start(String name)">
<node COLOR="#111111" CREATED="1491451461800" ID="ID_1835059112" MODIFIED="1491453971537" TEXT="name : &#x7ec4;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1491451479987" FOLDED="true" ID="ID_1733483898" MODIFIED="1500639122068" TEXT="public int end()">
<node COLOR="#111111" CREATED="1491451432884" ID="ID_1997915261" MODIFIED="1491453605081" TEXT="&#x5339;&#x914d;&#x5230;&#x7684;&#x6bcf;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x7ed3;&#x675f;&#x4f4d;&#x7f6e;"/>
</node>
<node COLOR="#111111" CREATED="1491453562416" FOLDED="true" ID="ID_231931827" MODIFIED="1500639122068" TEXT="public int end(int group)">
<node COLOR="#111111" CREATED="1491453609467" ID="ID_663162197" MODIFIED="1491453652634" TEXT="group :  &#x7ec4;&#x7684;&#x7d22;&#x5f15;"/>
</node>
<node COLOR="#111111" CREATED="1491453683102" FOLDED="true" ID="ID_1105568784" MODIFIED="1500639122068" TEXT="public int end(String name)">
<node COLOR="#111111" CREATED="1491451461800" ID="ID_222949198" MODIFIED="1491451473386" TEXT="name : &#x7ec4;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1491453787390" FOLDED="true" ID="ID_1755685344" MODIFIED="1500643853563" TEXT="public String group(int group)">
<node COLOR="#111111" CREATED="1491453886767" ID="ID_1609648802" MODIFIED="1491453894438" TEXT="&#x8fd4;&#x56de;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491453697212" FOLDED="true" ID="ID_1805125886" MODIFIED="1500643853563" TEXT="public String group()">
<node COLOR="#111111" CREATED="1491453793934" FOLDED="true" ID="ID_1235219005" MODIFIED="1500643853563" TEXT="?">
<node COLOR="#111111" CREATED="1491453886767" ID="ID_1324566934" MODIFIED="1491453894438" TEXT="&#x8fd4;&#x56de;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491453699138" ID="ID_83656029" MODIFIED="1491453717860" TEXT="&#x5c31;&#x662f; group(0)"/>
<node COLOR="#111111" CREATED="1491453718278" ID="ID_1689225691" MODIFIED="1491453779261" TEXT="0&#x7ec4;&#x6307;&#x7684;&#x662f;&#x6574;&#x4e2a;&#x6b63;&#x5219;, 1,2&#x7b49;&#x6307;&#x7684;&#x662f;&#x5b50;&#x7ec4;"/>
</node>
<node COLOR="#111111" CREATED="1491453907183" FOLDED="true" ID="ID_185321562" MODIFIED="1500639122068" TEXT="public String group(String name)">
<node COLOR="#111111" CREATED="1491453911343" ID="ID_1804678619" MODIFIED="1491453954265" TEXT="&#x901a;&#x8fc7;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x540d;&#x5b50;&#x6765;&#x83b7;&#x53d6;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x5b57;&#x7b26;&#x4e32;"/>
<node COLOR="#111111" CREATED="1491453936769" ID="ID_498267683" MODIFIED="1491453943549" TEXT="name: &#x7ec4;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1491453984060" FOLDED="true" ID="ID_1269431763" MODIFIED="1500640984044" TEXT="public int groupCount()">
<node COLOR="#111111" CREATED="1491453993477" ID="ID_1745017864" MODIFIED="1491454000597" TEXT="&#x8fd4;&#x56de;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x6570;&#x91cf;"/>
</node>
<node COLOR="#111111" CREATED="1491454008047" FOLDED="true" ID="ID_1609464706" MODIFIED="1500643853563" TEXT="public boolean matches()">
<node COLOR="#111111" CREATED="1491454019332" ID="ID_587448302" MODIFIED="1491455026467" TEXT="&#x5168;&#x90e8;&#x5339;&#x914d;,&#x5339;&#x914d;&#x6574;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x624d;&#x8fd4;&#x56de;true"/>
</node>
<node COLOR="#111111" CREATED="1491454034153" FOLDED="true" ID="ID_1928352519" MODIFIED="1500643853563" TEXT="public boolean find()">
<node COLOR="#111111" CREATED="1491454259613" ID="ID_1083155259" MODIFIED="1491454691205" TEXT="&#x90e8;&#x5206;&#x5339;&#x914d;"/>
<node COLOR="#111111" CREATED="1491454320058" ID="ID_1548135838" MODIFIED="1491455529618" TEXT="&#x4ece;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;(&#x5339;&#x914d;&#x6210;&#x529f;&#x4e4b;&#x540e;&#x7ed3;&#x675f;&#x7684;&#x4f4d;&#x7f6e;)&#x5f00;&#x59cb;&#x5339;&#x914d;&#xff0c;&#x627e;&#x5230;&#x4e00;&#x4e2a;&#x5339;&#x914d;&#x7684;&#x5b50;&#x4e32;&#xff0c;&#x5c06;&#x79fb;&#x52a8;&#x4e0b;&#x6b21;&#x5339;&#x914d;&#x7684;&#x4f4d;&#x7f6e;"/>
<node COLOR="#111111" CREATED="1491455541957" ID="ID_71272331" MODIFIED="1491455551903" TEXT="&#x901a;&#x5e38;&#x548c; while&#x5faa;&#x73af;&#x914d;&#x5408;&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#111111" CREATED="1491454416758" FOLDED="true" ID="ID_1357988756" MODIFIED="1500643853563" TEXT="public boolean find(int start)">
<node COLOR="#111111" CREATED="1491454419253" ID="ID_632332618" MODIFIED="1491454454493" TEXT="start : &#x4ece;&#x6307;&#x5b9a;&#x7684;&#x4f4d;&#x7f6e;&#x5f00;&#x59cb;&#x5339;&#x914d;"/>
</node>
<node COLOR="#111111" CREATED="1491454959326" FOLDED="true" ID="ID_449834649" MODIFIED="1500643853563" TEXT="public boolean lookingAt()">
<node COLOR="#111111" CREATED="1491455029647" ID="ID_1310813383" MODIFIED="1491455459386" TEXT="&#x90e8;&#x5206;&#x5339;&#x914d;"/>
<node COLOR="#111111" CREATED="1491455447846" ID="ID_1913230616" MODIFIED="1491455447846" TEXT="&#x603b;&#x662f;&#x4ece;&#x7b2c;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x8fdb;&#x884c;&#x5339;&#x914d;,&#x5339;&#x914d;&#x6210;&#x529f;&#x4e86;&#x4e0d;&#x518d;&#x7ee7;&#x7eed;&#x5339;&#x914d;&#xff0c;&#x5339;&#x914d;&#x5931;&#x8d25;&#x4e86;,&#x4e5f;&#x4e0d;&#x7ee7;&#x7eed;&#x5339;&#x914d;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1491455143690" FOLDED="true" ID="ID_1326710996" MODIFIED="1500639122068" TEXT="public String replaceAll(String replacement)">
<node COLOR="#111111" CREATED="1491455155506" ID="ID_1319335575" MODIFIED="1491455194802" TEXT="replacement : &#x65b0;&#x7684;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491455207414" ID="ID_1383976562" MODIFIED="1491455207414" TEXT="public String replaceFirst(String replacement)"/>
<node COLOR="#111111" CREATED="1491455241168" FOLDED="true" ID="ID_1600455655" MODIFIED="1500639122068" TEXT="public Matcher region(int start, int end)">
<node COLOR="#111111" CREATED="1491455250629" ID="ID_942339966" MODIFIED="1491455261967" TEXT="&#x8bbe;&#x7f6e;&#x9700;&#x8981;&#x5339;&#x914d;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x533a;&#x57df;"/>
<node COLOR="#111111" CREATED="1491455262721" ID="ID_1831666837" MODIFIED="1491455279789" TEXT="start :&#x5f00;&#x59cb;&#x4f4d;&#x7f6e;&#x7684;&#x4e0b;&#x6807;"/>
<node COLOR="#111111" CREATED="1491455269600" ID="ID_1083295856" MODIFIED="1491455282243" TEXT="end: &#x7ed3;&#x675f;&#x4f4d;&#x7f6e;&#x7684;&#x4e0b;&#x6807;"/>
</node>
<node COLOR="#111111" CREATED="1491455296082" FOLDED="true" ID="ID_813025349" MODIFIED="1500639122068" TEXT="public int regionStart()">
<node COLOR="#111111" CREATED="1491455300569" ID="ID_1595088909" MODIFIED="1491455321301" TEXT="&#x8fd4;&#x56de;&#x9700;&#x8981;&#x5339;&#x914d;&#x533a;&#x57df;&#x7684;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;"/>
</node>
<node COLOR="#111111" CREATED="1491455329153" FOLDED="true" ID="ID_140438125" MODIFIED="1500639122068" TEXT="public int regionEnd()">
<node COLOR="#111111" CREATED="1491455300569" ID="ID_1799681819" MODIFIED="1491455340337" TEXT="&#x8fd4;&#x56de;&#x9700;&#x8981;&#x5339;&#x914d;&#x533a;&#x57df;&#x7684;&#x7ed3;&#x675f;&#x4f4d;&#x7f6e;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491451315979" FOLDED="true" ID="ID_1956166270" MODIFIED="1500709468600" TEXT="MatchResult">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491455848297" FOLDED="true" ID="ID_446696106" MODIFIED="1500713165744" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491455849995" ID="ID_1959554879" MODIFIED="1491455869643" TEXT="&#x4e00;&#x4e2a;&#x63a5;&#x53e3;,Matcher&#x5b9e;&#x73b0;&#x7684;&#x63a5;&#x53e3;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491439850074" FOLDED="true" ID="ID_1210190763" MODIFIED="1501041779189" POSITION="right" TEXT="&#x6355;&#x83b7;&#x7ec4;&#xff08;Capture Group&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491439859982" FOLDED="true" ID="ID_1029243777" MODIFIED="1508831914580" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439861931" ID="ID_1921651042" MODIFIED="1491460653445" TEXT="&#x6355;&#x83b7;&#x7ec4;&#x5c31;&#x662f;&#x628a;&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;&#x4e2d;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#xff0c;&#x4fdd;&#x5b58;&#x5230;&#x5185;&#x5b58;&#x4e2d;&#x4ee5;&#x6570;&#x5b57;&#x7f16;&#x53f7;&#x6216;&#x624b;&#x52a8;&#x547d;&#x540d;&#x7684;&#x7ec4;&#x91cc;&#xff0c;&#x4ee5;&#x4f9b;&#x540e;&#x9762;&#x5f15;&#x7528;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500642439292" ID="ID_1540547479" MODIFIED="1500642470001" TEXT="&#x6574;&#x4e2a;regex&#x5b57;&#x7b26;&#x4e32;&#x662f;&#x4e00;&#x4e2a;&#x7ec4;: group 0">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1500642471268" FOLDED="true" ID="ID_1802995038" MODIFIED="1508831914580" TEXT="&#x6bcf;&#x4e00;&#x4e2a;()&#x4ee3;&#x8868;&#x4e00;&#x4e2a;&#x7ec4;,&#x4ece;&#x5de6;&#x5411;&#x53f3;&#x5206;&#x522b;&#x662f; group 1,group2,group3..">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1500642512685" FOLDED="true" ID="ID_1142274224" MODIFIED="1500643853563" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1500642516306" ID="ID_1226022513" MODIFIED="1500642666645" TEXT="String regex = &quot;(abc)|(b[abc])|(a\\d)&quot;;"/>
<node COLOR="#111111" CREATED="1500642592244" ID="ID_941002872" MODIFIED="1500642677123">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20849;&#22235;&#32452;:&#160;&#160;
    </p>
    <p>
      &#25972;&#20010; (abc)|(b[abc])|(a\\d) &#26159;&#160;&#160;group 0
    </p>
    <p>
      (abc)&#26159; group 1
    </p>
    <p>
      (b[abc]) &#26159; group 2
    </p>
    <p>
      (a\\d) &#26159;group3
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1500642703981" ID="ID_1383823827" MODIFIED="1500642749325" TEXT="&quot;abc|&#x54c8;&#x54c8;|work&quot;    :  &#x8be5;&#x6b63;&#x5219;&#x53ea;&#x6709;group 0 &#x4e00;&#x7ec4;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439871425" FOLDED="true" ID="ID_1172275411" MODIFIED="1500713165738" TEXT="(Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439871425" ID="ID_1488084891" MODIFIED="1500686206624">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26222;&#36890;&#25429;&#33719;&#32452;&#65292;&#23558;&#23376;&#34920;&#36798;&#24335;<br />Expression&#21305;&#37197;&#30340;&#20869;&#23481;&#20445;&#23384;<br />&#21040;&#20197;&#25968;&#23383;&#32534;&#21495;&#30340;&#32452;&#37324;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439871503" FOLDED="true" ID="ID_1856950045" MODIFIED="1508831914581" TEXT="(?&lt;name&gt; Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439871503" ID="ID_854255053" MODIFIED="1500686197617">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21629;&#21517;&#25429;&#33719;&#32452;&#65292;&#23558;&#23376;&#34920;&#36798;&#24335;<br />Expression&#21305;&#37197;&#30340;&#20869;&#23481;&#20445;&#23384;&#21040;<br />&#20197;name&#21629;&#21517;&#30340;&#32452;&#37324;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
