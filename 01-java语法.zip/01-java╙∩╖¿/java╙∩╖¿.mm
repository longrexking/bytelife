<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1472387066311" ID="1hk5qsa32g20kocfohfdcl1q7g" MODIFIED="1532056889098" TEXT="&#x57fa;&#x672c;&#x8bed;&#x6cd5;">
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1519455177001" FOLDED="true" ID="ID_1802495576" MODIFIED="1532056889035" POSITION="right" TEXT="&#x5927;&#x6570;&#x636e;&#x548c;java">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1519455659001" FOLDED="true" ID="ID_879090726" MODIFIED="1532056889035">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20108;&#32773;&#20851;&#31995;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1519455303409" FOLDED="true" ID="ID_1106622022" MODIFIED="1532056889035" TEXT="&#x6458;&#x8981;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519455308514" ID="ID_1017310237" MODIFIED="1519455659023" TEXT="&#x5927;&#x6570;&#x636e;&#x751f;&#x6001;&#x5708;&#x7684;&#x5404;&#x79cd;&#x6280;&#x672f;&#x5927;&#x90fd;&#x662f;java&#x7f16;&#x5199;&#x7684;,&#x6240;&#x4ee5;java&#x5177;&#x6709;&#x5148;&#x5929;&#x4f18;&#x52bf;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519455277907" ID="ID_1672846926" MODIFIED="1519455659030">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22823;&#25968;&#25454;&#23601;&#26159;&#19968;&#20010;&#34892;&#19994;&#65292;&#23454;&#29616;&#21516;&#19968;&#20010;&#38656;&#27714;&#21516;&#26679;&#26377;&#22810;&#31181;&#24037;&#20855;&#21487;&#20197;&#36873;&#25321;&#65292;&#29421;&#20041;&#19968;&#28857;&#20197;&#25216;&#26415;&#30340;&#35282;&#24230;&#35762;&#65292;&#21508;&#31867;&#26694;&#26550;&#26377;Hadoop&#65292;spark&#65292;storm&#65292;flink&#31561;&#65292;&#23601;&#36825;&#31867;&#25216;&#26415;&#29983;&#24577;&#22280;&#26469;&#35762;&#65292;&#36824;&#26377;&#21508;&#31181;&#20013;&#38388;&#20214;&#22914;flume&#65292;kafka&#65292;sqoop&#31561;&#31561; &#65292;&#36825;&#20123;&#26694;&#26550;&#20197;&#21450;&#24037;&#20855;&#22823;&#22810;&#25968;&#26159;&#29992;Java&#32534;&#20889;&#32780;&#25104;&#65292;&#20294;&#25552;&#20379;&#35832;&#22914;Java&#65292;scala&#65292;Python&#65292;R&#31561;&#21508;&#31181;&#35821;&#35328;API&#20379;&#32534;&#31243;&#12290;
    </p>
    <p>
      &#25152;&#20197;&#65292;Java&#20043;&#20110;&#22823;&#25968;&#25454;&#65292;&#23601;&#26159;&#19968;&#31181;&#24037;&#20855;&#32610;&#20102;&#12290;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1519455247772" ID="ID_398494128" MODIFIED="1519455659041" TEXT="&#x5927;&#x6570;&#x636e;&#x6846;&#x67b6;&#x7684;&#x7f16;&#x5199;&#x652f;&#x6301;&#x5f88;&#x591a;&#x5f00;&#x53d1;&#x8bed;&#x8a00;&#xff0c;&#x4f46;&#x662f;Java&#x5728;&#x5927;&#x6570;&#x636e;&#x5f00;&#x53d1;&#x65b9;&#x9762;&#x6709;&#x5f88;&#x5927;&#x7684;&#x4f18;&#x52bf;&#xff0c;&#x76ee;&#x524d;&#x6d41;&#x884c;&#x7684;&#x5927;&#x6570;&#x636e;Hadoop&#x6846;&#x67b6;&#x3001;map-reduce&#x6846;&#x67b6;&#xff0c;&#x5f88;&#x591a;&#x90e8;&#x5206;&#x90fd;&#x662f;&#x7528;&#x5f00;&#x6e90;&#x7684;Java&#x8bed;&#x8a00;&#x7f16;&#x5199;&#xff0c;&#x56e0;&#x6b64;Java&#x5728;&#x5927;&#x6570;&#x636e;&#x65b9;&#x9762;&#x6709;&#x5f88;&#x5927;&#x4f18;&#x52bf;&#xff01;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1519455368141" FOLDED="true" ID="ID_864604500" MODIFIED="1532056889035" TEXT="&#x6240;&#x4ee5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519455370884" ID="ID_100295417" MODIFIED="1519455659043" TEXT="&#x5927;&#x6570;&#x636e;&#x4ee5;Java&#x6280;&#x672f;&#x4e3a;&#x57fa;&#x7840;&#xff0c;&#x5728;&#x719f;&#x7ec3;&#x638c;&#x63e1;&#x4e86;Java&#x6280;&#x672f;&#x4ee5;&#x540e;&#xff0c;&#x518d;&#x5b66;&#x4e60;&#x5927;&#x6570;&#x636e;&#x7684;&#x76f8;&#x5173;&#x6280;&#x672f;&#x4f1a;&#x5bb9;&#x6613;&#x5f88;&#x591a;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1519455753072" FOLDED="true" ID="ID_479734524" MODIFIED="1532056889035" TEXT="&#x5927;&#x6570;&#x636e;&#x4e3a;&#x4f55;&#x9009;&#x62e9;java">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1519455848410" FOLDED="true" ID="ID_128151154" MODIFIED="1532056889035">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      java&#30340;&#20248;&#21183;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519455768144" ID="ID_1877182329" MODIFIED="1519455774912" TEXT="&#x7b80;&#x5355;&#x6027;"/>
<node COLOR="#111111" CREATED="1519456114984" ID="ID_1619163749" MODIFIED="1519456122260" TEXT="&#x6613;&#x7528;&#x6027;"/>
<node COLOR="#111111" CREATED="1519455775884" ID="ID_790071832" MODIFIED="1519455780905" TEXT="&#x9762;&#x5411;&#x5bf9;&#x8c61;"/>
<node COLOR="#111111" CREATED="1519455781775" ID="ID_1630150104" MODIFIED="1519455787068" TEXT="&#x5206;&#x5e03;&#x5f0f;"/>
<node COLOR="#111111" CREATED="1531203383739" ID="ID_1941305877" MODIFIED="1531203384411" TEXT="&#x591a;&#x7ebf;&#x7a0b; "/>
<node COLOR="#111111" CREATED="1519455788005" FOLDED="true" ID="ID_414808762" MODIFIED="1532056889035" TEXT="&#x5065;&#x58ee;&#x6027;">
<node COLOR="#111111" CREATED="1519456254666" ID="ID_1111259476" MODIFIED="1519456297155" TEXT="&#x5065;&#x58ee;&#x6027;&#x662f;&#x6307;&#x8f6f;&#x4ef6;&#x5bf9;&#x4e8e;&#x89c4;&#x8303;&#x8981;&#x6c42;&#x4ee5;&#x5916;&#x7684;&#x8f93;&#x5165;&#x60c5;&#x51b5;&#x7684;&#x5904;&#x7406;&#x80fd;&#x529b;&#x3002;&#x6240;&#x8c13;&#x5065;&#x58ee;&#x7684;&#x7cfb;&#xa;&#x7edf;&#x662f;&#x6307;&#x5bf9;&#x4e8e;&#x89c4;&#x8303;&#x8981;&#x6c42;&#x4ee5;&#x5916;&#x7684;&#x8f93;&#x5165;&#x80fd;&#x591f;&#x5224;&#x65ad;&#x51fa;&#x8fd9;&#x4e2a;&#x8f93;&#x5165;&#x4e0d;&#x7b26;&#x5408;&#x89c4;&#x8303;&#x8981;&#x6c42;&#xff0c;&#x5e76;&#x80fd;&#x6709;&#x5408;&#x7406;&#x7684;&#x5904;&#x7406;&#x65b9;&#x5f0f;&#x3002;"/>
<node COLOR="#111111" CREATED="1519456220118" ID="ID_697921439" MODIFIED="1519456220119" TEXT="&#x5065;&#x58ee;&#x6027;&#x4f53;&#x73b0;&#x5728;java&#x5f02;&#x5e38;&#x5904;&#x7406;&#x673a;&#x5236;"/>
<node COLOR="#111111" CREATED="1519456226663" ID="ID_1292050391" MODIFIED="1519456226663" TEXT="&#x5065;&#x58ee;&#x6027;&#x7a0b;&#x5e8f;,1/9&#x662f;&#x6838;&#x5fc3;&#x4ee3;&#x7801; 2/9&#x662f;&#x6ce8;&#x91ca; 2/3&#x662f;&#x5904;&#x7406;&#x53ef;&#x80fd;&#x7684;&#x5f02;&#x5e38;"/>
<node COLOR="#111111" CREATED="1519456273341" FOLDED="true" ID="ID_1827476595" MODIFIED="1532056889035">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#28145;&#23618;&#27425;&#29702;&#35299;&#65306;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1519456273342" ID="ID_882377814" MODIFIED="1519456289497" TEXT="&#x5065;&#x58ee;&#x6027;&#x662f;&#x6307;&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#x9002;&#x5e94;&#x6b63;&#x5e38;&#x548c;&#x975e;&#x6b63;&#x5e38;&#x7684;&#x8fd0;&#x884c;&#x73af;&#x5883;&#xff0c;&#x90fd;&#x53ef;&#x4ee5;&#x6b63;&#x786e;&#x5730;&#x8fd0;&#x884c;&#xff1b;&#xa;&#x968f;&#x7740;&#x4e1a;&#x52a1;&#x91cf;&#x7684;&#x589e;&#x52a0;&#xff0c;&#x4e0d;&#x4f1a;&#x51fa;&#x73b0;&#x963b;&#x585e;&#x548c;&#x4e0d;&#x53ef;&#x7528;&#x7684;&#x60c5;&#x51b5;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1519455792963" FOLDED="true" ID="ID_1190336640" MODIFIED="1532056889035" TEXT="&#x5b89;&#x5168;&#x6027;">
<node COLOR="#111111" CREATED="1519456322145" ID="ID_1944772566" MODIFIED="1519456322146" TEXT="&#x7b2c;&#x4e00;&#x4e2a;&#x5c31;&#x662f;garbage collection&#xff0c;"/>
<node COLOR="#111111" CREATED="1519456326890" ID="ID_1382005901" MODIFIED="1519456326890" TEXT="&#x7b2c;&#x4e8c;&#x4e2a;&#x5c31;&#x662f;exception"/>
<node COLOR="#111111" CREATED="1519456338504" FOLDED="true" ID="ID_1577441869" MODIFIED="1532056889035">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#31532;&#19977;&#20010;&#23601;&#26159;&#25351;&#38024;,JAVA&#37324;&#38754;&#27809;&#26377;&#25351;&#38024;&#65281;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1519456360333" ID="ID_1439443277" MODIFIED="1519456360333" TEXT="&#x8fd9;&#x6837;&#x7684;&#x8bdd;&#x4eba;&#x4eec;&#x5c31;&#x4e0d;&#x80fd;access&#x4e0d;&#x8be5;access&#x7684;&#x5185;&#x5b58;&#x4e86;&#x3002;C&#x7684;&#x8bdd;&#x5c31;&#x975e;&#x5e38;&#x5371;&#x9669;&#x4e86;&#xff0c;&#x9ed1;&#x5ba2;&#x53ef;&#x4ee5;&#x8ba9;C&#x7684;&#x7a0b;&#x5e8f;stack overflow&#xff0c; &#x7136;&#x540e;&#x5728;overflow&#x7684;&#x5185;&#x5b58;&#x5730;&#x5740;&#x8df3;&#x5230;&#x4e00;&#x4e2a;&#x4e0d;&#x8be5;&#x8df3;&#x7684;&#x5730;&#x65b9;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1519455799543" FOLDED="true" ID="ID_1893853856" MODIFIED="1532056889035" TEXT="&#x5e73;&#x53f0;&#x72ec;&#x7acb;">
<node COLOR="#111111" CREATED="1519456414324" ID="ID_253797906" MODIFIED="1519456414324" TEXT="&#x5e73;&#x53f0;&#x72ec;&#x7acb;&#x6027;&#x662f;&#x6307;&#x53ef;&#x4ee5;&#x5728;&#x4e00;&#x4e2a;&#x5e73;&#x53f0;&#x4e0a;&#x7f16;&#x5199;&#x548c;&#x7f16;&#x8bd1;&#x7a0b;&#x5e8f;&#xff0c;&#x800c;&#x5728;&#x5176;&#x4ed6;&#x5e73;&#x53f0;&#x4e0a;&#x8fd0;&#x884c;"/>
</node>
<node COLOR="#111111" CREATED="1519455819760" FOLDED="true" ID="ID_1530474229" MODIFIED="1532056889035" TEXT="&#x53ef;&#x79fb;&#x690d;&#x6027;">
<node COLOR="#111111" CREATED="1519456426315" ID="ID_581604754" MODIFIED="1519456426315" TEXT="&#x4fdd;&#x8bc1;Java&#x5177;&#x6709;&#x5e73;&#x53f0;&#x72ec;&#x7acb;&#x6027;&#x7684;&#x673a;&#x5236;&#x4e3a;&#x201c;&#x4e2d;&#x95f4;&#x7801;&#xff08;&#x5b57;&#x8282;&#x7801;&#xff09;&#x201d;&#x548c;&#x201c;Java&#x865a;&#x62df;&#x673a;&#xff08;Java Virtual Machine&#xff0c;JVM&#xff09;&#x201d;"/>
<node COLOR="#111111" CREATED="1519456453912" ID="ID_994718099" MODIFIED="1519456453913" TEXT="&#x4e0d;&#x540c;&#x7684;&#x786c;&#x4ef6;&#x5e73;&#x53f0;&#x4e0a;&#x4f1a;&#x5b89;&#x88c5;&#x6709;&#x4e0d;&#x540c;&#x7684;JVM&#xff0c;&#x7531;JVM&#x6765;&#x8d1f;&#x8d23;&#x628a;&#x201c;&#x4e2d;&#x95f4;&#x7801;&#x201d;&#x7ffb;&#x8bd1;&#x6210;&#x786c;&#x4ef6;&#x5e73;&#x53f0;&#x80fd;&#x6267;&#x884c;&#x7684;&#x4ee3;&#x7801;&#x3002;&#x7531;&#x6b64;&#x53ef;&#x4ee5;&#x770b;&#x51fa;JVM&#x4e0d;&#x5177;&#x6709;&#x5e73;&#x53f0;&#x72ec;&#x7acb;&#x6027;&#xff0c;&#x800c;&#x662f;&#x4e0e;&#x786c;&#x4ef6;&#x5e73;&#x53f0;&#x76f8;&#x5173;&#x7684;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1519455812793" FOLDED="true" ID="ID_1044470543" MODIFIED="1532056889035" TEXT="&#x52a8;&#x6001;&#x6027;">
<node COLOR="#111111" CREATED="1519456544417" ID="ID_1220829346" MODIFIED="1519456544417" TEXT="Java&#x7684;&#x52a8;&#x6001;&#x6027;&#x662f;&#x5176;&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x8bbe;&#x8ba1;&#x7684;&#x6269;&#x5c55;. &#x5b83;&#x63d0;&#x4f9b;&#x8fd0;&#x884c;&#x65f6;&#x523b;&#x7684;&#x6269;&#x5c55;&#x6027;, &#x5373;&#x5728;&#x540e;&#x671f;&#x624d;&#x5efa;&#x7acb;&#x5404;&#x6a21;&#x5757;&#x95f4;&#x7684;&#x4e92;&#x8fde;. &#x5404;&#x4e2a;&#x5e93;&#x53ef;&#x4ee5;&#x81ea;&#x7531;&#x5730;&#x589e;&#x52a0;&#x65b0;&#x7684;&#x65b9;&#x6cd5;&#x548c;&#x5b9e;&#x4f8b;(instance)&#x53d8;&#x91cf;. &#x8fd9;&#x610f;&#x5473;&#x7740;&#x73b0;&#x6709;&#x7684;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x53ef;&#x4ee5;&#x589e;&#x52a0;&#x529f;&#x80fd;, &#x53ea;&#x987b;&#x94fe;&#x63a5;&#x65b0;&#x7c7b;&#x5c01;&#x88c5;&#x6709;&#x6240;&#x9700;&#x7684;&#x65b9;&#x6cd5;."/>
<node COLOR="#111111" CREATED="1519456544426" ID="ID_1974256127" MODIFIED="1519456544426" TEXT="C++&#x662f;&#x591a;&#x91cd;&#x7ee7;&#x627f;(multiple inheritance)&#x7684;, &#x82e5;&#x67d0;&#x4e2a;&#x8d85;&#x7c7b;(superclass) &#x6539;&#x53d8;&#x4e86;&#x67d0;&#x4e2a;&#x65b9;&#x6cd5;&#x6216;&#x53d8;&#x91cf;, &#x5176;&#x5b50;&#x7c7b;(subclass)&#x5fc5;&#x987b;&#x91cd;&#x65b0;&#x7f16;&#x8bd1;. Java&#x5219;&#x7528;&#x63a5;&#x53e3;(interface)&#x6765;&#x5b9e;&#x73b0;&#x591a;&#x7ea7;&#x7ee7;&#x627f;, &#x4f7f;&#x7528;&#x8d77;&#x6765;&#x6bd4;C++&#x7684;&#x591a;&#x91cd;&#x7ee7;&#x627f;&#x66f4;&#x7075;&#x6d3b;."/>
<node COLOR="#111111" CREATED="1519456544430" ID="ID_1285602159" MODIFIED="1519456544431" TEXT="Java&#x8bed;&#x8a00;&#x7684;&#x52a8;&#x6001;&#x6027;&#x4f7f;&#x5b83;&#x80fd;&#x591f;&#x80dc;&#x4efb;&#x5206;&#x5e03;&#x5f0f;&#x7cfb;&#x7edf;&#x73af;&#x5883;&#x4e0b;&#x7684;&#x5e94;&#x7528;, &#x4f4d;&#x4e8e;&#x5404;&#x5730;&#x7684;&#x7c7b;&#x53ef;&#x4ee5;&#x81ea;&#x7531;&#x5730;&#x5347;&#x7ea7;, &#x800c;&#x4e0d;&#x5f71;&#x54cd;&#x539f;Java&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x7684;&#x8fd0;&#x884c;."/>
</node>
<node COLOR="#111111" CREATED="1519456136599" FOLDED="true" ID="ID_429370662" MODIFIED="1532056889035" TEXT="&#x5f00;&#x6e90;&#x793e;&#x533a;&#x6d3b;&#x8dc3; ">
<node COLOR="#111111" CREATED="1519456589395" ID="ID_138529299" MODIFIED="1519456593229" TEXT="Github"/>
<node COLOR="#111111" CREATED="1519456594267" ID="ID_677446209" MODIFIED="1519456597585" TEXT="CSDN"/>
<node COLOR="#111111" CREATED="1519456598306" ID="ID_1013598516" MODIFIED="1519456603042" TEXT="&#x7801;&#x4e91;"/>
<node COLOR="#111111" CREATED="1519456604953" ID="ID_1940585805" MODIFIED="1519456608583" TEXT="&#x6155;&#x8bfe;&#x7f51;"/>
<node COLOR="#111111" CREATED="1519456611673" ID="ID_479233006" MODIFIED="1519456628465" TEXT="&#x5e76;&#x53d1;&#x7f16;&#x7a0b;&#x7f51;"/>
<node COLOR="#111111" CREATED="1519456639019" ID="ID_2685631" MODIFIED="1519456650529" TEXT="&#x5404;&#x4e2a;&#x5b98;&#x7f51;"/>
</node>
<node COLOR="#111111" CREATED="1519456658247" FOLDED="true" ID="ID_1711126777" MODIFIED="1532056889035" TEXT="&#x76f8;&#x5173;&#x4e66;&#x7c4d;&#x4e30;&#x5bcc;">
<node COLOR="#111111" CREATED="1519456679341" ID="ID_495403870" MODIFIED="1519456684241" TEXT="java&#x7f16;&#x7a0b;&#x601d;&#x60f3;"/>
<node COLOR="#111111" CREATED="1519456688579" ID="ID_162893032" MODIFIED="1519457914746" TEXT="java&#x6838;&#x5fc3;&#x6280;&#x672f; &#x4e09;&#x5377;"/>
<node COLOR="#111111" CREATED="1519456707458" ID="ID_1709655119" MODIFIED="1519456714759" TEXT="java&#x4ece;&#x5165;&#x95e8;&#x5230;&#x7cbe;&#x901a;"/>
<node COLOR="#111111" CREATED="1519456781761" FOLDED="true" ID="ID_606962585" MODIFIED="1532056889035" TEXT="&#x6846;&#x67b6;">
<node COLOR="#111111" CREATED="1519456788071" ID="ID_13964824" MODIFIED="1519456793446" TEXT="spring"/>
<node COLOR="#111111" CREATED="1519456793927" ID="ID_1330329615" MODIFIED="1519456797345" TEXT="springmvc"/>
<node COLOR="#111111" CREATED="1531203876385" ID="ID_1686611092" MODIFIED="1531203881114" TEXT="struts"/>
<node COLOR="#111111" CREATED="1519456797878" ID="ID_1473904722" MODIFIED="1519456800607" TEXT="hibernate"/>
<node COLOR="#111111" CREATED="1519456800947" ID="ID_746035850" MODIFIED="1519456804351" TEXT="mybatis"/>
<node COLOR="#111111" CREATED="1519456813169" ID="ID_38697275" MODIFIED="1519456821067" TEXT="cassandra"/>
</node>
</node>
<node COLOR="#111111" CREATED="1519456137507" ID="ID_739296763" MODIFIED="1519456143155" TEXT="&#x5386;&#x53f2;&#x60a0;&#x4e45;"/>
<node COLOR="#111111" CREATED="1519456163450" ID="ID_174470352" MODIFIED="1519456165772" TEXT="&#x5176;&#x4ed6;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1519456901997" FOLDED="true" ID="ID_1286906381" MODIFIED="1532056889035" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      java&#29256;&#26412;&#21644;&#20998;&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1519456934894" FOLDED="true" ID="ID_165219632" MODIFIED="1532056889035">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20998;&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1519456908630" FOLDED="true" ID="ID_786140034" MODIFIED="1532056889035" TEXT="Java SE&#xff08;Java Platform&#xff0c;Standard Edition&#xff09;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node BACKGROUND_COLOR="#ffcccc" COLOR="#111111" CREATED="1519457122995" ID="ID_418439839" MODIFIED="1519457257391" TEXT="Java SE &#x662f;&#x505a;&#x7535;&#x8111;&#x4e0a;&#x8fd0;&#x884c;&#x7684;&#x8f6f;&#x4ef6;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457028781" ID="ID_1922234932" MODIFIED="1519457030387" TEXT="Java SE &#x4ee5;&#x524d;&#x79f0;&#x4e3a; J2SE"/>
<node COLOR="#111111" CREATED="1519457016632" ID="ID_597028354" MODIFIED="1519457016632" TEXT="&#x5b83;&#x5141;&#x8bb8;&#x5f00;&#x53d1;&#x548c;&#x90e8;&#x7f72;&#x5728;&#x684c;&#x9762;&#x3001;&#x670d;&#x52a1;&#x5668;&#x3001;&#x5d4c;&#x5165;&#x5f0f;&#x73af;&#x5883;&#x548c;&#x5b9e;&#x65f6;&#x73af;&#x5883;&#x4e2d;&#x4f7f;&#x7528;&#x7684; Java &#x5e94;&#x7528;&#x7a0b;&#x5e8f;"/>
<node COLOR="#111111" CREATED="1519457054776" ID="ID_231154663" MODIFIED="1519457208512">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Java SE &#21253;&#21547;&#20102;&#25903;&#25345; Java Web &#26381;&#21153;&#24320;&#21457;&#30340;&#31867;&#65292;<br />&#24182;&#20026; Java Platform&#65292;Enterprise Edition&#65288;Java EE&#65289;&#25552;&#20379;&#22522;&#30784;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1519456911029" FOLDED="true" ID="ID_1554429202" MODIFIED="1532056889035" TEXT="ME">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node BACKGROUND_COLOR="#ffcccc" COLOR="#111111" CREATED="1519457180618" ID="ID_433566834" MODIFIED="1519457257392" TEXT="Java ME &#x662f;&#x505a;&#x624b;&#x673a;&#x8f6f;&#x4ef6;&#x7684;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457093123" ID="ID_1654574166" MODIFIED="1519457217341" TEXT="&#x8fd9;&#x4e2a;&#x7248;&#x672c;&#x4ee5;&#x524d;&#x79f0;&#x4e3a; J2ME&#x3002;Java ME &#x4e3a;&#x5728;&#x79fb;&#x52a8;&#x8bbe;&#x5907;&#x548c;&#x5d4c;&#x5165;&#x5f0f;&#x8bbe;&#x5907;&#xa;&#xff08;&#x6bd4;&#x5982;&#x624b;&#x673a;&#x3001;PDA&#x3001;&#x7535;&#x89c6;&#x673a;&#x9876;&#x76d2;&#x548c;&#x6253;&#x5370;&#x673a;&#xff09;&#x4e0a;&#x8fd0;&#x884c;&#x7684;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x63d0;&#xa;&#x4f9b;&#x4e00;&#x4e2a;&#x5065;&#x58ee;&#x4e14;&#x7075;&#x6d3b;&#x7684;&#x73af;&#x5883;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457101331" ID="ID_1909890622" MODIFIED="1519457197772" TEXT="Java ME &#x5305;&#x62ec;&#x7075;&#x6d3b;&#x7684;&#x7528;&#x6237;&#x754c;&#x9762;&#x3001;&#x5065;&#x58ee;&#x7684;&#x5b89;&#x5168;&#x6a21;&#x578b;&#x3001;&#x8bb8;&#x591a;&#x5185;&#x7f6e;&#x7684;&#xa;&#x7f51;&#x7edc;&#x534f;&#x8bae;&#x4ee5;&#x53ca;&#x5bf9;&#x53ef;&#x4ee5;&#x52a8;&#x6001;&#x4e0b;&#x8f7d;&#x7684;&#x8fde;&#x7f51;&#x548c;&#x79bb;&#x7ebf;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x7684;&#x4e30;&#x5bcc;&#x652f;&#xa;&#x6301;&#x3002;&#x57fa;&#x4e8e; Java ME &#x89c4;&#x8303;&#x7684;&#x5e94;&#x7528;&#x7a0b;&#x5e8f;&#x53ea;&#x9700;&#x7f16;&#x5199;&#x4e00;&#x6b21;&#xff0c;&#x5c31;&#x53ef;&#x4ee5;&#x7528;&#x4e8e;&#xa;&#x8bb8;&#x591a;&#x8bbe;&#x5907;&#xff0c;&#x800c;&#x4e14;&#x53ef;&#x4ee5;&#x5229;&#x7528;&#x6bcf;&#x4e2a;&#x8bbe;&#x5907;&#x7684;&#x672c;&#x673a;&#x529f;&#x80fd;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1519456912207" FOLDED="true" ID="ID_1890943790" MODIFIED="1532056889035" TEXT="EE">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node BACKGROUND_COLOR="#ffcccc" COLOR="#111111" CREATED="1519457138954" ID="ID_1656320636" MODIFIED="1519457257392" TEXT="Java EE &#x662f;&#x7528;&#x6765;&#x505a;&#x7f51;&#x7ad9;&#x7684;"/>
<node COLOR="#111111" CREATED="1519457151545" ID="ID_1458176054" MODIFIED="1519457231416">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36825;&#20010;&#29256;&#26412;&#20197;&#21069;&#31216;&#20026; J2EE&#12290;&#20225;&#19994;&#29256;&#26412;&#24110;&#21161;&#24320;&#21457;&#21644;&#37096;<br />&#32626;&#21487;&#31227;&#26893;&#12289;&#20581;&#22766;&#12289;&#21487;&#20280;&#32553;&#19988;&#23433;&#20840;&#30340;&#26381;&#21153;&#22120;&#31471; Java<br />&#160;&#24212;&#29992;&#31243;&#24207;&#12290;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1519457161698" ID="ID_613777267" MODIFIED="1519457243716" TEXT="Java EE &#x662f;&#x5728; Java SE &#x7684;&#x57fa;&#x7840;&#x4e0a;&#x6784;&#x5efa;&#x7684;&#xff0c;&#x5b83;&#x63d0;&#x4f9b; Web &#x670d;&#x52a1;&#x3001;&#xa;&#x7ec4;&#x4ef6;&#x6a21;&#x578b;&#x3001;&#x7ba1;&#x7406;&#x548c;&#x901a;&#x4fe1; API&#xff0c;&#x53ef;&#x4ee5;&#x7528;&#x6765;&#x5b9e;&#x73b0;&#x4f01;&#x4e1a;&#x7ea7;&#x7684;&#x9762;&#x5411;&#x670d;&#xa;&#x52a1;&#x4f53;&#x7cfb;&#x7ed3;&#x6784;&#xff08;service-oriented architecture&#xff0c;SOA&#xff09;&#x548c; Web 2.0 &#x5e94;&#x7528;&#x7a0b;&#x5e8f;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1519456943391" FOLDED="true" ID="ID_380169061" MODIFIED="1532056889035" TEXT="&#x7248;&#x672c;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1519457316726" FOLDED="true" ID="ID_630375486" MODIFIED="1532056889035" TEXT="JDK Version 1.0">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457321387" ID="ID_1698557792" MODIFIED="1519457321387" TEXT="&#x5f00;&#x53d1;&#x4ee3;&#x53f7;&#x4e3a;Oak&#xff08;&#x6a61;&#x6811;&#xff09;&#xff0c;&#x4e8e;1996-01-23&#x53d1;&#x884c;"/>
</node>
<node COLOR="#990000" CREATED="1519457301748" FOLDED="true" ID="ID_1713414733" MODIFIED="1532056889035" TEXT="JDK Version 1.1">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457310789" ID="ID_706507911" MODIFIED="1519457310789" TEXT="&#x4e8e;1997-02-19&#x53d1;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457310791" FOLDED="true" ID="ID_129208976" MODIFIED="1532056889035" TEXT="&#x5f15;&#x5165;&#x7684;&#x65b0;&#x7279;&#x6027;&#x5305;&#x62ec;&#xff1a;">
<node COLOR="#111111" CREATED="1519457310793" ID="ID_753710521" MODIFIED="1519457310793" TEXT="&#x5f15;&#x5165;JDBC&#xff08;Java Database Connectivity&#xff09;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457310795" ID="ID_1003228831" MODIFIED="1519457310795" TEXT="&#x652f;&#x6301;&#x5185;&#x90e8;&#x7c7b;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457310797" ID="ID_898858352" MODIFIED="1519457310797" TEXT="&#x5f15;&#x5165;Java Bean&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457310799" ID="ID_169811683" MODIFIED="1519457310799" TEXT="&#x5f15;&#x5165;RMI&#xff08;Remote Method Invocation&#xff09;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457310801" ID="ID_429206248" MODIFIED="1519457310801" TEXT="&#x5f15;&#x5165;&#x53cd;&#x5c04;&#xff08;&#x4ec5;&#x7528;&#x4e8e;&#x5185;&#x7701;&#xff09;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457335440" FOLDED="true" ID="ID_551012589" MODIFIED="1532056889035" TEXT="J2SE Version 1.2">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457347150" ID="ID_1630625296" MODIFIED="1519457347150" TEXT="&#x5f00;&#x53d1;&#x4ee3;&#x53f7;&#x4e3a;Playground&#xff08;&#x64cd;&#x573a;&#xff09;&#xff0c;&#x4e8e;1998-12-08&#x53d1;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457347156" FOLDED="true" ID="ID_1505647796" MODIFIED="1532056889035" TEXT="&#x5f15;&#x5165;&#x7684;&#x65b0;&#x7279;&#x6027;&#x5305;&#x62ec;&#xff1a;">
<node COLOR="#111111" CREATED="1519457347159" ID="ID_1914016180" MODIFIED="1519457347159" TEXT="&#x5f15;&#x5165;&#x96c6;&#x5408;&#xff08;Collection&#xff09;&#x6846;&#x67b6;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347160" ID="ID_454724620" MODIFIED="1519457347160" TEXT="&#x5bf9;&#x5b57;&#x7b26;&#x4e32;&#x5e38;&#x91cf;&#x505a;&#x5185;&#x5b58;&#x6620;&#x5c04;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347162" ID="ID_416878886" MODIFIED="1519457347162" TEXT="&#x5f15;&#x5165;JIT&#xff08;Just In Time&#xff09;&#x7f16;&#x8bd1;&#x5668;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347167" ID="ID_1103907233" MODIFIED="1519457347167" TEXT="&#x5f15;&#x5165;&#x5bf9;&#x6253;&#x5305;&#x7684;Java&#x6587;&#x4ef6;&#x8fdb;&#x884c;&#x6570;&#x5b57;&#x7b7e;&#x540d;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347169" ID="ID_1233980857" MODIFIED="1519457347169" TEXT="&#x5f15;&#x5165;&#x63a7;&#x5236;&#x6388;&#x6743;&#x8bbf;&#x95ee;&#x7cfb;&#x7edf;&#x8d44;&#x6e90;&#x7684;&#x7b56;&#x7565;&#x5de5;&#x5177;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347171" ID="ID_850058460" MODIFIED="1519457347171" TEXT="&#x5f15;&#x5165;JFC&#xff08;Java Foundation Classes&#xff09;&#xff0c;&#x5305;&#x62ec;Swing 1.0&#x3001;&#x62d6;&#x653e;&#x548c;Java 2D&#x7c7b;&#x5e93;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347172" ID="ID_1155503976" MODIFIED="1519457347172" TEXT="&#x5f15;&#x5165;Java &#x63d2;&#x4ef6;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347173" ID="ID_1767738823" MODIFIED="1519457347173" TEXT="&#x5728;JDBC&#x4e2d;&#x5f15;&#x5165;&#x53ef;&#x6eda;&#x52a8;&#x7ed3;&#x679c;&#x96c6;&#x3001;BLOB&#x3001;CLOB&#x3001;&#x6279;&#x91cf;&#x66f4;&#x65b0;&#x548c;&#x7528;&#x6237;&#x81ea;&#x5b9a;&#x4e49;&#x7c7b;&#x578b;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457347174" ID="ID_1753488273" MODIFIED="1519457347174" TEXT="&#x5728;Applet&#x4e2d;&#x6dfb;&#x52a0;&#x58f0;&#x97f3;&#x652f;&#x6301;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457354492" FOLDED="true" ID="ID_209548699" MODIFIED="1532056889035" TEXT="J2SE Version 1.3">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457362680" ID="ID_451085409" MODIFIED="1519457362680" TEXT="&#x5f00;&#x53d1;&#x4ee3;&#x53f7;&#x4e3a;Kestrel&#xff08;&#x7ea2;&#x96bc;&#xff09;&#xff0c;&#x4e8e;2000-05-08&#x53d1;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457362680" FOLDED="true" ID="ID_1489945321" MODIFIED="1532056889035" TEXT="&#x5f15;&#x5165;&#x7684;&#x65b0;&#x7279;&#x6027;&#x5305;&#x62ec;&#xff1a;">
<node COLOR="#111111" CREATED="1519457362681" ID="ID_564287496" MODIFIED="1519457362681" TEXT="&#x5f15;&#x5165;Java Sound API&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457362681" ID="ID_1076081637" MODIFIED="1519457362681" TEXT="jar&#x6587;&#x4ef6;&#x7d22;&#x5f15;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457362682" ID="ID_1734097766" MODIFIED="1519457362682" TEXT="&#x5bf9;Java&#x7684;&#x5404;&#x4e2a;&#x65b9;&#x9762;&#x90fd;&#x505a;&#x4e86;&#x5927;&#x91cf;&#x4f18;&#x5316;&#x548c;&#x589e;&#x5f3a;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457386926" FOLDED="true" ID="ID_472250708" MODIFIED="1532056889035" TEXT="J2SE Version 1.4">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457393725" ID="ID_1673870733" MODIFIED="1519457393726" TEXT="&#x5f00;&#x53d1;&#x4ee3;&#x53f7;&#x4e3a;Merlin&#xff08;&#x96bc;&#xff09;&#xff0c;&#x4e8e;2004-02-06&#x53d1;&#x884c;&#xff08;&#x9996;&#x6b21;&#x5728;JCP&#x4e0b;&#x53d1;&#x884c;&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457399309" FOLDED="true" ID="ID_982231007" MODIFIED="1532056889035" TEXT="&#x5f15;&#x5165;&#x7684;&#x65b0;&#x7279;&#x6027;&#x5305;&#x62ec;:">
<node COLOR="#111111" CREATED="1519457399310" ID="ID_1640844799" MODIFIED="1519457399310" TEXT="XML&#x5904;&#x7406;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399312" ID="ID_37425076" MODIFIED="1519457399312" TEXT="Java&#x6253;&#x5370;&#x670d;&#x52a1;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399313" ID="ID_1173911950" MODIFIED="1519457399313" TEXT="&#x5f15;&#x5165;Logging API&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399314" ID="ID_1329273543" MODIFIED="1519457399314" TEXT="&#x5f15;&#x5165;Java Web Start&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399315" ID="ID_178689927" MODIFIED="1519457399315" TEXT="&#x5f15;&#x5165;JDBC 3.0 API&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399316" ID="ID_1237576023" MODIFIED="1519457399317" TEXT="&#x5f15;&#x5165;&#x65ad;&#x8a00;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399318" ID="ID_658683639" MODIFIED="1519457399318" TEXT="&#x5f15;&#x5165;Preferences API&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399320" ID="ID_1472952986" MODIFIED="1519457399321" TEXT="&#x5f15;&#x5165;&#x94fe;&#x5f0f;&#x5f02;&#x5e38;&#x5904;&#x7406;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399323" ID="ID_1408425713" MODIFIED="1519457399323" TEXT="&#x652f;&#x6301;IPv6&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399324" ID="ID_370064810" MODIFIED="1519457399324" TEXT="&#x652f;&#x6301;&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457399325" ID="ID_36645475" MODIFIED="1519457399326" TEXT="&#x5f15;&#x5165;Image I/O slot machine API&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457411146" FOLDED="true" ID="ID_376435440" MODIFIED="1532056889035" TEXT="Java Version SE 5.0">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457429870" ID="ID_561721311" MODIFIED="1519457431321" TEXT="&#x5f00;&#x53d1;&#x4ee3;&#x53f7;&#x4e3a;Tiger&#xff08;&#x8001;&#x864e;&#xff09;&#xff0c;&#x4e8e;2004-09-30&#x53d1;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457422582" FOLDED="true" ID="ID_1957636007" MODIFIED="1532056889035" TEXT="&#x5f15;&#x5165;&#x7684;&#x65b0;&#x7279;&#x6027;&#x5305;&#x62ec;:">
<node COLOR="#111111" CREATED="1519457422583" ID="ID_820113471" MODIFIED="1519457422583" TEXT="&#x5f15;&#x5165;&#x6cdb;&#x578b;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457422584" ID="ID_149607790" MODIFIED="1519457422585" TEXT="&#x589e;&#x5f3a;&#x5faa;&#x73af;&#xff0c;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;&#x8fed;&#x4ee3;&#x65b9;&#x5f0f;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457422586" ID="ID_725459328" MODIFIED="1519457422586" TEXT="&#x81ea;&#x52a8;&#x88c5;&#x7bb1;&#x4e0e;&#x81ea;&#x52a8;&#x62c6;&#x7bb1;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457422587" ID="ID_787003671" MODIFIED="1519457422587" TEXT="&#x7c7b;&#x578b;&#x5b89;&#x5168;&#x7684;&#x679a;&#x4e3e;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457422593" ID="ID_1991022093" MODIFIED="1519457422593" TEXT="&#x53ef;&#x53d8;&#x53c2;&#x6570;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457422595" ID="ID_702905181" MODIFIED="1519457422595" TEXT="&#x9759;&#x6001;&#x5f15;&#x5165;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457422597" ID="ID_1464196350" MODIFIED="1519457422597" TEXT="&#x5143;&#x6570;&#x636e;&#xff08;&#x6ce8;&#x89e3;&#xff09;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457422602" ID="ID_25556195" MODIFIED="1519457422602" TEXT="&#x5f15;&#x5165;Instrumentation&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457448335" FOLDED="true" ID="ID_509928343" MODIFIED="1532056889035">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <h2>
      <strong><font size="4"><b>Java Version SE 6</b></font></strong>
    </h2>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457449191" ID="ID_1308696491" MODIFIED="1519457449191" TEXT="&#x5f00;&#x53d1;&#x4ee3;&#x53f7;&#x4e3a;Mustang&#xff08;&#x91ce;&#x9a6c;&#xff09;&#xff0c;&#x4e8e;2006-12-11&#x53d1;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457449192" FOLDED="true" ID="ID_53535527" MODIFIED="1532056889035" TEXT="&#x5f15;&#x5165;&#x7684;&#x65b0;&#x7279;&#x6027;&#x5305;&#x62ec;&#xff1a;">
<node COLOR="#111111" CREATED="1519457449193" ID="ID_63873541" MODIFIED="1519457449193" TEXT="&#x652f;&#x6301;&#x811a;&#x672c;&#x8bed;&#x8a00;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457449194" ID="ID_101581315" MODIFIED="1519457449195" TEXT="&#x5f15;&#x5165;JDBC 4.0 API&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457449195" ID="ID_1568355050" MODIFIED="1519457449195" TEXT="&#x5f15;&#x5165;Java Compiler API&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457449196" ID="ID_754265677" MODIFIED="1519457449196" TEXT="&#x53ef;&#x63d2;&#x62d4;&#x6ce8;&#x89e3;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457449197" ID="ID_592985925" MODIFIED="1519457449197" TEXT="&#x589e;&#x52a0;&#x5bf9;Native PKI(Public Key Infrastructure)&#x3001;Java GSS(Generic Security Service)&#x3001;Kerberos&#x548c;LDAP(Lightweight Directory Access Protocol)&#x7684;&#x652f;&#x6301;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457449200" ID="ID_1043849521" MODIFIED="1519457449200" TEXT="&#x7ee7;&#x627f;Web Services&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457449201" ID="ID_1403229901" MODIFIED="1519457449201" TEXT="&#x505a;&#x4e86;&#x5f88;&#x591a;&#x4f18;&#x5316;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457483196" FOLDED="true" ID="ID_968535728" MODIFIED="1532056889035" TEXT="Java  SE 7">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457492750" ID="ID_997598798" MODIFIED="1519457492750" TEXT="&#x5f00;&#x53d1;&#x4ee3;&#x53f7;&#x662f;Dolphin&#xff08;&#x6d77;&#x8c5a;&#xff09;&#xff0c;&#x4e8e;2011-07-28&#x53d1;&#x884c;&#x3002;"/>
<node COLOR="#111111" CREATED="1519457492752" FOLDED="true" ID="ID_997719191" MODIFIED="1532056889035" TEXT="&#x5f15;&#x5165;&#x7684;&#x65b0;&#x7279;&#x6027;&#x5305;&#x62ec;&#xff1a;">
<node COLOR="#111111" CREATED="1519457492753" ID="ID_1725635590" MODIFIED="1519457492754" TEXT="switch&#x8bed;&#x53e5;&#x5757;&#x4e2d;&#x5141;&#x8bb8;&#x4ee5;&#x5b57;&#x7b26;&#x4e32;&#x4f5c;&#x4e3a;&#x5206;&#x652f;&#x6761;&#x4ef6;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492757" ID="ID_1328741622" MODIFIED="1519457492757" TEXT="&#x5728;&#x521b;&#x5efa;&#x6cdb;&#x578b;&#x5bf9;&#x8c61;&#x65f6;&#x5e94;&#x7528;&#x7c7b;&#x578b;&#x63a8;&#x65ad;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492759" ID="ID_1953452812" MODIFIED="1519457492759" TEXT="&#x5728;&#x4e00;&#x4e2a;&#x8bed;&#x53e5;&#x5757;&#x4e2d;&#x6355;&#x83b7;&#x591a;&#x79cd;&#x5f02;&#x5e38;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492761" ID="ID_1860481864" MODIFIED="1519457492761" TEXT="&#x652f;&#x6301;&#x52a8;&#x6001;&#x8bed;&#x8a00;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492762" ID="ID_952499573" MODIFIED="1519457492762" TEXT="&#x652f;&#x6301;try-with-resources&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492763" ID="ID_1938075973" MODIFIED="1519457492763" TEXT="&#x5f15;&#x5165;Java NIO.2&#x5f00;&#x53d1;&#x5305;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492764" ID="ID_423690098" MODIFIED="1519457492764" TEXT="&#x6570;&#x503c;&#x7c7b;&#x578b;&#x53ef;&#x4ee5;&#x7528;2&#x8fdb;&#x5236;&#x5b57;&#x7b26;&#x4e32;&#x8868;&#x793a;&#xff0c;&#x5e76;&#x4e14;&#x53ef;&#x4ee5;&#x5728;&#x5b57;&#x7b26;&#x4e32;&#x8868;&#x793a;&#x4e2d;&#x6dfb;&#x52a0;&#x4e0b;&#x5212;&#x7ebf;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492765" ID="ID_1647783511" MODIFIED="1519457492765" TEXT="&#x94bb;&#x77f3;&#x578b;&#x8bed;&#x6cd5;&#xff1b;"/>
<node COLOR="#111111" CREATED="1519457492766" ID="ID_1851178912" MODIFIED="1519457492766" TEXT="null&#x503c;&#x7684;&#x81ea;&#x52a8;&#x5904;&#x7406;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457517100" FOLDED="true" ID="ID_1521518205" MODIFIED="1532056889035" TEXT="Java SE 8">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519457529453" ID="ID_1831190328" MODIFIED="1519457529453" TEXT="Java SE 8&#x53d1;&#x884c;&#x4e8e;2014&#x5e74;3&#x6708;18&#x65e5;&#xff0c;&#x4ee3;&#x53f7;culture&#xff0c;&#x8fd9;&#x662f;&#x4e00;&#x4e2a;&#x5728;Java&#x5386;&#x53f2;&#x4e0a;&#x7684;&#x91cd;&#x5927;&#x53d1;&#x5e03;"/>
<node COLOR="#111111" CREATED="1519457529457" FOLDED="true" ID="ID_629394728" MODIFIED="1532056889035" TEXT="Java SE 8 &#x65b0;&#x7279;&#x6027;&#xff1a;">
<node COLOR="#111111" CREATED="1519457529458" ID="ID_1218309501" MODIFIED="1519457529459" TEXT="Lambda Expressions(Lambda&#x8868;&#x8fbe;&#x5f0f;)"/>
<node COLOR="#111111" CREATED="1519457529468" ID="ID_561387394" MODIFIED="1519457529468" TEXT="Pipelines and Streams(&#x7ba1;&#x9053;&#x548c;&#x6d41;)"/>
<node COLOR="#111111" CREATED="1519457529472" ID="ID_1054746472" MODIFIED="1519457529472" TEXT="Date and Time API(&#x65e5;&#x671f;&#x548c;&#x65f6;&#x95f4;API)"/>
<node COLOR="#111111" CREATED="1519457529474" ID="ID_362688416" MODIFIED="1519457529474" TEXT="Default Methods(&#x63a5;&#x53e3;&#x53ef;&#x4ee5;&#x6709;&#x9ed8;&#x8ba4;&#x65b9;&#x6cd5;)"/>
<node COLOR="#111111" CREATED="1519457529477" ID="ID_445179699" MODIFIED="1519457529477" TEXT="Type Annotations(&#x7c7b;&#x578b;&#x6ce8;&#x89e3;)"/>
<node COLOR="#111111" CREATED="1519457529478" ID="ID_1383467940" MODIFIED="1519457529478" TEXT="Nashhorn JavaScript Engine"/>
<node COLOR="#111111" CREATED="1519457529479" ID="ID_691111278" MODIFIED="1519457529479" TEXT="Concurrent Accumulators(&#x5e76;&#x884c;&#x7d2f;&#x52a0;&#x5668;)"/>
<node COLOR="#111111" CREATED="1519457529480" ID="ID_1939190068" MODIFIED="1519457529480" TEXT="Parallel operations(&#x5e73;&#x884c;&#x4f5c;&#x4e1a;)"/>
<node COLOR="#111111" CREATED="1519457529480" ID="ID_476518433" MODIFIED="1519457529481" TEXT="PermGen Error Removed"/>
<node COLOR="#111111" CREATED="1519457529481" ID="ID_1117877997" MODIFIED="1519457529481" TEXT="TLS SNI"/>
</node>
</node>
<node COLOR="#990000" CREATED="1519457722077" FOLDED="true" ID="ID_1686428375" MODIFIED="1532056889035" TEXT="Java SE 9">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1519458031059" FOLDED="true" ID="ID_938137818" MODIFIED="1532056889035" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---JShell&#x5de5;&#x5177;">
<node COLOR="#111111" CREATED="1519458047871" ID="ID_135910385" MODIFIED="1519458047871" TEXT="&#x76f8;&#x5f53;&#x4e8e;cmd&#x5de5;&#x5177;&#xff0c;&#x4f60;&#x53ef;&#x4ee5;&#x548c;cmd&#x4e00;&#x6837;&#xff0c;&#x76f4;&#x63a5;&#x5199;&#x65b9;&#x6cd5;&#x7b49;&#x7b49;&#xff0c;&#x4e0d;&#x8fc7;&#x6211;&#x8ba4;&#x4e3a;&#x53ea;&#x662f;&#x9002;&#x7528;&#x4e8e;&#x521d;&#x5b66;&#x8005;&#x505a;&#x4e00;&#x4e9b;&#x6700;&#x7b80;&#x5355;&#x7684;&#x8fd0;&#x7b97;&#x548c;&#x5199;&#x4e00;&#x4e9b;&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1519458054908" ID="ID_69710703" MODIFIED="1519458054908" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---&#x6a21;&#x5757;&#x5316;"/>
<node COLOR="#111111" CREATED="1519458069277" ID="ID_1545808070" MODIFIED="1519458069277" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---&#x591a;&#x7248;&#x672c;&#x517c;&#x5bb9;Jar&#x5305;"/>
<node COLOR="#111111" CREATED="1519458103687" ID="ID_1700646635" MODIFIED="1519458103687" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---&#x63a5;&#x53e3;Interface&#x7684;&#x5347;&#x7ea7;"/>
<node COLOR="#111111" CREATED="1519458110537" FOLDED="true" ID="ID_1628641278" MODIFIED="1532056889035" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---&#x94bb;&#x77f3;&#x64cd;&#x4f5c;&#x7b26;&#x7684;&#x5347;&#x7ea7;">
<node COLOR="#111111" CREATED="1519458128901" ID="ID_653039579" MODIFIED="1519458130344" TEXT="&#x5982;: //java9 &#x6dfb;&#x52a0;&#x4e86;&#x533f;&#x540d;&#x5185;&#x90e8;&#x7c7b;&#x7684;&#x529f;&#x80fd; &#x540e;&#x9762;&#x6dfb;&#x52a0;&#x4e86;&#x5927;&#x62ec;&#x53f7;{}  &#x53ef;&#x4ee5;&#x505a;&#x4e00;&#x4e9b;&#x7ec6;&#x8282;&#x7684;&#x64cd;&#x4f5c; Map&lt;String,String&gt; map9 = new HashMap&lt;&gt;(){};"/>
</node>
<node COLOR="#111111" CREATED="1519458139875" ID="ID_755706014" MODIFIED="1519458139875" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---&#x5f02;&#x5e38;&#x5904;&#x7406;try&#x5347;&#x7ea7;"/>
<node COLOR="#111111" CREATED="1519458235189" ID="ID_615827786" MODIFIED="1519458235191" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---&#x7279;&#x6b8a;&#x6807;&#x8bc6;&#x7b26;&#x589e;&#x52a0;&#x9650;&#x5236;"/>
<node COLOR="#111111" CREATED="1519458242547" FOLDED="true" ID="ID_323885237" MODIFIED="1532056889035" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---String&#x5e95;&#x5c42;&#x5b58;&#x50a8;&#x7ed3;&#x6784;&#x66f4;&#x6362;">
<node COLOR="#111111" CREATED="1519458255963" ID="ID_888365807" MODIFIED="1519458255963" TEXT="java8&#x4e4b;&#x524d; String&#x7684;&#x5e95;&#x5c42;&#x7ed3;&#x6784;&#x7c7b;&#x578b;&#x90fd;&#x662f; char[] ,&#x4f46;&#x662f;java9 &#x5c31;&#x66ff;&#x6362;&#x6210; byte[] &#x8fd9;&#x6837;&#x6765;&#x8bb2;&#xff0c;&#x66f4;&#x8282;&#x7701;&#x4e86;&#x7a7a;&#x95f4;&#x548c;&#x63d0;&#x9ad8;&#x4e86;&#x6027;&#x80fd;"/>
</node>
<node COLOR="#111111" CREATED="1519458282339" ID="ID_861207302" MODIFIED="1519458282340" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---Stream API &#x65b0;&#x65b9;&#x6cd5;&#x7684;&#x6dfb;&#x52a0;"/>
<node COLOR="#111111" CREATED="1519458325623" FOLDED="true" ID="ID_1303864740" MODIFIED="1532056889035" TEXT="Java9&#x65b0;&#x7279;&#x6027;&#x4e4b;---&#x5f15;&#x8fdb;HttpClient">
<node COLOR="#111111" CREATED="1519458331502" ID="ID_78432153" MODIFIED="1519458331502" TEXT="&#x4ee5;&#x5f80;&#x6211;&#x4eec;&#x90fd;&#x662f;&#x901a;&#x8fc7;maven&#x6dfb;&#x52a0;httpclient ,java9&#x76f4;&#x63a5;&#x5f15;&#x5165;&#x5373;&#x53ef;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1472778719120" FOLDED="true" ID="ID_158575747" MODIFIED="1532056889051" POSITION="left" TEXT="&#x53cd;&#x5c04;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1488894794198" FOLDED="true" ID="ID_1636711203" MODIFIED="1532056889035" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488894815229" ID="ID_1182392763" MODIFIED="1488894815230" TEXT="JAVA&#x53cd;&#x5c04;&#x673a;&#x5236;&#x662f;&#x5728;&#x8fd0;&#x884c;&#x72b6;&#x6001;&#x4e2d;&#xff0c;&#x5bf9;&#x4e8e;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x7c7b;&#xff0c;&#x90fd;&#x80fd;&#x591f;&#x77e5;&#x9053;&#x8fd9;&#x4e2a;&#x7c7b;&#x7684;&#x6240;&#x6709;&#x5c5e;&#x6027;&#x548c;&#x65b9;&#x6cd5;&#xff1b;&#x5bf9;&#x4e8e;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;&#xff0c;&#x90fd;&#x80fd;&#x591f;&#x8c03;&#x7528;&#x5b83;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#xff1b;&#x8fd9;&#x79cd;&#x52a8;&#x6001;&#x83b7;&#x53d6;&#x7684;&#x4fe1;&#x606f;&#x4ee5;&#x53ca;&#x52a8;&#x6001;&#x8c03;&#x7528;&#x5bf9;&#x8c61;&#x7684;&#x65b9;&#x6cd5;&#x7684;&#x529f;&#x80fd;&#x79f0;&#x4e3a;java&#x8bed;&#x8a00;&#x7684;&#x53cd;&#x5c04;&#x673a;&#x5236;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1488894777684" FOLDED="true" ID="ID_1075289687" MODIFIED="1532056889035" TEXT="&#x4f5c;&#x7528;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488894791401" ID="ID_437072897" MODIFIED="1488895009853" TEXT="&#x589e;&#x52a0;&#x7a0b;&#x5e8f;&#x7684;&#x7075;&#x6d3b;&#x6027;&#xff0c;&#x907f;&#x514d;&#x5c06;&#x7a0b;&#x5e8f;&#x5199;&#x6b7b;&#x5230;&#x4ee3;&#x7801;&#x91cc;">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="messagebox_warning"/>
</node>
<node COLOR="#990000" CREATED="1488894926455" ID="ID_727608659" MODIFIED="1488894977093" TEXT="Java&#x7684;&#x4ee3;&#x7801;&#x603b;&#x662f;&#x5728;new&#x5bf9;&#x8c61;,&#x4e00;&#x4e2a;&#x7c7b;&#x6301;&#x6709;&#x53e6;&#x4e00;&#x4e2a;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;&#x5c31;&#x628a;&#x8fd9;&#x4e24;&#x4e2a;&#x7c7b;&#x5173;&#x8054;&#x4e86;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488894977556" ID="ID_619863349" MODIFIED="1488894996275" TEXT="&#x8fd9;&#x6837;&#x5c31;&#x589e;&#x52a0;&#x7684;&#x7c7b;&#x548c;&#x7c7b;&#x4e4b;&#x95f4;&#x7684;&#x8026;&#x5408;&#x6027;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488895014475" ID="ID_1562226175" MODIFIED="1488895040554" TEXT="&#x4f7f;&#x7528;&#x53cd;&#x5c04;&#x53ef;&#x4ee5;&#x4f7f;&#x7c7b;&#x95f4;&#x7684;&#x8026;&#x5408;&#x6027;&#x964d;&#x4f4e;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488895041422" ID="ID_1405001149" MODIFIED="1488895065086" TEXT="&#x6bd4;&#x5982;SpringMvc&#x4e2d;&#x7684;&#x914d;&#x7f6e;&#x6587;&#x4ef6;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1488900082012" FOLDED="true" ID="ID_1689043458" MODIFIED="1532056889051" TEXT="&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488900098693" FOLDED="true" ID="ID_695971592" MODIFIED="1532056889051" TEXT="Class">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488900745875" FOLDED="true" ID="ID_1678404618" MODIFIED="1532056889051" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1488900699044" FOLDED="true" ID="ID_110272482" MODIFIED="1532056889035" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1488900701083" ID="ID_873170286" MODIFIED="1489030684233" TEXT="public static Class&lt;?&gt; forName(String name, boolean initialize,ClassLoader loader) "/>
<node COLOR="#111111" CREATED="1488900713378" FOLDED="true" ID="ID_554567236" MODIFIED="1532056889035" TEXT="public static Class&lt;?&gt; forName(String className)">
<node COLOR="#111111" CREATED="1489030821304" ID="ID_732681055" MODIFIED="1489030821305" TEXT="Class&lt;Goods&gt; cls = Goods.class;"/>
<node COLOR="#111111" CREATED="1489030827184" ID="ID_266148662" MODIFIED="1489030870159" TEXT="Class&lt;Goods&gt; class1 = Class.forName(&quot;com.zhiyou.Goods&quot;);"/>
<node COLOR="#111111" CREATED="1489030830093" ID="ID_1486608170" MODIFIED="1489030839037" TEXT="&#x4e8c;&#x8005;&#x610f;&#x601d;&#x4e00;&#x81f4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488900736907" FOLDED="true" ID="ID_1084223571" MODIFIED="1532056889035" TEXT="public T newInstance()">
<node COLOR="#111111" CREATED="1488900751574" ID="ID_1845106445" MODIFIED="1488900768934" TEXT="&#x5b9e;&#x4f8b;&#x5316;&#x4e00;&#x4e2a;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1488900978795" FOLDED="true" ID="ID_112701555" MODIFIED="1532056889035" TEXT="public native boolean isInstance(Object obj)">
<node COLOR="#111111" CREATED="1488900981374" ID="ID_840941652" MODIFIED="1488900996639" TEXT="obj&#x662f;&#x5426;&#x662f;&#x8be5;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1488901017011" FOLDED="true" ID="ID_377456556" MODIFIED="1532056889035" TEXT="public String getName()">
<node COLOR="#111111" CREATED="1488901092739" ID="ID_1236468043" MODIFIED="1488901109936" TEXT="&#x7c7b;&#x540d;&#x5168;&#x8def;&#x5f84;"/>
</node>
<node COLOR="#111111" CREATED="1488901087636" FOLDED="true" ID="ID_216598457" MODIFIED="1532056889035" TEXT="public String getSimpleName()">
<node COLOR="#111111" CREATED="1488901112104" ID="ID_863957921" MODIFIED="1488901123014" TEXT="&#x53ea;&#x662f;&#x7c7b;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1488901032222" FOLDED="true" ID="ID_852241569" MODIFIED="1532056889035" TEXT="public ClassLoader getClassLoader()">
<node COLOR="#111111" CREATED="1488902235073" ID="ID_1487739533" MODIFIED="1488902243655" TEXT="&#x83b7;&#x53d6;&#x7c7b;&#x52a0;&#x8f7d;&#x5668;"/>
</node>
<node COLOR="#111111" CREATED="1488901310793" ID="ID_155711364" MODIFIED="1489040032746" TEXT="public Field[] getFields()">
<arrowlink DESTINATION="ID_1464281949" ENDARROW="Default" ENDINCLINATION="250;0;" ID="Arrow_ID_1640141355" STARTARROW="None" STARTINCLINATION="244;0;"/>
</node>
<node COLOR="#111111" CREATED="1488901692847" ID="ID_1862518131" MODIFIED="1488902316241" TEXT="public Field[] getDeclaredFields() ">
<arrowlink DESTINATION="ID_800005156" ENDARROW="Default" ENDINCLINATION="276;0;" ID="Arrow_ID_725741206" STARTARROW="None" STARTINCLINATION="276;0;"/>
</node>
<node COLOR="#111111" CREATED="1488901351376" FOLDED="true" ID="ID_1443327623" MODIFIED="1532056889035" TEXT="public Field getField(String name)">
<node COLOR="#111111" CREATED="1488901354001" ID="ID_1840051560" MODIFIED="1488901368446" TEXT="&#x83b7;&#x53d6;&#x4e00;&#x4e2a;&#x5b57;&#x6bb5;,name&#x6307;&#x7684;&#x662f;&#x5b57;&#x6bb5;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1488901340865" ID="ID_1588856857" MODIFIED="1488902280287" TEXT="public Constructor&lt;?&gt;[] getConstructors()"/>
<node COLOR="#111111" CREATED="1488901600880" ID="ID_1550087621" MODIFIED="1488902280289" TEXT="public Constructor&lt;?&gt;[] getDeclaredConstructors()"/>
<node COLOR="#111111" CREATED="1488901952210" ID="ID_1481092290" MODIFIED="1488902280290" TEXT="public Constructor&lt;T&gt; getDeclaredConstructor(Class&lt;?&gt;... parameterTypes)">
<arrowlink COLOR="#0000ff" DESTINATION="ID_1437099928" ENDARROW="Default" ENDINCLINATION="361;0;" ID="Arrow_ID_1049970411" STARTARROW="None" STARTINCLINATION="361;0;"/>
</node>
<node COLOR="#111111" CREATED="1488901326412" ID="ID_1331011990" MODIFIED="1488901326412" TEXT="public Method[] getMethods()"/>
<node COLOR="#111111" CREATED="1488902122340" ID="ID_1952494444" MODIFIED="1488902124883" TEXT="public Method[] getDeclaredMethods()"/>
<node COLOR="#111111" CREATED="1488901818272" FOLDED="true" ID="ID_67202095" MODIFIED="1532056889035" TEXT="public Method getMethod(String name, Class&lt;?&gt;... parameterTypes)">
<node COLOR="#111111" CREATED="1488901827464" ID="ID_1667581583" MODIFIED="1488902220333" TEXT="&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x7c7b;&#x5355;&#x4e2a;public&#x65b9;&#x6cd5;Method"/>
<node COLOR="#111111" CREATED="1489040604179" FOLDED="true" ID="ID_712271682" MODIFIED="1532056889035" TEXT="name">
<node COLOR="#111111" CREATED="1489040609323" ID="ID_1410197348" MODIFIED="1489040614856" TEXT="&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x65b9;&#x6cd5;&#x540d;"/>
</node>
<node COLOR="#111111" CREATED="1489040625038" FOLDED="true" ID="ID_841538186" MODIFIED="1532056889035" TEXT="parameterTypes">
<node COLOR="#111111" CREATED="1489040626527" ID="ID_690107351" MODIFIED="1489040633956" TEXT="&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x53c2;&#x6570;&#x7684;&#x7c7b;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488902178503" FOLDED="true" ID="ID_1439437689" MODIFIED="1532056889035" TEXT="public Method getDeclaredMethod(String name, Class&lt;?&gt;... parameterTypes)">
<node COLOR="#111111" CREATED="1488901827464" ID="ID_138628327" MODIFIED="1488902226817" TEXT="&#x83b7;&#x53d6;&#x5f53;&#x524d;&#x7c7b;&#x548c;&#x7236;&#x7c7b;&#x5355;&#x4e2a;&#x4efb;&#x610f;&#x65b9;&#x6cd5;Method"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488901699928" FOLDED="true" ID="ID_1705348652" MODIFIED="1532056889051" TEXT="&#x6ce8;&#x610f;">
<node COLOR="#111111" CREATED="1488901736010" FOLDED="true" ID="ID_1464281949" MODIFIED="1532056889051" TEXT="&#x4e0d;&#x5e26;Declared&#x7684;">
<node COLOR="#111111" CREATED="1488901371778" ID="ID_1806644274" MODIFIED="1522668200070" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x7c7b;&#x6216;&#x63a5;&#x53e3;&#x6240;&#x6709;&#x7684;public&#x7684;&#x57df;,&#x4f46;&#x4e0d;&#x5305;&#x542b;&#x7ee7;&#x627f;&#x7684;&#x65b9;&#x6cd5;(&#x4e0d;&#x5305;&#x542b;&#x88ab;&#x590d;&#x5199;&#x7684;&#x65b9;&#x6cd5;)"/>
<node COLOR="#111111" CREATED="1522668309874" ID="ID_138963045" MODIFIED="1522668349380" TEXT="&#x5982;&#x679c;&#x662f;&#x63a5;&#x53e3;&#x5219;&#x5305;&#x542b;&#x63a5;&#x53e3;&#x4e2d;&#x7684;default&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1488901711042" FOLDED="true" ID="ID_800005156" MODIFIED="1532056889051" TEXT="&#x5e26;Declared">
<node COLOR="#111111" CREATED="1488901607464" ID="ID_925631075" MODIFIED="1522668204720" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x7c7b;&#x6216;&#x63a5;&#x53e3;&#x4e2d;&#x7684;&#x6240;&#x6709;&#x7684;&#x65b9;&#x6cd5;(&#x4e0d;&#x5305;&#x542b;&#x88ab;&#x590d;&#x5199;&#x7684;&#x65b9;&#x6cd5;),&#x4e0d;&#x8bba;&#x662f;&#x4ec0;&#x4e48;&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;"/>
<node COLOR="#111111" CREATED="1522668309874" ID="ID_510254946" MODIFIED="1522668349380" TEXT="&#x5982;&#x679c;&#x662f;&#x63a5;&#x53e3;&#x5219;&#x5305;&#x542b;&#x63a5;&#x53e3;&#x4e2d;&#x7684;default&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1488901845272" FOLDED="true" ID="ID_1437099928" MODIFIED="1532056889051" TEXT="parameterTypes">
<node COLOR="#111111" CREATED="1488901854096" ID="ID_722245164" MODIFIED="1488901895803" TEXT="&#x6307;&#x7684;&#x662f;&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;&#x4e2d;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1488901909745" ID="ID_1210934100" MODIFIED="1488901924816" TEXT="&#x5982;&#x679c;&#x4e0d;&#x5199;&#x5219;&#x4ee3;&#x8868;&#x6ca1;&#x6709;&#x53c2;&#x6570;"/>
<node COLOR="#111111" CREATED="1488901892679" ID="ID_494024775" MODIFIED="1488901892679" TEXT="&#x6bd4;&#x5982;String.class,Integer.class"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1488900117020" FOLDED="true" ID="ID_1662628869" MODIFIED="1532056889051" TEXT="Constructor">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902363509" FOLDED="true" ID="ID_599957466" MODIFIED="1532056889051" TEXT="public String getName()">
<node COLOR="#111111" CREATED="1489040711224" ID="ID_132499742" MODIFIED="1489040719495" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1488902384978" FOLDED="true" ID="ID_1981829051" MODIFIED="1532056889051" TEXT="public Class&lt;?&gt;[] getParameterTypes()">
<node COLOR="#111111" CREATED="1489040727843" ID="ID_1443999976" MODIFIED="1489040739065" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;&#x7684;&#x7c7b;&#x578b;&#x6570;&#x7ec4;"/>
</node>
<node COLOR="#111111" CREATED="1488902431884" FOLDED="true" ID="ID_1433092426" MODIFIED="1532056889051" TEXT="public T newInstance(Object ... initargs)">
<node COLOR="#111111" CREATED="1488902433837" ID="ID_811240114" MODIFIED="1488902459583" TEXT="&#x521d;&#x59cb;&#x5316;&#x5f53;&#x524d;&#x7c7b;,&#x76f8;&#x5f53;&#x4e8e;new &#x8be5;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;"/>
<node COLOR="#111111" CREATED="1488902468753" FOLDED="true" ID="ID_144952567" MODIFIED="1532056889051" TEXT="initargs">
<node COLOR="#111111" CREATED="1488902470405" ID="ID_1151790937" MODIFIED="1488902492239" TEXT="&#x521d;&#x59cb;&#x5316;&#x53c2;&#x6570;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;,&#x591a;&#x4e2a;,&#x6216;&#x8005;&#x6ca1;&#x6709;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1489040766662" FOLDED="true" ID="ID_1923473935" MODIFIED="1532056889051" TEXT="public int getParameterCount()">
<node COLOR="#111111" CREATED="1489040769848" ID="ID_976890080" MODIFIED="1489040775302" TEXT="&#x53c2;&#x6570;&#x7684;&#x6570;&#x91cf;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1488900104481" FOLDED="true" ID="ID_1965265368" MODIFIED="1532056889051" TEXT="Method">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902527971" ID="ID_479748297" MODIFIED="1488902527971" TEXT="public String getName()"/>
<node COLOR="#111111" CREATED="1488902704915" FOLDED="true" ID="ID_1813692187" MODIFIED="1532056889051" TEXT="public Class&lt;?&gt; getReturnType()">
<node COLOR="#111111" CREATED="1489040802390" ID="ID_1259319078" MODIFIED="1489040811247" TEXT="&#x8fd4;&#x56de;&#x503c;&#x7684;&#x7c7b;&#x578b;"/>
</node>
<node COLOR="#111111" CREATED="1488902717070" FOLDED="true" ID="ID_1798325885" MODIFIED="1532056889051" TEXT="public int getModifiers()">
<node COLOR="#111111" CREATED="1488902720369" ID="ID_1310653195" MODIFIED="1488902730336" TEXT="&#x8fd4;&#x56de;&#x65b9;&#x6cd5;&#x7684;&#x4fee;&#x9970;&#x7b26;&#x7ea7;&#x522b;"/>
</node>
<node COLOR="#111111" CREATED="1488902764893" FOLDED="true" ID="ID_1378406028" MODIFIED="1532056889051" TEXT="public Class&lt;?&gt;[] getParameterTypes()">
<node COLOR="#111111" CREATED="1488902768351" ID="ID_1661621796" MODIFIED="1488902775117" TEXT="&#x83b7;&#x53d6;&#x65b9;&#x6cd5;&#x53c2;&#x6570;&#x7684;&#x7c7b;&#x578b;"/>
</node>
<node COLOR="#111111" CREATED="1488902799472" FOLDED="true" ID="ID_350058596" MODIFIED="1532056889051" TEXT="public Object invoke(Object obj, Object... args)">
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="messagebox_warning"/>
<node COLOR="#111111" CREATED="1488902806652" ID="ID_866579516" MODIFIED="1488902812844" TEXT="&#x8c03;&#x7528;&#x8be5;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1488902819133" FOLDED="true" ID="ID_188337432" MODIFIED="1532056889051" TEXT="obj">
<node COLOR="#111111" CREATED="1488902824954" ID="ID_218387315" MODIFIED="1488902869718" TEXT="&#x5f53;&#x524d;&#x65b9;&#x6cd5;&#x6240;&#x5c5e;&#x7684;&#x5bf9;&#x8c61;&#x7684;&#x5b9e;&#x4f8b;:"/>
<node COLOR="#111111" CREATED="1488902870749" ID="ID_1413395924" MODIFIED="1488902870749" TEXT="&#x5982; currentClass.newInstance()"/>
</node>
<node COLOR="#111111" CREATED="1488902872450" FOLDED="true" ID="ID_142739352" MODIFIED="1532056889051" TEXT="args">
<node COLOR="#111111" CREATED="1488902877077" ID="ID_1583523602" MODIFIED="1488902895093" TEXT="&#x8be5;&#x65b9;&#x6cd5;&#x7684;&#x5b9e;&#x9645;&#x53c2;&#x6570;&#x5217;&#x8868;"/>
<node COLOR="#111111" CREATED="1488902895702" ID="ID_244331569" MODIFIED="1488902907188" TEXT="&#x5982;&#x679c;&#x65b9;&#x6cd5;&#x6ca1;&#x6709;&#x53c2;&#x6570;&#x5217;&#x8868;,&#x5219;&#x4e0d;&#x5199;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1488900110164" FOLDED="true" ID="ID_1538661656" MODIFIED="1532056889051" TEXT="Field">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488902527971" ID="ID_743333299" MODIFIED="1488902527971" TEXT="public String getName()"/>
<node COLOR="#111111" CREATED="1488902717070" FOLDED="true" ID="ID_26958035" MODIFIED="1532056889051" TEXT="public int getModifiers()">
<node COLOR="#111111" CREATED="1488902720369" ID="ID_498700612" MODIFIED="1488902967746" TEXT="&#x8fd4;&#x56de;&#x5b57;&#x6bb5;&#x7684;&#x4fee;&#x9970;&#x7b26;&#x7ea7;&#x522b;"/>
</node>
<node COLOR="#111111" CREATED="1488902986086" ID="ID_458712022" MODIFIED="1488902986086" TEXT="public Class&lt;?&gt; getType()"/>
<node COLOR="#111111" CREATED="1488903159491" FOLDED="true" ID="ID_182616805" MODIFIED="1532056889051" TEXT="&#x83b7;&#x53d6;&#x5b57;&#x6bb5;&#x7684;&#x503c;">
<node COLOR="#111111" CREATED="1488903001496" FOLDED="true" ID="ID_1160794707" MODIFIED="1532056889051" TEXT="public Object get(Object obj)">
<node COLOR="#111111" CREATED="1488903004936" ID="ID_597597690" MODIFIED="1488903021345" TEXT="&#x83b7;&#x53d6;&#x8be5;&#x5c5e;&#x6027;&#x7684;&#x503c;"/>
<node COLOR="#111111" CREATED="1488903021910" ID="ID_1904519562" MODIFIED="1488903032980" TEXT="&#x8fd4;&#x56de;object&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1488902819133" FOLDED="true" ID="ID_1447672923" MODIFIED="1532056889051" TEXT="obj">
<node COLOR="#111111" CREATED="1488902824954" ID="ID_1729739" MODIFIED="1488902869718" TEXT="&#x5f53;&#x524d;&#x65b9;&#x6cd5;&#x6240;&#x5c5e;&#x7684;&#x5bf9;&#x8c61;&#x7684;&#x5b9e;&#x4f8b;:"/>
<node COLOR="#111111" CREATED="1488902870749" ID="ID_1304734660" MODIFIED="1488902870749" TEXT="&#x5982; currentClass.newInstance()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488903092344" ID="ID_1974883132" MODIFIED="1488903092344" TEXT="public boolean getBoolean(Object obj)"/>
<node COLOR="#111111" CREATED="1488903098849" ID="ID_668732950" MODIFIED="1488903098849" TEXT="public byte getByte(Object obj)"/>
<node COLOR="#111111" CREATED="1488903105032" ID="ID_1374161554" MODIFIED="1488903105032" TEXT="public char getChar(Object obj)"/>
<node COLOR="#111111" CREATED="1488903110635" ID="ID_1620588224" MODIFIED="1488903110635" TEXT="public short getShort(Object obj)"/>
<node COLOR="#111111" CREATED="1488903116790" ID="ID_1438739495" MODIFIED="1488903116790" TEXT="public int getInt(Object obj)"/>
<node COLOR="#111111" CREATED="1488903125419" ID="ID_1402875625" MODIFIED="1488903125419" TEXT="public long getLong(Object obj)"/>
<node COLOR="#111111" CREATED="1488903133754" ID="ID_657672434" MODIFIED="1488903133754" TEXT="public float getFloat(Object obj)"/>
<node COLOR="#111111" CREATED="1488903142011" ID="ID_1981476235" MODIFIED="1488903142011" TEXT="public double getDouble(Object obj)"/>
</node>
<node COLOR="#111111" CREATED="1488903183929" FOLDED="true" ID="ID_1394651076" MODIFIED="1532056889051" TEXT="&#x8bbe;&#x7f6e;&#x5b57;&#x6bb5;&#x7684;&#x503c;">
<node COLOR="#111111" CREATED="1488903153743" ID="ID_64736057" MODIFIED="1488903153743" TEXT="public void set(Object obj, Object value)"/>
<node COLOR="#111111" CREATED="1488903181097" ID="ID_1651229698" MODIFIED="1488903181097" TEXT="public void setBoolean(Object obj, boolean z)"/>
<node COLOR="#111111" CREATED="1488903200675" ID="ID_1809994066" MODIFIED="1488903200675" TEXT="public void setByte(Object obj, byte b)"/>
<node COLOR="#111111" CREATED="1488903208173" ID="ID_1801341428" MODIFIED="1488903208173" TEXT="public void setChar(Object obj, char c)"/>
<node COLOR="#111111" CREATED="1488903214541" ID="ID_1806279262" MODIFIED="1488903214541" TEXT="public void setShort(Object obj, short s)"/>
<node COLOR="#111111" CREATED="1488903222095" ID="ID_569349012" MODIFIED="1488903222096" TEXT="public void setInt(Object obj, int i)"/>
<node COLOR="#111111" CREATED="1488903231150" ID="ID_59894851" MODIFIED="1488903231150" TEXT="public void setLong(Object obj, long l)"/>
<node COLOR="#111111" CREATED="1488903237561" ID="ID_1766134866" MODIFIED="1488903237561" TEXT="public void setFloat(Object obj, float f)"/>
<node COLOR="#111111" CREATED="1488903243047" ID="ID_1743778394" MODIFIED="1488903243047" TEXT="public void setDouble(Object obj, double d)"/>
</node>
</node>
<node COLOR="#990000" CREATED="1488900582271" FOLDED="true" ID="ID_1204787274" MODIFIED="1532056889051" TEXT="ClassLoader">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488900595415" FOLDED="true" ID="ID_996107887" MODIFIED="1532056889051" TEXT="?">
<node COLOR="#111111" CREATED="1488900600259" ID="ID_794891248" MODIFIED="1488900634675" TEXT="cls.getClass().getClassLoader()"/>
<node COLOR="#111111" CREATED="1488900635170" ID="ID_568739875" MODIFIED="1488900659335" TEXT="&#x6216; xx.class.getClassLoader()"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1495165320374" FOLDED="true" ID="ID_704462203" LINK="https://www.cnblogs.com/skywang12345/p/3327482.html" MODIFIED="1532307148935" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Calendar
    </p>
  </body>
</html></richcontent>
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1495379470846" FOLDED="true" ID="ID_1905388504" MODIFIED="1532056889051" TEXT="&#x5b50;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495379486981" FOLDED="true" ID="ID_139777292" MODIFIED="1532056889051" TEXT="GregorianCalendar">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495379247895" FOLDED="true" ID="ID_1212969357" MODIFIED="1532056889051" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495379328241" ID="ID_401690031" MODIFIED="1495379500023" TEXT="public GregorianCalendar()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379328243" ID="ID_1593212286" MODIFIED="1495379500023" TEXT="public GregorianCalendar(TimeZone zone)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379328245" ID="ID_826860783" MODIFIED="1495379500023" TEXT="public GregorianCalendar(Locale aLocale)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379328245" ID="ID_400951275" MODIFIED="1495379500023" TEXT="public GregorianCalendar(TimeZone zone, Locale aLocale)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379328247" ID="ID_1066407353" MODIFIED="1495379500023" TEXT="public GregorianCalendar(int year, int month, int dayOfMonth)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379258204" ID="ID_1293823291" MODIFIED="1495379500023">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      public GregorianCalendar(int year, int month, int dayOfMonth, int hourOfDay,int minute, int second)
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379286010" ID="ID_1338944000" MODIFIED="1495379500023" TEXT="public GregorianCalendar(int year, int month, int dayOfMonth, int hourOfDay,  int minute)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495379362696" FOLDED="true" ID="ID_932164755" MODIFIED="1532056889051" TEXT="&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495379365206" ID="ID_1662440090" MODIFIED="1495379500082" TEXT="public void setGregorianChange(Date date)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365207" ID="ID_1471229743" MODIFIED="1495379500082" TEXT="public final Date getGregorianChange()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365208" ID="ID_972985599" MODIFIED="1495379500082" TEXT="public boolean isLeapYear(int year)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365210" ID="ID_1921537451" MODIFIED="1495379500083" TEXT="public String getCalendarType()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365211" ID="ID_160713349" MODIFIED="1495379500083" TEXT="public boolean equals(Object obj)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365212" ID="ID_414456385" MODIFIED="1495379500083" TEXT="public int hashCode()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365213" FOLDED="true" ID="ID_720403763" MODIFIED="1532056889051" TEXT="public void add(int field, int amount)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495382137715" ID="ID_686452252" MODIFIED="1495382166987" TEXT="&#x8c03;&#x6574;&#x6307;&#x5b9a;&#x5b57;&#x6bb5;,&#x6bd4;&#x4ed6;&#x5927;&#x7684;&#x5b57;&#x6bb5;&#x4e5f;&#x4f1a;&#x81ea;&#x52a8;&#x88ab;&#x6539;&#x53d8;"/>
</node>
<node COLOR="#111111" CREATED="1495379365214" ID="ID_810550189" MODIFIED="1495379500083" TEXT="public void roll(int field, boolean up)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365217" ID="ID_763729617" MODIFIED="1495379500083" TEXT="public void roll(int field, int amount)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365219" FOLDED="true" ID="ID_1377007669" MODIFIED="1532056889051" TEXT="public int getMinimum(int field)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495381695155" ID="ID_231274992" MODIFIED="1495381695155" TEXT="&#x8fd4;&#x56de;&#x6b64; Calendar &#x5b9e;&#x4f8b;&#x7ed9;&#x5b9a;&#x65e5;&#x5386;&#x5b57;&#x6bb5;&#x7684;&#x6700;&#x5c0f;&#x503c;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495379365219" FOLDED="true" ID="ID_1264494190" MODIFIED="1532056889051" TEXT="public int getMaximum(int field)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495381681164" ID="ID_1282064535" MODIFIED="1495381681164" TEXT="&#x8fd4;&#x56de;&#x6b64; Calendar &#x5b9e;&#x4f8b;&#x7ed9;&#x5b9a;&#x65e5;&#x5386;&#x5b57;&#x6bb5;&#x7684;&#x6700;&#x5927;&#x503c;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495379365220" ID="ID_972448808" MODIFIED="1495379500083" TEXT="public int getGreatestMinimum(int field)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365221" ID="ID_1144467469" MODIFIED="1495379500083" TEXT="public int getLeastMaximum(int field)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365222" FOLDED="true" ID="ID_1288537649" MODIFIED="1532056889051" TEXT="public int getActualMinimum(int field)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495382238786" ID="ID_1849591271" MODIFIED="1495382238786" TEXT="&#x7ed9;&#x5b9a;&#x6b64; Calendar &#x7684;&#x65f6;&#x95f4;&#x503c;&#xff0c;&#x8fd4;&#x56de;&#x6307;&#x5b9a;&#x65e5;&#x5386;&#x5b57;&#x6bb5;&#x53ef;&#x80fd;&#x62e5;&#x6709;&#x7684;&#x6700;&#x5c0f;&#x503c;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495379365223" FOLDED="true" ID="ID_1917478397" MODIFIED="1532056889051" TEXT="public int getActualMaximum(int field)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495382220250" ID="ID_1749432877" MODIFIED="1495382220251" TEXT="&#x7ed9;&#x5b9a;&#x6b64; Calendar &#x7684;&#x65f6;&#x95f4;&#x503c;&#xff0c;&#x8fd4;&#x56de;&#x6307;&#x5b9a;&#x65e5;&#x5386;&#x5b57;&#x6bb5;&#x53ef;&#x80fd;&#x62e5;&#x6709;&#x7684;&#x6700;&#x5927;&#x503c;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1495379365226" ID="ID_889251365" MODIFIED="1495379500084" TEXT="public TimeZone getTimeZone()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365228" ID="ID_521142104" MODIFIED="1495379500084" TEXT="public void setTimeZone(TimeZone zone)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365229" ID="ID_229403415" MODIFIED="1495379500084" TEXT="public final boolean isWeekDateSupported()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365230" ID="ID_140918862" MODIFIED="1495379500084" TEXT="public int getWeekYear()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365230" ID="ID_19809537" MODIFIED="1495379500084" TEXT="public void setWeekDate(int weekYear, int weekOfYear, int dayOfWeek)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365232" ID="ID_216463787" MODIFIED="1495379500084" TEXT="public int getWeeksInWeekYear()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365233" ID="ID_1156852890" MODIFIED="1495379500084" TEXT="public ZonedDateTime toZonedDateTime()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495379365234" ID="ID_1181122181" MODIFIED="1495379500084" TEXT="public static GregorianCalendar from(ZonedDateTime zdt)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1495379760331" FOLDED="true" ID="ID_1012081596" MODIFIED="1532070950620" TEXT="&#x5e38;&#x91cf;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495379763991" ID="ID_278206898" MODIFIED="1495379763991" TEXT="public final static int ERA = 0">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379763997" ID="ID_984604597" MODIFIED="1495379763997" TEXT="public final static int YEAR = 1">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379763998" ID="ID_901597561" MODIFIED="1495379763998" TEXT="public final static int MONTH = 2">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764001" ID="ID_15734053" MODIFIED="1495379764002" TEXT="public final static int WEEK_OF_YEAR = 3">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764004" ID="ID_230435240" MODIFIED="1495379764005" TEXT="public final static int WEEK_OF_MONTH = 4">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764006" ID="ID_1589895430" MODIFIED="1495379764006" TEXT="public final static int DATE = 5">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764007" FOLDED="true" ID="ID_1625485412" MODIFIED="1532056889051" TEXT="public final static int DAY_OF_MONTH = 5">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1531651567290" ID="ID_1711956438" MODIFIED="1531651577337" TEXT="&#x51e0;&#x53f7;"/>
</node>
<node COLOR="#990000" CREATED="1495379764010" ID="ID_1289869398" MODIFIED="1495379764011" TEXT="public final static int DAY_OF_YEAR = 6">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764011" FOLDED="true" ID="ID_22012558" MODIFIED="1532056889051" TEXT="public final static int DAY_OF_WEEK = 7">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1531651583670" ID="ID_619969076" MODIFIED="1531651631216" TEXT="&#x5468;&#x65e5;&#x4f5c;&#x4e3a;&#x4e00;&#x5468;&#x7684;&#x7b2c;&#x4e00;&#x5929;,&#x662f;1,&#x5468;&#x4e00;&#x662f;2,&#x5468;&#x516d;&#x662f;7"/>
</node>
<node COLOR="#990000" CREATED="1495379764012" ID="ID_908901761" MODIFIED="1495379764012" TEXT="public final static int DAY_OF_WEEK_IN_MONTH = 8">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764013" ID="ID_1625645745" MODIFIED="1495379764013" TEXT="public final static int AM_PM = 9">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764014" ID="ID_1596918507" MODIFIED="1495379764014" TEXT="public final static int HOUR = 10">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764015" ID="ID_1552570383" MODIFIED="1495379764015" TEXT="public final static int HOUR_OF_DAY = 11">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764015" ID="ID_231605025" MODIFIED="1495379764016" TEXT="public final static int MINUTE = 12">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764016" ID="ID_249631964" MODIFIED="1495379764016" TEXT="public final static int SECOND = 13">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764017" ID="ID_1865120634" MODIFIED="1495379764017" TEXT="public final static int MILLISECOND = 14">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764017" ID="ID_335537211" MODIFIED="1495379764018" TEXT="public final static int ZONE_OFFSET = 15">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764018" ID="ID_1638532838" MODIFIED="1495379764018" TEXT="public final static int DST_OFFSET = 16">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764019" ID="ID_89477967" MODIFIED="1495379764019" TEXT="public final static int FIELD_COUNT = 17">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764020" ID="ID_205177919" MODIFIED="1495379764020" TEXT="public final static int SUNDAY = 1">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764021" ID="ID_829078537" MODIFIED="1495379764021" TEXT="public final static int MONDAY = 2">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764024" ID="ID_1305923244" MODIFIED="1495379764024" TEXT="public final static int TUESDAY = 3">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764025" ID="ID_400731683" MODIFIED="1495379764025" TEXT="public final static int WEDNESDAY = 4">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764026" ID="ID_1966180037" MODIFIED="1495379764026" TEXT="public final static int THURSDAY = 5">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764027" ID="ID_535530570" MODIFIED="1495379764027" TEXT="public final static int FRIDAY = 6">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764028" ID="ID_783442618" MODIFIED="1495379764028" TEXT="public final static int SATURDAY = 7">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764029" ID="ID_687064915" MODIFIED="1495379764029" TEXT="public final static int JANUARY = 0">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764030" ID="ID_495961579" MODIFIED="1495379764030" TEXT="public final static int FEBRUARY = 1">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764031" ID="ID_818225641" MODIFIED="1495379764031" TEXT="public final static int MARCH = 2">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764031" ID="ID_665886733" MODIFIED="1495379764031" TEXT="public final static int APRIL = 3">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764031" ID="ID_612779736" MODIFIED="1495379764032" TEXT="public final static int MAY = 4">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764032" ID="ID_774455203" MODIFIED="1495379764032" TEXT="public final static int JUNE = 5">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764032" ID="ID_1356156803" MODIFIED="1495379764032" TEXT="public final static int JULY = 6">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764033" ID="ID_828366590" MODIFIED="1495379764033" TEXT="public final static int AUGUST = 7">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764033" ID="ID_147798273" MODIFIED="1495379764033" TEXT="public final static int SEPTEMBER = 8">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764033" ID="ID_1748220300" MODIFIED="1495379764034" TEXT="public final static int OCTOBER = 9">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764034" ID="ID_1351127665" MODIFIED="1495379764034" TEXT="public final static int NOVEMBER = 10">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764035" ID="ID_750478839" MODIFIED="1495379764036" TEXT="public final static int DECEMBER = 11">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764036" ID="ID_258273015" MODIFIED="1495379764036" TEXT="public final static int UNDECIMBER = 12">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764036" ID="ID_461837498" MODIFIED="1495379764037" TEXT="public final static int AM = 0">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764037" ID="ID_340675240" MODIFIED="1495379764037" TEXT="public final static int PM = 1">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764037" ID="ID_1403128776" MODIFIED="1495379764037" TEXT="public static final int ALL_STYLES = 0">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764038" ID="ID_1238995758" MODIFIED="1495379764038" TEXT="public static final int SHORT = 1">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764038" ID="ID_1292937578" MODIFIED="1495379764039" TEXT="public static final int LONG = 2">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764039" ID="ID_1018501837" MODIFIED="1495379764039" TEXT="public static final int NARROW_FORMAT = 4">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764040" ID="ID_531381242" MODIFIED="1495379764040" TEXT="public static final int NARROW_STANDALONE = NARROW_FORMAT | STANDALONE_MASK">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764040" ID="ID_1035087816" MODIFIED="1495379764040" TEXT="public static final int SHORT_FORMAT = 1">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764040" ID="ID_1819975831" MODIFIED="1495379764040" TEXT="public static final int LONG_FORMAT = 2">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764041" ID="ID_347315538" MODIFIED="1495379764041" TEXT="public static final int SHORT_STANDALONE = SHORT | STANDALONE_MASK">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379764041" ID="ID_1963390798" MODIFIED="1495379764041" TEXT="public static final int LONG_STANDALONE = LONG | STANDALONE_MASK">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495379767126" FOLDED="true" ID="ID_520443429" MODIFIED="1532056889051" TEXT="&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495379812232" FOLDED="true" ID="ID_1609151968" MODIFIED="1532056889051" TEXT="public final Date getTime()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495379842813" ID="ID_769349308" MODIFIED="1495379850307" TEXT="&#x83b7;&#x53d6;&#x65e5;&#x671f;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#990000" CREATED="1495379812233" FOLDED="true" ID="ID_1998743426" MODIFIED="1532056889051" TEXT="public final void setTime(Date date)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495379852619" ID="ID_742074271" MODIFIED="1495379856412" TEXT="&#x8bbe;&#x7f6e;&#x65e5;&#x671f;&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#990000" CREATED="1495379812233" FOLDED="true" ID="ID_1038031840" MODIFIED="1532056889051" TEXT="public long getTimeInMillis()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495379951289" ID="ID_316952632" MODIFIED="1495379959942" TEXT="&#x83b7;&#x53d6;&#x65f6;&#x95f4;&#x7684;&#x6beb;&#x79d2;&#x503c;"/>
</node>
<node COLOR="#990000" CREATED="1495379812235" FOLDED="true" ID="ID_748486583" MODIFIED="1532056889051" TEXT="public void setTimeInMillis(long millis)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495381925991" ID="ID_1394760145" MODIFIED="1495381925991" TEXT="&#x7528;&#x7ed9;&#x5b9a;&#x7684; long &#x503c;&#x8bbe;&#x7f6e;&#x6b64; Calendar &#x7684;&#x5f53;&#x524d;&#x65f6;&#x95f4;&#x503c;"/>
</node>
<node COLOR="#990000" CREATED="1495379812235" ID="ID_765733860" MODIFIED="1495379812236" TEXT="public String getDisplayName(int field, int style, Locale locale)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812236" ID="ID_1817178011" MODIFIED="1495379812236" TEXT="public Map&lt;String, Integer&gt; getDisplayNames(int field, int style, Locale locale)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812237" ID="ID_1621286275" MODIFIED="1495379812237" TEXT="public static Set&lt;String&gt; getAvailableCalendarTypes()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812238" ID="ID_1240588989" MODIFIED="1495379812238" TEXT="public String getCalendarType()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812239" ID="ID_1619281116" MODIFIED="1495379812239" TEXT="public boolean equals(Object obj)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812251" FOLDED="true" ID="ID_1104964284" MODIFIED="1532056889051" TEXT="public boolean before(Object when)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495380161473" ID="ID_208848110" MODIFIED="1495380179984" TEXT="&#x5bf9;&#x6bd4;Calendar&#x4ee3;&#x8868;&#x7684;&#x65f6;&#x95f4;&#x7684;&#x65e9;&#x665a;"/>
</node>
<node COLOR="#990000" CREATED="1495379812252" ID="ID_1670904846" MODIFIED="1495379812252" TEXT="public boolean after(Object when)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812253" ID="ID_368380754" MODIFIED="1495379812253" TEXT="public int compareTo(Calendar anotherCalendar)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812254" ID="ID_1468069262" MODIFIED="1495379812254" TEXT="public boolean isWeekDateSupported()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812255" ID="ID_1266102725" MODIFIED="1495379812255" TEXT="public int getWeekYear()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812257" ID="ID_496286962" MODIFIED="1495379812257" TEXT="public void setWeekDate(int weekYear, int weekOfYear, int dayOfWeek)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812259" FOLDED="true" ID="ID_1993192431" MODIFIED="1532056889051" TEXT="public int getWeeksInWeekYear()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495382491045" ID="ID_977686990" MODIFIED="1495382505346" TEXT="Returns the number of weeks in the week year represented by this calendar"/>
</node>
<node COLOR="#990000" CREATED="1495379812263" FOLDED="true" ID="ID_1081562351" MODIFIED="1532056889051" TEXT="public int getActualMinimum(int field)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495381531416" ID="ID_1149558270" MODIFIED="1495381531416" TEXT="&#x7ed9;&#x5b9a;&#x6b64; Calendar &#x7684;&#x65f6;&#x95f4;&#x503c;&#xff0c;&#x8fd4;&#x56de;&#x6307;&#x5b9a;&#x65e5;&#x5386;&#x5b57;&#x6bb5;&#x53ef;&#x80fd;&#x62e5;&#x6709;&#x7684;&#x6700;&#x5c0f;&#x503c;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1495379812264" FOLDED="true" ID="ID_1733112750" MODIFIED="1532056889051" TEXT="public int getActualMaximum(int field)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495381540817" ID="ID_351453535" MODIFIED="1495381540817" TEXT="&#x7ed9;&#x5b9a;&#x6b64; Calendar &#x7684;&#x65f6;&#x95f4;&#x503c;&#xff0c;&#x8fd4;&#x56de;&#x6307;&#x5b9a;&#x65e5;&#x5386;&#x5b57;&#x6bb5;&#x53ef;&#x80fd;&#x62e5;&#x6709;&#x7684;&#x6700;&#x5927;&#x503c;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1495379812265" ID="ID_429128861" MODIFIED="1495379812265" TEXT="public String toString()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495379812266" ID="ID_357042801" MODIFIED="1495379812266" TEXT="public final Instant toInstant()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381250142" ID="ID_525168390" MODIFIED="1495381250143" TEXT="public int getFirstDayOfWeek()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354075" ID="ID_918138369" MODIFIED="1495381450828" TEXT="public static Calendar getInstance()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354076" ID="ID_1572537625" MODIFIED="1495381447262" TEXT="public static Calendar getInstance(TimeZone zone)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354077" ID="ID_582521249" MODIFIED="1495381444005" TEXT="public static Calendar getInstance(Locale aLocale)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354078" ID="ID_1660993590" MODIFIED="1495381440880" TEXT="public static synchronized Locale[] getAvailableLocales()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354079" FOLDED="true" ID="ID_879093046" MODIFIED="1532056889051" TEXT="public int get(int field)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495381556986" ID="ID_331099770" MODIFIED="1495381556986" TEXT="&#x8fd4;&#x56de;&#x7ed9;&#x5b9a;&#x65e5;&#x5386;&#x5b57;&#x6bb5;&#x7684;&#x503c;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1495381354080" ID="ID_1022431869" MODIFIED="1495381429455" TEXT="public void set(int field, int value)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354080" ID="ID_426705287" MODIFIED="1495381426023" TEXT="public final void set(int year, int month, int date)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354081" ID="ID_1952009543" MODIFIED="1495381422172" TEXT="public final void set(int year, int month, int date, int hourOfDay, int minute)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354083" ID="ID_868739266" MODIFIED="1495381418704" TEXT="public final void clear()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354088" ID="ID_583217409" MODIFIED="1495381415151" TEXT="public final void clear(int field)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354090" ID="ID_496364148" MODIFIED="1495381412205" TEXT="public final boolean isSet(int field)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354091" FOLDED="true" ID="ID_1718986982" MODIFIED="1532056889051">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      public void roll(int field, int amount)
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495381981926" ID="ID_1242037000" MODIFIED="1495382022695" TEXT="&#x8c03;&#x6574;&#x4e00;&#x4e2a;&#x5b57;&#x6bb5;,&#x6bd4;&#x8be5;&#x5b57;&#x6bb5;&#x5927;&#x7684;&#x5b57;&#x6bb5;&#x4e0d;&#x4f1a;&#x88ab;&#x4fee;&#x6539;"/>
</node>
<node COLOR="#990000" CREATED="1495381354092" ID="ID_972715432" MODIFIED="1495381387172" TEXT="public void setTimeZone(TimeZone value)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354093" ID="ID_558167939" MODIFIED="1495381383702" TEXT="public TimeZone getTimeZone()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354094" FOLDED="true" ID="ID_1393470756" MODIFIED="1532056889051" TEXT="public void setLenient(boolean lenient)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495381890959" ID="ID_1918552295" MODIFIED="1495381890959" TEXT="&#x6307;&#x5b9a;&#x65e5;&#x671f;/&#x65f6;&#x95f4;&#x89e3;&#x91ca;&#x662f;&#x5426;&#x662f;&#x5bbd;&#x677e;&#x7684;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1495381354095" ID="ID_395322396" MODIFIED="1495381376843" TEXT="public boolean isLenient()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354096" FOLDED="true" ID="ID_1365462572" MODIFIED="1532056889051" TEXT="public void setFirstDayOfWeek(int value)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495381874720" ID="ID_852009054" MODIFIED="1495381874721" TEXT="&#x8bbe;&#x7f6e;&#x4e00;&#x661f;&#x671f;&#x7684;&#x7b2c;&#x4e00;&#x5929;&#x662f;&#x54ea;&#x4e00;&#x5929;&#xff1b;&#x4f8b;&#x5982;&#xff0c;&#x5728;&#x7f8e;&#x56fd;&#xff0c;&#x8fd9;&#x4e00;&#x5929;&#x662f; SUNDAY&#xff0c;&#x800c;&#x5728;&#x6cd5;&#x56fd;&#xff0c;&#x8fd9;&#x4e00;&#x5929;&#x662f; MONDAY&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1495381354097" ID="ID_1954990373" MODIFIED="1495381369033" TEXT="public int getFirstDayOfWeek()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354098" ID="ID_1617975316" MODIFIED="1495381468590" TEXT="public void setMinimalDaysInFirstWeek(int value)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495381354107" ID="ID_114428220" MODIFIED="1495381364396" TEXT="public int getMinimalDaysInFirstWeek()">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1521677951313" FOLDED="true" ID="ID_1614576057" MODIFIED="1532307148155" TEXT="&#x5176;&#x4ed6;&#x76f8;&#x5173;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1521677955186" ID="ID_1420943063" MODIFIED="1532071245002" TEXT="ZoneId">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1521677972746" ID="ID_1012374079" MODIFIED="1521677988180">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 30.0pt"><font color="#078013" size="3"><i>&lt;li&gt;ACT - Australia/Darwin&lt;/li&gt;<br size="3" />* &lt;li&gt;AET - Australia/Sydney&lt;/li&gt;<br size="3" />* &lt;li&gt;AGT - America/Argentina/Buenos_Aires&lt;/li&gt;<br size="3" />* &lt;li&gt;ART - Africa/Cairo&lt;/li&gt;<br size="3" />* &lt;li&gt;AST - America/Anchorage&lt;/li&gt;<br size="3" />* &lt;li&gt;BET - America/Sao_Paulo&lt;/li&gt;<br size="3" />* &lt;li&gt;BST - Asia/Dhaka&lt;/li&gt;<br size="3" />* &lt;li&gt;CAT - Africa/Harare&lt;/li&gt;<br size="3" />* &lt;li&gt;CNT - America/St_Johns&lt;/li&gt;<br size="3" />* &lt;li&gt;CST - America/Chicago&lt;/li&gt;<br size="3" />* &lt;li&gt;CTT - Asia/Shanghai&lt;/li&gt;<br size="3" />* &lt;li&gt;EAT - Africa/Addis_Ababa&lt;/li&gt;<br size="3" />* &lt;li&gt;ECT - Europe/Paris&lt;/li&gt;<br size="3" />* &lt;li&gt;IET - America/Indiana/Indianapolis&lt;/li&gt;<br size="3" />* &lt;li&gt;IST - Asia/Kolkata&lt;/li&gt;<br size="3" />* &lt;li&gt;JST - Asia/Tokyo&lt;/li&gt;<br size="3" />* &lt;li&gt;MIT - Pacific/Apia&lt;/li&gt;<br size="3" />* &lt;li&gt;NET - Asia/Yerevan&lt;/li&gt;<br size="3" />* &lt;li&gt;NST - Pacific/Auckland&lt;/li&gt;<br size="3" />* &lt;li&gt;PLT - Asia/Karachi&lt;/li&gt;<br size="3" />* &lt;li&gt;PNT - America/Phoenix&lt;/li&gt;<br size="3" />* &lt;li&gt;PRT - America/Puerto_Rico&lt;/li&gt;<br size="3" />* &lt;li&gt;PST - America/Los_Angeles&lt;/li&gt;<br size="3" />* &lt;li&gt;SST - Pacific/Guadalcanal&lt;/li&gt;<br size="3" />* &lt;li&gt;VST - Asia/Ho_Chi_Minh&lt;/li&gt;</i></font></pre>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1521676838546" ID="ID_1037977155" MODIFIED="1532070956905" TEXT="&#x5176;&#x4ed6;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1521676841688" FOLDED="true" ID="ID_1298073882" MODIFIED="1532070971612" TEXT="CTS">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1521676844171" ID="ID_1205852775" MODIFIED="1521676844171">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="java&#x8bed;&#x6cd5;_1712963887345870504.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1521677880339" ID="ID_282313267" MODIFIED="1532070968801" TEXT="EDT">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1521677882968" ID="ID_909736601" MODIFIED="1521677898157" TEXT="Eastern Daylight Time  :&#x5317;&#x7f8e;&#x4e1c;&#x90e8;&#x65f6;&#x95f4;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1531650318193" ID="ID_1371915629" MODIFIED="1532070958764" TEXT="&#x4ee3;&#x7801;&#x76f8;&#x5173;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1531650325166" ID="ID_1144602656" MODIFIED="1531650396384" TEXT="&#x60f3;&#x8981;&#x83b7;&#x53d6;&#x5176;&#x4ed6;&#x65f6;&#x671f;&#x7684;&#x65e5;&#x671f;&#x5219;&#x9700;&#x8981;&#x5728;&#x83b7;&#x53d6;Calendar&#x5bf9;&#x8c61;&#x524d;&#x6dfb;&#x52a0;:&#xa; TimeZone.setDefault(TimeZone.getTimeZone(&quot;AET&quot;)); //&quot;AET&quot;&#x662f;&#x76ee;&#x6807;&#x65f6;&#x533a;&#x7684;id">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1531651754759" ID="ID_1706844044" MODIFIED="1531651754761" TEXT="System.out.println(&quot;12&#x5c0f;&#x65f6;&#x5236;:&quot;+calendar.get(Calendar.HOUR));">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1531651754765" ID="ID_799091389" MODIFIED="1531651758110" TEXT="System.out.println(&quot;24&#x5c0f;&#x65f6;&#x5236;:&quot;+calendar.get(Calendar.HOUR_OF_DAY));">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1488889603069" FOLDED="true" ID="ID_1315543098" MODIFIED="1532327642208" POSITION="right" TEXT="&#x6570;&#x636e;&#x7c7b;&#x578b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472387066311" FOLDED="true" ID="ID_1104056496" MODIFIED="1532308058712" TEXT="&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066311" FOLDED="true" ID="ID_80832748" MODIFIED="1532056889051" TEXT="&#x7c7b;&#x578b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="full-1"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1062916902" MODIFIED="1532056889051" TEXT="byte">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_576725086" MODIFIED="1532056889051">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1640425536" MODIFIED="1472778412080" TEXT="&#x8ba1;&#x91cf;&#x5b58;&#x50a8;&#x5bb9;&#x91cf;&#x7684;&#x4e00;&#x79cd;&#x8ba1;&#x91cf;&#x5355;&#x4f4d;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1756460373" MODIFIED="1472778412080" TEXT="&#x8ba1;&#x7b97;&#x673a;&#x7f16;&#x7a0b;&#x8bed;&#x8a00;&#x4e2d;&#x7684;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x548c;&#x8bed;&#x8a00;&#x5b57;&#x7b26;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_946789056" MODIFIED="1532056889051" TEXT="bit">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1733287534" MODIFIED="1532056889051" TEXT="?">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_786366628" MODIFIED="1472778412080" TEXT="&#x4f4d;, &#x4ee3;&#x8868;&#x4e00;&#x4e2a;0&#x6216;1"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1189546647" MODIFIED="1472778412080" TEXT="&#x6bcf;8&#x4e2a;bit &#x7ec4;&#x6210;&#x4e00;&#x4e2a;&#x5b57;&#x8282;byte"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1683673022" MODIFIED="1472778412080" TEXT="&#x662f;&#x6700;&#x5c0f;&#x4e00;&#x7ea7;&#x7684;&#x4fe1;&#x606f;&#x5355;&#x4f4d;(&#x6570;&#x636e;&#x5728;&#x7f51;&#x7edc;&#x4e2d;&#x7684;&#x4f20;&#x8f93;&#x5f62;&#x5f0f;)"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_176939998" MODIFIED="1472778412080" TEXT="&#x6362;&#x7b97;&#x4e3a;&#x5341;&#x8fdb;&#x5236;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_620363493" MODIFIED="1532056889051" TEXT="&#x4e8c;&#x8fdb;&#x5236;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1551412192" MODIFIED="1472778412080" TEXT="? &#x662f;&#x7528;0&#x548c;1&#x4e24;&#x4e2a;&#x6570;&#x7801;&#x6765;&#x8868;&#x793a;&#x7684;&#x6570;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1060531904" MODIFIED="1472778412080" TEXT="&#x8fdb;&#x4f4d;&#x89c4;&#x5219;&#x662f;&#x201c;&#x9022;&#x4e8c;&#x8fdb;&#x4e00;&#x201d;&#xff0c;"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1924973043" MODIFIED="1532056889051" TEXT="&#x6613;&#x4e8e;&#x7528;&#x7535;&#x5b50;&#x65b9;&#x5f0f;&#x5b9e;&#x73b0;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1460611318" LINK="http://learn.tsinghua.edu.cn/kejian/data/77130/138627/html-chunk/ch14s01.html" MODIFIED="1532056889051" TEXT="?">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1810450350" MODIFIED="1472778412080" TEXT="&#x8ba1;&#x7b97;&#x673a;&#x662f;&#x7531;&#x903b;&#x8f91;&#x7535;&#x8def;&#x7ec4;&#x6210;&#x7684;"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_69492410" MODIFIED="1532056889051" TEXT="&#x903b;&#x8f91;&#x7535;&#x8def;&#x901a;&#x5e38;&#x53ea;&#x6709;&#x4e24;&#x79cd;&#x72b6;&#x6001;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1199539629" MODIFIED="1532056889051" TEXT="&#x9ad8;&#x7535;&#x538b;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1111718797" MODIFIED="1472778412080" TEXT="&#x76f8;&#x5f53;&#x4e8e; 1"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_399555100" MODIFIED="1532056889051" TEXT="&#x4f4e;&#x7535;&#x538b;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1044026828" MODIFIED="1472778412080" TEXT="&#x76f8;&#x5f53;&#x4e8e; 0"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_614323490" MODIFIED="1472778412080" TEXT="0&#x548c;1 &#x6b63;&#x597d;&#x4e0e;&#x903b;&#x8f91;&#x4ee3;&#x6570;&#x7684;&#x771f;&#x5047;&#x7684;&#x543b;&#x5408;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_565163070" LINK="http://baike.baidu.com/link?url=OCtNR78Sn3_B6oamna-SIC0cPmYRkMnCGgdsmnAqo3W4OSocaI7qEM35WvW3fglKge9Z2l1qkeML-FeAgGr9wa" MODIFIED="1532056889051" TEXT="&#x8fdb;&#x5236;&#x8f6c;&#x6362;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_238779640" MODIFIED="1532056889051" TEXT="&#x5341;&#x8fdb;&#x5236; &#x8f6c; &#x4e8c;&#x8fdb;&#x5236;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_260002353" MODIFIED="1532056889051" TEXT="&#x91c7;&#x7528;&quot;&#x9664;2&#x53d6;&#x4f59;&#xff0c;&#x9006;&#x5e8f;&#x6392;&#x5217;&quot;&#x6cd5;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1731784237" LINK="images/7r2v6p3k1lvle7rtl77j4i2lvs.png" MODIFIED="1472778412095" TEXT="10&#x5341;&#x8fdb;&#x5236;_&#x4e8c;&#x8fdb;&#x5236;.png"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1037127735" MODIFIED="1472778412095" TEXT="&#x7528;2&#x6574;&#x9664;&#x5341;&#x8fdb;&#x5236;&#x6574;&#x6570;&#xff0c;&#x53ef;&#x4ee5;&#x5f97;&#x5230;&#x4e00;&#x4e2a;&#x5546;&#x548c;&#x4f59;&#x6570;&#xff1b;&#x518d;&#x7528;2&#x53bb;&#x9664;&#x5546;&#xff0c;&#x53c8;&#x4f1a;&#x5f97;&#x5230;&#x4e00;&#x4e2a;&#x5546;&#x548c;&#x4f59;&#x6570;&#xff0c;&#x5982;&#x6b64;&#x8fdb;&#x884c;&#xff0c;&#x76f4;&#x5230;&#x5546;&#x4e3a;0&#x65f6;&#x4e3a;&#x6b62;&#xff0c;&#x7136;&#x540e;&#x628a;&#x5148;&#x5f97;&#x5230;&#x7684;&#x4f59;&#x6570;&#x4f5c;&#x4e3a;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x7684;&#x4f4e;&#x4f4d;&#x6709;&#x6548;&#x4f4d;&#xff0c;&#x540e;&#x5f97;&#x5230;&#x7684;&#x4f59;&#x6570;&#x4f5c;&#x4e3a;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x7684;&#x9ad8;&#x4f4d;&#x6709;&#x6548;&#x4f4d;&#xff0c;&#x4f9d;&#x6b21;&#x6392;&#x5217;&#x8d77;&#x6765;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1985156312" MODIFIED="1532056889051" TEXT="&#x4e8c;&#x8fdb;&#x5236;&#x8f6c;&#x5341;&#x8fdb;&#x5236;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1394030654" MODIFIED="1472778412095" TEXT="&#x516c;&#x5f0f;:   abcd.efg = d*2^0+c*2^1+b*2^2+a*2^3+e*2^-1+f*2^-2+g*2^-3"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1848360029" MODIFIED="1472778412095" TEXT="&#x4e3e;&#x4f8b;:  1101.01=1*2^0+0*2^1+1*2^2+1*2^3 +0*2^-1+1*2^-2=1+0+4+8+0+0.25=13.25"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_93658386" MODIFIED="1532056889051" TEXT="N&#x8fdb;&#x5236;&#x8f6c;&#x5341;&#x8fdb;&#x5236;:">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1300722449" MODIFIED="1472778412095" TEXT="N&#x8fdb;&#x5236;&#x7684;&#x6570;abcd,&#xd;&#xa;&#x5219;&#x5b83;&#x7684;&#x5341;&#x8fdb;&#x5236;&#x6570;&#x662f;&#xff1a;a*N^3+b*N^2+c*N+d"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_136594749" MODIFIED="1532056889051" TEXT="&#x6743;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_311827676" MODIFIED="1472778412095" TEXT="?  &#x6743;&#x662f;&#x4ee5;N&#x4e3a;&#x57fa;&#x6570;&#x7684;&#x6574;&#x6570;&#x6b21;&#x5e42;"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_327397644" MODIFIED="1532056889051" TEXT="char">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1441958610" MODIFIED="1472778412095" TEXT="&apos;&apos;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_694086719" MODIFIED="1488889608976" TEXT="short">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_340392324" MODIFIED="1488889608976" TEXT="int">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_113846441" MODIFIED="1488889608977" TEXT="long">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1127569662" MODIFIED="1488889608977" TEXT="double">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_917682793" MODIFIED="1488889608977" TEXT="float">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1221844111" MODIFIED="1532056889051" TEXT="boolean">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_791304846" MODIFIED="1472778412095" TEXT="&#x4e0d;&#x80fd;&#x6267;&#x884c;&#x6309;&#x4f4d;~&#x8fd0;&#x7b97;"/>
</node>
<node COLOR="#111111" CREATED="1495729055229" FOLDED="true" ID="ID_613620320" MODIFIED="1532056889051">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22270;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_793606104" MODIFIED="1488889608977">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="images/1vvg980hrlgnpjngftesu1n11m.png" />
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066311" FOLDED="true" ID="ID_1758965597" MODIFIED="1532056889051" TEXT="&#x5305;&#x88c5;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="full-2"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1271454898" MODIFIED="1488889608978" TEXT="Byte">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1577301074" MODIFIED="1488889608978" TEXT="Short">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_463883275" MODIFIED="1488889608978" TEXT="Integer">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_665615024" MODIFIED="1488889608978" TEXT="Long">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1771912744" MODIFIED="1488889608978" TEXT="Double">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1923992435" MODIFIED="1488889608978" TEXT="Float">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_518190458" MODIFIED="1488889608978" TEXT="Boolean">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1581617734" MODIFIED="1491804911045" TEXT="Character">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066311" FOLDED="true" ID="ID_994177867" LINK="http://www.cnblogs.com/xiohao/p/4296059.html" MODIFIED="1532056889051" TEXT="&#x5f02;&#x540c;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="flag"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1950723177" MODIFIED="1532056889051" TEXT="&#x53d8;&#x91cf;&#x540d;&#x5206;&#x914d;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1473032543" MODIFIED="1472778412095" TEXT="&#x57fa;&#x672c;&#x7c7b;&#x578b;&#x7684;&#x53d8;&#x91cf;&#x540d;&#x6808;&#x5185;&#x5b58;&#x4e2d;&#x5206;&#x914d; "/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_250672446" MODIFIED="1472778412095" TEXT="&#x5bf9;&#x8c61;&#x7684;&#x5f15;&#x7528;&#x53d8;&#x91cf;&#x540d;&#x4e5f;&#x662f;&#x5728;&#x6808;&#x5185;&#x5b58;&#x4e2d;&#x5206;&#x914d;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_400314392" MODIFIED="1532056889051" TEXT="&#x53d8;&#x91cf;&#x7684;&#x503c;&#x5206;&#x914d;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_410875796" MODIFIED="1532056889051" TEXT="&#x57fa;&#x672c;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_723061677" MODIFIED="1472778412111" TEXT="&#x4e0d;&#x786e;&#x5b9a;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_419657235" MODIFIED="1532056889051" TEXT="&#x5bf9;&#x8c61;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1747952925" MODIFIED="1472778412111" TEXT="&#x5b9e;&#x9645;&#x7684;&#x5bf9;&#x8c61;&#x662f;&#x5728;&#x5b58;&#x50a8;&#x5806;&#x5185;&#x5b58;&#x4e2d; "/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066311" ID="ID_1032494867" MODIFIED="1532308059355" TEXT="&#x5f15;&#x7528;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066311" FOLDED="true" ID="ID_1590229929" MODIFIED="1532056889051" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_696967315" MODIFIED="1488889611208" TEXT="&#x4ece;&#x57fa;&#x672c;&#x7c7b;&#x578b;&#x6784;&#x9020;&#x800c;&#x6765;&#x7684;&#x7c7b;&#x548c;&#x5176;&#x4ed6;&#x590d;&#x6742;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_623613717" MODIFIED="1532056889051" TEXT="&#x5f15;&#x7528;&#x7c7b;&#x578b;&#x7684;&#x5185;&#x5b58;&#x5355;&#x5143;&#x4e2d;&#x53ea;&#x5b58;&#x653e;&#x5bf9;&#x8c61;&#x7684;&#x5730;&#x5740;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1017607520" MODIFIED="1472778412111" TEXT="&#x5bf9;&#x8c61;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1114373788" MODIFIED="1472778412111" TEXT="&#x5730;&#x5740;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_426401184" MODIFIED="1488889611208" TEXT="&#x5bf9;&#x8c61;&#x672c;&#x8eab;&#x5b58;&#x8d2e;&#x5728;&#x5185;&#x5b58;&#x5806;&#x4e2d;&#xff0c;&#x53ea;&#x662f;&#x7b80;&#x5355;&#x7684;&#x5f15;&#x7528;&#x5bf9;&#x8c61;&#x7684;&#x5730;&#x5740;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066311" FOLDED="true" ID="ID_538134526" MODIFIED="1532327639719" TEXT="&#x5206;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_602220978" MODIFIED="1532056889066" TEXT="Class &#xff08;&#x7c7b;&#xff09;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_215752830" MODIFIED="1532056889051" TEXT="?&#x662f;&#x4ec0;&#x4e48;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1297497366" MODIFIED="1472778412111" TEXT="&#x662f;&#x5bf9;&#x6240;&#x5177;&#x6709;&#x76f8;&#x540c;&#x7279;&#x5f81;&#x5b9e;&#x4f53;&#x7684;&#x62bd;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_252726463" MODIFIED="1532056889066" TEXT="&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x4ecb;&#x7ecd;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_779926532" MODIFIED="1532056889066" TEXT="?">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1368180803" MODIFIED="1532056889051" TEXT="&#x9762;&#x5411;&#x8fc7;&#x7a0b;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1727870398" MODIFIED="1472778412111" TEXT="&#x5173;&#x6ce8;&#x4e8b;&#x4ef6;&#x6d41;&#x7a0b;&#x7684;&#x601d;&#x60f3;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_515381606" MODIFIED="1472778412111" TEXT="&#x9002;&#x5408;&#x5904;&#x7406;&#x76f8;&#x5bf9;&#x7b80;&#x5355;&#x7684;&#x95ee;&#x9898;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_857894323" MODIFIED="1532056889066" TEXT="&#x9762;&#x5411;&#x5bf9;&#x8c61;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1646343386" MODIFIED="1532056889051" TEXT="&#x662f;?">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1092477496" MODIFIED="1532056889051" TEXT="&#x4ece;&#x73b0;&#x5b9e;&#x4e16;&#x754c;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_695718693" MODIFIED="1472778412111" TEXT="&#x8ba4;&#x4e3a;&#x4e16;&#x754c;&#x662f;&#x7531;&#x5404;&#x79cd;&#x5404;&#x6837;&#x5177;&#x6709;&#x81ea;&#x5df1;&#x7684;&#x8fd0;&#x52a8;&#x89c4;&#x5f8b;&#x548c;&#x5185;&#x90e8;&#x72b6;&#x6001;&#x7684;&#x5bf9;&#x8c61;&#x6240;&#x7ec4;&#x6210;&#x7684;&#xff1b;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_480389077" MODIFIED="1472778412111" TEXT="&#x4e0d;&#x540c;&#x5bf9;&#x8c61;&#x4e4b;&#x95f4;&#x7684;&#x76f8;&#x4e92;&#x4f5c;&#x7528;&#x548c;&#x901a;&#x8baf;&#x6784;&#x6210;&#x4e86;&#x5b8c;&#x6574;&#x7684;&#x73b0;&#x5b9e;&#x4e16;&#x754c;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1581983328" MODIFIED="1532056889051" TEXT="&#x4ece;&#x65b9;&#x6cd5;&#x5b66;&#x7684;&#x89d2;&#x5ea6;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_762067759" MODIFIED="1472778412111" TEXT="&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x7684;&#x65b9;&#x6cd5;&#x662f;&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x7684;&#x4e16;&#x754c;&#x89c2;&#x5728;&#x5f00;&#x53d1;&#x65b9;&#x6cd5;&#x4e2d;&#x7684;&#x76f4;&#x63a5;&#x8fd0;&#x7528;&#x3002;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_959909368" MODIFIED="1472778412111" TEXT="&#x5b83;&#x5f3a;&#x8c03;&#x7cfb;&#x7edf;&#x7684;&#x7ed3;&#x6784;&#x5e94;&#x8be5;&#x76f4;&#x63a5;&#x4e0e;&#x73b0;&#x5b9e;&#x4e16;&#x754c;&#x7684;&#x7ed3;&#x6784;&#x76f8;&#x5bf9;&#x5e94;&#xff0c;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1486047040" MODIFIED="1472778412111" TEXT="&#x5e94;&#x8be5;&#x56f4;&#x7ed5;&#x73b0;&#x5b9e;&#x4e16;&#x754c;&#x4e2d;&#x7684;&#x5bf9;&#x8c61;&#x6765;&#x6784;&#x9020;&#x7cfb;&#x7edf;&#xff0c;&#x800c;&#x4e0d;&#x662f;&#x56f4;&#x7ed5;&#x529f;&#x80fd;&#x6765;&#x6784;&#x9020;&#x7cfb;&#x7edf;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_532210666" MODIFIED="1532056889066" TEXT="&#x9002;&#x5408;&#x4e8e;&#x5904;&#x7406;&#x590d;&#x6742;&#x7684;&#x95ee;&#x9898;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1485565799" MODIFIED="1532056889066" TEXT="&#xff1f;&#x4ec0;&#x4e48;&#x662f;&#x590d;&#x6742;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1051791327" MODIFIED="1532056889051" TEXT="&#x4e3e;&#x4f8b;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_739936464" MODIFIED="1532056889051" TEXT="&#x9762;&#x8bd5;1&#x5bb6;&#x516c;&#x53f8;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1296090342" MODIFIED="1472778412111" TEXT="&#x8fd9;&#x65f6;&#x5019;&#x53ea;&#x5173;&#x6ce8;&#x9762;&#x8bd5;&#x7ec6;&#x8282;&#x5373;&#x53ef;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_120911422" MODIFIED="1532056889051" TEXT="&#x9762;&#x8bd5;1000&#x5bb6;&#x516c;&#x53f8;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_401049727" MODIFIED="1472778412111" TEXT="&#x5206;&#x7c7b;&#xff0c;&#x5b89;&#x6392;&#x65f6;&#x95f4;&#xff0c;&#x5b89;&#x6392;&#x8def;&#x7ebf;"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_407386783" MODIFIED="1472778412111" TEXT="&#x5173;&#x6ce8;&#x4e8b;&#x4ef6;&#x7684;&#x6574;&#x4f53;&#xff0c;&#x5bf9;&#x6574;&#x4f53;&#x5173;&#x7cfb;&#x4f5c;&#x51fa;&#x5206;&#x7c7b;&#xff0c;&#x7136;&#x540e;&#xff0c;&#x6839;&#x636e;&#x4e0d;&#x540c;&#x7684;&#x7c7b;&#x6df1;&#x5165;&#x7ec6;&#x8282;&#x7684;&#x5904;."/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_33425500" MODIFIED="1532056889066" TEXT="&#x4e8c;&#x8005;&#x8054;&#x7cfb;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_770682385" MODIFIED="1532056889066" TEXT="&#x76f8;&#x8f85;&#x76f8;&#x6210;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1368577813" MODIFIED="1472778412111" TEXT="&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x5173;&#x6ce8;&#x4e8e;&#x4ece;&#x5b8f;&#x89c2;&#x4e0a;&#x628a;&#x63e1;&#x4e8b;&#x7269;&#x4e4b;&#x95f4;&#x7684;&#x5173;&#x7cfb;&#xff1b;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_624021002" MODIFIED="1472778412111" TEXT="&#x5728;&#x5177;&#x4f53;&#x5230;&#x5982;&#x4f55;&#x5b9e;&#x73b0;&#x67d0;&#x4e2a;&#x7ec6;&#x8282;&#x65f6;&#xff0c;&#x4ecd;&#x7136;&#x91c7;&#x7528;&#x9762;&#x5411;&#x8fc7;&#x7a0b;&#x7684;&#x601d;&#x7ef4;&#x65b9;&#x5f0f;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1690099031" MODIFIED="1532056889066" TEXT="&#x672c;&#x8d28;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_354520016" MODIFIED="1472778412111" TEXT="&#x4ece;&#x95ee;&#x9898;&#x9886;&#x57df;&#x8003;&#x8651;&#xff0c;&#x629b;&#x5f00;&#x7f16;&#x7a0b;&#x8bed;&#x8a00;&#x8fd9;&#x4e00;&#x5c42;&#x9762;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_195356997" MODIFIED="1532056889066" TEXT="&#x5bf9;&#x8c61;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_29909852" MODIFIED="1472778412126" TEXT="&#x662f;&#x7c7b;&#x7684;&#x5b9e;&#x4f8b;"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_728390219" MODIFIED="1532056889066" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1617736015" MODIFIED="1472778412126" TEXT="new &#x5173;&#x952e;&#x5b57;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1729891950" MODIFIED="1532056889066" TEXT="Class&#x7684;&#x6784;&#x6210;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_735612711" MODIFIED="1532056889066" TEXT="&#x5b57;&#x6bb5;(&#x5c5e;&#x6027;)">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1746935272" MODIFIED="1532056889066" TEXT="?">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1601074988" MODIFIED="1472778412126" TEXT="&#x5b9e;&#x8d28;&#x662f;&#x4e00;&#x5c0f;&#x5757;&#x5185;&#x5b58;&#x5355;&#x5143;&#x3002;&#x8fd9;&#x4e00;&#x5c0f;&#x5757;&#x5185;&#x5b58;&#x91cc;&#x5b58;&#x50a8;&#x7740;&#x53d8;&#x91cf;&#x7684;&#x503c;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1917053598" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1456604530" MODIFIED="1532056889066" TEXT="&#x53d8;&#x91cf;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_661118429" MODIFIED="1532056889066" TEXT="&#x53ef;&#x53d8;&#x5316;&#x7684;&#x91cf;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1722730089" MODIFIED="1532056889066" TEXT="&#x91cf; &#xff1f;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1097883292" MODIFIED="1472778412126" TEXT="&#x6570;&#x636e;&#x7c7b;&#x578b;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_108023186" MODIFIED="1532056889066" TEXT="&#x5e38;&#x91cf;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_725129536" MODIFIED="1532056889066" TEXT="&#x4e0d;&#x53ef;&#x53d8;&#x5316;&#x7684;&#x91cf;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1693487131" LINK="http://blog.csdn.net/autofei/article/details/6419460" MODIFIED="1472778412126" TEXT="&#x5982;&#x4f55;&#x4f7f;&#x7528;? "/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_655609673" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;(&#x51fd;&#x6570;)">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_202455268" MODIFIED="1532056889066" TEXT="?">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_898148672" MODIFIED="1472778412126" TEXT="&#x505a;&#x67d0;&#x4e9b;&#x4e8b;&#x60c5;&#x7684;&#x65b9;&#x5f0f;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_708135466" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1225268658" MODIFIED="1532056889066" TEXT="&#x666e;&#x901a;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1026618308" MODIFIED="1532056889066" TEXT="&#x662f;?">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1815377977" MODIFIED="1472778412126" TEXT="&#x7c7b;&#x7684;&#x67d0;&#x4e2a;&#x529f;&#x80fd;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_633773352" MODIFIED="1532056889066" TEXT="&#x6784;&#x6210;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1205732628" MODIFIED="1472778412126" TEXT="&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1291923381" MODIFIED="1532056889066" TEXT="&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1680360435" MODIFIED="1472778412126" TEXT="void"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_845912862" MODIFIED="1472778412126" TEXT="&#x975e; void"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_797886708" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;&#x540d;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_422863209" MODIFIED="1472778412126" TEXT="&#x65b9;&#x6cd5;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_137327489" MODIFIED="1532056889066" TEXT="&#x53c2;&#x6570;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_939404263" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_315425849" MODIFIED="1532056889066" TEXT="&#x5f62;&#x5f0f;&#x53c2;&#x6570;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1914450559" MODIFIED="1472778412126" TEXT="&#x51fd;&#x6570;&#x5b9a;&#x4e49;&#x4e2d;&#x7684;&#xff0c;&#x7cfb;&#x7edf;&#x6ca1;&#x6709;&#x4e3a;&#x5176;&#x5206;&#x914d;&#x5185;&#x5b58;&#x7a7a;&#x95f4;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1391567115" MODIFIED="1472778412126" TEXT="&#x5728;&#x5b9a;&#x4e49;&#x91cc;&#x9762;&#x53ef;&#x4ee5;&#x4f7f;&#x7528;&#x7684;&#x53c2;&#x6570;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_409913405" MODIFIED="1532056889066" TEXT="&#x5b9e;&#x9645;&#x53c2;&#x6570;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_825429369" MODIFIED="1472778412126" TEXT="&#x51fd;&#x6570;&#x8c03;&#x7528;&#x7684;&#x65f6;&#x5019;&#x4f20;&#x7ed9;&#x51fd;&#x6570;&#x7684;&#x53d8;&#x91cf;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_511683052" MODIFIED="1472778412126" TEXT="&#x662f;&#x7cfb;&#x7edf;&#x5b9e;&#x5b9e;&#x5728;&#x5728;&#x5206;&#x914d;&#x4e86;&#x5185;&#x5b58;&#x7a7a;&#x95f4;&#x7684;&#x53d8;&#x91cf;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_938004777" MODIFIED="1532056889066" TEXT="&#x53c2;&#x6570;&#x5217;&#x8868;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1662599274" MODIFIED="1472778412126" TEXT="&#x53c2;&#x6570;&#x6784;&#x6210;&#x7684;&#x5217;&#x8868;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1041790751" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;&#x4f53; &#xff1f;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1477433820" MODIFIED="1472778412126" TEXT="&#x65b9;&#x6cd5;&#x7684;&#x5185;&#x5bb9;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_966358712" MODIFIED="1532056889066" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1852102667" LINK="http://baike.baidu.com/view/126530.htm" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;&#x91cd;&#x8f7d;(Overloading)">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_58838864" MODIFIED="1532056889066" TEXT="&#x662f;?">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1617864256" MODIFIED="1472778412126" TEXT="&#x662f;&#x65b9;&#x6cd5;&#x540d;&#x79f0;&#x91cd;&#x590d;&#xff0c;&#x52a0;&#x8f7d;&#x53c2;&#x6570;&#x4e0d;&#x540c;&#x3002;">
<icon BUILTIN="flag"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1381339371" MODIFIED="1472778412126" TEXT="&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;&gt;=&#x7236;&#x7c7b;&#x7684;&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1647611373" MODIFIED="1532056889066" TEXT="&#x4e3a;?">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1347422904" MODIFIED="1472778412126" TEXT="&#x91cd;&#x8f7d;&#x7684;&#x610f;&#x4e49;&#x5728;&#x4e8e;&#x6269;&#x5c55;&#x7236;&#x7c7b;&#x7684;&#x529f;&#x80fd;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_295729754" MODIFIED="1532056889066" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_914014884" MODIFIED="1532056889066" TEXT="&#x53c2;&#x6570;&#x4e0d;&#x540c;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_748630289" MODIFIED="1472778412126" TEXT="&#x53c2;&#x6570;&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1825804996" MODIFIED="1472778412126" TEXT="&#x53c2;&#x6570;&#x6570;&#x91cf;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1154596433" MODIFIED="1472778412126" TEXT="&#x53c2;&#x6570;&#x987a;&#x5e8f;"/>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1256672322" MODIFIED="1532056889066" TEXT="&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;&#x4e0d;&#x540c;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_1167678906" MODIFIED="1472778412126" TEXT="&gt;= &#x88ab;&#x91cd;&#x8f7d;&#x7684;&#x65b9;&#x6cd5;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1304882194" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;&#x91cd;&#x5199;(Overriding)">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_268657140" MODIFIED="1532056889066" TEXT="&#x662f;?">
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1300517126" MODIFIED="1532056889066" TEXT="&#x5982;&#x679c;&#x5728;&#x5b50;&#x7c7b;&#x4e2d;&#x5b9a;&#x4e49;&#x67d0;&#x65b9;&#x6cd5;&#x4e0e;&#x5176;&#x7236;&#x7c7b;&#x6709;&#x5b8c;&#x5168;&#x76f8;&#x540c;&#x7684;&#x540d;&#x79f0;&#x548c;&#x53c2;&#x6570;&#x5217;&#x8868;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_234492838" MODIFIED="1472778412126" TEXT="&#x7236;&#x7c7b;&#x548c;&#x5b50;&#x7c7b;"/>
<node COLOR="#111111" CREATED="1472387066311" ID="ID_575456854" MODIFIED="1472778412126" TEXT="&#x5b8c;&#x5168;&#x76f8;&#x540c;&#x7684;&#x540d;&#x79f0;"/>
<node COLOR="#111111" CREATED="1472387066311" FOLDED="true" ID="ID_1344641319" MODIFIED="1532056889066" TEXT="&#x5b8c;&#x5168;&#x76f8;&#x540c;&#x7684;&#x53c2;&#x6570;&#x5217;&#x8868;">
<node COLOR="#111111" CREATED="1472387066311" ID="ID_160010810" MODIFIED="1472778412142" TEXT="&#x53c2;&#x6570;&#x7c7b;&#x578b;&#x5b8c;&#x5168;&#x76f8;&#x540c;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1878059551" MODIFIED="1472778412142" TEXT="&#x53c2;&#x6570;&#x6570;&#x76ee;&#x5b8c;&#x5168;&#x76f8;&#x540c;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1583655184" MODIFIED="1472778412142" TEXT="&#x53c2;&#x6570;&#x5217;&#x8868;&#x987a;&#x5e8f;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1618685539" MODIFIED="1472778412142" TEXT="&#x5b8c;&#x5168;&#x76f8;&#x540c;&#x7684;&#x8fd4;&#x56de;&#x503c;&#x7c7b;&#x578b;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1960145136" MODIFIED="1472778412142" TEXT="&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;&gt;=&#x7236;&#x7c7b;&#x7684;&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1021692542" MODIFIED="1532056889066" TEXT="&#x4e3a;?">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1623493745" MODIFIED="1472778412142" TEXT="&#x6709;&#x65f6;&#x5b50;&#x7c7b;&#x5e76;&#x4e0d;&#x60f3;&#x539f;&#x5c01;&#x4e0d;&#x52a8;&#x5730;&#x7ee7;&#x627f;&#x7236;&#x7c7b;&#x7684;&#x65b9;&#x6cd5;&#xff0c;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_338621666" MODIFIED="1472778412142" TEXT="&#x800c;&#x662f;&#x60f3;&#x4f5c;&#x4e00;&#x5b9a;&#x7684;&#x4fee;&#x6539;&#xff0c;&#x8fd9;&#x5c31;&#x9700;&#x8981;&#x91c7;&#x7528;&#x65b9;&#x6cd5;&#x7684;&#x91cd;&#x5199;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1217770788" MODIFIED="1532056889066" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1765890039" MODIFIED="1532056889066" TEXT="&#x4fdd;&#x7559;&#x7236;&#x7c7b;&#x65b9;&#x6cd5;&#x529f;&#x80fd;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1533618443" MODIFIED="1472778412142" TEXT="public void test(){ super.(); }"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1001904659" MODIFIED="1532056889066" TEXT="&#x4e0d;&#x4fdd;&#x7559;&#x7236;&#x7c7b;&#x65b9;&#x6cd5;&#x529f;&#x80fd;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_200039651" MODIFIED="1472778412142" TEXT="public void test(){ }"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1802585633" MODIFIED="1532056889066" TEXT="&#x5f02;&#x540c;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_492201646" MODIFIED="1532056889066" TEXT="&#x53c2;&#x6570;&#x5217;&#x8868;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1170803348" MODIFIED="1532056889066" TEXT="&#x91cd;&#x5199;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1775527125" MODIFIED="1472778412142" TEXT="&#x5fc5;&#x987b;&#x5b8c;&#x5168;&#x4e0e;&#x88ab;&#x91cd;&#x5199;&#x7684;&#x65b9;&#x6cd5;&#x5b8c;&#x5168;&#x76f8;&#x540c;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1356397347" MODIFIED="1532056889066" TEXT="&#x91cd;&#x8f7d;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1982901810" MODIFIED="1472778412142" TEXT="&#x53ef;&#x4ee5;&#x4e0d;&#x540c;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1983531858" MODIFIED="1532056889066" TEXT="&#x629b;&#x51fa;&#x7684;&#x5f02;&#x5e38;&#x7c7b;&#x578b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_701251299" MODIFIED="1532056889066" TEXT="&#x91cd;&#x5199;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_957127912" MODIFIED="1472778412142" TEXT="&#x53ef;&#x4ee5;&#x662f;&#x7236;&#x7c7b;&#x629b;&#x51fa;&#x5f02;&#x5e38;&#x7684;&#x5b50;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_428510504" MODIFIED="1532056889066" TEXT="&#x91cd;&#x8f7d;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_943700496" MODIFIED="1472778412142" TEXT="&#x53ef;&#x4ee5;&#x629b;&#x51fa;&#x4e0d;&#x540c;&#x7684;&#x5f02;&#x5e38;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_771847489" MODIFIED="1472778412142" TEXT="&#x91cd;&#x8f7d;&#x4e5f;&#x53ef;&#x4ee5;&#x5728;&#x5b83;&#x81ea;&#x5df1;&#xff08;&#x7c7b;&#xff09;&#x4e2d;&#x4f7f;&#x7528;&#xff0c;&#x91cd;&#x5199;&#x53ea;&#x80fd;&#x5b58;&#x5728;&#x4e0e;&#x5177;&#x6709;&#x7236;&#x5b50;&#x5173;&#x7cfb;&#x7684;&#x7c7b;&#x4e2d;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_715028683" MODIFIED="1472778412142" TEXT="&#x90fd;&#x53ea;&#x80fd;&#x64cd;&#x4f5c;&#x7236;&#x7c7b;&#x975e;&#x79c1;&#x6709;&#x7684;&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1046113070" MODIFIED="1472778412142" TEXT="&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;&#x7684;&#x9650;&#x5236;&#x4e00;&#x5b9a;&#x8981;&gt;=&#x7236;&#x7c7b;&#x65b9;&#x6cd5;&#x7684;&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1820791471" MODIFIED="1472778412142" TEXT="&#x90fd;&#x53ef;&#x4ee5;&#x5b58;&#x5728;&#x4e8e;&#x5177;&#x6709;&#x7ee7;&#x627f;&#x5173;&#x7cfb;&#x7684;&#x7c7b;&#x4e2d;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1109823851" MODIFIED="1532056889066" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_856391770" MODIFIED="1532056889066" TEXT="&#xff1f;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1512508616" MODIFIED="1472778412142" TEXT="&#x4e00;&#x79cd;&#x7279;&#x6b8a;&#x7684;&#x51fd;&#x6570;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1662681808" MODIFIED="1472778412142" TEXT="&#x529f;&#x80fd;&#x662f;&#x7528;&#x6765;&#x5728;&#x521b;&#x5efa;&#x5bf9;&#x8c61;&#x65f6;&#x521d;&#x59cb;&#x5316;&#x5bf9;&#x8c61;&#xff0c; &#x5373;&#x4e3a;&#x5bf9;&#x8c61;&#x6210;&#x5458;&#x53d8;&#x91cf;&#x8d4b;&#x521d;&#x59cb;&#x503c;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1654684933" MODIFIED="1472778412142" TEXT="&#x603b;&#x4e0e; new &#x8fd0;&#x7b97;&#x7b26;&#x4e00;&#x8d77;&#x4f7f;&#x7528;&#x5728;&#x521b;&#x5efa;&#x5bf9;&#x8c61;&#x7684;&#x8bed;&#x53e5;&#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1307539938" MODIFIED="1532056889066" TEXT="&#x7279;&#x70b9;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1017153298" MODIFIED="1532056889066" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;&#x7684;&#x65b9;&#x6cd5;&#x540d;&#x5fc5;&#x987b;&#x4e0e;&#x7c7b;&#x540d;&#x76f8;&#x540c;&#x3002;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_351897249" MODIFIED="1472778412142" TEXT="&#x6ce8;&#x610f;&#x5b57;&#x6bcd;&#x7684;&#x5927;&#x5c0f;&#x5199;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_79266578" MODIFIED="1472778412142" TEXT="&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x6ca1;&#x6709;&#x8fd4;&#x56de;&#x7c7b;&#x578b;&#xff0c;&#x4e5f;&#x4e0d;&#x80fd;&#x5b9a;&#x4e49;&#x4e3a;void"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_869902325" MODIFIED="1472778412142" TEXT="&#x4f5c;&#x7528;&#x662f;&#x5b8c;&#x6210;&#x5bf9;&#x8c61;&#x7684;&#x521d;&#x59cb;&#x5316;&#x5de5;&#x4f5c;&#xff0c;&#x5b83;&#x80fd;&#x591f;&#x628a;&#x5b9a;&#x4e49;&#x5bf9;&#x8c61;&#x65f6;&#x7684;&#x53c2;&#x6570;&#x4f20;&#x7ed9;&#x5bf9;&#x8c61;&#x7684;&#x57df;&#xff08;&#x5b57;&#x6bb5;&#x6216;&#x6216;&#x5c5e;&#x6027;&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_334540646" MODIFIED="1472778412142" TEXT="&#x4e00;&#x4e2a;&#x7c7b;&#x53ef;&#x4ee5;&#x5b9a;&#x4e49;&#x591a;&#x4e2a;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x7684;&#x9ed8;&#x8ba4;&#x6784;&#x9020;&#x5668;&#xff08;&#x6784;&#x9020;&#x51fd;&#x6570;&#x6216;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#xff09;&#xff0c;&#x8fd9;&#x4e2a;&#x6784;&#x9020;&#x5668;&#x4e0d;&#x6267;&#x884c;&#x4efb;&#x4f55;&#x4ee3;&#x7801;&#x3002;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1541262678" MODIFIED="1472778412142" TEXT="&#x5982;&#x679c;&#x5728;&#x5b9a;&#x4e49;&#x7c7b;&#x65f6;&#x6ca1;&#x6709;&#x5b9a;&#x4e49;&#x6784;&#x9020;&#x65b9;&#x6cd5;&#xff0c;&#x5219;&#x7f16;&#x8bd1;&#x7cfb;&#x7edf;&#x4f1a;&#x81ea;&#x52a8;&#x63d2;&#x5165;&#x4e00;&#x4e2a;&#x65e0;&#x53c2;&#x6570;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_63960345" MODIFIED="1472778412142" TEXT="&#x6784;&#x9020;&#x65b9;&#x6cd5;&#x53ef;&#x4ee5;&#x91cd;&#x8f7d;"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_829843828" MODIFIED="1532056889066" TEXT="&#x6ce8;&#x610f;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_775959312" MODIFIED="1472778412142" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;&#x5185;&#x90e8;&#x5c3d;&#x53ef;&#x80fd;&#x505a;&#x5f88;&#x5c11;&#x7684;&#x64cd;&#x4f5c;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_202715314" MODIFIED="1532056889066" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;&#x7684;&#x7ee7;&#x627f;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_510312958" MODIFIED="1472778412142" TEXT="&#x5b50;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;&#x4e2d;&#x7684;&#x7b2c;&#x4e00;&#x884c;&#xff08;&#x9664;&#x6ce8;&#x91ca;&#x5916;&#xff09;&#x5fc5;&#x987b;&#x662f;&#x7236;&#x7c7b;&#x5bf9;&#x8c61;&#xff08;super)&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;&#x3002;"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1365084016" MODIFIED="1532056889066" TEXT="&#x5b50;&#x7c7b;&#x53ea;&#x7ee7;&#x627f;&#x7236;&#x7c7b;&#x7684;&#x9ed8;&#x8ba4;(&#x7f3a;&#x7701;)&#x6784;&#x9020;&#x51fd;&#x6570;&#xff0c;&#x5373;&#x65e0;&#x5f62;&#x53c2;&#x6784;&#x9020;&#x51fd;&#x6570;&#x3002;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_710715683" MODIFIED="1472778412142" TEXT="&#x5982;&#x679c;&#x7236;&#x7c7b;&#x6ca1;&#x6709;&#x9ed8;&#x8ba4;&#x6784;&#x9020;&#x51fd;&#x6570;&#xff0c;&#x90a3;&#x5b50;&#x7c7b;&#x4e0d;&#x80fd;&#x4ece;&#x7236;&#x7c7b;&#x7ee7;&#x627f;&#x9ed8;&#x8ba4;&#x6784;&#x9020;&#x51fd;&#x6570;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1660398425" MODIFIED="1472778412142" TEXT="&#x5728;&#x521b;&#x5efa;&#x5bf9;&#x8c61;&#x65f6;&#xff0c;&#x5148;&#x8c03;&#x7528;&#x7236;&#x7c7b;&#x9ed8;&#x8ba4;&#x6784;&#x9020;&#x51fd;&#x6570;&#x5bf9;&#x5bf9;&#x8c61;&#x8fdb;&#x884c;&#x521d;&#x59cb;&#x5316;&#xff0c;&#x7136;&#x540e;&#x8c03;&#x7528;&#x5b50;&#x7c7b;&#x81ea;&#x8eab;&#x81ea;&#x5df1;&#x5b9a;&#x4e49;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1251275922" LINK="http://blog.csdn.net/kuanxu/article/details/6928837" MODIFIED="1532056889066" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;&#x8c03;&#x7528;&#x987a;&#x5e8f;">
<icon BUILTIN="flag"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1995499214" MODIFIED="1532056889066" TEXT="&#x5148;&#x6267;&#x884c;&#x81ea;&#x5df1;&#x7684;&#x5185;&#x90e8;&#x9759;&#x6001;&#x6210;&#x5458;&#xff08;&#x9759;&#x6001;&#x5e38;&#x91cf;&#xff0c;&#x9759;&#x6001;&#x4ee3;&#x7801;&#x5757;&#xff09;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;">
<icon BUILTIN="full-1"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_387412374" MODIFIED="1472778412142" TEXT="&#x5982;&#x679c;&#x6709;&#x591a;&#x4e2a;&#x6309;&#x5b9a;&#x4e49;&#x7684;&#x5148;&#x540e;&#x987a;&#x5e8f;&#x6267;&#x884c;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1686026799" MODIFIED="1472778412142" TEXT="&#x4e14;&#x9759;&#x6001;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;&#x53ea;&#x4f1a;&#x88ab;&#x6267;&#x884c;&#x4e00;&#x6b21;&#xff0c;&#x53ea;&#x5728;&#x5176;&#x7b2c;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;&#x521b;&#x5efa;&#x65f6;&#x8c03;&#x7528;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_872813417" MODIFIED="1472778412142" TEXT="&#x9759;&#x6001;&#x5e38;&#x91cf;&#x53ca;&#x9759;&#x6001;&#x4ee3;&#x7801;&#x5757;&#x4e5f;&#x53ea;&#x4f1a;&#x6267;&#x884c;&#x4e00;&#x6b21;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1347991559" LINK="http://www.360doc.com/content/10/0926/19/3594441_56610542.shtml" MODIFIED="1472778412142" TEXT="&#x9759;&#x6001;&#x548c;&#x975e;&#x9759;&#x6001;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1362473217" MODIFIED="1472778412142" TEXT=" &#x518d;&#x6267;&#x884c;&#x57fa;&#x7c7b;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;">
<icon BUILTIN="full-2"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_543665776" MODIFIED="1472778412142" TEXT="&#x6309;&#x58f0;&#x660e;&#x987a;&#x5e8f;&#x5c06;&#x6210;&#x5458;&#x5f15;&#x7528;&#x5bf9;&#x8c61;&#x53d8;&#x91cf;&#x521d;&#x59cb;&#x5316;&#x3002;">
<icon BUILTIN="full-3"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_233229645" MODIFIED="1472778412142" TEXT=" &#x6700;&#x540e;&#x6267;&#x884c;&#x8be5;&#x7c7b;&#x672c;&#x8eab;&#x7684;&#x6784;&#x9020;&#x51fd;&#x6570;">
<icon BUILTIN="full-4"/>
</node>
</node>
<node COLOR="#111111" CREATED="1499302718474" ID="ID_1020543632" MODIFIED="1499302787763" TEXT="&#x5927;&#x5bf9;&#x8c61;&#x4f7f;&#x7528;&#x5efa;&#x9020;&#x8005;&#x6a21;&#x5f0f;&#x6784;&#x5efa;&#x5bf9;&#x8c61;builder.build(),&#x5e76;&#x4e14;&#x80fd;&#x91cd;&#x7528;&#x5219;&#x91cd;&#x7528;,&#x4f7f;&#x7528;&#x5b8c;&#x6bd5;&#x4e4b;&#x540e;&#x8981;&#x4e3b;&#x52a8;&#x56de;&#x6536;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1729655386" MODIFIED="1532056889066" TEXT="&#x7ec4;&#x6210;&#x5143;&#x7d20;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_914665600" MODIFIED="1472778412158" TEXT="&#x540d;&#x79f0;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_357230246" MODIFIED="1472778412158" TEXT="&#x53c2;&#x6570;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_50307892" MODIFIED="1472778412158" TEXT="&#x8fd4;&#x56de;&#x503c;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1196858272" MODIFIED="1472778412158" TEXT="&#x65b9;&#x6cd5;&#x4f53;"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1062933216" MODIFIED="1532056889066" TEXT="&#x8bbf;&#x95ee;&#x63a7;&#x5236;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_98052865" MODIFIED="1532056889066" TEXT="public ">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_406914307" MODIFIED="1472778412158" TEXT="&#x80fd;&#x88ab;&#x6240;&#x6709;&#x7684;&#x7c7b;(&#x63a5;&#x53e3;&#x3001;&#x6210;&#x5458;)&#x8bbf;&#x95ee;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_719388035" MODIFIED="1532056889066" TEXT="protected">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1919051711" MODIFIED="1532056889066" TEXT="&#x540c;&#x4e00;&#x4e2a;&#x5305;">
<arrowlink DESTINATION="ID_1403654964" ENDARROW="Default" ENDINCLINATION="65;0;" ID="Arrow_ID_1701115377" STARTARROW="None" STARTINCLINATION="65;0;"/>
<icon BUILTIN="full-1"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_487261990" MODIFIED="1472778412158" TEXT="&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_519102817" MODIFIED="1532056889066" TEXT="&#x5176;&#x4ed6;&#x5305;">
<icon BUILTIN="full-2"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1330108033" MODIFIED="1472778412158" TEXT="&#x5176;&#x4ed6;&#x5305;&#x4e2d;&#x7684;&#x7c7b;&#x5fc5;&#x987b;&#x662f;&#x8be5;&#x6210;&#x5458;&#x6240;&#x5c5e;&#x7c7b;&#x7684;&#x5b50;&#x7c7b;&#x65f6;&#xff0c;&#x624d;&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;&#x7236;&#x7c7b;&#x4e2d;&#x7684;&#x8be5;&#x6210;&#x5458;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1403654964" MODIFIED="1532056889066" TEXT="default &#xff08;package&#xff09;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_622706003" MODIFIED="1472778412158" TEXT="&#x53ea;&#x80fd;&#x88ab;&#x672c;&#x7c7b;&#x3001;&#x540c;&#x4e00;&#x4e2a;&#x5305;&#x4e2d;&#x7684;&#x7c7b;&#x8bbf;&#x95ee;&#xff1b;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1349163774" MODIFIED="1532056889066" TEXT="private">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1037384144" MODIFIED="1532056889066" TEXT="&#x6210;&#x5458;(&#x53d8;&#x91cf;&#x548c;&#x65b9;&#x6cd5;)&#x90fd;&#x53ea;&#x80fd;&#x5728;&#x5b9a;&#x4e49;&#x5b83;&#x7684;&#x7c7b;&#x4e2d;&#x88ab;&#x8bbf;&#x95ee;&#xff0c;&#x5176;&#x4ed6;&#x7c7b;&#x90fd;&#x8bbf;&#x95ee;&#x4e0d;&#x5230;&#x3002;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_727845459" MODIFIED="1472778412158" TEXT="&#x5bf9;&#x6210;&#x5458;&#x53d8;&#x91cf;&#x7684;&#x83b7;&#x53d6;&#x548c;&#x66f4;&#x6539;&#xff0c;&#x4e00;&#x822c;&#x7528;get()&#xff0c;set() &#xff0c;public &#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1542769516" MODIFIED="1472778412158" TEXT="&#x5b9e;&#x73b0;&#x4e86;Java&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x7684;&#x5c01;&#x88c5;&#x601d;&#x60f3;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1811846423" MODIFIED="1472778412158" TEXT="&#x8bbf;&#x95ee;&#x4fee;&#x9970;&#x7b26;&#x7684;&#x7ea7;&#x522b;&#xff1a;&#x3000;&#x3000;public &gt; protected &gt; default(package) &gt; private"/>
</node>
</node>
<node COLOR="#111111" CREATED="1499302808615" ID="ID_1167526381" MODIFIED="1499302815182" TEXT="&#x4ee3;&#x7801;&#x5757;  {   }"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_343504745" MODIFIED="1532056889066" TEXT="Class&#x7684;&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1393301200" MODIFIED="1532056889066" TEXT="&#x62bd;&#x8c61;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_587887035" MODIFIED="1532056889066" TEXT="&#x662f;?">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1891014137" MODIFIED="1472778412158" TEXT="&#x4f7f;&#x7528;&#x5173;&#x952e;&#x5b57; abstract&#x58f0;&#x660e;&#x7684;&#x7c7b;"/>
<node COLOR="#111111" CREATED="1486257529762" ID="ID_1799706128" MODIFIED="1486257575031" TEXT="&#x4f9d;&#x7136;&#x662f;&#x4e00;&#x4e2a;&#x5b8c;&#x6574;&#x7684;&#x7c7b;&#xff0c;&#x5177;&#x6709;&#x7c7b;&#x7684;&#x7279;&#x5f81;&#xff08;&#x5c5e;&#x6027;&#xff0c;&#x6784;&#x9020;&#x51fd;&#x6570;&#xff0c;&#x65b9;&#x6cd5;&#x7b49;&#xff09;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1909902007" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_153890469" MODIFIED="1532056889066" TEXT="&#x666e;&#x901a;&#x7684;&#x62bd;&#x8c61;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_377943460" MODIFIED="1532056889066" TEXT="&#x7279;&#x6027;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1889893628" MODIFIED="1472778412158" TEXT="&#x62bd;&#x8c61;&#x7c7b;&#x5c31;&#x662f;&#x4e3a;&#x4e86;&#x7ee7;&#x627f;&#x800c;&#x5b58;&#x5728;&#x7684;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_538974539" MODIFIED="1472778412158" TEXT="&#x62bd;&#x8c61;&#x65b9;&#x6cd5;&#x5fc5;&#x987b;&#x4e3a;public&#x6216;&#x8005;protected, &#x7f3a;&#x7701;&#x60c5;&#x51b5;&#x4e0b;&#x9ed8;&#x8ba4;&#x4e3a;public&#x3002;"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_851292824" MODIFIED="1532056889066" TEXT="&#x62bd;&#x8c61;&#x7c7b;&#x4e0d;&#x80fd;&#x76f4;&#x63a5;&#x7528;&#x6765;&#x521b;&#x5efa;&#x5bf9;&#x8c61;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_204624740" MODIFIED="1472778412158" TEXT="&#x5982;&#x679c;&#x76f4;&#x63a5;new &#x4e00;&#x4e2a;&#x62bd;&#x8c61;&#x7c7b;&#x7684;&#x8bdd;&#x5c31;&#x5fc5;&#x987b;&#x5b9e;&#x73b0;&#x62bd;&#x8c61;&#x7c7b;&#x7684;&#x62bd;&#x8c61;&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1067047683" MODIFIED="1472778412158" TEXT="&#x5982;&#x679c;&#x4e00;&#x4e2a;&#x7c7b;&#x7ee7;&#x627f;&#x4e8e;&#x4e00;&#x4e2a;&#x62bd;&#x8c61;&#x7c7b;&#xff0c;&#x5219;&#x5b50;&#x7c7b;&#x5fc5;&#x987b;&#x5b9e;&#x73b0;&#x7236;&#x7c7b;&#x7684;&#x62bd;&#x8c61;&#x65b9;&#x6cd5;&#x3002;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_102812774" LINK="http://www.cnblogs.com/suneryong/p/3571409.html" MODIFIED="1532056889066" TEXT="&#x63a5;&#x53e3; interface">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_246713208" MODIFIED="1532056889066" TEXT="&#x662f;?">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_691096728" MODIFIED="1532056889066" TEXT="&#x662f;&#x4e00;&#x4e2a;&#x5b8c;&#x5168;&#x7684;&#x62bd;&#x8c61;&#x7c7b;">
<node COLOR="#111111" CREATED="1486257719626" FOLDED="true" ID="ID_1609216030" MODIFIED="1532056889066" TEXT="&#x4ec0;&#x4e48;&#x662f;&#x201c;&#x5b8c;&#x5168;&#x201d;">
<node COLOR="#111111" CREATED="1486257728156" ID="ID_1113267802" MODIFIED="1486257746827" TEXT="&#x610f;&#x5473;&#x7740;&#x66f4;&#x52a0;&#x7684;&#x62bd;&#x8c61;&#xff0c;&#x6bd4;&#x62bd;&#x8c61;&#x7c7b;&#x8fd8;&#x8981;&#x62bd;&#x8c61;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1486257588604" ID="ID_1720650343" MODIFIED="1486257698614" TEXT="&#x4e0d;&#x5b8c;&#x6574;&#x7684;&#x7c7b;&#xff0c;&#x6ca1;&#x6709;&#x5c5e;&#x6027;&#xff08;&#x53ef;&#x53d8;&#x7684;&#x5c5e;&#x6027;&#xff0c;&#x63a5;&#x53e3;&#x4e2d;&#x6ca1;&#x6709;&#x6210;&#x5458;&#x53d8;&#x91cf;&#xff0c;&#x90fd;&#x662f;&#x5e38;&#x91cf;&#xff09;&#xff0c;&#x6ca1;&#x6709;&#x6784;&#x9020;&#x51fd;&#x6570;&#xff0c;&#x53ef;&#x4ee5;&#x6709;&#x62bd;&#x8c61;&#x7684;&#x65b9;&#x6cd5;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_965667011" MODIFIED="1532056889066" TEXT="&#x7279;&#x6027;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_186769525" MODIFIED="1472778412158" TEXT="&#x5b83;&#x662f;&#x5bf9;&#x884c;&#x4e3a;&#x7684;&#x62bd;&#x8c61;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1773369944" MODIFIED="1472778412158" TEXT="&#x63a5;&#x53e3;&#x4e2d;&#x7684;&#x53d8;&#x91cf;&#x4f1a;&#x88ab;&#x9690;&#x5f0f;&#x5730;&#x6307;&#x5b9a;&#x4e3a;public static final&#x53d8;&#x91cf;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_374158368" MODIFIED="1472778412158" TEXT="&#x65b9;&#x6cd5;&#x4f1a;&#x88ab;&#x9690;&#x5f0f;&#x5730;&#x6307;&#x5b9a;&#x4e3a;public abstract&#x65b9;&#x6cd5;&#x4e14;&#x53ea;&#x80fd;&#x662f;public abstract&#x65b9;&#x6cd5;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_745640323" MODIFIED="1472778412158" TEXT="&#x63a5;&#x53e3;&#x4e2d;&#x6240;&#x6709;&#x7684;&#x65b9;&#x6cd5;&#x4e0d;&#x80fd;&#x6709;&#x5177;&#x4f53;&#x7684;&#x5b9e;&#x73b0;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1222615369" MODIFIED="1472778412158" TEXT="&#x63a5;&#x53e3;&#x53ef;&#x4ee5;&#x7ee7;&#x627f;&#x63a5;&#x53e3;,&#x4f46;&#x4e0d;&#x53ef;&#x4ee5; implements&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_638083860" MODIFIED="1472778412158" TEXT="&#x7c7b;&#x53ef;&#x4ee5;implements&#x63a5;&#x53e3;,&#x800c;&#x4e14;&#x53ef;&#x4ee5;implements&#x591a;&#x4e2a;&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1827925817" MODIFIED="1472778412158" TEXT="&#x63a5;&#x53e3;&#x53ef;&#x4ee5;extends&#x63a5;&#x53e3;&#xff0c;&#x800c;&#x4e14;&#x662f;&#x591a;&#x7ee7;&#x627f;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_135104505" MODIFIED="1472778412158" TEXT="&#x6ce8;&#x610f;&#xff1a; &#x7c7b;&#x53ea;&#x80fd;&#x662f;&#x5355;&#x7ee7;&#x627f;&#x7684;&#xff0c;&#x4f46;&#x53ef;&#x4ee5;&#x5b9e;&#x73b0;&#x591a;&#x4e2a;&#x63a5;&#x53e3;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1230167334" MODIFIED="1532056889066" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_594855534" MODIFIED="1532056889066" TEXT="&#x884c;&#x4e3a;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1955834297" MODIFIED="1472778412158" TEXT="public interface Name { }"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_679665771" MODIFIED="1472778412158" TEXT="public class A implements Name{ .... }"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_891061614" MODIFIED="1472778412158" TEXT="&#x4f5c;&#x4e3a;&#x4e00;&#x4e2a;&#x5e38;&#x91cf;&#x7c7b;&#x4f7f;&#x7528;"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1175877370" MODIFIED="1532056889066" TEXT="&#x4ece;&#x5185;&#x5916;&#x90e8;&#x6765;&#x533a;&#x5206;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1929222220" MODIFIED="1472778412158" TEXT="&#x5916;&#x90e8;&#x7c7b;">
<icon BUILTIN="flag"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_60985795" LINK="http://www.cnblogs.com/jiangao/archive/2012/02/23/2364119.html" MODIFIED="1532056889066" TEXT="&#x5185;&#x90e8;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1969151790" MODIFIED="1532056889066" TEXT="?&#x662f;&#x4ec0;&#x4e48;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_283453288" MODIFIED="1472778412158" TEXT="&#x5728;&#x5916;&#x90e8;&#x7c7b;&#x4e2d;&#x65b9;&#x6cd5;&#x95f4;&#x5b9a;&#x4e49;&#x7684;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_825840238" MODIFIED="1532056889066" TEXT="&#x7279;&#x6027;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_231076805" MODIFIED="1472778412173" TEXT="&#x5185;&#x90e8;&#x7c7b;&#x4ecd;&#x7136;&#x662f;&#x4e00;&#x4e2a;&#x72ec;&#x7acb;&#x7684;&#x7c7b;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1960105828" MODIFIED="1472778412173" TEXT="&#x7f16;&#x8bd1;&#x4e4b;&#x540e;&#x5185;&#x90e8;&#x7c7b;&#x4f1a;&#x88ab;&#x7f16;&#x8bd1;&#x6210;&#x72ec;&#x7acb;&#x7684;.class&#x6587;&#x4ef6;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1063248877" MODIFIED="1472778412173" TEXT="&#x5185;&#x90e8;&#x7c7b;&#x53ef;&#x4ee5;&#x81ea;&#x7531;&#x5730;&#x8bbf;&#x95ee;&#x5916;&#x90e8;&#x7c7b;&#x7684;&#x6210;&#x5458;&#x53d8;&#x91cf;&#xff0c;&#x65e0;&#x8bba;&#x662f;&#x5426;&#x662f;private&#x7684;"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1558919482" MODIFIED="1532056889066" TEXT="&#x9759;&#x6001;&#x5185;&#x90e8;&#x7c7b;&#x53ea;&#x80fd;&#x8bbf;&#x95ee;&#x5916;&#x90e8;&#x7c7b;&#x7684;&#x9759;&#x6001;&#x5b57;&#x6bb5;&#x6216;&#x9759;&#x6001;&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1804830233" MODIFIED="1472778412173" TEXT="&#x9759;&#x6001;&#xff1f;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1874987066" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1734984929" MODIFIED="1532056889066" TEXT="&#x6210;&#x5458;&#x5185;&#x90e8;&#x7c7b;&#xff08;&#x548c;&#x65b9;&#x6cd5;&#x53ca;&#x5b57;&#x6bb5;&#x5904;&#x4e8e;&#x540c;&#x4e00;&#x7ea7;&#x522b;&#x7684;&#x7c7b;&#xff09;">
<icon BUILTIN="full-1"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_973705528" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;&#xff08;&#x9759;&#x6001;&#x548c;&#x975e;&#x9759;&#x6001;&#xff09;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1979779813" MODIFIED="1532056889066" TEXT="&#x9759;&#x6001;&#x5185;&#x90e8;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_386520586" MODIFIED="1472778412173" TEXT="&#x53ea;&#x80fd;&#x8bbf;&#x95ee;&#x5916;&#x90e8;&#x7c7b;&#x7684;&#x9759;&#x6001;&#x6210;&#x5458;&#x3002;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1383892500" MODIFIED="1472778412173" TEXT="&#x53ef;&#x4ee5;&#x5b9a;&#x4e49;&#x9759;&#x6001;&#x6210;&#x5458;&#x53d8;&#x91cf;&#x548c;&#x975e;&#x9759;&#x6001;&#x6210;&#x5458;&#x53d8;&#x91cf;&#x4ee5;&#x53ca;&#x5e38;&#x91cf;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_587716816" MODIFIED="1532056889066" TEXT="&#x975e;&#x9759;&#x6001;&#x5185;&#x90e8;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_606140756" MODIFIED="1472778412173" TEXT="&#x5916;&#x56f4;&#x7c7b;&#x548c;&#x5185;&#x90e8;&#x7c7b;&#x53ef;&#x4e92;&#x76f8;&#x8bbf;&#x95ee;&#x81ea;&#x5df1;&#x7684;&#x79c1;&#x6709;&#x6210;&#x5458;&#x3002;&#x4e0d;&#x8bba;&#x9759;&#x6001;&#x4e0e;&#x975e;&#x9759;&#x6001;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_9053151" MODIFIED="1491891032291" TEXT="&#x5185;&#x90e8;&#x7c7b;&#x4e2d;&#x4e0d;&#x80fd;&#x5b9a;&#x4e49;&#x9759;&#x6001;&#x6210;&#x5458;&#x53d8;&#x91cf;&#x3002;&#xff08;&#x6bd4;&#x5982;&#xff1a; static int mNo = 1&#xff09;">
<icon BUILTIN="bookmark"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_914249976" MODIFIED="1472778412173" TEXT="&#x4f46;&#x53ef;&#x4ee5;&#x5b9a;&#x4e49;&#x5e38;&#x91cf;&#x548c;&#x9759;&#x6001;&#x5e38;&#x91cf;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1786377904" MODIFIED="1532056889066" TEXT="&#x5185;&#x90e8;&#x7c7b;&#x7684;&#x5b9e;&#x4f8b;&#x5316;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1223770241" MODIFIED="1472778412173" TEXT="OuterClass outer = new OuterClass&#xff08;&#xff09;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_494376062" MODIFIED="1472778412173" TEXT="InnerClass inner  = outer. new InnerClass()"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1329707357" MODIFIED="1532056889066" TEXT="&#x5185;&#x90e8;&#x7c7b;&#x7684;&#x8986;&#x76d6;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1588534853" MODIFIED="1532056889066" TEXT="&#x663e;&#x793a;&#x7684;&#x58f0;&#x660e;&#x5b50;&#x7c7b;&#x4e2d;&#x7684;&#x5185;&#x90e8;&#x7c7b;&#x662f;&#x7ee7;&#x627f;&#x4e86;&#x7236;&#x7c7b;&#x4e2d;&#x7684;&#x5185;&#x90e8;&#x7c7b;&#x3002; P213">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1720169741" MODIFIED="1491888090389" TEXT="&#x5916;&#x90e8;&#x7c7b;A&#x9996;&#x5148;&#x8981;extends&#x53e6;&#x5916;&#x4e00;&#x4e2a;&#x7c7b;B">
<icon BUILTIN="messagebox_warning"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_45140617" MODIFIED="1472778412173" TEXT="&#x7136;&#x540e;&#x8be5;&#x7c7b;A&#x4e2d;&#x7684;&#x5185;&#x90e8;&#x7c7b;&#x624d;&#x53ef;&#x4ee5;extends&#x7236;&#x7c7b;(&#x7c7b;B)&#x4e2d;&#x7684;&#x5185;&#x90e8;&#x7c7b;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1508890595" MODIFIED="1532056889066" TEXT="&#x5c40;&#x90e8;&#xff08;&#x65b9;&#x6cd5;&#xff09;&#x5185;&#x90e8;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1201104120" MODIFIED="1532056889066" TEXT="?">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_964425083" MODIFIED="1472778412173" TEXT="&#x628a;&#x7c7b;&#x7684;&#x5b9a;&#x4e49;&#x653e;&#x5728;&#x65b9;&#x6cd5;&#x5185;&#x90e8;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_82623662" MODIFIED="1532056889066" TEXT="&#x7279;&#x6027;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1674320374" MODIFIED="1472778412173" TEXT="&#x5c40;&#x90e8;&#x5185;&#x90e8;&#x7c7b;&#x53ea;&#x80fd;&#x5728;&#x5b9a;&#x4e49;&#x8be5;&#x5185;&#x90e8;&#x7c7b;&#x7684;&#x65b9;&#x6cd5;&#x5185;&#x5b9e;&#x4f8b;&#x5316;&#xff0c;&#x4e0d;&#x53ef;&#x4ee5;&#x5728;&#x6b64;&#x65b9;&#x6cd5;&#x5916;&#x5bf9;&#x5176;&#x5b9e;&#x4f8b;&#x5316;&#x3002;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1477591645" MODIFIED="1491892051846" TEXT=" &#x65b9;&#x6cd5;&#x4f53;&#x4e2d;&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;&#x5c40;&#x90e8;&#x5185;&#x90e8;&#x7c7b;&#xff0c;&#x4f46;&#x662f;&#x8bbf;&#x95ee;&#x8bed;&#x53e5;&#x5fc5;&#x987b;&#x5728;&#x5b9a;&#x4e49;&#x5c40;&#x90e8;&#x5185;&#x90e8;&#x7c7b;&#x4e4b;&#x540e;&#x3002;">
<icon BUILTIN="messagebox_warning"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_274026491" MODIFIED="1532056889066" TEXT="&#x5c40;&#x90e8;&#x5185;&#x90e8;&#x7c7b;&#x80fd;&#x8bbf;&#x95ee;&#x65b9;&#x6cd5;&#x4f53;&#x4e2d;&#x7684;&#x5e38;&#x91cf;&#x6216;&#x53d8;&#x91cf;&#x3002;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1881477541" MODIFIED="1472778412173" TEXT="1.8&#x7684;&#x7248;&#x672c;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_365126617" MODIFIED="1532056889066" TEXT="&#x5c40;&#x90e8;&#x5185;&#x90e8;&#x7c7b;&#x53ea;&#x80fd;&#x8bbf;&#x95ee;&#x65b9;&#x6cd5;&#x4f53;&#x4e2d;&#x7684;final&#x4fee;&#x9970;&#x7684;&#x5e38;&#x91cf;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1553059531" MODIFIED="1472778412173" TEXT="1.7&#x7248;&#x672c;&#x53ca;&#x4ee5;&#x4e0b;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1381119102" MODIFIED="1472778412173" TEXT="&#x5916;&#x90e8;&#xff08;&#x56f4;&#xff09;&#x7c7b;&#x8bbf;&#x95ee;&#x4e0d;&#x5230;&#x65b9;&#x6cd5;&#x4e2d;&#x7684;&#x5c40;&#x90e8;&#x5185;&#x90e8;&#x7c7b;&#xff0c;&#x4f46;&#x662f;&#x5c40;&#x90e8;&#x5185;&#x90e8;&#x7c7b;&#x53ef;&#x4ee5;&#x8bbf;&#x95ee;&#x5916;&#x56f4;&#x7c7b;&#x7684;&#x4efb;&#x4f55;&#x6210;&#x5458;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1517367809" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1493693883301" FOLDED="true" ID="ID_343553762" MODIFIED="1532056889066" TEXT="&#x975e;&#x9759;&#x6001;&#x5185;&#x90e8;&#x7c7b; ">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_12845263" MODIFIED="1493693938097" TEXT="&#x53ef;&#x4ee5;&#x5728;&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x548c;&#x975e;&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x4e2d;"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_16543129" MODIFIED="1532056889066" TEXT="&#x533f;&#x540d;&#x5185;&#x90e8;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_250383597" MODIFIED="1532056889066" TEXT="?">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1485790645" MODIFIED="1532056889066" TEXT="&#x5728;&#x65b9;&#x6cd5;&#x5185;&#x5b9a;&#x4e49;&#x7684;&#x6ca1;&#x6709;&#x540d;&#x5b57;&#x7684;&#x7c7b;&#xff0c;&#x53ef;&#x4ee5;&#x662f;&#xff1a;  ">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_507165994" MODIFIED="1472778412173" TEXT="&#x63a5;&#x53e3;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_901165197" MODIFIED="1472778412173" TEXT="&#x62bd;&#x8c61;&#x7c7b;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_907307464" MODIFIED="1472778412173" TEXT="&#x4f8b;&#x5982;&#xff1a; new &#x63a5;&#x53e3;  &#x6216; new &#x62bd;&#x8c61;&#x7c7b;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_228752571" MODIFIED="1532056889066" TEXT="&#x5206;&#x7c7b;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1043982499" MODIFIED="1472778412173" TEXT="&#x975e;&#x9759;&#x6001;&#x533f;&#x540d;&#x5185;&#x90e8;&#x7c7b;"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1674246824" MODIFIED="1532056889066" TEXT="&#x4e3a;&#x4ec0;&#x4e48;&#x9700;&#x8981;&#x5185;&#x90e8;&#x7c7b;&#xff1f;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_739338693" MODIFIED="1472778412173" TEXT="&#x63a5;&#x53e3;&#x89e3;&#x51b3;&#x4e86;&#x90e8;&#x5206;&#x7684;&#x591a;&#x91cd;&#x7ee7;&#x627f;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1149639896" MODIFIED="1472778412173" TEXT="&#x800c;&#x5185;&#x90e8;&#x7c7b;&#x4f7f;&#x5f97;&#x591a;&#x91cd;&#x7ee7;&#x627f;&#x53d8;&#x5f97;&#x5b8c;&#x6574; P204"/>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1005494044" MODIFIED="1532308204335">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25968;&#32452;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_21978449" MODIFIED="1532056889066" TEXT="&#x7ef4;&#x5ea6;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1925421068" MODIFIED="1532056889066" TEXT="&#x4e00;&#x7ef4;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_469815645" MODIFIED="1472778412189" TEXT="String [ ] a = new String[ 10 ]"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_157389719" MODIFIED="1532056889066" TEXT="&#x4e8c;&#x7ef4;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_517948900" MODIFIED="1472778412189" TEXT="String [ ] [ ] a = new String[ 10 ] [10];"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1322704960" MODIFIED="1472778412189" TEXT="String [ ] [ ]  a = new String[10] [ ];"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1883824820" MODIFIED="1472778412189" TEXT="String[ ] [ ] a = { { } ,{ }, { },}"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_262887869" MODIFIED="1472778412189" TEXT="&#x591a;&#x7ef4;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1552397160" MODIFIED="1532056889066" TEXT="&#x6570;&#x7ec4;&#x7684;&#x58f0;&#x660e;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_35890548" MODIFIED="1472778412189" TEXT="String [ ] a = new String [10];"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_408057929" MODIFIED="1472778412189" TEXT="String [ ]a = new String [ ]{?,?...};"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_183897044" MODIFIED="1472778412189" TEXT="String [ ] a = {?,?....}"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_814759300" MODIFIED="1532056889066" TEXT="&#x6570;&#x7ec4;&#x7684;&#x904d;&#x5386;">
<node COLOR="#111111" CREATED="1489017053568" ID="ID_608847680" MODIFIED="1489017058403" TEXT="for&#x5faa;&#x73af;"/>
<node COLOR="#111111" CREATED="1489017058755" ID="ID_399650627" MODIFIED="1489017063829" TEXT="foreach&#x5faa;&#x73af;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_729530051" MODIFIED="1532056889066" TEXT="&#x6570;&#x7ec4;&#x5143;&#x7d20;&#x7684;&#x4f7f;&#x7528;&#x65b9;&#x5f0f;">
<node COLOR="#111111" CREATED="1489017067283" ID="ID_44890052" MODIFIED="1489017073714" TEXT="array[index]"/>
</node>
</node>
<node COLOR="#111111" CREATED="1532308204293" FOLDED="true" ID="ID_502107280" MODIFIED="1532308211043" TEXT="">
<node COLOR="#111111" CREATED="1519470622412" FOLDED="true" ID="ID_1351891323" MODIFIED="1532308202423" TEXT="&#x6392;&#x5e8f;">
<node COLOR="#111111" CREATED="1519470649555" FOLDED="true" ID="ID_1897211813" MODIFIED="1532056889066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20882;&#27873;:
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1521155566246" ID="ID_327500002" MODIFIED="1521155572097">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <ul>
      <li class="list-num-1-1 list-num-paddingleft-1">
        <div class="para" label-module="para">
          &#27604;&#36739;&#30456;&#37051;&#30340;&#20803;&#32032;&#12290;&#22914;&#26524;&#31532;&#19968;&#20010;&#27604;&#31532;&#20108;&#20010;&#22823;&#65292;&#23601;&#20132;&#25442;&#20182;&#20204;&#20004;&#20010;&#12290;
        </div>
      </li>
      <li class="list-num-1-2 list-num-paddingleft-1">
        <div class="para" label-module="para">
          &#23545;&#27599;&#19968;&#23545;&#30456;&#37051;&#20803;&#32032;&#20316;&#21516;&#26679;&#30340;&#24037;&#20316;&#65292;&#20174;&#24320;&#22987;&#31532;&#19968;&#23545;&#21040;&#32467;&#23614;&#30340;&#26368;&#21518;&#19968;&#23545;&#12290;&#22312;&#36825;&#19968;&#28857;&#65292;&#26368;&#21518;&#30340;&#20803;&#32032;&#24212;&#35813;&#20250;&#26159;&#26368;&#22823;&#30340;&#25968;&#12290;
        </div>
      </li>
      <li class="list-num-1-3 list-num-paddingleft-1">
        <div class="para" label-module="para">
          &#38024;&#23545;&#25152;&#26377;&#30340;&#20803;&#32032;&#37325;&#22797;&#20197;&#19978;&#30340;&#27493;&#39588;&#65292;&#38500;&#20102;&#26368;&#21518;&#19968;&#20010;&#12290;
        </div>
      </li>
      <li class="list-num-1-4 list-num-paddingleft-1">
        <div class="para" label-module="para">
          &#25345;&#32493;&#27599;&#27425;&#23545;&#36234;&#26469;&#36234;&#23569;&#30340;&#20803;&#32032;&#37325;&#22797;&#19978;&#38754;&#30340;&#27493;&#39588;&#65292;&#30452;&#21040;&#27809;&#26377;&#20219;&#20309;&#19968;&#23545;&#25968;&#23383;&#38656;&#35201;&#27604;&#36739;
        </div>
      </li>
    </ul>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1519470628894" ID="ID_1363973229" MODIFIED="1519470648078">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <pre style="background-color: #2b2b2b; color: #a9b7c6; font-family: Consolas; font-size: 15.0pt"><font color="#cc7832">public void </font><font color="#ffc66d">bubbleSort</font>() {<br />    <font color="#cc7832">int </font>len = <font color="#9876aa">array</font>.<font color="#9876aa">length</font><font color="#cc7832">;<br />    int </font>temp<font color="#cc7832">;<br />    for </font>(<font color="#cc7832">int </font>i = <font color="#6897bb">0</font><font color="#cc7832">; </font>i &lt; len<font color="#cc7832">; </font>i++) {<br />        <font color="#cc7832">for </font>(<font color="#cc7832">int </font>j = <font color="#6897bb">1</font><font color="#cc7832">; </font>j &lt; len - i<font color="#cc7832">; </font>j++) {<br />            <font color="#cc7832">if </font>(<font color="#9876aa">array</font>[j] &gt; <font color="#9876aa">array</font>[j - <font color="#6897bb">1</font>]) {<br />                temp = <font color="#9876aa">array</font>[j]<font color="#cc7832">;<br />                </font><font color="#9876aa">array</font>[j] = <font color="#9876aa">array</font>[j - <font color="#6897bb">1</font>]<font color="#cc7832">;<br />                </font><font color="#9876aa">array</font>[j - <font color="#6897bb">1</font>] = temp<font color="#cc7832">;<br />            </font>}<br />        }<br />    }<br />    printArray()<font color="#cc7832">;<br /></font>}</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1519470653762" FOLDED="true" ID="ID_1061399275" MODIFIED="1532056889066" TEXT="&#x63d2;&#x5165;">
<node COLOR="#111111" CREATED="1521156580538" ID="ID_1278209478" MODIFIED="1521156584228">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <div class="para" label-module="para">
      &#9352; &#20174;&#31532;&#19968;&#20010;&#20803;&#32032;&#24320;&#22987;&#65292;&#35813;&#20803;&#32032;&#21487;&#20197;&#35748;&#20026;&#24050;&#32463;&#34987;&#25490;&#24207;
    </div>
    <div class="para" label-module="para">
      &#9353; &#21462;&#20986;&#19979;&#19968;&#20010;&#20803;&#32032;&#65292;&#22312;&#24050;&#32463;&#25490;&#24207;&#30340;&#20803;&#32032;&#24207;&#21015;&#20013;&#20174;&#21518;&#21521;&#21069;&#25195;&#25551;
    </div>
    <div class="para" label-module="para">
      &#9354; &#22914;&#26524;&#35813;&#20803;&#32032;&#65288;&#24050;&#25490;&#24207;&#65289;&#22823;&#20110;&#26032;&#20803;&#32032;&#65292;&#23558;&#35813;&#20803;&#32032;&#31227;&#21040;&#19979;&#19968;&#20301;&#32622;
    </div>
    <div class="para" label-module="para">
      &#9355; &#37325;&#22797;&#27493;&#39588;3&#65292;&#30452;&#21040;&#25214;&#21040;&#24050;&#25490;&#24207;&#30340;&#20803;&#32032;&#23567;&#20110;&#25110;&#32773;&#31561;&#20110;&#26032;&#20803;&#32032;&#30340;&#20301;&#32622;
    </div>
    <div class="para" label-module="para">
      &#9356; &#23558;&#26032;&#20803;&#32032;&#25554;&#20837;&#21040;&#19979;&#19968;&#20301;&#32622;&#20013;
    </div>
    <div class="para" label-module="para">
      &#9357; &#37325;&#22797;&#27493;&#39588;2~5
    </div>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1519470665021" ID="ID_218579339" MODIFIED="1519898862526">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #2b2b2b; color: #a9b7c6; font-family: Consolas; font-size: 15.0pt"><font color="#cc7832">public void </font><font color="#ffc66d">insertSort</font>() {<br />    <font color="#cc7832">int </font>j<font color="#cc7832">;<br />    int </font>element<font color="#cc7832">;<br />    for </font>(<font color="#cc7832">int </font>i = 1<font color="#cc7832">; </font>i &lt; <font color="#9876aa">array</font>.<font color="#9876aa">length</font><font color="#cc7832">; </font>i++) {<br />        element = <font color="#9876aa">array</font>[i]<font color="#cc7832">;<br />        </font>j=i<font color="#cc7832">;<br />        while </font>(j &gt; <font color="#6897bb">0 </font>&amp;&amp; element &gt; <font color="#9876aa">array</font>[j - <font color="#6897bb">1</font>]) {<br />            <font color="#9876aa">array</font>[j] = <font color="#9876aa">array</font>[j - <font color="#6897bb">1</font>]<font color="#cc7832">;<br />            </font>j--<font color="#cc7832">;<br />        </font>}<br />        <font color="#9876aa">array</font>[j] = element<font color="#cc7832">;<br />    </font>}<br />    printArray()<font color="#cc7832">;<br /></font>}</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1519472272890" FOLDED="true" ID="ID_424067971" MODIFIED="1532056889066" TEXT="&#x9009;&#x62e9;&#x6392;&#x5e8f;">
<node COLOR="#111111" CREATED="1519472278862" ID="ID_864529891" MODIFIED="1519472281869">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #2b2b2b; color: #a9b7c6; font-family: Consolas; font-size: 15.0pt"><font color="#808080">//</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#27599;&#27425;&#24490;&#29615;&#20174;&#21097;&#20313;&#30340;&#25214;&#21040;&#26368;&#23567;</font><font color="#808080">/</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#22823;&#30340;&#28982;&#21518;&#25918;&#21040;&#21069;&#38754;&#20301;&#32622;</font><font color="#808080">,<br />// </font><font color="#808080" face="&#x5b8b;&#x4f53;">&#24050;&#32463;&#25490;&#24207;&#22909;&#30340;&#20803;&#32032;&#19981;&#21442;&#19982;&#21518;&#32493;&#30340;&#27604;&#36739;<br /></font><font color="#cc7832">public void </font><font color="#ffc66d">selectionSort</font>() {<br />    <font color="#cc7832">int </font>temp<font color="#cc7832">, </font>i<font color="#cc7832">, </font>j<font color="#cc7832">, </font>k<font color="#cc7832">,</font>len=<font color="#9876aa">array</font>.<font color="#9876aa">length</font><font color="#cc7832">;<br />    for </font>(i = <font color="#6897bb">0</font><font color="#cc7832">; </font>i &lt; len - <font color="#6897bb">1</font><font color="#cc7832">; </font>i++) {<br />        k = i<font color="#cc7832">;<br />        for </font>(j = i + <font color="#6897bb">1</font><font color="#cc7832">; </font>j &lt; len<font color="#cc7832">; </font>j++) {<br />            <font color="#cc7832">if </font>(<font color="#9876aa">array</font>[j] &gt; <font color="#9876aa">array</font>[k]) {<br />                k = j<font color="#cc7832">;<br />            </font>}<br />        }<br />        <font color="#cc7832">if </font>(k != i) {<font color="#808080">//</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#24403;</font><font color="#808080">array[i]</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#19981;&#26159;&#26368;&#23567;</font><font color="#808080">/</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#22823;&#30340;&#26102;</font><font color="#808080">,</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#20132;&#25442;&#20803;&#32032;<br />            </font>temp = <font color="#9876aa">array</font>[i]<font color="#cc7832">;<br />            </font><font color="#9876aa">array</font>[i] = <font color="#9876aa">array</font>[k]<font color="#cc7832">;<br />            </font><font color="#9876aa">array</font>[k] = temp<font color="#cc7832">;<br />        </font>}<br />    }<br />    printArray()<font color="#cc7832">;<br /></font>}</pre>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_588124496" LINK="http://lavasoft.blog.51cto.com/62575/79243/" MODIFIED="1532056889066" TEXT="null">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_20189829" MODIFIED="1532056889066" TEXT="&#xff1f;  &#x4ee3;&#x8868;&#x4e0d;&#x786e;&#x5b9a;&#x7684;&#x5bf9;&#x8c61;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_559857082" MODIFIED="1472778412189" TEXT="&#x4f46;&#x5b83;&#x4e0d;&#x662f;&#x5bf9;&#x8c61;">
<icon BUILTIN="flag"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1269530108" MODIFIED="1472778412189" TEXT="&#x53ef;&#x4ee5;&#x5c06;null&#x8d4b;&#x7ed9;&#x5f15;&#x7528;&#x7c7b;&#x578b;&#x53d8;&#x91cf;&#xff0c;&#x4f46;&#x4e0d;&#x53ef;&#x4ee5;&#x5c06;null&#x8d4b;&#x7ed9;&#x57fa;&#x672c;&#x7c7b;&#x578b;&#x53d8;&#x91cf;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1706162467" MODIFIED="1532056889066" TEXT="&#x4f5c;&#x7528;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_7114766" MODIFIED="1472778412189" TEXT="&#x5224;&#x65ad;&#x4e00;&#x4e2a;&#x5f15;&#x7528;&#x7c7b;&#x578b;&#x6570;&#x636e;&#x662f;&#x5426;null&#x3002; &#x7528;==&#x6765;&#x5224;&#x65ad;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1056373093" MODIFIED="1472778412189" TEXT="&#x91ca;&#x653e;&#x5185;&#x5b58;&#xff0c;&#x8ba9;&#x4e00;&#x4e2a;&#x975e;null&#x7684;&#x5f15;&#x7528;&#x7c7b;&#x578b;&#x53d8;&#x91cf;&#x6307;&#x5411;null&#x3002;&#x8fd9;&#x6837;&#x8fd9;&#x4e2a;&#x5bf9;&#x8c61;&#x5c31;&#x4e0d;&#x518d;&#x88ab;&#x4efb;&#x4f55;&#x5bf9;&#x8c61;&#x5e94;&#x7528;&#x4e86;&#x3002;&#x7b49;&#x5f85;JVM&#x5783;&#x573e;&#x56de;&#x6536;&#x673a;&#x5236;&#x53bb;&#x56de;&#x6536;&#x3002;"/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066327" FOLDED="true" ID="ID_272912331" MODIFIED="1532056889066" TEXT="&#x57fa;&#x672c;&#x548c;&#x5f15;&#x7528;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x7684;&#x5f02;&#x540c;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_229257341" MODIFIED="1532056889066" TEXT="&#x6570;&#x636e;&#x7c7b;&#x578b;&#x6307;&#x5411;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_944855553" MODIFIED="1532056889066" TEXT="&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1801442725" MODIFIED="1472778412189" TEXT="&#x6307;&#x5411;&#x5177;&#x4f53;&#x7684;&#x6570;&#x503c;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1687759424" MODIFIED="1532056889066" TEXT="&#x5f15;&#x7528;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_785064032" MODIFIED="1532056889066" TEXT="&#x6307;&#x5411;&#x5b58;&#x6570;&#x636e;&#x5bf9;&#x8c61;&#x7684;&#x5185;&#x5b58;&#x5730;&#x5740;,&#x5373;&#x53d8;&#x91cf;&#x540d;&#x6307;&#x5411;hash&#x503c;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1269144534" LINK="http://jianfeihit.iteye.com/blog/1786213" MODIFIED="1472778412189" TEXT="&#xff1f;hash"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_1750647086" MODIFIED="1532056889066" TEXT="&#x4ece;&#x5185;&#x5b58;&#x6784;&#x5efa;&#x65b9;&#x9762;&#x6765;&#x8bf4;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_448242934" MODIFIED="1532056889066" TEXT="&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1682742064" MODIFIED="1472778412189" TEXT="&#x58f0;&#x660e;&#x4e4b;&#x540e;java&#x5c31;&#x4f1a;&#x7acb;&#x523b;&#x5206;&#x914d;&#x7ed9;&#x4ed6;&#x5185;&#x5b58;&#x7a7a;&#x95f4;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_520116787" MODIFIED="1532056889066" TEXT="&#x5f15;&#x7528;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_450950214" MODIFIED="1472778412189" TEXT="&#x5b83;&#x4ee5;&#x7279;&#x6b8a;&#x7684;&#x65b9;&#x5f0f;(&#x7c7b;&#x4f3c;C&#x6307;&#x9488;)&#x6307;&#x5411;&#x5bf9;&#x8c61;&#x5b9e;&#x4f53;&#xff08;&#x5177;&#x4f53;&#x7684;&#x503c;&#xff09;&#xff0c;&#x8fd9;&#x7c7b;&#x53d8;&#x91cf;&#x58f0;&#x660e;&#x65f6;&#x4e0d;&#x4f1a;&#x5206;&#x914d;&#x5185;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_1777998590" MODIFIED="1532056889066" TEXT="&#x4ece;&#x4f7f;&#x7528;&#x65b9;&#x9762;&#x6765;&#x8bf4;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1332514532" MODIFIED="1532056889066" TEXT="&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_743214424" MODIFIED="1472778412189" TEXT="&#x4f7f;&#x7528;&#x65f6;&#x9700;&#x8981;&#x8d4b;&#x5177;&#x4f53;&#x503c;,&#x5224;&#x65ad;&#x65f6;&#x4f7f;&#x7528;&#x201c;==&#x201d;&#x53f7;"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_132536281" MODIFIED="1532056889066" TEXT="&#x5f15;&#x7528;&#x6570;&#x636e;&#x7c7b;&#x578b;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_240589774" MODIFIED="1472778412189" TEXT="&#x4f7f;&#x7528;&#x65f6;&#x53ef;&#x4ee5;&#x8d4b;null,&#x5224;&#x65ad;&#x65f6;&#x4f7f;&#x7528;equals&#x65b9;&#x6cd5;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1472387066327" FOLDED="true" ID="ID_230797767" MODIFIED="1532070945658" POSITION="right" TEXT="String">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472387066327" ID="ID_236276037" LINK="http://www.cnblogs.com/ITtangtang/p/3976820.html" MODIFIED="1495165875286" TEXT="&#x5b57;&#x7b26;&#x4e32;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1472387066327" ID="ID_63084598" MODIFIED="1495165875286" TEXT="&quot;&quot;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1472387066327" FOLDED="true" ID="ID_1717366049" MODIFIED="1532056889066" TEXT="&#x4f7f;&#x7528;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_1527004916" MODIFIED="1495165875287" TEXT="String value = &#x201c;aaa&#x201d;; &#x4f1a;&#x88ab;&#x653e;&#x5230;&#x5e38;&#x91cf;&#x6c60;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473602025286" FOLDED="true" ID="ID_643537450" MODIFIED="1532056889066" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473602029998" ID="ID_229043758" MODIFIED="1495165875287" TEXT="public String()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602115071" ID="ID_1189267517" MODIFIED="1495165875287" TEXT="public String(String original)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602122641" ID="ID_165077752" MODIFIED="1495165875288" TEXT="public String(char value[])">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602135260" ID="ID_886198552" MODIFIED="1495165875288" TEXT="public String(char value[], int offset, int count)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602161495" ID="ID_1423020662" MODIFIED="1495165875288" TEXT="public String(byte bytes[], int offset, int length)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602175170" ID="ID_1082969621" MODIFIED="1495165875288" TEXT="public String(byte bytes[])">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602182379" ID="ID_1352098851" MODIFIED="1495165875288" TEXT="public String(StringBuffer buffer)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602187759" ID="ID_1818509133" MODIFIED="1495165875289" TEXT="public String(StringBuilder builder)">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473598613967" FOLDED="true" ID="ID_770551902" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473602200107" ID="ID_979604678" MODIFIED="1495165875289" TEXT="public int length()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602206399" ID="ID_1907166183" MODIFIED="1495165875289" TEXT="public boolean isEmpty()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602212452" ID="ID_1030974409" MODIFIED="1495165875289" TEXT="public char charAt(int index)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602370729" ID="ID_771954181" MODIFIED="1495165875290" TEXT="public byte[] getBytes()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602378277" ID="ID_955939741" MODIFIED="1495165875290" TEXT="public boolean equals(Object anObject)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602583975" ID="ID_1505000201" MODIFIED="1495165875290" TEXT="public boolean equalsIgnoreCase(String anotherString)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602590186" ID="ID_1582786628" MODIFIED="1495165875290" TEXT="public int compareTo(String anotherString)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602596324" ID="ID_1113364639" MODIFIED="1495165875290" TEXT="public int compareToIgnoreCase(String str)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602682548" ID="ID_1784100391" MODIFIED="1495376429067" TEXT="public boolean regionMatches(int toffset, String other, int ooffset,int len) ">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602693724" ID="ID_251347962" MODIFIED="1495376450095">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      public boolean regionMatches(boolean ignoreCase, int toffset,<font color="#111111">String other, int ooffset, int len)</font>
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602700347" ID="ID_43911649" MODIFIED="1495165875291" TEXT="public boolean startsWith(String prefix, int toffset)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602709597" ID="ID_1667659935" MODIFIED="1495165875291" TEXT="public boolean startsWith(String prefix)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602717189" ID="ID_163153093" MODIFIED="1495165875291" TEXT="public boolean endsWith(String suffix)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495376391868" FOLDED="true" ID="ID_1355367450" MODIFIED="1532056889066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      index of
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473602724093" ID="ID_296835692" MODIFIED="1495376391883" TEXT="public int indexOf(int ch)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602802451" ID="ID_423684627" MODIFIED="1495376391888" TEXT="public int indexOf(int ch, int fromIndex)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602808731" ID="ID_1166818508" MODIFIED="1495376391889" TEXT="public int indexOf(int ch, int fromIndex)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602822030" ID="ID_1254447931" MODIFIED="1495376391890" TEXT="public int lastIndexOf(int ch, int fromIndex)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602832100" ID="ID_1145264818" MODIFIED="1495376391891" TEXT="public int indexOf(String str)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602838740" ID="ID_32874964" MODIFIED="1495376391892" TEXT="public int indexOf(String str, int fromIndex)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473602889568" ID="ID_1628429452" MODIFIED="1495165875292" TEXT="public String substring(int beginIndex)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602895636" ID="ID_1109086916" MODIFIED="1495165875292" TEXT="public String substring(int beginIndex, int endIndex)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602901663" ID="ID_448720911" MODIFIED="1495165875293" TEXT="public CharSequence subSequence(int beginIndex, int endIndex)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602907206" ID="ID_50789449" MODIFIED="1495165875293" TEXT="public String concat(String str)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602912682" ID="ID_1909957221" MODIFIED="1495165875293" TEXT="public String replace(char oldChar, char newChar)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602922401" ID="ID_1446214293" MODIFIED="1495165875293" TEXT="public boolean matches(String regex)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602928661" ID="ID_1163532313" MODIFIED="1495165875293" TEXT="public boolean contains(CharSequence s)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602958916" ID="ID_1405857306" MODIFIED="1495165875294" TEXT="public String[] split(String regex, int limit)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473602965311" ID="ID_910949169" MODIFIED="1495165875294" TEXT="public String[] split(String regex)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495376351293" FOLDED="true" ID="ID_1906756246" MODIFIED="1532056889066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22823;&#23567;&#20889;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473602975445" ID="ID_552151992" MODIFIED="1495376351313" TEXT="public String toLowerCase(Locale locale)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602981407" ID="ID_1022462313" MODIFIED="1495376351315" TEXT="public String toLowerCase(Locale locale)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602986676" ID="ID_789183185" MODIFIED="1495376351316" TEXT="public String toUpperCase(Locale locale)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602992766" ID="ID_1675960719" MODIFIED="1495376351317" TEXT="public String toUpperCase()">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473602999293" ID="ID_118380734" MODIFIED="1495376351317" TEXT="public String toUpperCase()">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473603005762" ID="ID_711658105" MODIFIED="1495165875295" TEXT="public char[] toCharArray()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473603013537" ID="ID_581921243" MODIFIED="1495165875295" TEXT="public static String format(String format, Object... args)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473603022934" ID="ID_1101076970" LINK="String/string&#x7684;format&#x65b9;&#x6cd5;.txt" MODIFIED="1495165875295" TEXT="public static String format(Locale l, String format, Object... args)">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495376367407" FOLDED="true" ID="ID_232023939" MODIFIED="1532056889066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      valueOf
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473603049055" ID="ID_345800189" MODIFIED="1495376367422" TEXT="public static String valueOf(boolean b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473603054630" ID="ID_1388851444" MODIFIED="1495376367423" TEXT="public static String valueOf(char c)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473603063465" ID="ID_1377879214" MODIFIED="1495376367423" TEXT="public static String valueOf(int i)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473603070305" ID="ID_712753670" MODIFIED="1495376367424" TEXT="public static String valueOf(long l)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473603077390" ID="ID_555875910" MODIFIED="1495376367424" TEXT="public static String valueOf(float f)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1473603085419" ID="ID_1673322570" MODIFIED="1495376367425" TEXT="public static String valueOf(double d)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1473603358040" FOLDED="true" ID="ID_554533691" MODIFIED="1532056889066" TEXT="public native String intern()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1473603347549" ID="ID_639705620" MODIFIED="1473603347549" TEXT="&#x5148;&#x53bb;&#x5b57;&#x7b26;&#x4e32;&#x5e38;&#x91cf;&#x6c60;&#x4e2d;&#x67e5;&#x627e;&#x76f8;&#x5e94;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#xff0c;&#x5982;&#x679c;&#x5b57;&#x7b26;&#x4e32;&#x4e0d;&#x5b58;&#x5728;&#xff0c;&#x5c31;&#x4f1a;&#x5728;&#x5b57;&#x7b26;&#x4e32;&#x5e38;&#x91cf;&#x6c60;&#x4e2d;&#x521b;&#x5efa;&#x8be5;&#x5b57;&#x7b26;&#x4e32;&#x7136;&#x540e;&#x518d;&#x8fd4;&#x56de;&#x3002;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1489017149587" FOLDED="true" ID="ID_454105369" MODIFIED="1532056889066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23383;&#31526;&#20018;&#24120;&#37327;&#27744;(&#30693;&#36947;&#21363;&#21487;)
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1489018420613" ID="ID_1933077843" MODIFIED="1495165875298" TEXT="&#x7ba1;&#x7406;&#x6574;&#x4e2a;&#x5e94;&#x7528;&#x4e2d;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x533a;&#x57df;,&#x9664;&#x4e86;new String() &#x7684;&#x5b57;&#x7b26;&#x4e32;&#x4ee5;&#x5916;,&#x6240;&#x4ee5;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x90fd;&#x5728;&#x8fd9;&#x91cc;&#x5b58;&#x653e;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1489018465111" FOLDED="true" ID="ID_123941416" MODIFIED="1532056889066" TEXT="&#x8303;&#x4f8b;1">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1489018468969" ID="ID_1432565488" MODIFIED="1489018505716" TEXT="String a = &quot;abc&quot;; &#x548c; String b = newString(&quot;abc&quot;);&#x7684;&#x5730;&#x5740;&#x662f;&#x4e0d;&#x4e00;&#x6837;&#x7684;"/>
<node COLOR="#111111" CREATED="1489018507101" ID="ID_1890996007" MODIFIED="1489018512488" TEXT="a&#x5728;&#x5e38;&#x91cf;&#x6c60;"/>
<node COLOR="#111111" CREATED="1489018512940" ID="ID_1871369082" MODIFIED="1489018516500" TEXT="b&#x5728;&#x5185;&#x5b58;"/>
</node>
<node COLOR="#990000" CREATED="1489149293680" FOLDED="true" ID="ID_1088192155" MODIFIED="1532056889066" TEXT="&#x8303;&#x4f8b;2">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1489149319241" ID="ID_234003028" MODIFIED="1489150306217">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      String s1 = &quot;a&quot;+&quot;bc&quot;;&#160;
    </p>
    <p>
      String s2 = &quot;abc&quot;;
    </p>
    <p>
      String s3 = b+bc;&#160;&#160;
    </p>
    <p>
      String a1 = &quot;a&quot;;
    </p>
    <p>
      String a = &quot;a&quot;;
    </p>
    <p>
      String b&#160;= &quot;b&quot;;&#160;&#160;&#160;
    </p>
    <p>
      String bc = &quot;bc&quot;;&#160;
    </p>
    <p>
      String s4 = &quot;a&quot;+bc;
    </p>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1489149443181" ID="ID_886928073" MODIFIED="1489149466852" TEXT="System.out.println(s1 == s3);   &#x6253;&#x5370;false"/>
<node COLOR="#111111" CREATED="1489149543380" ID="ID_1147412792" MODIFIED="1489149557537" TEXT="System.out.println(s2==s1);  &#x6253;&#x5370; true"/>
<node COLOR="#111111" CREATED="1489150187722" ID="ID_274440674" MODIFIED="1489150247239" TEXT="System.out.println(s3==s4);  &#x6253;&#x5370;false"/>
<node COLOR="#111111" CREATED="1489149602504" ID="ID_604777089" MODIFIED="1489149641478" TEXT="System.out.println(a == a1); &#x6253;&#x5370;true"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495165923143" FOLDED="true" ID="ID_597930572" MODIFIED="1532056889066" TEXT="&#x76f8;&#x5173;&#x7684;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495165932944" FOLDED="true" ID="ID_661093915" MODIFIED="1532056889066" TEXT="StringBuilder">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495166642407" FOLDED="true" ID="ID_40726680" MODIFIED="1532056889066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495166612529" ID="ID_934683132" MODIFIED="1495166640448" TEXT="&#x5b57;&#x7b26;&#x4e32;&#x7f13;&#x51b2;&#x533a;&#x7c7b;,&#x975e;&#x7ebf;&#x7a0b;&#x5b89;&#x5168;"/>
</node>
<node COLOR="#111111" CREATED="1495166298101" FOLDED="true" ID="ID_1385240829" MODIFIED="1532056889066" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495166300649" ID="ID_1004032393" MODIFIED="1495166300649" TEXT="public StringBuilder()"/>
<node COLOR="#111111" CREATED="1495166300653" ID="ID_696407155" MODIFIED="1495166300653" TEXT="public StringBuilder(int capacity)"/>
<node COLOR="#111111" CREATED="1495166300654" ID="ID_1196686373" MODIFIED="1495166300654" TEXT="public StringBuilder(String str)"/>
<node COLOR="#111111" CREATED="1495166300654" ID="ID_1546359340" MODIFIED="1495166300654" TEXT="public StringBuilder(CharSequence seq)"/>
</node>
<node COLOR="#111111" CREATED="1495166302577" FOLDED="true" ID="ID_1575112423" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495166376895" FOLDED="true" ID="ID_406084730" MODIFIED="1532056889066" TEXT="&#x8ffd;&#x52a0;">
<node COLOR="#111111" CREATED="1495166317907" ID="ID_1437507366" MODIFIED="1495166317908" TEXT="public StringBuilder append(Object obj)"/>
<node COLOR="#111111" CREATED="1495166317913" ID="ID_187536475" MODIFIED="1495166317913" TEXT="public StringBuilder append(String str)"/>
<node COLOR="#111111" CREATED="1495166317914" ID="ID_31154755" MODIFIED="1495166317915" TEXT="public StringBuilder append(StringBuffer sb)"/>
<node COLOR="#111111" CREATED="1495166317918" ID="ID_1549779103" MODIFIED="1495166317918" TEXT="public StringBuilder append(CharSequence s)"/>
<node COLOR="#111111" CREATED="1495166317922" ID="ID_4225540" MODIFIED="1495166317923" TEXT="public StringBuilder append(CharSequence s, int start, int end)"/>
<node COLOR="#111111" CREATED="1495166317926" ID="ID_426988983" MODIFIED="1495166317926" TEXT="public StringBuilder append(char[] str)"/>
<node COLOR="#111111" CREATED="1495166317931" ID="ID_493308620" MODIFIED="1495166317931" TEXT="public StringBuilder append(char[] str, int offset, int len)"/>
<node COLOR="#111111" CREATED="1495166317931" ID="ID_527791617" MODIFIED="1495166317932" TEXT="public StringBuilder append(boolean b)"/>
<node COLOR="#111111" CREATED="1495166317932" ID="ID_628700048" MODIFIED="1495166317932" TEXT="public StringBuilder append(char c)"/>
<node COLOR="#111111" CREATED="1495166317932" ID="ID_855466244" MODIFIED="1495166317932" TEXT="public StringBuilder append(int i)"/>
<node COLOR="#111111" CREATED="1495166317936" ID="ID_1657982350" MODIFIED="1495166317936" TEXT="public StringBuilder append(long lng)"/>
<node COLOR="#111111" CREATED="1495166317937" ID="ID_1538044724" MODIFIED="1495166317937" TEXT="public StringBuilder append(float f)"/>
<node COLOR="#111111" CREATED="1495166317938" ID="ID_422330222" MODIFIED="1495166317938" TEXT="public StringBuilder append(double d)"/>
<node COLOR="#111111" CREATED="1495166513754" FOLDED="true" ID="ID_1651527328" MODIFIED="1532056889066" TEXT="public AbstractStringBuilder appendCodePoint(int codePoint)">
<node COLOR="#111111" CREATED="1495166516743" ID="ID_1155913784" MODIFIED="1495166534239" TEXT="&#x8ffd;&#x52a0;Unicode&#x5b57;&#x7b26;&#x7f16;&#x7801;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495166352891" FOLDED="true" ID="ID_677353783" MODIFIED="1532056889066" TEXT="&#x63d2;&#x5165;">
<node COLOR="#111111" CREATED="1495166356139" ID="ID_1857819330" MODIFIED="1495166356139" TEXT="public StringBuilder insert(int offset, Object obj)"/>
<node COLOR="#111111" CREATED="1495166356140" ID="ID_62545991" MODIFIED="1495166356140" TEXT="public StringBuilder insert(int offset, String str)"/>
<node COLOR="#111111" CREATED="1495166356142" ID="ID_1994760302" MODIFIED="1495166356143" TEXT="public StringBuilder insert(int offset, char[] str)"/>
<node COLOR="#111111" CREATED="1495166356143" ID="ID_356223502" MODIFIED="1495166356143" TEXT="public StringBuilder insert(int dstOffset, CharSequence s)"/>
<node COLOR="#111111" CREATED="1495166356144" ID="ID_29079927" MODIFIED="1495166356144" TEXT="public StringBuilder insert(int offset, boolean b)"/>
<node COLOR="#111111" CREATED="1495166356145" ID="ID_1086957266" MODIFIED="1495166356145" TEXT="public StringBuilder insert(int offset, char c)"/>
<node COLOR="#111111" CREATED="1495166356146" ID="ID_1215624502" MODIFIED="1495166356146" TEXT="public StringBuilder insert(int offset, int i)"/>
<node COLOR="#111111" CREATED="1495166356146" ID="ID_1907383830" MODIFIED="1495166356146" TEXT="public StringBuilder insert(int offset, long l)"/>
<node COLOR="#111111" CREATED="1495166356147" ID="ID_231224875" MODIFIED="1495166356148" TEXT="public StringBuilder insert(int offset, float f)"/>
<node COLOR="#111111" CREATED="1495166356148" ID="ID_91028381" MODIFIED="1495166356149" TEXT="public StringBuilder insert(int offset, double d)"/>
</node>
<node COLOR="#111111" CREATED="1495166368232" FOLDED="true" ID="ID_1832290270" MODIFIED="1532056889066" TEXT="&#x5220;&#x9664;">
<node COLOR="#111111" CREATED="1495166333578" ID="ID_1376077" MODIFIED="1495166333578" TEXT="public StringBuilder delete(int start, int end)"/>
<node COLOR="#111111" CREATED="1495166333581" ID="ID_1159235177" MODIFIED="1495166333581" TEXT="public StringBuilder deleteCharAt(int index)"/>
</node>
<node COLOR="#111111" CREATED="1495166409332" FOLDED="true" ID="ID_818394810" MODIFIED="1532056889066" TEXT="&#x83b7;&#x53d6;&#x4e0b;&#x6807;">
<node COLOR="#111111" CREATED="1495166412511" ID="ID_1148315624" MODIFIED="1495166412512" TEXT="public int indexOf(String str)"/>
<node COLOR="#111111" CREATED="1495166412513" ID="ID_461993378" MODIFIED="1495166412513" TEXT="public int indexOf(String str, int fromIndex)"/>
<node COLOR="#111111" CREATED="1495166412517" ID="ID_1485965502" MODIFIED="1495166412517" TEXT="public int lastIndexOf(String str)"/>
<node COLOR="#111111" CREATED="1495166412519" ID="ID_861095782" MODIFIED="1495166412519" TEXT="public int lastIndexOf(String str, int fromIndex)"/>
</node>
<node COLOR="#111111" CREATED="1495166423446" FOLDED="true" ID="ID_416683541" MODIFIED="1532056889066" TEXT="public StringBuilder reverse()">
<node COLOR="#111111" CREATED="1495166425075" ID="ID_427030392" MODIFIED="1495166434947" TEXT="&#x53cd;&#x8f6c;&#x5185;&#x5bb9;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495166866026" ID="ID_1492956975" MODIFIED="1495166866026" TEXT="public String toString()"/>
</node>
<node COLOR="#990000" CREATED="1495165939030" FOLDED="true" ID="ID_317547694" MODIFIED="1532056889066" TEXT="StringBuffer">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495166668999" FOLDED="true" ID="ID_467214499" MODIFIED="1532056889066">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1495166650861" ID="ID_16090537" MODIFIED="1495166668157" TEXT="&#x5b57;&#x7b26;&#x4e32;&#x7f13;&#x51b2;&#x533a;&#x7c7b;,&#x7ebf;&#x7a0b;&#x5b89;&#x5168;&#x7684;"/>
</node>
<node COLOR="#111111" CREATED="1495166600690" FOLDED="true" ID="ID_959948026" MODIFIED="1532056889066" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<node COLOR="#111111" CREATED="1495166604132" ID="ID_1127480351" MODIFIED="1495166604132" TEXT="public StringBuffer()"/>
<node COLOR="#111111" CREATED="1495166604133" ID="ID_109689718" MODIFIED="1495166604134" TEXT="public StringBuffer(int capacity)"/>
<node COLOR="#111111" CREATED="1495166604135" ID="ID_945126430" MODIFIED="1495166604135" TEXT="public StringBuffer(String str)"/>
<node COLOR="#111111" CREATED="1495166604136" ID="ID_1463840707" MODIFIED="1495166604136" TEXT="public StringBuffer(CharSequence seq)"/>
</node>
<node COLOR="#111111" CREATED="1495166675412" FOLDED="true" ID="ID_1374487101" MODIFIED="1532056889066" TEXT="&#x65b9;&#x6cd5;">
<node COLOR="#111111" CREATED="1495166677291" FOLDED="true" ID="ID_1449220777" MODIFIED="1532056889066" TEXT="&#x8ffd;&#x52a0;">
<node COLOR="#111111" CREATED="1495166735464" ID="ID_314612629" MODIFIED="1495166735464" TEXT="public synchronized StringBuffer append(Object obj)"/>
<node COLOR="#111111" CREATED="1495166735466" ID="ID_1412203070" MODIFIED="1495166735466" TEXT="public synchronized StringBuffer append(String str)"/>
<node COLOR="#111111" CREATED="1495166735467" ID="ID_483598120" MODIFIED="1495166735467" TEXT="public synchronized StringBuffer append(StringBuffer sb)"/>
<node COLOR="#111111" CREATED="1495166735468" ID="ID_1128913887" MODIFIED="1495166735468" TEXT="public synchronized StringBuffer append(CharSequence s)"/>
<node COLOR="#111111" CREATED="1495166735469" ID="ID_1785324166" MODIFIED="1495166735469" TEXT="public synchronized StringBuffer append(char[] str)"/>
<node COLOR="#111111" CREATED="1495166735469" ID="ID_1648571951" MODIFIED="1495166735470" TEXT="public synchronized StringBuffer append(char[] str, int offset, int len)"/>
<node COLOR="#111111" CREATED="1495166735470" ID="ID_1060130554" MODIFIED="1495166735471" TEXT="public synchronized StringBuffer append(boolean b)"/>
<node COLOR="#111111" CREATED="1495166735471" ID="ID_348602175" MODIFIED="1495166735471" TEXT="public synchronized StringBuffer append(char c)"/>
<node COLOR="#111111" CREATED="1495166735471" ID="ID_1497579631" MODIFIED="1495166735472" TEXT="public synchronized StringBuffer append(int i)"/>
<node COLOR="#111111" CREATED="1495166735472" ID="ID_692285904" MODIFIED="1495166735472" TEXT="public synchronized StringBuffer appendCodePoint(int codePoint)"/>
<node COLOR="#111111" CREATED="1495166735472" ID="ID_1730445577" MODIFIED="1495166735472" TEXT="public synchronized StringBuffer append(long lng)"/>
<node COLOR="#111111" CREATED="1495166735473" ID="ID_569488276" MODIFIED="1495166735473" TEXT="public synchronized StringBuffer append(float f)"/>
<node COLOR="#111111" CREATED="1495166735473" ID="ID_386575417" MODIFIED="1495166735473" TEXT="public synchronized StringBuffer append(double d)"/>
</node>
<node COLOR="#111111" CREATED="1495166744193" FOLDED="true" ID="ID_971182434" MODIFIED="1532056889066" TEXT="&#x5220;&#x9664;">
<node COLOR="#111111" CREATED="1495166755937" ID="ID_223470576" MODIFIED="1495166755937" TEXT="public synchronized StringBuffer delete(int start, int end)"/>
<node COLOR="#111111" CREATED="1495166755938" ID="ID_813088745" MODIFIED="1495166755938" TEXT="public synchronized StringBuffer deleteCharAt(int index)"/>
</node>
<node COLOR="#111111" CREATED="1495166762309" FOLDED="true" ID="ID_1732780997" MODIFIED="1532056889066" TEXT="&#x66ff;&#x6362;">
<node COLOR="#111111" CREATED="1495166770795" ID="ID_1205248576" MODIFIED="1495166770795" TEXT="public synchronized StringBuffer replace(int start, int end, String str)"/>
</node>
<node COLOR="#111111" CREATED="1495166771587" FOLDED="true" ID="ID_1525224470" MODIFIED="1532056889066" TEXT="&#x622a;&#x53d6;">
<node COLOR="#111111" CREATED="1495166782715" ID="ID_1197589272" MODIFIED="1495166782715" TEXT="public synchronized String substring(int start)"/>
<node COLOR="#111111" CREATED="1495166782715" ID="ID_1384419866" MODIFIED="1495166782715" TEXT="public synchronized CharSequence subSequence(int start, int end)"/>
<node COLOR="#111111" CREATED="1495166782716" ID="ID_1796887089" MODIFIED="1495166782716" TEXT="public synchronized String substring(int start, int end)"/>
</node>
<node COLOR="#111111" CREATED="1495166682060" FOLDED="true" ID="ID_527130962" MODIFIED="1532056889066" TEXT="&#x63d2;&#x5165;">
<node COLOR="#111111" CREATED="1495166798580" ID="ID_1089174064" MODIFIED="1495166798580" TEXT="public synchronized StringBuffer insert(int offset, Object obj)"/>
<node COLOR="#111111" CREATED="1495166798581" ID="ID_320797989" MODIFIED="1495166798581" TEXT="public synchronized StringBuffer insert(int offset, String str)"/>
<node COLOR="#111111" CREATED="1495166798582" ID="ID_552838838" MODIFIED="1495166798583" TEXT="public synchronized StringBuffer insert(int offset, char[] str)"/>
<node COLOR="#111111" CREATED="1495166798584" ID="ID_223234382" MODIFIED="1495166798584" TEXT="public StringBuffer insert(int dstOffset, CharSequence s)"/>
<node COLOR="#111111" CREATED="1495166798585" ID="ID_1358811100" MODIFIED="1495166798585" TEXT="public  StringBuffer insert(int offset, boolean b)"/>
<node COLOR="#111111" CREATED="1495166798586" ID="ID_463442999" MODIFIED="1495166798586" TEXT="public synchronized StringBuffer insert(int offset, char c)"/>
<node COLOR="#111111" CREATED="1495166798587" ID="ID_649760773" MODIFIED="1495166798587" TEXT="public StringBuffer insert(int offset, int i)"/>
<node COLOR="#111111" CREATED="1495166798588" ID="ID_745437322" MODIFIED="1495166798588" TEXT="public StringBuffer insert(int offset, long l)"/>
<node COLOR="#111111" CREATED="1495166798588" ID="ID_1551043694" MODIFIED="1495166798589" TEXT="public StringBuffer insert(int offset, float f)"/>
<node COLOR="#111111" CREATED="1495166798589" ID="ID_1267642163" MODIFIED="1495166798589" TEXT="public StringBuffer insert(int offset, double d)"/>
</node>
<node COLOR="#111111" CREATED="1495166813111" FOLDED="true" ID="ID_493529840" MODIFIED="1532056889066" TEXT="&#x83b7;&#x53d6;&#x4e0b;&#x6807;">
<node COLOR="#111111" CREATED="1495166816651" ID="ID_610567907" MODIFIED="1495166816651" TEXT="public int indexOf(String str)"/>
<node COLOR="#111111" CREATED="1495166816653" ID="ID_1899633608" MODIFIED="1495166816654" TEXT="public synchronized int indexOf(String str, int fromIndex)"/>
<node COLOR="#111111" CREATED="1495166816655" ID="ID_1211064310" MODIFIED="1495166816655" TEXT="public int lastIndexOf(String str)"/>
<node COLOR="#111111" CREATED="1495166816656" ID="ID_661019020" MODIFIED="1495166816657" TEXT="public synchronized int lastIndexOf(String str, int fromIndex)"/>
</node>
<node COLOR="#111111" CREATED="1495166685740" FOLDED="true" ID="ID_581708072" MODIFIED="1532056889066" TEXT="&#x5176;&#x4ed6;">
<node COLOR="#111111" CREATED="1495166716228" ID="ID_1571429214" MODIFIED="1495166716229" TEXT="public synchronized int length()"/>
<node COLOR="#111111" CREATED="1495166716232" ID="ID_1042480295" MODIFIED="1495166716232" TEXT="public synchronized int capacity()"/>
<node COLOR="#111111" CREATED="1495166716233" ID="ID_1578217309" MODIFIED="1495166716234" TEXT="public synchronized void ensureCapacity(int minimumCapacity)"/>
<node COLOR="#111111" CREATED="1495166716235" ID="ID_818306157" MODIFIED="1495166716235" TEXT="public synchronized void trimToSize()"/>
<node COLOR="#111111" CREATED="1495166716240" ID="ID_1750553781" MODIFIED="1495166716240" TEXT="public synchronized void setLength(int newLength)"/>
<node COLOR="#111111" CREATED="1495166716244" ID="ID_228398219" MODIFIED="1495166716244" TEXT="public synchronized char charAt(int index)"/>
<node COLOR="#111111" CREATED="1495166716244" ID="ID_67755047" MODIFIED="1495166716245" TEXT="public synchronized int codePointAt(int index)"/>
<node COLOR="#111111" CREATED="1495166716245" ID="ID_725660820" MODIFIED="1495166716245" TEXT="public synchronized int codePointBefore(int index)"/>
<node COLOR="#111111" CREATED="1495166716246" ID="ID_718748726" MODIFIED="1495166716246" TEXT="public synchronized int codePointCount(int beginIndex, int endIndex)"/>
<node COLOR="#111111" CREATED="1495166716246" ID="ID_851367517" MODIFIED="1495166716247" TEXT="public synchronized int offsetByCodePoints(int index, int codePointOffset)"/>
<node COLOR="#111111" CREATED="1495166716247" ID="ID_868569728" MODIFIED="1495166716247" TEXT="public synchronized void setCharAt(int index, char ch)"/>
<node COLOR="#111111" CREATED="1495166825347" ID="ID_32712484" MODIFIED="1495166825347" TEXT="public synchronized StringBuffer reverse()"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495166843328" ID="ID_1499259234" MODIFIED="1495166843328" TEXT="public synchronized String toString()"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495376535234" FOLDED="true" ID="ID_328803148" MODIFIED="1532066366870" TEXT="String.format()&#x683c;&#x5f0f;&#x5316;&#x65f6;&#x95f4;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495382608333" FOLDED="true" ID="ID_1906252366" LINK="String/TestFormatDate.java" MODIFIED="1532066353780" TEXT="&#x683c;&#x5f0f;&#x5316;&#x65e5;&#x671f;:">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495382608339" ID="ID_236348113" MODIFIED="1531651823854" TEXT="&apos;A&apos;     &#x7279;&#x5b9a;&#x4e8e;&#x8bed;&#x8a00;&#x73af;&#x5883;&#x7684;&#x661f;&#x671f;&#x51e0;&#x5168;&#x79f0;&#xff0c;&#x4f8b;&#x5982; &quot;Sunday&quot; &#x548c; &quot;Monday&quot;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608344" ID="ID_128221523" MODIFIED="1531651823856" TEXT="&apos;a&apos;     &#x7279;&#x5b9a;&#x4e8e;&#x8bed;&#x8a00;&#x73af;&#x5883;&#x7684;&#x661f;&#x671f;&#x51e0;&#x7b80;&#x79f0;&#xff0c;&#x4f8b;&#x5982; &quot;Sun&quot; &#x548c; &quot;Mon&quot;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608334" ID="ID_1156561033" MODIFIED="1495383600046" TEXT="&apos;B&apos;     &#x7279;&#x5b9a;&#x4e8e;&#x8bed;&#x8a00;&#x73af;&#x5883;&#x7684;&#x6708;&#x4efd;&#x5168;&#x79f0;&#xff0c;&#x4f8b;&#x5982; &quot;January&quot; &#x548c; &quot;February&quot;&#x3002;&#x5982;&#x679c;&#x662f;&#x6c49;&#x5b57;,&#x5219;&#x5982;&#x4e94;&#x6708;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608337" ID="ID_491477966" MODIFIED="1495383592843" TEXT="&apos;b&apos;     &#x7279;&#x5b9a;&#x4e8e;&#x8bed;&#x8a00;&#x73af;&#x5883;&#x7684;&#x6708;&#x4efd;&#x7b80;&#x79f0;&#xff0c;&#x4f8b;&#x5982; &quot;Jan&quot; &#x548c; &quot;Feb&quot;&#x3002;&#x5982;&#x679c;&#x662f;&#x6c49;&#x5b57;,&#x5219;&#x5982;&#x4e94;&#x6708;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608338" ID="ID_1900108078" MODIFIED="1495382623774" TEXT="&apos;h&apos;     &#x4e0e; &apos;b&apos; &#x76f8;&#x540c;&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608345" FOLDED="true" ID="ID_1879781740" MODIFIED="1532056889066" TEXT="&apos;C&apos;     &#x9664;&#x4ee5; 100 &#x7684;&#x56db;&#x4f4d;&#x6570;&#x8868;&#x793a;&#x7684;&#x5e74;&#x4efd;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 00 - 99">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495384171438" ID="ID_1692195789" MODIFIED="1495384180654" TEXT="&#x5982; 2017 &#x8fd4;&#x56de; 20"/>
</node>
<node COLOR="#111111" CREATED="1495382608347" FOLDED="true" ID="ID_108557584" MODIFIED="1532056889066" TEXT="&apos;Y&apos;     &#x5e74;&#x4efd;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x56db;&#x4f4d;&#x6570;&#xff08;&#x81f3;&#x5c11;&#xff09;&#xff0c;&#x4f8b;&#x5982;&#xff0c;0092 &#x7b49;&#x4e8e;&#x683c;&#x91cc;&#x9ad8;&#x5229;&#x5386;&#x7684; 92 CE&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495384210413" ID="ID_1797530562" MODIFIED="1495384221628" TEXT="&#x5982;2017 &#x5e74;&#x5219;&#x8fd4;&#x56de; 2017"/>
</node>
<node COLOR="#111111" CREATED="1495382608354" ID="ID_885077827" MODIFIED="1495382623786" TEXT="&apos;y&apos;     &#x5e74;&#x4efd;&#x7684;&#x6700;&#x540e;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 00 - 99&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608355" ID="ID_1799186987" MODIFIED="1495382623789" TEXT="&apos;j&apos;     &#x4e00;&#x5e74;&#x4e2d;&#x7684;&#x5929;&#x6570;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e09;&#x4f4d;&#x6570;&#xff0c;&#x4f8b;&#x5982;&#xff0c;&#x5bf9;&#x4e8e;&#x683c;&#x91cc;&#x9ad8;&#x5229;&#x5386;&#x662f; 001 - 366&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608358" ID="ID_882589846" MODIFIED="1495382623792" TEXT="&apos;m&apos;     &#x6708;&#x4efd;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 01 - 13&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608359" ID="ID_758875055" MODIFIED="1495382623793" TEXT="&apos;d&apos;     &#x4e00;&#x4e2a;&#x6708;&#x4e2d;&#x7684;&#x5929;&#x6570;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 01 - 31">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382608360" ID="ID_1289624258" MODIFIED="1495382623795" TEXT="&apos;e&apos;     &#x4e00;&#x4e2a;&#x6708;&#x4e2d;&#x7684;&#x5929;&#x6570;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 1 - 31&#x3002;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495382891588" ID="ID_1427519943" MODIFIED="1495382903706" TEXT="&#x6ce8;&#x610f;: &#x683c;&#x91cc;&#x9ad8;&#x5229;&#x5386;&#x5c31;&#x662f;&#x516c;&#x5386;"/>
</node>
<node COLOR="#990000" CREATED="1495382625368" FOLDED="true" ID="ID_1489124219" MODIFIED="1532066358986" TEXT="&#x683c;&#x5f0f;&#x5316;&#x65f6;&#x95f4;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495382640747" ID="ID_704259569" MODIFIED="1495382640747" TEXT="&apos;H&apos;     24 &#x5c0f;&#x65f6;&#x5236;&#x7684;&#x5c0f;&#x65f6;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 00 - 23&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640750" ID="ID_1101182048" MODIFIED="1495382640750" TEXT="&apos;I&apos;     12 &#x5c0f;&#x65f6;&#x5236;&#x7684;&#x5c0f;&#x65f6;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 01 - 12&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640751" ID="ID_1238489410" MODIFIED="1495382640751" TEXT="&apos;k&apos;     24 &#x5c0f;&#x65f6;&#x5236;&#x7684;&#x5c0f;&#x65f6;&#xff0c;&#x5373; 0 - 23&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640752" ID="ID_450074362" MODIFIED="1495382640752" TEXT="&apos;l&apos;     12 &#x5c0f;&#x65f6;&#x5236;&#x7684;&#x5c0f;&#x65f6;&#xff0c;&#x5373; 1 - 12&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640753" ID="ID_399661536" MODIFIED="1495382640754" TEXT="&apos;M&apos;     &#x5c0f;&#x65f6;&#x4e2d;&#x7684;&#x5206;&#x949f;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 00 - 59&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640756" ID="ID_643261654" MODIFIED="1495382640756" TEXT="&apos;S&apos;     &#x5206;&#x949f;&#x4e2d;&#x7684;&#x79d2;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e24;&#x4f4d;&#x6570;&#xff0c;&#x5373; 00 - 60 &#xff08;&quot;60&quot; &#x662f;&#x652f;&#x6301;&#x95f0;&#x79d2;&#x6240;&#x9700;&#x7684;&#x4e00;&#x4e2a;&#x7279;&#x6b8a;&#x503c;&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640766" ID="ID_323515227" MODIFIED="1495382640766" TEXT="&apos;L&apos;     &#x79d2;&#x4e2d;&#x7684;&#x6beb;&#x79d2;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e09;&#x4f4d;&#x6570;&#xff0c;&#x5373; 000 - 999&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640767" ID="ID_791984813" MODIFIED="1495382640768" TEXT="&apos;N&apos;     &#x79d2;&#x4e2d;&#x7684;&#x6beb;&#x5fae;&#x79d2;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a;&#x5fc5;&#x8981;&#x65f6;&#x5e26;&#x524d;&#x5bfc;&#x96f6;&#x7684;&#x4e5d;&#x4f4d;&#x6570;&#xff0c;&#x5373; 000000000 - 999999999&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640768" ID="ID_1470354631" MODIFIED="1495382640768" TEXT="&apos;p&apos;     &#x7279;&#x5b9a;&#x4e8e;&#x8bed;&#x8a00;&#x73af;&#x5883;&#x7684; &#x4e0a;&#x5348;&#x6216;&#x4e0b;&#x5348; &#x6807;&#x8bb0;&#x4ee5;&#x5c0f;&#x5199;&#x5f62;&#x5f0f;&#x8868;&#x793a;&#xff0c;&#x4f8b;&#x5982; &quot;am&quot; &#x6216; &quot;pm&quot;&#x3002;&#x4f7f;&#x7528;&#x8f6c;&#x6362;&#x524d;&#x7f00; &apos;T&apos; &#x53ef;&#x4ee5;&#x5f3a;&#x884c;&#x5c06;&#x6b64;&#x8f93;&#x51fa;&#x8f6c;&#x6362;&#x4e3a;&#x5927;&#x5199;&#x5f62;&#x5f0f;&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640771" ID="ID_1297992662" MODIFIED="1495382640771" TEXT="&apos;z&apos;     &#x76f8;&#x5bf9;&#x4e8e; GMT &#x7684; RFC 822 &#x683c;&#x5f0f;&#x7684;&#x6570;&#x5b57;&#x65f6;&#x533a;&#x504f;&#x79fb;&#x91cf;&#xff0c;&#x4f8b;&#x5982; -0800&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640774" ID="ID_1276407275" MODIFIED="1495382640774" TEXT="&apos;Z&apos;     &#x8868;&#x793a;&#x65f6;&#x533a;&#x7f29;&#x5199;&#x5f62;&#x5f0f;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x3002;Formatter &#x7684;&#x8bed;&#x8a00;&#x73af;&#x5883;&#x5c06;&#x53d6;&#x4ee3;&#x53c2;&#x6570;&#x7684;&#x8bed;&#x8a00;&#x73af;&#x5883;&#xff08;&#x5982;&#x679c;&#x6709;&#xff09;&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640775" ID="ID_69372649" MODIFIED="1495382640776" TEXT="&apos;s&apos;     &#x81ea;&#x534f;&#x8c03;&#x4e16;&#x754c;&#x65f6; (UTC) 1970 &#x5e74; 1 &#x6708; 1 &#x65e5; 00:00:00 &#x81f3;&#x73b0;&#x5728;&#x6240;&#x7ecf;&#x8fc7;&#x7684;&#x79d2;&#x6570;&#xff0c;&#x5373; Long.MIN_VALUE/1000 &#x4e0e; Long.MAX_VALUE/1000 &#x4e4b;&#x95f4;&#x7684;&#x5dee;&#x503c;&#x3002;"/>
<node COLOR="#111111" CREATED="1495382640785" ID="ID_869237608" MODIFIED="1495382640785" TEXT="&apos;Q&apos;     &#x81ea;&#x534f;&#x8c03;&#x4e16;&#x754c;&#x65f6; (UTC) 1970 &#x5e74; 1 &#x6708; 1 &#x65e5; 00:00:00 &#x81f3;&#x73b0;&#x5728;&#x6240;&#x7ecf;&#x8fc7;&#x7684;&#x6beb;&#x79d2;&#x6570;&#xff0c;&#x5373; Long.MIN_VALUE &#x4e0e; Long.MAX_VALUE &#x4e4b;&#x95f4;&#x7684;&#x5dee;&#x503c;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1495382673829" FOLDED="true" ID="ID_687314588" MODIFIED="1532066364284">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24120;&#29992;&#26102;&#38388;/&#26085;&#26399;&#32452;&#21512;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495382680585" FOLDED="true" ID="ID_221529417" MODIFIED="1532056889066" TEXT="&apos;R&apos;     24 &#x5c0f;&#x65f6;&#x5236;&#x7684;&#x65f6;&#x95f4;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a; &quot;%tH:%tM&quot;">
<node COLOR="#111111" CREATED="1495383402186" ID="ID_846881976" MODIFIED="1495383402186" TEXT="00:16"/>
</node>
<node COLOR="#111111" CREATED="1495382680588" FOLDED="true" ID="ID_920398365" MODIFIED="1532056889066" TEXT="&apos;T&apos;     24 &#x5c0f;&#x65f6;&#x5236;&#x7684;&#x65f6;&#x95f4;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a; &quot;%tH:%tM:%tS&quot;&#x3002;">
<node COLOR="#111111" CREATED="1495383245090" ID="ID_328989372" MODIFIED="1495383245090" TEXT="00:13:58"/>
</node>
<node COLOR="#111111" CREATED="1495382680599" FOLDED="true" ID="ID_1143310656" MODIFIED="1532056889066" TEXT="&apos;r&apos;     12 &#x5c0f;&#x65f6;&#x5236;&#x7684;&#x65f6;&#x95f4;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a; &quot;%tI:%tM:%tS %Tp&quot;&#x3002;&#x4e0a;&#x5348;&#x6216;&#x4e0b;&#x5348;&#x6807;&#x8bb0; (&apos;%Tp&apos;) &#x7684;&#x4f4d;&#x7f6e;&#x53ef;&#x80fd;&#x4e0e;&#x8bed;&#x8a00;&#x73af;&#x5883;&#x6709;&#x5173;&#x3002;">
<node COLOR="#111111" CREATED="1495383182151" ID="ID_850522942" MODIFIED="1495383182151" TEXT="12:12:38 &#x4e0a;&#x5348;"/>
</node>
<node COLOR="#111111" CREATED="1495382680604" ID="ID_449512748" MODIFIED="1532066124084" TEXT="&apos;D&apos;     &#x65e5;&#x671f;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a; &quot;%tm/%td/%ty&quot;&#x3002;">
<node COLOR="#111111" CREATED="1495383106203" ID="ID_234664870" MODIFIED="1495383106203" TEXT="05/22/17"/>
</node>
<node COLOR="#111111" CREATED="1495382680605" ID="ID_344139823" MODIFIED="1532066132325" TEXT="&apos;F&apos;     ISO 8601 &#x683c;&#x5f0f;&#x7684;&#x5b8c;&#x6574;&#x65e5;&#x671f;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a; &quot;%tY-%tm-%td&quot;&#x3002;">
<node COLOR="#111111" CREATED="1495383035681" ID="ID_1510618945" MODIFIED="1495383038375" TEXT="&#x5982;: 2017-05-22"/>
</node>
<node COLOR="#111111" CREATED="1495382680606" FOLDED="true" ID="ID_460263040" MODIFIED="1532056889066" TEXT="&apos;c&apos;     &#x65e5;&#x671f;&#x548c;&#x65f6;&#x95f4;&#xff0c;&#x88ab;&#x683c;&#x5f0f;&#x5316;&#x4e3a; &quot;%ta %tb %td %tT %tZ %tY&quot;">
<node COLOR="#111111" CREATED="1495383053710" ID="ID_1612560295" MODIFIED="1495383055991" TEXT="&#x5982; : &#x661f;&#x671f;&#x4e00; &#x4e94;&#x6708; 22 00:10:16 CST 2017"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1497056217842" FOLDED="true" ID="ID_1913066105" LINK="http://kgd1120.iteye.com/blog/1293633" MODIFIED="1532066028447" TEXT="&#x683c;&#x5f0f;&#x5316;&#x6570;&#x5b57;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1531652509063" ID="ID_385946399" MODIFIED="1531652511155">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <table class="MsoNormalTable" width="545" cellspacing="0" cellpadding="0" border="1" style="margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 8.45pt; width: 408.4pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: 1pt; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a4" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#36716;&#160;&#160;&#25442;&#160;&#160;&#31526;
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: solid; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: 1pt; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a4" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#35828;&#160;&#160;&#160;&#160;&#26126;&#160;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: solid; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: 1pt; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a4" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#31034;&#160;&#160;&#160;&#160;&#20363;
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 92.75pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %s
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 195.95pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#23383;&#31526;&#20018;&#31867;&#22411;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; width: 119.7pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &quot;mingrisoft&quot;
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %c
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#23383;&#31526;&#31867;&#22411;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            'm'
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 92.75pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %b
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 195.95pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#24067;&#23572;&#31867;&#22411;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; width: 119.7pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            true
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %d
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#25972;&#25968;&#31867;&#22411;&#65288;&#21313;&#36827;&#21046;&#65289;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            99
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 92.75pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %x
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 195.95pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#25972;&#25968;&#31867;&#22411;&#65288;&#21313;&#20845;&#36827;&#21046;&#65289;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; width: 119.7pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            FF
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %o
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#25972;&#25968;&#31867;&#22411;&#65288;&#20843;&#36827;&#21046;&#65289;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            77
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 92.75pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %f
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 195.95pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#28014;&#28857;&#31867;&#22411;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; width: 119.7pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            99.99
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %a
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#21313;&#20845;&#36827;&#21046;&#28014;&#28857;&#31867;&#22411;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            FF.35AE
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 92.75pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %e
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 195.95pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#25351;&#25968;&#31867;&#22411;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; width: 119.7pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            9.38e+5
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %g
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#36890;&#29992;&#28014;&#28857;&#31867;&#22411;&#65288;f&#21644;e&#31867;&#22411;&#20013;&#36739;&#30701;&#30340;&#65289;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <br style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px" />
          
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 92.75pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %h
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 195.95pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#25955;&#21015;&#30721;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; width: 119.7pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <br style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px" />
          
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %%
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#30334;&#20998;&#27604;&#31867;&#22411;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#65285;
          </p>
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 92.75pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %n
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; width: 195.95pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#25442;&#34892;&#31526;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; width: 119.7pt; height: 16.75pt; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <br style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px" />
          
        </td>
      </tr>
      <tr style="height: 16.75pt; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
        <td width="124" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 92.75pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            %tx
          </p>
        </td>
        <td width="261" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: solid; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: 1pt; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 195.95pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <p class="a0" style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px">
            &#26085;&#26399;&#19982;&#26102;&#38388;&#31867;&#22411;&#65288;x&#20195;&#34920;&#19981;&#21516;&#30340;&#26085;&#26399;&#19982;&#26102;&#38388;&#36716;&#25442;&#31526;
          </p>
        </td>
        <td width="160" style="padding-top: 0cm; padding-right: 5.4pt; padding-bottom: 0cm; padding-left: 5.4pt; border-top-style: none; border-right-style: none; border-bottom-style: solid; border-left-style: none; border-top-width: medium; border-right-width: medium; border-bottom-width: 1pt; border-left-width: medium; background-image: none; background-color: #d9d9d9; width: 119.7pt; height: 16.75pt; background-position: 0% 50%; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px">
          <br style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px" />
          
        </td>
      </tr>
    </table>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1531653099365" ID="ID_1758550378" MODIFIED="1531653123355" TEXT="char c = String.format(&quot;%c&quot;, 98);&#x6b64;&#x65f6; c&#x4e3a;&#x5b57;&#x7b26;&apos;b&apos;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1495165335405" FOLDED="true" ID="ID_449420762" MODIFIED="1532056889098" POSITION="right" TEXT="&#x5176;&#x4ed6;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1495165349196" FOLDED="true" ID="ID_1479492753" MODIFIED="1532056889082" TEXT="Random">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495185530304" FOLDED="true" ID="ID_70060552" MODIFIED="1532056889082" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495185532228" ID="ID_864677121" MODIFIED="1495185552050" TEXT="&#x53ef;&#x4ee5;&#x968f;&#x673a;&#x751f;&#x6210;&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x7684;&#x5de5;&#x5177;&#x7c7b;"/>
</node>
<node COLOR="#990000" CREATED="1495185526096" FOLDED="true" ID="ID_1381570250" MODIFIED="1532056889082" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495185529019" ID="ID_1870738065" MODIFIED="1495185529019" TEXT="public Random()"/>
<node COLOR="#111111" CREATED="1495185529019" ID="ID_1557039261" MODIFIED="1495185529019" TEXT="public Random(long seed)"/>
</node>
<node COLOR="#990000" CREATED="1495185559789" FOLDED="true" ID="ID_1163864475" MODIFIED="1532056889082" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495185576947" ID="ID_1964095680" MODIFIED="1495185576947" TEXT="public void nextBytes(byte[] bytes)"/>
<node COLOR="#111111" CREATED="1495185576947" FOLDED="true" ID="ID_337952487" MODIFIED="1532056889082" TEXT="public int nextInt()">
<node COLOR="#111111" CREATED="1495194490019" ID="ID_1019534315" MODIFIED="1495194500609" TEXT="&#x83b7;&#x53d6;&#x968f;&#x673a;&#x7684;&#x6574;&#x6570;"/>
</node>
<node COLOR="#111111" CREATED="1495185576947" FOLDED="true" ID="ID_259737610" MODIFIED="1532056889082" TEXT="public int nextInt(int bound)">
<node COLOR="#111111" CREATED="1495194503123" ID="ID_214827472" MODIFIED="1495194524410" TEXT="&#x83b7;&#x53d6; &#x5c0f;&#x4e8e;bound &#x7684;&#x6570;"/>
<node COLOR="#111111" CREATED="1495194525013" ID="ID_1959397759" MODIFIED="1495194573322" TEXT="bound &#x8fb9;&#x754c;,&#x968f;&#x673a;&#x6570;&#x7684;&#x6700;&#x5927;&#x503c;,&#x5fc5;&#x987b;&#x662f;&#x6b63;&#x6570;,exclusive"/>
</node>
<node COLOR="#111111" CREATED="1495185576947" ID="ID_1978753387" MODIFIED="1495185576947" TEXT="public long nextLong()"/>
<node COLOR="#111111" CREATED="1495185576947" ID="ID_1246277755" MODIFIED="1495185576947" TEXT="public boolean nextBoolean()"/>
<node COLOR="#111111" CREATED="1495185576947" FOLDED="true" ID="ID_1460642962" MODIFIED="1532056889082" TEXT="public float nextFloat()">
<node COLOR="#111111" CREATED="1495194736278" ID="ID_620763580" MODIFIED="1495194756214" TEXT="value between 0.0 and 1.0"/>
</node>
<node COLOR="#111111" CREATED="1495185576947" FOLDED="true" ID="ID_1450046299" MODIFIED="1532056889082" TEXT="public double nextDouble()">
<node COLOR="#111111" CREATED="1495194736278" ID="ID_750175198" MODIFIED="1495194756214" TEXT="value between 0.0 and 1.0"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495193394182" FOLDED="true" ID="ID_1004000654" MODIFIED="1532056889082" TEXT="jdk 1.8&#x65b0;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495193405859" ID="ID_1874524622" MODIFIED="1495193405859" TEXT="public IntStream ints(long streamSize)"/>
<node COLOR="#111111" CREATED="1495193405860" ID="ID_1009959718" MODIFIED="1495193405860" TEXT="public IntStream ints()"/>
<node COLOR="#111111" CREATED="1495193405860" ID="ID_1506808350" MODIFIED="1495193405861" TEXT="public IntStream ints(int randomNumberOrigin, int randomNumberBound)"/>
<node COLOR="#111111" CREATED="1495193405863" ID="ID_1028166744" MODIFIED="1495193405863" TEXT="public LongStream longs(long streamSize)"/>
<node COLOR="#111111" CREATED="1495193405864" ID="ID_288974811" MODIFIED="1495193405865" TEXT="public LongStream longs()"/>
<node COLOR="#111111" CREATED="1495193405866" ID="ID_1128430801" MODIFIED="1495193405866" TEXT="public LongStream longs(long randomNumberOrigin, long randomNumberBound)"/>
<node COLOR="#111111" CREATED="1495193405867" ID="ID_912864900" MODIFIED="1495193405867" TEXT="public DoubleStream doubles(long streamSize)"/>
<node COLOR="#111111" CREATED="1495193405868" ID="ID_810834798" MODIFIED="1495193405868" TEXT="public DoubleStream doubles()"/>
<node COLOR="#111111" CREATED="1495193405876" ID="ID_1572823200" MODIFIED="1495193405877" TEXT="public DoubleStream doubles(double randomNumberOrigin, double randomNumberBound)"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495171468726" FOLDED="true" ID="ID_1877669465" LINK="https://msdn.microsoft.com/zh-cn/library/system.math.ieeeremainder.aspx" MODIFIED="1532056889082" TEXT="Math">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495195021243" FOLDED="true" ID="ID_774332070" MODIFIED="1532056889082" TEXT="&#x4e09;&#x89d2;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495195026913" FOLDED="true" ID="ID_1891084300" MODIFIED="1532056889082" TEXT="public static double sin(double a)">
<node COLOR="#111111" CREATED="1495195500446" ID="ID_442416791" MODIFIED="1495195506473" TEXT="&#x6b63;&#x5f26;"/>
</node>
<node COLOR="#111111" CREATED="1495195026921" FOLDED="true" ID="ID_1810831690" MODIFIED="1532056889082" TEXT="public static double cos(double a)">
<node COLOR="#111111" CREATED="1495195508351" ID="ID_1491676936" MODIFIED="1495195514406" TEXT="&#x4f59;&#x5f26;"/>
</node>
<node COLOR="#111111" CREATED="1495195026922" FOLDED="true" ID="ID_122495332" MODIFIED="1532056889082" TEXT="public static double tan(double a)">
<node COLOR="#111111" CREATED="1495195519539" ID="ID_25719866" MODIFIED="1495195526085" TEXT="&#x6b63;&#x5207;"/>
</node>
<node COLOR="#111111" CREATED="1495195026924" FOLDED="true" ID="ID_1392847887" MODIFIED="1532056889082" TEXT="public static double asin(double a)">
<node COLOR="#111111" CREATED="1495195528844" ID="ID_218393781" MODIFIED="1495195549803" TEXT="&#x53cd;&#x6b63;&#x5f26;"/>
</node>
<node COLOR="#111111" CREATED="1495195026925" FOLDED="true" ID="ID_296014939" MODIFIED="1532056889082" TEXT="public static double acos(double a)">
<node COLOR="#111111" CREATED="1495195552160" ID="ID_341427989" MODIFIED="1495195555303" TEXT="&#x53cd;&#x4f59;&#x5f26;"/>
</node>
<node COLOR="#111111" CREATED="1495195026926" FOLDED="true" ID="ID_202125282" MODIFIED="1532056889082" TEXT="public static double atan(double a)">
<node COLOR="#111111" CREATED="1495195556879" ID="ID_789311141" MODIFIED="1495195560217" TEXT="&#x53cd;&#x6b63;&#x5207;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495196063029" FOLDED="true" ID="ID_497118666" MODIFIED="1532056889082" TEXT="&#x5706;&#x5f62;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495196074222" FOLDED="true" ID="ID_1015508407" MODIFIED="1532056889082" TEXT="public static double toRadians(double angdeg)">
<node COLOR="#111111" CREATED="1495196078137" FOLDED="true" ID="ID_1161483050" MODIFIED="1532056889082" TEXT="&#x89d2;&#x5ea6;&#x8f6c;&#x5f27;&#x5ea6;">
<node COLOR="#111111" CREATED="1495196102985" ID="ID_1492278541" MODIFIED="1495196102985" TEXT="&#x89d2;&#xff08;&#x5f27;&#x5ea6;&#xff09;&#xff1d; &#x5f27;&#x957f;/&#x534a;&#x5f84;"/>
<node COLOR="#111111" CREATED="1495196110276" ID="ID_671608076" MODIFIED="1495196110276" TEXT="180&#x5ea6;&#xff1d;&#x3c0;&#x5f27;&#x5ea6;"/>
<node COLOR="#111111" CREATED="1495196117070" ID="ID_304466102" MODIFIED="1495196117070" TEXT="1&#x5ea6;&#xff1d;&#x3c0;/180 &#x5f27;&#x5ea6; ( &#x2248;0.017453&#x5f27;&#x5ea6; )"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495196177375" FOLDED="true" ID="ID_1670985405" MODIFIED="1532056889082" TEXT="public static double toDegrees(double angrad)">
<node COLOR="#111111" CREATED="1495196179607" ID="ID_1016851762" MODIFIED="1495196188113" TEXT="&#x5f27;&#x5ea6;&#x8f6c;&#x89d2;&#x5ea6;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495196393601" FOLDED="true" ID="ID_24426918" MODIFIED="1532056889082" TEXT="&#x5bf9;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495196398035" ID="ID_141056847" MODIFIED="1495196398035" TEXT="public static double log(double a)"/>
<node COLOR="#111111" CREATED="1495196398036" ID="ID_1174749724" MODIFIED="1495196398036" TEXT="public static double log10(double a)"/>
</node>
<node COLOR="#990000" CREATED="1495198088477" FOLDED="true" ID="ID_1781784705" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27714;&#26041;&#26681;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495196510724" FOLDED="true" ID="ID_614000632" MODIFIED="1532056889082" TEXT="public static double sqrt(double a) ">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495196514450" ID="ID_949897821" MODIFIED="1495196594414" TEXT="&#x5e73;&#x65b9;&#x6839;"/>
</node>
<node COLOR="#111111" CREATED="1495196578685" FOLDED="true" ID="ID_963672365" MODIFIED="1532056889082" TEXT="public static double cbrt(double a)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495196580475" ID="ID_742238206" MODIFIED="1495196585747" TEXT="&#x7acb;&#x65b9;&#x6839;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495196775195" FOLDED="true" ID="ID_318735967" MODIFIED="1532056889082" TEXT="public static double IEEEremainder(double f1, double f2)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495196789213" ID="ID_824708098" MODIFIED="1495196789213">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="&#x57fa;&#x672c;&#x8bed;&#x6cd5;_3412947725394497728.jpeg" />
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1495196798335" ID="ID_1475303118" MODIFIED="1495196845548" TEXT="&#x6c42;&#x4f59;&#x6570;,&#x548c; &#x53d6;&#x6a21;&#x8fd0;&#x7b97;&#x4e0d;&#x540c;"/>
<node COLOR="#111111" CREATED="1495196848981" ID="ID_1799631646" MODIFIED="1495196872996" TEXT="&#x53d6;&#x6a21;&#x8fd0;&#x7b97;&#x53d6;&#x63a5;&#x8fd1;&#x7684;&#x6b63;&#x6570;"/>
<node COLOR="#111111" CREATED="1495196876433" ID="ID_5792044" MODIFIED="1495196909564" TEXT="IEEEremainder&#x53d6;&#x5f97;&#x662f;&#x63a5;&#x8fd1;&#x7684;&#x6b63;&#x6570;&#x6216;&#x8d1f;&#x6570;"/>
</node>
<node COLOR="#990000" CREATED="1495197096615" FOLDED="true" ID="ID_145190803" MODIFIED="1532056889082" TEXT="public static double pow(double a, double b)">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197156331" ID="ID_254483566" MODIFIED="1495197161845" TEXT="a&#x7684;b&#x6b21;&#x65b9;"/>
</node>
<node COLOR="#990000" CREATED="1495198071814" FOLDED="true" ID="ID_1880892940" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22235;&#33293;&#20116;&#20837;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197096616" ID="ID_692213172" MODIFIED="1495198071820" TEXT="public static int round(float a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495197096617" ID="ID_321070566" MODIFIED="1495198071820" TEXT="public static long round(double a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495197096619" FOLDED="true" ID="ID_992065660" MODIFIED="1532056889082" TEXT="public static double random()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197629613" ID="ID_204875440" MODIFIED="1495197642697" TEXT="equal to 0.0 and less than 1.0"/>
</node>
<node COLOR="#990000" CREATED="1495197722546" FOLDED="true" ID="ID_1283910965" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27714;&#21644;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197726116" ID="ID_235950064" MODIFIED="1495197726117" TEXT="public static int addExact(int x, int y)"/>
<node COLOR="#111111" CREATED="1495197726118" ID="ID_126947070" MODIFIED="1495197726118" TEXT="public static long addExact(long x, long y)"/>
</node>
<node COLOR="#990000" CREATED="1495197749550" FOLDED="true" ID="ID_294115431" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27714;&#24046;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197775033" ID="ID_450593848" MODIFIED="1495197775033" TEXT="public static int subtractExact(int x, int y)"/>
<node COLOR="#111111" CREATED="1495197775035" ID="ID_1215645568" MODIFIED="1495197775035" TEXT="public static long subtractExact(long x, long y)"/>
</node>
<node COLOR="#990000" CREATED="1495197786956" FOLDED="true" ID="ID_70002139" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27714;&#31215;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197811569" ID="ID_1593271890" MODIFIED="1495197811569" TEXT="public static int multiplyExact(int x, int y)"/>
<node COLOR="#111111" CREATED="1495197811570" ID="ID_719179191" MODIFIED="1495197811570" TEXT="public static long multiplyExact(long x, long y)"/>
</node>
<node COLOR="#990000" CREATED="1495197956192" FOLDED="true" ID="ID_596667330" MODIFIED="1532056889082" TEXT="&#x81ea;&#x589e;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197963540" ID="ID_581955213" MODIFIED="1495197963540" TEXT="public static int incrementExact(int a)"/>
<node COLOR="#111111" CREATED="1495197963541" ID="ID_467328703" MODIFIED="1495197963542" TEXT="public static long incrementExact(long a)"/>
</node>
<node COLOR="#990000" CREATED="1495197968470" FOLDED="true" ID="ID_1799115557" MODIFIED="1532056889082" TEXT="&#x81ea;&#x51cf;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197963543" ID="ID_716369886" MODIFIED="1495197963543" TEXT="public static int decrementExact(int a)"/>
<node COLOR="#111111" CREATED="1495197963544" ID="ID_1182488716" MODIFIED="1495197963544" TEXT="public static long decrementExact(long a)"/>
</node>
<node COLOR="#990000" CREATED="1495198008577" FOLDED="true" ID="ID_1267363309" MODIFIED="1532056889082" TEXT="&#x53d6;&#x8d1f;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495198024644" ID="ID_1327836743" MODIFIED="1495198024644" TEXT="public static int negateExact(int a)"/>
<node COLOR="#111111" CREATED="1495198024645" ID="ID_4815412" MODIFIED="1495198024645" TEXT="public static long negateExact(long a)"/>
</node>
<node COLOR="#990000" CREATED="1495198117847" FOLDED="true" ID="ID_985494548" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27714;&#32477;&#23545;&#20540;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495198067101" ID="ID_100688219" MODIFIED="1495198117858" TEXT="public static int abs(int a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067102" ID="ID_1431133217" MODIFIED="1495198117859" TEXT="public static long abs(long a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067108" ID="ID_792846263" MODIFIED="1495198117859" TEXT="public static float abs(float a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067109" ID="ID_1056018476" MODIFIED="1495198117861" TEXT="public static double abs(double a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495198130864" FOLDED="true" ID="ID_428220794" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21462;&#26368;&#22823;&#20540;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495198067110" ID="ID_319938011" MODIFIED="1495198130874" TEXT="public static int max(int a, int b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067111" ID="ID_273556546" MODIFIED="1495198130875" TEXT="public static long max(long a, long b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067112" ID="ID_1837269549" MODIFIED="1495198130876" TEXT="public static float max(float a, float b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067113" ID="ID_633999646" MODIFIED="1495198130877" TEXT="public static double max(double a, double b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495198143188" FOLDED="true" ID="ID_758768314" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21462;&#26368;&#23567;&#20540;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495198067114" ID="ID_392100032" MODIFIED="1495198143196" TEXT="public static int min(int a, int b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067115" ID="ID_1556139725" MODIFIED="1495198143199" TEXT="public static long min(long a, long b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067116" ID="ID_1519868037" MODIFIED="1495198143200" TEXT="public static float min(float a, float b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067117" ID="ID_654896030" MODIFIED="1495198143200" TEXT="public static double min(double a, double b)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495197101498" FOLDED="true" ID="ID_1515343566" MODIFIED="1532056889082">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20854;&#20182;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495197096611" ID="ID_1792647916" MODIFIED="1495197101516" TEXT="public static double ceil(double a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495197096612" ID="ID_1520612519" MODIFIED="1495197101517" TEXT="public static double floor(double a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495197096613" ID="ID_739608265" MODIFIED="1495197101519" TEXT="public static double rint(double a)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495197096614" ID="ID_1901004072" MODIFIED="1495197101520" TEXT="public static double atan2(double y, double x)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067124" ID="ID_1266424929" MODIFIED="1495198308863" TEXT="public static double signum(double d)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067124" ID="ID_1535756956" MODIFIED="1495198308864" TEXT="public static float signum(float f)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067125" ID="ID_1220887021" MODIFIED="1495198308865" TEXT="public static double sinh(double x)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067127" ID="ID_922514756" MODIFIED="1495198308866" TEXT="public static double cosh(double x)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067128" ID="ID_41334739" MODIFIED="1495198308867" TEXT="public static double tanh(double x)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067129" ID="ID_740813003" MODIFIED="1495198308870" TEXT="public static double hypot(double x, double y)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067130" ID="ID_1500060312" MODIFIED="1495198308874" TEXT="public static double expm1(double x)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067131" ID="ID_1950185818" MODIFIED="1495198308875" TEXT="public static double log1p(double x)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067132" ID="ID_1130268020" MODIFIED="1495198308876" TEXT="public static double copySign(double magnitude, double sign)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067133" ID="ID_607945806" MODIFIED="1495198308877" TEXT="public static float copySign(float magnitude, float sign)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067134" ID="ID_724290323" MODIFIED="1495198308878" TEXT="public static int getExponent(float f)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067142" ID="ID_1311121921" MODIFIED="1495198308879" TEXT="public static int getExponent(double d)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067143" ID="ID_1076404990" MODIFIED="1495198308880" TEXT="public static double nextAfter(double start, double direction)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067144" ID="ID_1904057089" MODIFIED="1495198308881" TEXT="public static float nextAfter(float start, double direction)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067145" ID="ID_1523589593" MODIFIED="1495198308883" TEXT="public static double nextUp(double d)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067145" ID="ID_499150987" MODIFIED="1495198308884" TEXT="public static float nextUp(float f)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067146" ID="ID_1728745818" MODIFIED="1495198308885" TEXT="public static double nextDown(double d)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067147" ID="ID_612860165" MODIFIED="1495198308886" TEXT="public static float nextDown(float f)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067148" ID="ID_842366584" MODIFIED="1495198308892" TEXT="public static double scalb(double d, int scaleFactor)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067148" ID="ID_1092703790" MODIFIED="1495198308893" TEXT="public static float scalb(float f, int scaleFactor)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067095" ID="ID_170812545" MODIFIED="1495198317623" TEXT="public static int toIntExact(long value)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067096" ID="ID_1384782758" MODIFIED="1495198317624" TEXT="public static int floorDiv(int x, int y)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067097" ID="ID_953519221" MODIFIED="1495198317624" TEXT="public static long floorDiv(long x, long y)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067098" ID="ID_826052244" MODIFIED="1495198317624" TEXT="public static int floorMod(int x, int y)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067099" ID="ID_58762501" MODIFIED="1495198317625" TEXT="public static long floorMod(long x, long y)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067121" ID="ID_497067159" MODIFIED="1495198269804" TEXT="public static double ulp(double d)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1495198067123" ID="ID_1938652173" MODIFIED="1495198269804" TEXT="public static float ulp(float f)">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1495165355976" FOLDED="true" ID="ID_639071519" MODIFIED="1532056889082" TEXT="UUID">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495170765592" FOLDED="true" ID="ID_961837152" MODIFIED="1532056889082" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495170766600" ID="ID_924540583" MODIFIED="1495170808923" TEXT="Universally Unique Identifier  &#x5168;&#x5c40;&#x552f;&#x4e00;&#x6807;&#x8bc6;&#x7b26;,&#x662f;&#x6307;&#x5728;&#x4e00;&#x53f0;&#x673a;&#x5668;&#x4e0a;&#x751f;&#x6210;&#x7684;&#x6570;&#x5b57;&#xff0c;&#x5b83;&#x4fdd;&#x8bc1;&#x5bf9;&#x5728;&#x540c;&#x4e00;&#x65f6;&#x7a7a;&#x4e2d;&#x7684;&#x6240;&#x6709;&#x673a;&#x5668;&#x90fd;&#x662f;&#x552f;&#x4e00;&#x7684;"/>
<node COLOR="#111111" CREATED="1495170824529" ID="ID_1355240694" MODIFIED="1495170824530" TEXT="&#x7528;&#x5230;&#x4e86;&#x4ee5;&#x592a;&#x7f51;&#x5361;&#x5730;&#x5740;&#x3001;&#x7eb3;&#x79d2;&#x7ea7;&#x65f6;&#x95f4;&#x3001;&#x82af;&#x7247;ID&#x7801;&#x548c;&#x8bb8;&#x591a;&#x53ef;&#x80fd;&#x7684;&#x6570;&#x5b57;"/>
<node COLOR="#111111" CREATED="1495171168412" FOLDED="true" ID="ID_769683731" MODIFIED="1532056889082" TEXT="UUID&#x662f;16&#x5b57;&#x8282;128&#x4f4d;&#x957f;&#x7684;&#x6570;&#x5b57;&#xff0c;&#x901a;&#x5e38;&#x4ee5;36&#x5b57;&#x8282;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x8868;&#x793a;">
<node COLOR="#111111" CREATED="1495171337208" FOLDED="true" ID="ID_1513792601" MODIFIED="1532056889082" TEXT="&#x8303;&#x4f8b;">
<node COLOR="#111111" CREATED="1495171345458" ID="ID_1512945450" MODIFIED="1495171345458" TEXT="3F2504E0-4F89-11D3-9A0C-0305E82C3301"/>
</node>
<node COLOR="#111111" CREATED="1495171354850" ID="ID_654943851" MODIFIED="1495171354850" TEXT="&#x5176;&#x4e2d;&#x7684;&#x5b57;&#x6bcd;&#x662f;16&#x8fdb;&#x5236;&#x8868;&#x793a;&#xff0c;&#x5927;&#x5c0f;&#x5199;&#x65e0;&#x5173;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495170845919" FOLDED="true" ID="ID_743311106" MODIFIED="1532056889082" TEXT="&#x7ec4;&#x6210;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495170941261" ID="ID_1939442480" MODIFIED="1495170941262" TEXT="&#xff08;1&#xff09;&#x5f53;&#x524d;&#x65e5;&#x671f;&#x548c;&#x65f6;&#x95f4;&#xff0c;UUID&#x7684;&#x7b2c;&#x4e00;&#x4e2a;&#x90e8;&#x5206;&#x4e0e;&#x65f6;&#x95f4;&#x6709;&#x5173;&#xff0c;&#x5982;&#x679c;&#x4f60;&#x5728;&#x751f;&#x6210;&#x4e00;&#x4e2a;UUID&#x4e4b;&#x540e;&#xff0c;&#x8fc7;&#x51e0;&#x79d2;&#x53c8;&#x751f;&#x6210;&#x4e00;&#x4e2a;UUID&#xff0c;&#x5219;&#x7b2c;&#x4e00;&#x4e2a;&#x90e8;&#x5206;&#x4e0d;&#x540c;&#xff0c;&#x5176;&#x4f59;&#x76f8;&#x540c;&#x3002;"/>
<node COLOR="#111111" CREATED="1495170941268" ID="ID_1557970090" MODIFIED="1495170947181" TEXT="&#xff08;2&#xff09;&#x65f6;&#x949f;&#x5e8f;&#x5217;"/>
<node COLOR="#111111" CREATED="1495170941271" ID="ID_960326916" MODIFIED="1495170951645" TEXT="&#xff08;3&#xff09;&#x5168;&#x5c40;&#x552f;&#x4e00;&#x7684;IEEE&#x673a;&#x5668;&#x8bc6;&#x522b;&#x53f7;&#xff0c;&#x5982;&#x679c;&#x6709;&#x7f51;&#x5361;&#xff0c;&#x4ece;&#x7f51;&#x5361;MAC&#x5730;&#x5740;&#x83b7;&#x5f97;&#xff0c;&#x6ca1;&#x6709;&#x7f51;&#x5361;&#x4ee5;&#x5176;&#x4ed6;&#x65b9;&#x5f0f;&#x83b7;&#x5f97;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1495171014965" FOLDED="true" ID="ID_307603709" MODIFIED="1532056889082" TEXT="&#x5e38;&#x7528;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495171055568" ID="ID_695162878" MODIFIED="1495171055568" TEXT="public static UUID randomUUID()"/>
<node COLOR="#111111" CREATED="1495171105168" ID="ID_262010769" MODIFIED="1495171105168" TEXT="public String toString()"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1495711799703" FOLDED="true" ID="ID_152902073" MODIFIED="1532056889098">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Timer
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495719702705" FOLDED="true" ID="ID_269207388" MODIFIED="1532056889098" TEXT="&#x6784;&#x9020;&#x51fd;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495719705460" ID="ID_834073463" MODIFIED="1495719705460" TEXT="public Timer()"/>
<node COLOR="#111111" CREATED="1495719715637" FOLDED="true" ID="ID_1742835940" MODIFIED="1532056889082" TEXT="public Timer(String name)">
<node COLOR="#111111" CREATED="1495720918302" FOLDED="true" ID="ID_5744676" MODIFIED="1532056889082" TEXT="name">
<node COLOR="#111111" CREATED="1495720921457" ID="ID_1701668369" MODIFIED="1495720931126" TEXT="&#x5b9a;&#x65f6;&#x5668;&#x7684;&#x540d;&#x5b57;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720360023" FOLDED="true" ID="ID_586306859" MODIFIED="1532056889098" TEXT="public Timer(String name, boolean isDaemon)">
<node COLOR="#111111" CREATED="1495720934368" FOLDED="true" ID="ID_1967642518" MODIFIED="1532056889082" TEXT="isDaemon">
<node COLOR="#111111" CREATED="1495720941292" ID="ID_382396859" MODIFIED="1495720954214" TEXT="&#x662f;&#x5426;&#x8bbe;&#x7f6e;&#x4e3a;&#x540e;&#x53f0;&#x7ebf;&#x7a0b;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1495720374673" FOLDED="true" ID="ID_605618299" MODIFIED="1532056889098" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495720376582" FOLDED="true" ID="ID_666047092" MODIFIED="1532056889098" TEXT="public void schedule(TimerTask task, long delay)">
<node COLOR="#111111" CREATED="1495720957657" FOLDED="true" ID="ID_598719033" MODIFIED="1532056889098" TEXT="?">
<node COLOR="#111111" CREATED="1495720964679" ID="ID_1550802319" MODIFIED="1495720973184" TEXT="&#x5b9a;&#x65f6;&#x6267;&#x884c;&#x4efb;&#x52a1;"/>
</node>
<node COLOR="#111111" CREATED="1495720974545" FOLDED="true" ID="ID_1017288220" MODIFIED="1532056889098" TEXT="TimerTask">
<arrowlink DESTINATION="ID_1650574484" ENDARROW="Default" ENDINCLINATION="448;0;" ID="Arrow_ID_835366314" STARTARROW="None" STARTINCLINATION="448;0;"/>
<node COLOR="#111111" CREATED="1495720983452" ID="ID_328988391" MODIFIED="1495720994055" TEXT="&#x4e00;&#x4e2a;&#x5b9a;&#x65f6;&#x4efb;&#x52a1;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_1363799868" MODIFIED="1532056889098" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_915183348" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720390342" FOLDED="true" ID="ID_300547047" MODIFIED="1532056889098" TEXT="public void schedule(TimerTask task, Date time)">
<node COLOR="#111111" CREATED="1495721069628" ID="ID_342960082" MODIFIED="1495721087940" TEXT="&#x5728;&#x672a;&#x6765;&#x7684;&#x67d0;&#x4e2a;&#x65f6;&#x95f4; time&#x6267;&#x884c;"/>
<node COLOR="#111111" CREATED="1495721088453" ID="ID_1990036126" MODIFIED="1495721102118" TEXT="time:&#x672a;&#x6765;&#x67d0;&#x4e2a;&#x65e5;&#x671f;"/>
</node>
<node COLOR="#111111" CREATED="1495720424345" FOLDED="true" ID="ID_1494274988" MODIFIED="1532056889098" TEXT="public void schedule(TimerTask task, long delay, long period)">
<node COLOR="#111111" CREATED="1495721106799" ID="ID_185295240" MODIFIED="1495721133859" TEXT="&#x4efb;&#x52a1;&#x6bcf;&#x9694; period&#x6267;&#x884c;&#x4e00;&#x6b21;"/>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_1773164714" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_1409090879" MODIFIED="1532056889098" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_1061308242" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1495720410305" FOLDED="true" ID="ID_1789051404" MODIFIED="1532056889098" TEXT="public void schedule(TimerTask task, Date firstTime, long period)">
<node COLOR="#111111" CREATED="1495721137538" ID="ID_237587403" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721882093" ID="ID_285571300" MODIFIED="1495721914513">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      firstTime : &#39318;&#27425;&#25191;&#34892;&#30340;&#26102;&#38388;,&#29992;Date&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495720444767" FOLDED="true" ID="ID_253357917" MODIFIED="1532056889098" TEXT="public void scheduleAtFixedRate(TimerTask task, long delay, long period)">
<node COLOR="#111111" CREATED="1495721032502" FOLDED="true" ID="ID_764304382" MODIFIED="1532056889098" TEXT="delay">
<node COLOR="#111111" CREATED="1495721035781" ID="ID_1609057719" MODIFIED="1495721055762" TEXT="&#x5ef6;&#x65f6;&#x7684;&#x65f6;&#x95f4;"/>
</node>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_989185369" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
</node>
<node COLOR="#111111" CREATED="1495720460358" FOLDED="true" ID="ID_605233019" MODIFIED="1532056889098" TEXT="public void scheduleAtFixedRate(TimerTask task, Date firstTime,     long period)">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1495721137538" ID="ID_1926199847" MODIFIED="1495721158557" TEXT="period: &#x76f8;&#x90bb;&#x4e24;&#x6b21;&#x6267;&#x884c;&#x7684;&#x65f6;&#x95f4;&#x95f4;&#x9694;"/>
<node COLOR="#111111" CREATED="1495721882093" ID="ID_424558010" MODIFIED="1495721914513">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      firstTime : &#39318;&#27425;&#25191;&#34892;&#30340;&#26102;&#38388;,&#29992;Date&#34920;&#31034;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1495720490697" FOLDED="true" ID="ID_1020148639" MODIFIED="1532056889098" TEXT="public void cancel()">
<node COLOR="#111111" CREATED="1495722025551" ID="ID_1841405845" MODIFIED="1495722033537" TEXT="&#x53d6;&#x6d88;&#x4efb;&#x52a1;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1495721015686" FOLDED="true" ID="ID_1650574484" MODIFIED="1532056889098">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      TimerTask&#25277;&#35937;&#31867;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1495722213466" FOLDED="true" ID="ID_1678365498" MODIFIED="1532056889098">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      ?
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1495722194538" ID="ID_985057047" MODIFIED="1495722213472" TEXT="&#x548c;Timer&#x5171;&#x540c;&#x4f7f;&#x7528;&#x6765;&#x5b9a;&#x65f6;&#x4e00;&#x4e2a;&#x4efb;&#x52a1;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1495722074591" ID="ID_351274268" MODIFIED="1495722074592" TEXT="public abstract void run()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1495722151326" ID="ID_934257226" MODIFIED="1495722151327" TEXT="public boolean cancel()">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1473640567998" FOLDED="true" ID="ID_1792970883" MODIFIED="1532056889098" POSITION="right" TEXT="&#x9759;&#x6001;&#x4e0e;&#x975e;&#x9759;&#x6001;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1489017645089" FOLDED="true" ID="ID_1204011279" MODIFIED="1532056889098" TEXT="&#x9759;&#x6001;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1489017677606" ID="ID_1328457057" MODIFIED="1489017677606" TEXT="&#x6bcf;&#x6b21;new&#x5c31;&#x4f1a;&#x88ab;&#x5206;&#x914d;&#x5185;&#x5b58;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1489017682610" ID="ID_121271269" MODIFIED="1489017691405" TEXT="&#x7528;static&#x7684;&#x4fee;&#x9970;&#x7684;&#x53d8;&#x91cf;&#x548c;&#x65b9;&#x6cd5;&#xff0c;&#x5b9e;&#x9645;&#x4e0a;&#x662f;&#x6307;&#x5b9a;&#x4e86;&#x8fd9;&#x4e9b;&#x53d8;&#x91cf;&#x548c;&#x65b9;&#x6cd5;&#x5728;&#x5185;&#x5b58;&#x4e2d;&#x7684;&quot;&#x56fa;&#x5b9a;&#x4f4d;&#x7f6e;&quot;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1489017714478" ID="ID_414906042" MODIFIED="1489018258472" TEXT="&#x9759;&#x6001;&#x6570;&#x636e;&#x4f1a;&#x88ab;&#x5171;&#x4eab;,&#x6240;&#x4ee5;&#x6bcf;&#x4e00;&#x4e2a;&#x5b9e;&#x4f8b;&#x90fd;&#x6307;&#x5411;&#x540c;&#x4e00;&#x4e2a;&#x5185;&#x5b58;&#x5730;&#x5740;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1489017649256" FOLDED="true" ID="ID_1800913658" MODIFIED="1532056889098" TEXT="&#x975e;&#x9759;&#x6001;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1489018271445" ID="ID_998396187" MODIFIED="1489018306216" TEXT="&#x975e;&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x4e5f;&#x53ea;&#x6709;&#x4e00;&#x4efd;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1489018323925" ID="ID_1211563392" MODIFIED="1489018376769" TEXT="&#x975e;&#x9759;&#x6001;&#x5f15;&#x7528;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x4f1a;&#x5728;&#x5806;&#x4e2d;&#x5206;&#x914d;&#x591a;&#x5206;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473641138026" FOLDED="true" ID="ID_146386168" MODIFIED="1532056889098" TEXT="&#x5171;&#x540c;&#x4e4b;&#x5904;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473641141527" ID="ID_803854092" MODIFIED="1489018206823" TEXT="&#x65b9;&#x6cd5;&#x4e0d;&#x8bba;&#x6709;&#x591a;&#x5c11;&#x4e2a;&#x5b9e;&#x4f8b;&#x5bf9;&#x8c61;&#xff0c;&#x5b83;&#x7684;&#x65b9;&#x6cd5;&#x7684;&#x4ee3;&#x7801;&#x90fd;&#x662f;&#x4e00;&#x6837;&#x7684;&#xff0c;&#xa;&#x6240;&#x4ee5;&#x53ea;&#x8981;&#x6709;&#x4e00;&#x4efd;&#x4ee3;&#x7801;&#x5c31;&#x591f;&#x4e86;&#x3002;&#xa;&#x56e0;&#x6b64;&#x65e0;&#x8bba;&#x662f;static&#x8fd8;&#x662f;non-static&#x7684;&#x65b9;&#x6cd5;&#xff0c;&#x90fd;&#x53ea;&#x5b58;&#x5728;&#x4e00;&#x4efd;&#x4ee3;&#x7801;&#xff0c;&#xa;&#x4e5f;&#x5c31;&#x662f;&#x53ea;&#x5360;&#x7528;&#x4e00;&#x4efd;&#x5185;&#x5b58;&#x7a7a;&#x95f4;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473640668659" ID="ID_1550139370" MODIFIED="1489018411563" TEXT="&#x9759;&#x6001;&#x5b57;&#x6bb5;&#x548c;&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x4ee5;&#x53ca;&#x975e;&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x90fd;&#x53ea;&#x6709;&#x4e00;&#x4efd;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1473640744610" FOLDED="true" ID="ID_227688705" MODIFIED="1532056889098" TEXT="&#x5982;&#x4f55;&#x9009;&#x62e9;?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1473641336687" ID="ID_1337346894" MODIFIED="1489018194251" TEXT="&#x4ece;&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x7684;&#x89d2;&#x5ea6;&#x4e0a;&#x6765;&#x8bf4;&#xff0c;&#x5728;&#x6289;&#x62e9;&#x4f7f;&#x7528;&#x5b9e;&#x4f8b;&#x5316;&#x65b9;&#x6cd5;&#x6216;&#x9759;&#x6001;&#x65b9;&#xa;&#x6cd5;&#x65f6;&#xff0c;&#x5e94;&#x8be5;&#x6839;&#x636e;&#x662f;&#x5426;&#x8be5;&#x65b9;&#x6cd5;&#x548c;&#x5b9e;&#x4f8b;&#x5316;&#x5bf9;&#x8c61;&#x5177;&#x6709;&#x903b;&#x8f91;&#x4e0a;&#x7684;&#x76f8;&#x5173;&#x6027;&#xff0c;&#xa;&#x5982;&#x679c;&#x662f;&#x5c31;&#x5e94;&#x8be5;&#x4f7f;&#x7528;&#x5b9e;&#x4f8b;&#x5316;&#x5bf9;&#x8c61;, &#x53cd;&#x4e4b;&#x4f7f;&#x7528;&#x9759;&#x6001;&#x65b9;&#x6cd5;&#x3002;&#xa;&#x8fd9;&#x53ea;&#x662f;&#x4ece;&#x9762;&#x5411;&#x5bf9;&#x8c61;&#x89d2;&#x5ea6;&#x4e0a;&#x6765;&#x8bf4;&#x7684;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473640753214" ID="ID_846930760" MODIFIED="1488364284008" TEXT="&#x516c;&#x7528;&#x7684;&#x65b9;&#x6cd5;&#xff0c;&#x800c;&#x4e14;&#x662f;&#x4e00;&#x4e9b;&#x96f6;&#x6563;&#x7684; &#x4e00;&#x822c;&#x7528;&#x9759;&#x6001;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1473641372626" ID="ID_246944189" MODIFIED="1488364284008" TEXT="&#x5982;&#x679c;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#x4e0e;&#x4ed6;&#x6240;&#x5728;&#x7c7b;&#x7684;&#x5b9e;&#x4f8b;&#x5bf9;&#x8c61;&#x65e0;&#x5173;&#xff0c;&#x90a3;&#x4e48;&#x5b83;&#x5c31;&#x5e94;&#x8be5;&#x662f;&#x9759;&#x6001;&#x7684;&#xff0c;&#x800c;&#x4e0d;&#x5e94;&#x8be5;&#x628a;&#x5b83;&#x5199;&#x6210;&#x5b9e;&#x4f8b;&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1489016745163" FOLDED="true" ID="ID_340381935" LINK="../&#x6587;&#x6863;/java&#x5185;&#x5b58;&#x6a21;&#x578b;.docx" MODIFIED="1532056889098" TEXT="&#x5ef6;&#x4f38;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1531268384843" FOLDED="true" ID="ID_956016254" MODIFIED="1532056889098" TEXT="&#x9644;&#x4ef6;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1531268388740" ID="ID_428721271" MODIFIED="1531268388741">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="java&#x8bed;&#x6cd5;_9037194382993349360.jpeg" />
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1531268399989" ID="ID_478696871" MODIFIED="1531268399990">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="java&#x8bed;&#x6cd5;_6663227557096311944.jpeg" />
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#990000" CREATED="1489016782768" FOLDED="true" ID="ID_264472154" MODIFIED="1532056889098" TEXT="&#x5185;&#x5b58;&#x57fa;&#x672c;&#x6784;&#x6210;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1489016787908" FOLDED="true" ID="ID_1571664198" MODIFIED="1532056889098" TEXT="&#x7f16;&#x7a0b;&#x5185;&#x5b58;&#x5728;&#x57fa;&#x672c;&#x4e0a;&#x5206;&#x4e3a;&#x8fd9;&#x6837;&#x7684;&#x51e0;&#x5927;&#x90e8;&#x5206;&#xff1a;">
<node COLOR="#111111" CREATED="1531268672334" FOLDED="true" ID="ID_668595394" MODIFIED="1532056889098" TEXT="&#x2022;        &#x6808;&#xff1a;&#x5b58;&#x653e;&#x5c40;&#x90e8;&#x53d8;&#x91cf;">
<node COLOR="#111111" CREATED="1531268732735" ID="ID_1814466080" MODIFIED="1531268732735" TEXT="&#x2022;        &#x7ebf;&#x7a0b;&#x79c1;&#x6709;&#xff0c;&#x751f;&#x547d;&#x5468;&#x671f;&#x548c;&#x7ebf;&#x7a0b;&#x76f8;&#x540c;"/>
<node COLOR="#111111" CREATED="1531268732736" ID="ID_1893636029" MODIFIED="1531268732736" TEXT="&#x2022;        &#x6808;&#x7531;&#x4e00;&#x7cfb;&#x5217;&#x5e27;&#x7ec4;&#x6210;&#xff08;&#x56e0;&#x6b64;Java&#x6808;&#x4e5f;&#x53eb;&#x505a;&#x5e27;&#x6808;&#xff09;"/>
<node COLOR="#111111" CREATED="1531268732737" ID="ID_1749178775" MODIFIED="1531268732737" TEXT="&#x2022;        &#x5e27;&#x4fdd;&#x5b58;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#x7684;&#x5c40;&#x90e8;&#x53d8;&#x91cf;&#x3001;&#x64cd;&#x4f5c;&#x6570;&#x6808;&#x3001;&#x5e38;&#x91cf;&#x6c60;&#x6307;&#x9488;"/>
<node COLOR="#111111" CREATED="1531268732737" ID="ID_1103859822" MODIFIED="1531268732737" TEXT="&#x2022;        &#x6bcf;&#x4e00;&#x6b21;&#x65b9;&#x6cd5;&#x8c03;&#x7528;&#x521b;&#x5efa;&#x4e00;&#x4e2a;&#x5e27;&#xff0c;&#x5e76;&#x538b;&#x6808;"/>
<node COLOR="#111111" CREATED="1531268754042" FOLDED="true" ID="ID_1624920695" MODIFIED="1532056889098" TEXT="&#x89e3;&#x91ca;&#xff1a;">
<node COLOR="#111111" CREATED="1531268754043" ID="ID_124372291" MODIFIED="1531268754043" TEXT="Java&#x865a;&#x62df;&#x673a;&#x6808;&#x63cf;&#x8ff0;&#x7684;&#x662f;Java&#x65b9;&#x6cd5;&#x6267;&#x884c;&#x7684;&#x5185;&#x5b58;&#x6a21;&#x578b;&#xff1a;&#x6bcf;&#x4e2a;&#x65b9;&#x6cd5;&#x88ab;&#x8c03;&#x7528;&#x7684;&#x65f6;&#x5019;&#x90fd;&#x4f1a;&#x521b;&#x5efa;&#x4e00;&#x4e2a;&#x6808;&#x5e27;&#xff0c;&#x7528;&#x4e8e;&#x5b58;&#x50a8;&#x5c40;&#x90e8;&#x53d8;&#x91cf;&#x8868;&#x3001;&#x64cd;&#x4f5c;&#x6808;&#x3001;&#x52a8;&#x6001;&#x94fe;&#x63a5;&#x3001;&#x65b9;&#x6cd5;&#x51fa;&#x53e3;&#x7b49;&#x4fe1;&#x606f;&#x3002;&#x6bcf;&#x4e00;&#x4e2a;&#x65b9;&#x6cd5;&#x88ab;&#x8c03;&#x7528;&#x76f4;&#x81f3;&#x6267;&#x884c;&#x5b8c;&#x6210;&#x7684;&#x8fc7;&#x7a0b;&#x5c31;&#x5bf9;&#x5e94;&#x7740;&#x4e00;&#x4e2a;&#x6808;&#x5e27;&#x5728;&#x865a;&#x62df;&#x673a;&#x4e2d;&#x4ece;&#x5165;&#x6808;&#x5230;&#x51fa;&#x6808;&#x7684;&#x8fc7;&#x7a0b;&#x3002;"/>
<node COLOR="#111111" CREATED="1531268754045" FOLDED="true" ID="ID_475103777" MODIFIED="1532056889098" TEXT="&#x5728;Java&#x865a;&#x62df;&#x673a;&#x89c4;&#x8303;&#x4e2d;&#xff0c;&#x5bf9;&#x8fd9;&#x4e2a;&#x533a;&#x57df;&#x89c4;&#x5b9a;&#x4e86;&#x4e24;&#x79cd;&#x5f02;&#x5e38;&#x60c5;&#x51b5;&#xff1a;">
<node COLOR="#111111" CREATED="1531268754046" ID="ID_1987821005" MODIFIED="1531268754046" TEXT="&#xff08;1&#xff09;&#x5982;&#x679c;&#x7ebf;&#x7a0b;&#x8bf7;&#x6c42;&#x7684;&#x6808;&#x6df1;&#x5ea6;&#x592a;&#x6df1;&#xff0c;&#x8d85;&#x51fa;&#x4e86;&#x865a;&#x62df;&#x673a;&#x6240;&#x5141;&#x8bb8;&#x7684;&#x6df1;&#x5ea6;&#xff0c;&#x5c31;&#x4f1a;&#x51fa;&#x73b0;StackOverFlowError&#xff08;&#x6bd4;&#x5982;&#x65e0;&#x9650;&#x9012;&#x5f52;&#x3002;&#x56e0;&#x4e3a;&#x6bcf;&#x4e00;&#x5c42;&#x6808;&#x5e27;&#x90fd;&#x5360;&#x7528;&#x4e00;&#x5b9a;&#x7a7a;&#x95f4;&#xff0c;&#x800c; Xss &#x89c4;&#x5b9a;&#x4e86;&#x6808;&#x7684;&#x6700;&#x5927;&#x7a7a;&#x95f4;&#xff0c;&#x8d85;&#x51fa;&#x8fd9;&#x4e2a;&#x503c;&#x5c31;&#x4f1a;&#x62a5;&#x9519;&#xff09;"/>
<node COLOR="#111111" CREATED="1531268754051" ID="ID_1930017780" MODIFIED="1531268754051" TEXT="&#xff08;2&#xff09;&#x865a;&#x62df;&#x673a;&#x6808;&#x53ef;&#x4ee5;&#x52a8;&#x6001;&#x6269;&#x5c55;&#xff0c;&#x5982;&#x679c;&#x6269;&#x5c55;&#x5230;&#x65e0;&#x6cd5;&#x7533;&#x8bf7;&#x8db3;&#x591f;&#x7684;&#x5185;&#x5b58;&#x7a7a;&#x95f4;&#xff0c;&#x4f1a;&#x51fa;&#x73b0;OOM"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1531268672335" FOLDED="true" ID="ID_1039510429" MODIFIED="1532056889098" TEXT="&#x2022;        &#x5806;&#xff1a;&#x5b58;&#x653e;&#x6240;&#x6709;new&#x51fa;&#x6765;&#x7684;&#x4e1c;&#x897f;">
<node COLOR="#111111" CREATED="1531268724642" ID="ID_500710366" MODIFIED="1531268724642" TEXT="&#x548c;&#x7a0b;&#x5e8f;&#x5f00;&#x53d1;&#x5bc6;&#x5207;&#x76f8;&#x5173;"/>
<node COLOR="#111111" CREATED="1531268724643" ID="ID_84279041" MODIFIED="1531268724643" TEXT="&#x5e94;&#x7528;&#x7cfb;&#x7edf;&#x5bf9;&#x8c61;&#x90fd;&#x4fdd;&#x5b58;&#x5728;Java&#x5806;&#x4e2d;"/>
<node COLOR="#111111" CREATED="1531268724645" ID="ID_263878342" MODIFIED="1531268724645" TEXT="&#x6240;&#x6709;&#x7ebf;&#x7a0b;&#x5171;&#x4eab;Java&#x5806;"/>
</node>
<node COLOR="#111111" CREATED="1531268672337" FOLDED="true" ID="ID_1034293132" MODIFIED="1532056889098" TEXT="&#x2022;        &#x65b9;&#x6cd5;&#x533a;&#xff1a;&#x88ab;&#x865a;&#x62df;&#x673a;&#x52a0;&#x8f7d;&#x7684;&#x7c7b;&#x4fe1;&#x606f;&#x3001;&#x5e38;&#x91cf;&#x3001;&#x9759;&#x6001;&#x5e38;&#x91cf;&#x7b49;&#x3002;">
<node COLOR="#111111" CREATED="1531268704736" ID="ID_345952506" MODIFIED="1531268704736" TEXT="&#x4fdd;&#x5b58;&#x88c5;&#x8f7d;&#x7684;&#x7c7b;&#x4fe1;&#x606f;"/>
<node COLOR="#111111" CREATED="1531268704737" ID="ID_1157806714" MODIFIED="1531268704737" TEXT="&#x3000;&#x3000;&#x7c7b;&#x578b;&#x7684;&#x5e38;&#x91cf;&#x6c60;"/>
<node COLOR="#111111" CREATED="1531268704738" ID="ID_279459320" MODIFIED="1531268704738" TEXT="&#x3000;&#x3000;&#x5b57;&#x6bb5;&#xff0c;&#x65b9;&#x6cd5;&#x4fe1;&#x606f;"/>
<node COLOR="#111111" CREATED="1531268704738" ID="ID_1200113714" MODIFIED="1531268704738" TEXT="&#x3000;&#x3000;&#x65b9;&#x6cd5;&#x5b57;&#x8282;&#x7801;"/>
<node COLOR="#111111" CREATED="1531268704739" ID="ID_652192224" MODIFIED="1531268704739" TEXT="&#x901a;&#x5e38;&#x548c;&#x6c38;&#x4e45;&#x533a;(Perm)&#x5173;&#x8054;&#x5728;&#x4e00;&#x8d77;"/>
</node>
<node COLOR="#111111" CREATED="1531268672344" FOLDED="true" ID="ID_1641073512" MODIFIED="1532056889098" TEXT="&#x2022;        &#x7a0b;&#x5e8f;&#x8ba1;&#x6570;&#x5668;(&#x548c;&#x7cfb;&#x7edf;&#x76f8;&#x5173;)">
<node COLOR="#111111" CREATED="1531268691982" ID="ID_1592568652" MODIFIED="1531268691982" TEXT="&#x6bcf;&#x4e2a;&#x7ebf;&#x7a0b;&#x62e5;&#x6709;&#x4e00;&#x4e2a;PC&#x5bc4;&#x5b58;&#x5668;"/>
<node COLOR="#111111" CREATED="1531268691983" ID="ID_1943489070" MODIFIED="1531268691983" TEXT="&#x5728;&#x7ebf;&#x7a0b;&#x521b;&#x5efa;&#x65f6;&#x521b;&#x5efa;"/>
<node COLOR="#111111" CREATED="1531268691984" ID="ID_897324952" MODIFIED="1531268691984" TEXT="&#x6307;&#x5411;&#x4e0b;&#x4e00;&#x6761;&#x6307;&#x4ee4;&#x7684;&#x5730;&#x5740;"/>
<node COLOR="#111111" CREATED="1531268691984" ID="ID_301675547" MODIFIED="1531268691985" TEXT="&#x6267;&#x884c;&#x672c;&#x5730;&#x65b9;&#x6cd5;&#x65f6;&#xff0c;PC&#x7684;&#x503c;&#x4e3a;undefined"/>
</node>
<node COLOR="#111111" CREATED="1531268672345" FOLDED="true" ID="ID_205672402" MODIFIED="1532056889098" TEXT="&#x2022;        &#x672c;&#x5730;&#x65b9;&#x6cd5;&#x6808;">
<node COLOR="#111111" CREATED="1531268836566" ID="ID_1847636343" MODIFIED="1531268840435" TEXT="native&#x65b9;&#x6cd5;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1489016766483" FOLDED="true" ID="ID_499809848" MODIFIED="1532056889098" TEXT="&#x9759;&#x6001;&#x5b58;&#x50a8;&#x533a;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1489016800215" ID="ID_15212013" MODIFIED="1489017121881" TEXT="&#x5185;&#x5b58;&#x5728;&#x7a0b;&#x5e8f;&#x7f16;&#x8bd1;&#x7684;&#x65f6;&#x5019;&#x5c31;&#x5df2;&#x7ecf;&#x5206;&#x914d;&#x597d;&#xff0c;&#xa;&#x8fd9;&#x5757;&#x5185;&#x5b58;&#x5728;&#x7a0b;&#x5e8f;&#x7684;&#x6574;&#x4e2a;&#x8fd0;&#x884c;&#x671f;&#x95f4;&#x90fd;&#x5b58;&#x5728;&#x3002;&#xa;&#x5b83;&#x4e3b;&#x8981;&#x5b58;&#x653e;&#x9759;&#x6001;&#x6570;&#x636e;&#x3001;&#x5168;&#x5c40;&#x6570;&#x636e;&#x548c;&#x5e38;&#x91cf;&#x3002;"/>
</node>
<node COLOR="#990000" CREATED="1489016757265" FOLDED="true" ID="ID_355469184" MODIFIED="1532056889098" TEXT="&#x5806;&#x533a;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1489017420100" FOLDED="true" ID="ID_424948263" MODIFIED="1532056889098" TEXT="?">
<node COLOR="#111111" CREATED="1489016844578" ID="ID_221846462" MODIFIED="1489017334451" TEXT="&#x4ea6;&#x79f0;&#x52a8;&#x6001;&#x5185;&#x5b58;&#x5206;&#x914d;&#x3002;&#x7a0b;&#x5e8f;&#x5728;&#x8fd0;&#x884c;&#x7684;&#x65f6;&#x5019;&#x7533;&#x8bf7;&#x7684;&#x5185;&#x5b58;. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1489016899880" ID="ID_729965540" MODIFIED="1489016968618" TEXT="&#x52a8;&#x6001;&#x5185;&#x5b58;&#x7684;&#x751f;&#x5b58;&#x671f;&#x53ef;&#x4ee5;&#x7531;&#x6211;&#x4eec;&#x51b3;&#x5b9a;&#xff0c;&#x5982;&#x679c;&#x6211;&#x4eec;&#x4e0d;&#x91ca;&#x653e;&#x5185;&#x5b58;&#xff0c;java&#x7684;&#x5783;&#x573e;&#x56de;&#x6536;&#x5668;(GC)&#x4f1a;&#x8d1f;&#x8d23;&#x56de;&#x6536;&#x3002;"/>
<node COLOR="#111111" CREATED="1489016969750" ID="ID_873104529" MODIFIED="1489016969750" TEXT="&#x5b83;&#x4e3b;&#x8981;&#x5b58;&#x653e;&#x5bf9;&#x8c61;&#x548c;&#x6570;&#x7ec4;&#x3002;&#x200b;"/>
</node>
<node COLOR="#111111" CREATED="1489017363879" FOLDED="true" ID="ID_1883421652" MODIFIED="1532056889098" TEXT="&#x7f3a;&#x70b9;">
<node COLOR="#111111" CREATED="1489017371655" ID="ID_1591806346" MODIFIED="1489017375325" TEXT="&#x8981;&#x5728;&#x8fd0;&#x884c;&#x65f6;&#x52a8;&#x6001;&#x5206;&#x914d;&#x5185;&#x5b58;&#xff0c;&#x5b58;&#x53d6;&#x901f;&#x5ea6;&#x8f83;&#x6162;"/>
</node>
<node COLOR="#111111" CREATED="1489017379375" FOLDED="true" ID="ID_1469346809" MODIFIED="1532056889098" TEXT="&#x4f18;&#x70b9;">
<node COLOR="#111111" CREATED="1489017400878" ID="ID_55030002" MODIFIED="1489017400878" TEXT="&#x53ef;&#x4ee5;&#x52a8;&#x6001;&#x5206;&#x914d;&#x5185;&#x5b58;&#x5927;&#x5c0f;&#xff0c;&#x751f;&#x5b58;&#x671f;&#x4e5f;&#x4e0d;&#x5fc5;&#x4e8b;&#x5148;&#x544a;&#x8bc9;&#x7f16;&#x8bd1;&#x5668;&#xff0c;&#x56e0;&#x4e3a;&#x5b83;&#x662f;&#x5728;&#x8fd0;&#x884c;&#x65f6;&#x52a8;&#x6001;&#x5206;&#x914d;&#x5185;&#x5b58;&#x7684;&#x3002;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1489016762319" FOLDED="true" ID="ID_1275393652" MODIFIED="1532056889098" TEXT="&#x6808;&#x533a;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1489017467356" FOLDED="true" ID="ID_885487980" MODIFIED="1532056889098" TEXT="?">
<node COLOR="#111111" CREATED="1489016814192" ID="ID_760687457" MODIFIED="1489016821351" TEXT="&#x5728;&#x6267;&#x884c;&#x51fd;&#x6570;&#x65f6;&#xff0c;&#x51fd;&#x6570;&#x5185;&#x5c40;&#x90e8;&#x53d8;&#x91cf;&#x7684;&#x5b58;&#x50a8;&#x5355;&#x5143;&#x90fd;&#x53ef;&#x4ee5;&#x5728;&#x6808;&#x4e0a;&#x521b;&#x5efa;&#xff0c;&#x51fd;&#x6570;&#x6267;&#x884c;&#x7ed3;&#x675f;&#x65f6;&#x8fd9;&#x4e9b;&#x5b58;&#x50a8;&#x5355;&#x5143;&#x81ea;&#x52a8;&#x88ab;&#x91ca;&#x653e;&#x3002;"/>
<node COLOR="#111111" CREATED="1489016829311" ID="ID_1715716028" MODIFIED="1489016829312" TEXT="&#x5b83;&#x4e3b;&#x8981;&#x5b58;&#x653e;&#x5c40;&#x90e8;&#x53d8;&#x91cf;&#xff0c;&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x53d8;&#x91cf;&#x548c;&#x5bf9;&#x8c61;&#x7684;&#x5f15;&#x7528;&#x53d8;&#x91cf;&#x3002;"/>
<node COLOR="#111111" CREATED="1489017213934" ID="ID_1025518101" MODIFIED="1489017231247" TEXT="&#x6240;&#x6709;&#x7684;&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x90fd;&#x5b58;&#x653e;&#x5728;&#x8be5;&#x533a;&#x4e2d;"/>
</node>
<node COLOR="#111111" CREATED="1489017430800" FOLDED="true" ID="ID_1140562166" MODIFIED="1532056889098" TEXT="&#x4f18;&#x70b9;">
<node COLOR="#111111" CREATED="1489017442552" ID="ID_826135904" MODIFIED="1489017442552" TEXT="&#x6808;&#x5185;&#x5b58;&#x5206;&#x914d;&#x8fd0;&#x7b97;&#x5185;&#x7f6e;&#x4e8e;&#x5904;&#x7406;&#x5668;&#x7684;&#x6307;&#x4ee4;&#x96c6;&#x4e2d;&#xff0c;&#x6548;&#x7387;&#x5f88;&#x9ad8;&#xff0c;"/>
</node>
<node COLOR="#111111" CREATED="1489017443375" FOLDED="true" ID="ID_163427480" MODIFIED="1532056889098" TEXT="&#x7f3a;&#x70b9;">
<node COLOR="#111111" CREATED="1489016822802" ID="ID_615400929" MODIFIED="1489017460039" TEXT="&#x53ef;&#x5206;&#x914d;&#x7684;&#x5185;&#x5b58;&#x5bb9;&#x91cf;&#x6709;&#x9650;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1489017498542" FOLDED="true" ID="ID_1591021400" MODIFIED="1532056889098" TEXT="&#x7279;&#x6b8a;&#x6027;">
<node COLOR="#111111" CREATED="1489017507504" ID="ID_1626088066" MODIFIED="1489017507504" TEXT="&#x5b58;&#x5728;&#x6808;&#x4e2d;&#x7684;&#x6570;&#x636e;&#x53ef;&#x4ee5;&#x5171;&#x4eab;"/>
<node COLOR="#111111" CREATED="1489017537455" FOLDED="true" ID="ID_1212559125" MODIFIED="1532056889098" TEXT="&#x8303;&#x4f8b;&#x63cf;&#x8ff0;">
<node COLOR="#111111" CREATED="1489017545061" ID="ID_331673518" MODIFIED="1489017545062" TEXT="&#x7f16;&#x8bd1;&#x5668;&#x5148;&#x5904;&#x7406;int a = 3&#xff1b;&#x9996;&#x5148;&#x5b83;&#x4f1a;&#x5728;&#x6808;&#x4e2d;&#x521b;&#x5efa;&#x4e00;&#x4e2a;&#x53d8;&#x91cf;&#x4e3a;a&#x7684;&#x5f15;&#x7528;&#xff0c;&#x7136;&#x540e;&#x67e5;&#x627e;&#x6709;&#x6ca1;&#x6709;&#x5b57;&#x9762;&#x503c;&#x4e3a;3&#x7684;&#x5730;&#x5740;&#xff0c;&#x6ca1;&#x627e;&#x5230;&#xff0c;&#x5c31;&#x5f00;&#x8f9f;&#x4e00;&#x4e2a;&#x5b58;&#x653e;3&#x8fd9;&#x4e2a;&#x5b57;&#x9762;&#x503c;&#x7684;&#x5730;&#x5740;&#xff0c;&#x7136;&#x540e;&#x5c06;a&#x6307;&#x5411;3&#x7684;&#x5730;&#x5740;&#x3002;&#x63a5;&#x7740;&#x5904;&#x7406;int b = 3&#xff1b;&#x5728;&#x521b;&#x5efa;&#x5b8c;b&#x8fd9;&#x4e2a;&#x5f15;&#x7528;&#x53d8;&#x91cf;&#x540e;&#xff0c;&#x7531;&#x4e8e;&#x5728;&#x6808;&#x4e2d;&#x5df2;&#x7ecf;&#x6709;3&#x8fd9;&#x4e2a;&#x5b57;&#x9762;&#x503c;&#xff0c;&#x4fbf;&#x5c06;b&#x76f4;&#x63a5;&#x6307;&#x5411;3&#x7684;&#x5730;&#x5740;&#x3002;&#x8fd9;&#x6837;&#xff0c;&#x5c31;&#x51fa;&#x73b0;&#x4e86;a&#x4e0e;b&#x540c;&#x65f6;&#x5747;&#x6307;&#x5411;3&#x7684;&#x60c5;&#x51b5;&#x3002;"/>
<node COLOR="#111111" CREATED="1489017564647" ID="ID_1303837025" MODIFIED="1489017564649" TEXT="&#x5b9a;&#x4e49;&#x5b8c;a&#x4e0e;b&#x7684;&#x503c;&#x540e;&#xff0c;&#x518d;&#x4ee4;a = 4&#xff1b;&#x90a3;&#x4e48;&#xff0c;b&#x4e0d;&#x4f1a;&#x7b49;&#x4e8e;4&#xff0c;&#x8fd8;&#x662f;&#x7b49;&#x4e8e;3&#x3002;&#x5728;&#x7f16;&#x8bd1;&#x5668;&#x5185;&#x90e8;&#xff0c;&#x9047;&#x5230;&#x65f6;&#xff0c;&#x5b83;&#x5c31;&#x4f1a;&#x91cd;&#x65b0;&#x641c;&#x7d22;&#x6808;&#x4e2d;&#x662f;&#x5426;&#x6709;4&#x7684;&#x5b57;&#x9762;&#x503c;&#xff0c;&#x5982;&#x679c;&#x6ca1;&#x6709;&#xff0c;&#x91cd;&#x65b0;&#x5f00;&#x8f9f;&#x5730;&#x5740;&#x5b58;&#x653e;4&#x7684;&#x503c;&#xff1b;&#x5982;&#x679c;&#x5df2;&#x7ecf;&#x6709;&#x4e86;&#xff0c;&#x5219;&#x76f4;&#x63a5;&#x5c06;a&#x6307;&#x5411;&#x8fd9;&#x4e2a;&#x5730;&#x5740;&#x3002;&#x56e0;&#x6b64;a&#x503c;&#x7684;&#x6539;&#x53d8;&#x4e0d;&#x4f1a;&#x5f71;&#x54cd;&#x5230;b&#x7684;&#x503c;&#x3002;"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1489017149587" FOLDED="true" ID="ID_44614003" MODIFIED="1532056889098" TEXT="&#x5b57;&#x7b26;&#x4e32;&#x5e38;&#x91cf;&#x6c60;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1489018420613" ID="ID_788497325" MODIFIED="1489018459782" TEXT="&#x7ba1;&#x7406;&#x6574;&#x4e2a;&#x5e94;&#x7528;&#x4e2d;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x533a;&#x57df;,&#x9664;&#x4e86;new String() &#x7684;&#x5b57;&#x7b26;&#x4e32;&#x4ee5;&#x5916;,&#x6240;&#x4ee5;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x90fd;&#x5728;&#x8fd9;&#x91cc;&#x5b58;&#x653e;"/>
<node COLOR="#111111" CREATED="1489018465111" FOLDED="true" ID="ID_1216247061" MODIFIED="1532056889098" TEXT="&#x8303;&#x4f8b;1">
<node COLOR="#111111" CREATED="1489018468969" ID="ID_1512048985" MODIFIED="1498703795641" TEXT="String a = &quot;abc&quot;; &#x548c; String b = new  String(&quot;abc&quot;);&#x7684;&#x5730;&#x5740;&#x662f;&#x4e0d;&#x4e00;&#x6837;&#x7684;"/>
<node COLOR="#111111" CREATED="1489018507101" ID="ID_1505467690" MODIFIED="1489018512488" TEXT="a&#x5728;&#x5e38;&#x91cf;&#x6c60;"/>
<node COLOR="#111111" CREATED="1489018512940" ID="ID_1813080328" MODIFIED="1489018516500" TEXT="b&#x5728;&#x5185;&#x5b58;"/>
</node>
<node COLOR="#111111" CREATED="1531181644668" FOLDED="true" ID="ID_756878881" MODIFIED="1532056889098" TEXT="&#x6ce8;&#x610f;">
<node COLOR="#111111" CREATED="1531181647071" ID="ID_436269619" MODIFIED="1531181647071" TEXT="&#x5fc5;&#x987b;&#x8981;&#x5173;&#x6ce8;&#x7f16;&#x8bd1;&#x671f;&#x7684;&#x884c;&#x4e3a;&#xff0c;&#x624d;&#x80fd;&#x66f4;&#x597d;&#x7684;&#x7406;&#x89e3;&#x5e38;&#x91cf;&#x6c60;&#x3002;"/>
<node COLOR="#111111" CREATED="1531181647071" ID="ID_832510267" MODIFIED="1531181647071" TEXT="&#x8fd0;&#x884c;&#x65f6;&#x5e38;&#x91cf;&#x6c60;&#x4e2d;&#x7684;&#x5e38;&#x91cf;&#xff0c;&#x57fa;&#x672c;&#x6765;&#x6e90;&#x4e8e;&#x5404;&#x4e2a;class&#x6587;&#x4ef6;&#x4e2d;&#x7684;&#x5e38;&#x91cf;&#x6c60;&#x3002;"/>
<node COLOR="#111111" CREATED="1531181647071" ID="ID_1147890468" MODIFIED="1531181647071" TEXT="&#x7a0b;&#x5e8f;&#x8fd0;&#x884c;&#x65f6;&#xff0c;&#x9664;&#x975e;&#x624b;&#x52a8;&#x5411;&#x5e38;&#x91cf;&#x6c60;&#x4e2d;&#x6dfb;&#x52a0;&#x5e38;&#x91cf;(&#x6bd4;&#x5982;&#x8c03;&#x7528;intern&#x65b9;&#x6cd5;)&#xff0c;&#x5426;&#x5219;jvm&#x4e0d;&#x4f1a;&#x81ea;&#x52a8;&#x6dfb;&#x52a0;&#x5e38;&#x91cf;&#x5230;&#x5e38;&#x91cf;&#x6c60;"/>
</node>
<node COLOR="#111111" CREATED="1489149293680" FOLDED="true" ID="ID_1211214776" MODIFIED="1532056889098" TEXT="&#x8303;&#x4f8b;2">
<node COLOR="#111111" CREATED="1531181661053" ID="ID_496659043" LINK="https://www.cnblogs.com/dreamroute/p/5946272.html" MODIFIED="1531181881609">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre> 1 String s1 = &quot;Hello&quot;;
 2 String s2 = &quot;Hello&quot;;
 3 String s3 = &quot;Hel&quot; + &quot;lo&quot;;
 4 String s4 = &quot;Hel&quot; + new String(&quot;lo&quot;);
 5 String s5 = new String(&quot;Hello&quot;);
 6 String s6 = s5.intern();
 7 String s7 = &quot;H&quot;;
 8 String s8 = &quot;ello&quot;;
 9 String s9 = s7 + s8;
10           
11 System.out.println(s1 == s2);  // true
12 System.out.println(s1 == s3);  // true
13 System.out.println(s1 == s4);  // false
14 System.out.println(s1 == s9);  // false
15 System.out.println(s4 == s5);  // false
16 System.out.println(s1 == s6);  // true</pre>
  </body>
</html></richcontent>
</node>
<node COLOR="#111111" CREATED="1531181679220" ID="ID_423411974" MODIFIED="1531181679501" TEXT="String s3 = &quot;Hel&quot; + &quot;lo&quot;;&#x5728;class&#x6587;&#x4ef6;&#x4e2d;&#x88ab;&#x4f18;&#x5316;&#x6210;String s3 = &quot;Hello&quot;;&#xff0c;&#x6240;&#x4ee5;s1 == s3&#x6210;&#x7acb;&#x3002;"/>
<node COLOR="#111111" CREATED="1531181703063" ID="ID_1106569148" MODIFIED="1531181704120" TEXT=" s1 == s2&#x8fd9;&#x4e2a;&#x975e;&#x5e38;&#x597d;&#x7406;&#x89e3;&#xff0c;s1&#x3001;s2&#x5728;&#x8d4b;&#x503c;&#x65f6;&#xff0c;&#x5747;&#x4f7f;&#x7528;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x5b57;&#x9762;&#x91cf;&#xff0c;&#x8bf4;&#x767d;&#x8bdd;&#x70b9;&#xff0c;&#x5c31;&#x662f;&#x76f4;&#x63a5;&#x628a;&#x5b57;&#x7b26;&#x4e32;&#x5199;&#x6b7b;&#xff0c;&#x5728;&#x7f16;&#x8bd1;&#x671f;&#x95f4;&#xff0c;&#x8fd9;&#x79cd;&#x5b57;&#x9762;&#x91cf;&#x4f1a;&#x76f4;&#x63a5;&#x653e;&#x5165;class&#x6587;&#x4ef6;&#x7684;&#x5e38;&#x91cf;&#x6c60;&#x4e2d;&#xff0c;&#x4ece;&#x800c;&#x5b9e;&#x73b0;&#x590d;&#x7528;&#xff0c;&#x8f7d;&#x5165;&#x8fd0;&#x884c;&#x65f6;&#x5e38;&#x91cf;&#x6c60;&#x540e;&#xff0c;s1&#x3001;s2&#x6307;&#x5411;&#x7684;&#x662f;&#x540c;&#x4e00;&#x4e2a;&#x5185;&#x5b58;&#x5730;&#x5740;&#xff0c;&#x6240;&#x4ee5;&#x76f8;&#x7b49;&#x3002;"/>
<node COLOR="#111111" CREATED="1531181728704" ID="ID_871777348" MODIFIED="1531181729625" TEXT=" s1 == s9&#x4e5f;&#x4e0d;&#x76f8;&#x7b49;&#xff0c;&#x9053;&#x7406;&#x5dee;&#x4e0d;&#x591a;&#xff0c;&#x867d;&#x7136;s7&#x3001;s8&#x5728;&#x8d4b;&#x503c;&#x7684;&#x65f6;&#x5019;&#x4f7f;&#x7528;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x5b57;&#x9762;&#x91cf;&#xff0c;&#x4f46;&#x662f;&#x62fc;&#x63a5;&#x6210;s9&#x7684;&#x65f6;&#x5019;&#xff0c;s7&#x3001;s8&#x4f5c;&#x4e3a;&#x4e24;&#x4e2a;&#x53d8;&#x91cf;&#xff0c;&#x90fd;&#x662f;&#x4e0d;&#x53ef;&#x9884;&#x6599;&#x7684;&#xff0c;&#x7f16;&#x8bd1;&#x5668;&#x6bd5;&#x7adf;&#x662f;&#x7f16;&#x8bd1;&#x5668;&#xff0c;&#x4e0d;&#x53ef;&#x80fd;&#x5f53;&#x89e3;&#x91ca;&#x5668;&#x7528;&#xff0c;&#x6240;&#x4ee5;&#x4e0d;&#x505a;&#x4f18;&#x5316;&#xff0c;&#x7b49;&#x5230;&#x8fd0;&#x884c;&#x65f6;&#xff0c;s7&#x3001;s8&#x62fc;&#x63a5;&#x6210;&#x7684;&#x65b0;&#x5b57;&#x7b26;&#x4e32;&#xff0c;&#x5728;&#x5806;&#x4e2d;&#x5730;&#x5740;&#x4e0d;&#x786e;&#x5b9a;&#xff0c;&#x4e0d;&#x53ef;&#x80fd;&#x4e0e;&#x65b9;&#x6cd5;&#x533a;&#x5e38;&#x91cf;&#x6c60;&#x4e2d;&#x7684;s1&#x5730;&#x5740;&#x76f8;&#x540c;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1499817008002" FOLDED="true" ID="ID_542647697" MODIFIED="1532056889098" POSITION="left" TEXT="&#x6392;&#x5e8f;&#x7b97;&#x6cd5;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1499817017962" FOLDED="true" ID="ID_1407443536" MODIFIED="1532056889098" TEXT="&#x63d2;&#x5165;&#x6392;&#x5e8f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1499817057299" ID="ID_510493727" MODIFIED="1499817073237" TEXT="&#x524d;&#x9762;&#x7684;&#x5047;&#x5b9a;&#x90fd;&#x6392;&#x597d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1499902920258" FOLDED="true" ID="ID_196316698" MODIFIED="1532056889098" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1499902930918" ID="ID_54672521" MODIFIED="1499903012485">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <div align="left">
      <div>
        <font color="#7F0055" face="Consolas" size="22pt"><b>public</b></font>&#160;<font color="#7F0055" face="Consolas" size="22pt"><b>void</b></font><font face="Consolas" size="22pt">&#160;insertSort(</font><font color="#7F0055" face="Consolas" size="22pt"><b>int</b></font><font face="Consolas" size="22pt">[]</font>&#160; <font color="#6A3E3E" face="Consolas" size="22pt">array</font><font face="Consolas" size="22pt">) {</font>
      </div>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas" size="22pt"><b>int</b></font>&#160;<font color="#6A3E3E" face="Consolas" size="22pt">target</font><font face="Consolas" size="22pt">,</font>&#160; <font color="#6A3E3E" face="Consolas" size="22pt">j</font><font face="Consolas" size="22pt">;</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas" size="22pt"><b>for</b></font>&#160;<font face="Consolas" size="22pt">(</font><font color="#7F0055" face="Consolas" size="22pt"><b>int</b></font>&#160; <font color="#6A3E3E" face="Consolas" size="22pt">i</font>&#160;<font face="Consolas" size="22pt">= 0;</font>&#160;<font color="#6A3E3E" face="Consolas" size="22pt">i</font>&#160;<font face="Consolas" size="22pt">&lt;</font>&#160;<font color="#6A3E3E" face="Consolas" size="22pt">array</font><font face="Consolas" size="22pt">.</font><font color="#0000C0" face="Consolas" size="22pt">length</font><font face="Consolas" size="22pt">;</font>&#160; <font color="#6A3E3E" face="Consolas" size="22pt">i</font><font face="Consolas" size="22pt">++) {</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas" size="22pt">target</font>&#160;<font face="Consolas" size="22pt">=</font>&#160; <font color="#6A3E3E" face="Consolas" size="22pt">array</font><font face="Consolas" size="22pt">[</font><font color="#6A3E3E" face="Consolas" size="22pt">i</font><font face="Consolas" size="22pt">];</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas" size="22pt">j</font>&#160;<font face="Consolas" size="22pt">=</font>&#160; <font color="#6A3E3E" face="Consolas" size="22pt">i</font><font face="Consolas" size="22pt">;</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas" size="22pt"><b>while</b></font>&#160; <font face="Consolas" size="22pt">(</font><font color="#6A3E3E" face="Consolas" size="22pt">j</font>&#160;<font face="Consolas" size="22pt">&gt; 0 &amp;&amp;</font>&#160;<font color="#6A3E3E" face="Consolas" size="22pt">array</font><font face="Consolas" size="22pt">[</font><font color="#6A3E3E" face="Consolas" size="22pt">j</font>&#160;<font face="Consolas" size="22pt">- 1] &gt;</font>&#160;<font color="#6A3E3E" face="Consolas" size="22pt">target</font><font face="Consolas" size="22pt">) {</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas" size="22pt">array</font><font face="Consolas" size="22pt">[</font><font color="#6A3E3E" face="Consolas" size="22pt">j</font><font face="Consolas" size="22pt">] =</font>&#160;<font color="#6A3E3E" face="Consolas" size="22pt">array</font><font face="Consolas" size="22pt">[</font><font color="#6A3E3E" face="Consolas" size="22pt">j</font>&#160;<font face="Consolas" size="22pt">- 1];</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas" size="22pt">j</font><font face="Consolas" size="22pt">--;</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas" size="22pt">array</font><font face="Consolas" size="22pt">[</font><font color="#6A3E3E" face="Consolas" size="22pt">j</font><font face="Consolas" size="22pt">] =</font>&#160;<font color="#6A3E3E" face="Consolas" size="22pt">target</font><font face="Consolas" size="22pt">;</font>
    </div>
    <div align="left">
      <font face="Consolas" size="22pt">&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div align="left">
      <div>
        <font face="Consolas" size="22pt">&#160;&#160;&#160;}</font>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1499817023122" FOLDED="true" ID="ID_737208117" MODIFIED="1532056889098" TEXT="&#x5192;&#x6ce1;&#x6392;&#x5e8f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1499817036108" ID="ID_1605705540" MODIFIED="1499817055021" TEXT="&#x4e24;&#x4e24;&#x76f8;&#x6bd4;,&#x4ea4;&#x6362;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1499903101874" FOLDED="true" ID="ID_1567356807" MODIFIED="1532056889098" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1499903104067" ID="ID_1293171442" MODIFIED="1499924336385">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      
    </p>
    <div align="left">
      <font color="#7F0055" face="Consolas"><b>public</b></font>&#160;<font color="#7F0055" face="Consolas"><b>void</b></font>&#160;<font face="Consolas">doSort(</font><font color="#7F0055" face="Consolas"><b>int</b></font><font face="Consolas">[]</font>&#160; <font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">) {</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas"><b>int</b></font>&#160;<font color="#6A3E3E" face="Consolas">temp</font><font face="Consolas">;</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas"><b>for</b></font>&#160;<font face="Consolas">(</font><font color="#7F0055" face="Consolas"><b>int</b></font>&#160; <font color="#6A3E3E" face="Consolas">i</font>&#160;<font face="Consolas">= 0;</font>&#160;<font color="#6A3E3E" face="Consolas">i</font>&#160;<font face="Consolas">&lt;</font>&#160;<font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">.</font><font color="#0000C0" face="Consolas">length</font><font face="Consolas">;</font>&#160; <font color="#6A3E3E" face="Consolas">i</font><font face="Consolas">++) {</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas"><b>for</b></font>&#160; <font face="Consolas">(</font><font color="#7F0055" face="Consolas"><b>int</b></font>&#160;<font color="#6A3E3E" face="Consolas">j</font>&#160;<font face="Consolas">= 0;</font>&#160;<font color="#6A3E3E" face="Consolas">j</font>&#160;<font face="Consolas">&lt;</font>&#160; <font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">.</font><font color="#0000C0" face="Consolas">length-1</font><font face="Consolas">;</font>&#160;<font color="#6A3E3E" face="Consolas">j</font><font face="Consolas">++) {</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#7F0055" face="Consolas"><b>if</b></font>&#160; <font face="Consolas">(</font><font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">[j] &gt;</font>&#160;<font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">[</font><font color="#6A3E3E" face="Consolas">j+1</font><font face="Consolas">]) {</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas">temp</font>&#160; <font face="Consolas">=</font>&#160;<font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">[j];</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">[j] =</font>&#160;<font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">[</font><font color="#6A3E3E" face="Consolas">j+1</font><font face="Consolas">];</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;</font><font color="#6A3E3E" face="Consolas">array</font><font face="Consolas">[</font><font color="#6A3E3E" face="Consolas">j+1</font><font face="Consolas">] =</font>&#160;<font color="#6A3E3E" face="Consolas">temp</font><font face="Consolas">;</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div align="left">
      <font face="Consolas">&#160;&#160;&#160;&#160;&#160;&#160;}</font>
    </div>
    <div align="left">
      <div>
        <font face="Consolas">&#160;&#160;&#160;}</font>
      </div>
    </div>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1499899357286" FOLDED="true" ID="ID_225919795" MODIFIED="1532056889098" TEXT="&#x9009;&#x62e9;&#x6392;&#x5e8f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1499899447209" FOLDED="true" ID="ID_1445133745" MODIFIED="1532056889098" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1499899448147" ID="ID_871543943" MODIFIED="1499899448148" TEXT="&#x5c31;&#x662f;&#x76f4;&#x63a5;&#x4ece;&#x5f85;&#x6392;&#x5e8f;&#x6570;&#x7ec4;&#x91cc;&#x9009;&#x62e9;&#x4e00;&#x4e2a;&#x6700;&#x5c0f;(&#x6216;&#x6700;&#x5927;)&#x7684;&#x6570;&#x5b57;,&#x6bcf;&#x6b21;&#x90fd;&#x62ff;&#x4e00;&#x4e2a;&#x6700;&#x5c0f;&#x6570;&#x5b57;&#x51fa;&#x6765;,"/>
<node COLOR="#111111" CREATED="1499899448151" ID="ID_1689279092" MODIFIED="1499899448151" TEXT="&#x987a;&#x5e8f;&#x653e;&#x5165;&#x65b0;&#x6570;&#x7ec4;,&#x76f4;&#x5230;&#x5168;&#x90e8;&#x62ff;&#x5b8c;"/>
</node>
<node COLOR="#990000" CREATED="1499899422680" ID="ID_1929750981" MODIFIED="1499902934864">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33539;&#20363;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1513156315545" FOLDED="true" ID="ID_1841591020" MODIFIED="1532056889098" POSITION="left" TEXT="&#x6ce8;&#x91ca;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1513156318872" ID="ID_45901042" MODIFIED="1513156332309" TEXT="{@link &#x7c7b;&#x7684;&#x5168;&#x8def;&#x5f84;}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1513156332961" ID="ID_480414575" MODIFIED="1513156340029" TEXT="{@see &#x7c7b;&#x7684;&#x5168;&#x8def;&#x5f84;}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1513156499856" FOLDED="true" ID="ID_1056093104" MODIFIED="1532056889098" TEXT="&#x8303;&#x4f8b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1513156503913" ID="ID_1009210100" MODIFIED="1513156507784">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 15.0pt"><font color="#808080"><i>/**<br /> *<b>@see </b>com.hc.ems.constants.PushConstants<br /> * <b>@param </b></i></font><i><b><font color="#3d3d3d">id </font></b><font color="#808080" face="&#x5b8b;&#x4f53;">&#38656;&#35201;&#36339;&#36716;&#30340;&#36164;&#28304;&#30340;</font><font color="#808080">id<br /> * <b>@param </b></font><b><font color="#3d3d3d">link_type </font></b><font color="#808080" face="&#x5b8b;&#x4f53;">&#36339;&#36716;&#30340;&#31867;&#22411; </font><font color="#808080">{<b>@link </b>com.hc.ems.constants.PushConstants}<br /> * <b>@param </b></font><b><font color="#3d3d3d">msg </font></b><font color="#808080" face="&#x5b8b;&#x4f53;">&#28040;&#24687;<br /> </font><font color="#808080">* <b>@param </b></font><b><font color="#3d3d3d">toAccounts </font></b><font color="#808080" face="&#x5b8b;&#x4f53;">&#32473;&#21738;&#20123;&#20154;&#21457;&#28040;&#24687;&#30340;&#20154;&#30340; </font><font color="#808080">TimIdentifier<br /> * <b>@param </b></font><b><font color="#3d3d3d">fromAccount </font></b><font color="#808080" face="&#x5b8b;&#x4f53;">&#28040;&#24687;&#30340;&#21457;&#36865;&#26041; </font><font color="#808080">{<b>@link </b>com.hc.ems.module.mq.constants.MqConstants#FROM_ANNOUNCEMENT </font><font color="#808080" face="&#x5b8b;&#x4f53;">&#31561;</font><font color="#808080">}<br /> * <b>@param </b></font><b><font color="#3d3d3d">body </font></b><font color="#808080">Tim </font><font color="#808080" face="&#x5b8b;&#x4f53;">&#28040;&#24687;&#20307;&#20013;&#30340; </font><font color="#808080">Data</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#23383;&#27573;&#30340;&#25968;&#25454;<br /> </font><font color="#808080">* <b>@return </b></font><font color="#808080" face="&#x5b8b;&#x4f53;">&#19968;&#20010;</font><font color="#808080">MQ</font><font color="#808080" face="&#x5b8b;&#x4f53;">&#30340;&#28040;&#24687;<br /> </font><font color="#808080">*/<br /></font></i><font color="#000080"><b>private static </b></font>JSONObject innerGetNoticeAll(String id, <font color="#000080"><b>int </b></font>link_type,<br />                                 String msg, JSONArray toAccounts,<br />                                 String fromAccount, JSONObject body){<br />   JSONObject data = <font color="#000080"><b>new </b></font>JSONObject();<br />   data.put(<font color="#008000"><b>&quot;fromAccount&quot;</b></font>, fromAccount);<font color="#808080"><i>//</i></font><i><font color="#808080" face="&#x5b8b;&#x4f53;">&#25103;&#32536;&#31649;&#29702;&#21592;&#24080;&#21495;<br />   </font></i>data.put(<font color="#008000"><b>&quot;toAccounts&quot;</b></font>, toAccounts);<br />   data.put(<font color="#008000"><b>&quot;type&quot;</b></font>, link_type);<br />   body.put(<font color="#008000"><b>&quot;tips&quot;</b></font>, msg);<br />   body.put(<font color="#008000"><b>&quot;id&quot;</b></font>, id);<br />   data.put(<font color="#008000"><b>&quot;body&quot;</b></font>, body);<br />   <font color="#000080"><b>return </b></font>data;<br />}</pre>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1519467673574" ID="ID_1983974" LINK="java&#x7f16;&#x7a0b;&#x89c4;&#x8303;.pdf" MODIFIED="1519467765043" POSITION="left" TEXT="&#x7f16;&#x7a0b;&#x89c4;&#x8303;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1472387066342" FOLDED="true" ID="79l7cp0b3q1tne6iv12on3irg0" MODIFIED="1532056889098" POSITION="right" TEXT="&#x63a7;&#x5236;&#x6d41;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_1302890584" MODIFIED="1532056889098" TEXT="&#x9009;&#x62e9;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_1902237171" MODIFIED="1472778412251" TEXT="if()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_1017635178" MODIFIED="1472778412251" TEXT="if ()- else">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_1408421101" MODIFIED="1472778412251" TEXT="if ()- else if()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_602178812" MODIFIED="1472778412251" TEXT="if() -else if() - else()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1006165778" MODIFIED="1532056889098" TEXT="switch ()- case">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1796792376" MODIFIED="1532056889098" TEXT="&#x53ef;&#x4ee5;&#x64cd;&#x4f5c;&#x7684;&#x7c7b;&#x578b;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_220951807" MODIFIED="1472778412267" TEXT="char"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_748930456" MODIFIED="1472778412267" TEXT="byte"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_201730618" MODIFIED="1472778412267" TEXT="short"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_181570187" MODIFIED="1472778412267" TEXT="int"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1625890632" MODIFIED="1472778412267" TEXT="String"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1645643879" MODIFIED="1472778412267" TEXT="enum"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_706659144" MODIFIED="1472778412267" TEXT="Character"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1123058804" MODIFIED="1472778412267" TEXT="Byte"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1611458385" MODIFIED="1472778412267" TEXT="Short"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1047140129" MODIFIED="1472778412267" TEXT="Integer"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_667632004" MODIFIED="1532056889098" TEXT="&#x6ce8;&#x610f;&#xff1a;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_203389575" MODIFIED="1472778412267" TEXT="&#x4e00;&#x5b9a;&#x4e0d;&#x8981;&#x5fd8;&#x4e86;break;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_709695836" MODIFIED="1472778412267" TEXT="&#x5982;&#x679c;&#x6ca1;&#x6709;break; &#x5219;&#x4f1a;&#x7ee7;&#x7eed;&#x6267;&#x884c;&#x540e;&#x9762;&#x7684;case&#xff0c;&#x76f4;&#x5230;&#x9047;&#x5230;break&#x4e3a;&#x6b62;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_1515962579" MODIFIED="1532056889098" TEXT="&#x5faa;&#x73af;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1116589070" MODIFIED="1532056889098" TEXT="for( ){}">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_14120272" MODIFIED="1472778412267" TEXT="&#x7528;&#x6765;&#x5904;&#x7406;&#x786e;&#x5b9a;&#x5faa;&#x73af;&#x6570;&#x91cf;&#x7684;&#x64cd;&#x4f5c;"/>
<node COLOR="#111111" CREATED="1531649017726" FOLDED="true" ID="ID_289265223" MODIFIED="1532056889098" TEXT="&#x83f1;&#x5f62;">
<node COLOR="#111111" CREATED="1531649023986" ID="ID_1138647293" MODIFIED="1531649073178">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 15.0pt"><font color="#000080"><b>int </b></font>height = <font color="#0000ff">3</font>, diff = <font color="#0000ff">1</font>, blank = height * diff - <font color="#0000ff">1 </font>+ <font color="#0000ff">10</font>;<br /><font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>level = <font color="#0000ff">0</font>; level &lt; height; level++) {<br />&#160;&#160;&#160; <font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>i = <font color="#0000ff">0</font>; i &lt; blank; i++) {<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.<font color="#660e7a"><b><i>out</i></b></font>.print(<font color="#008000"><b>&quot; &quot;</b></font>);<br />&#160;&#160;&#160;&#160;}<br />&#160;&#160;&#160;&#160;blank -= diff;<br />&#160;&#160;&#160; <font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>i = <font color="#0000ff">0</font>; i &lt; <font color="#0000ff">2 </font>* diff * level + <font color="#0000ff">1</font>; i++) {<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.<font color="#660e7a"><b><i>out</i></b></font>.print(<font color="#008000"><b>&quot;*&quot;</b></font>);<br />&#160;&#160;&#160;&#160;}<br />&#160;&#160;&#160;&#160;System.<font color="#660e7a"><b><i>out</i></b></font>.println();<br />}
// &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;   &#160;&#160;&gt;=0 &#34920;&#31034;&#22810;&#25171;&#21360;&#19968;&#23618;&#160;&#160;&#160;&#160;&#160;&#160; <br /><font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>level = height; level &gt;= <font color="#0000ff">0</font>; level--) {<br />&#160;&#160;&#160; <font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>i = <font color="#0000ff">0</font>; i &lt; blank; i++) {<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.<font color="#660e7a"><b><i>out</i></b></font>.print(<font color="#008000"><b>&quot; &quot;</b></font>);<br />&#160;&#160;&#160;&#160;}<br />&#160;&#160;&#160;&#160;blank += diff;<br />&#160;&#160;&#160; <font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>i = <font color="#0000ff">2 </font>* diff * level + <font color="#0000ff">1</font>; i &gt; <font color="#0000ff">0</font>; i--) {<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.<font color="#660e7a"><b><i>out</i></b></font>.print(<font color="#008000"><b>&quot;*&quot;</b></font>);<br />&#160;&#160;&#160;&#160;}<br />&#160;&#160;&#160;&#160;System.<font color="#660e7a"><b><i>out</i></b></font>.println();<br />}</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1531649439667" FOLDED="true" ID="ID_1058585610" MODIFIED="1532056889098" TEXT="&#x9636;&#x4e58;">
<node COLOR="#111111" CREATED="1531649443507" ID="ID_410838749" MODIFIED="1531649446111">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 15.0pt"><font color="#000080"><b>int </b></font>fac = <font color="#0000ff">1</font>;<br /><font color="#000080"><b>int </b></font>all = <font color="#0000ff">0</font>;<br /><font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>i = <font color="#0000ff">1</font>; i &lt;= <font color="#0000ff">10</font>; i++) {<br />    fac *= i;<br />    all += fac;<br />}</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1531649600868" FOLDED="true" ID="ID_1670003544" MODIFIED="1532056889098" TEXT="&#x8ba1;&#x7b97;&#x5956;&#x91d1;">
<node COLOR="#111111" CREATED="1531649605069" FOLDED="true" ID="ID_1410996392" MODIFIED="1532056889098">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20195;&#30721;
    </p>
  </body>
</html></richcontent>
<node COLOR="#111111" CREATED="1531649610870" ID="ID_358418185" MODIFIED="1531649612947">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 15.0pt"><font color="#000080"><b>private static void </b></font>bonus() {<br /><br />    Scanner scanner = <font color="#000080"><b>new </b></font>Scanner(System.<font color="#660e7a"><b><i>in</i></b></font>);<br />    <font color="#000080"><b>while </b></font>(<font color="#000080"><b>true</b></font>) {<br />        <font color="#000080"><b>float </b></font>bonus = <font color="#0000ff">0</font>;<br />        System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;</b></font><b><font color="#008000" face="&#x5b8b;&#x4f53;">&#35831;&#36755;&#20837;&#21033;&#28070;</font><font color="#008000">: &quot;</font></b>);<br />        <font color="#000080"><b>float </b></font>profit = scanner.nextInt();<br />        <font color="#000080"><b>if </b></font>(profit &gt; <font color="#0000ff">100</font>) {<br />            bonus += (profit - <font color="#0000ff">100</font>) * <font color="#0000ff">0.01f</font>;<br />            profit = <font color="#0000ff">100</font>;<br />        }<br /><br />        <font color="#000080"><b>if </b></font>(profit &gt; <font color="#0000ff">60 </font>&amp;&amp; profit &lt;= <font color="#0000ff">100</font>) {<br />            bonus += (profit - <font color="#0000ff">60</font>) * <font color="#0000ff">0.015f</font>;<br />            profit = <font color="#0000ff">60</font>;<br />        }<br /><br />        <font color="#000080"><b>if </b></font>(profit &gt; <font color="#0000ff">40 </font>&amp;&amp; profit &lt;= <font color="#0000ff">60</font>) {<br />            bonus += (profit - <font color="#0000ff">40</font>) * <font color="#0000ff">0.03f</font>;<br />            profit = <font color="#0000ff">40</font>;<br />        }<br />        <font color="#000080"><b>if </b></font>(profit &gt; <font color="#0000ff">20 </font>&amp;&amp; profit &lt;= <font color="#0000ff">40</font>) {<br />            bonus += (profit - <font color="#0000ff">20</font>) * <font color="#0000ff">0.05f</font>;<br />            profit = <font color="#0000ff">20</font>;<br />        }<br />        <font color="#000080"><b>if </b></font>(profit &gt; <font color="#0000ff">10 </font>&amp;&amp; profit &lt;= <font color="#0000ff">20</font>) {<br />            bonus += (profit - <font color="#0000ff">10</font>) * <font color="#0000ff">0.075f</font>;<br />            profit = <font color="#0000ff">10</font>;<br />        }<br />        <font color="#000080"><b>if </b></font>(profit &lt;= <font color="#0000ff">10</font>) {<br />            bonus += profit * <font color="#0000ff">0.1f</font>;<br />        }<br /><br />        System.<font color="#660e7a"><b><i>out</i></b></font>.println(<font color="#008000"><b>&quot;</b></font><b><font color="#008000" face="&#x5b8b;&#x4f53;">&#20320;&#21487;&#33719;&#24471;&#30340;&#22870;&#37329;&#20026;</font><font color="#008000">: &quot; </font></b>+ bonus * <font color="#0000ff">10000 </font>+ <font color="#008000"><b>&quot;</b></font><b><font color="#008000" face="&#x5b8b;&#x4f53;">&#20803;</font><font color="#008000">&quot;</font></b>);<br />    }<br />}</pre>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#111111" CREATED="1531649622759" FOLDED="true" ID="ID_1782273576" MODIFIED="1532056889098" TEXT="&#x95ee;&#x9898;">
<node COLOR="#111111" CREATED="1531649625581" ID="ID_1903476696" MODIFIED="1531649628071">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20225;&#19994;&#21457;&#25918;&#30340;&#22870;&#37329;&#26681;&#25454;&#21033;&#28070;&#25552;&#25104;&#12290;&#21033;&#28070;(I)&#20302;&#20110;&#25110;&#31561;&#20110;10&#19975;&#20803;&#26102;&#65292;&#22870;&#37329;&#21487;&#25552;10%&#65307;
    </p>
    <p>
      &#21033;&#28070;&#39640;&#20110;10&#19975;&#20803;&#65292;&#20302;&#20110;20&#19975;&#20803;&#26102;&#65292;&#20302;&#20110;10&#19975;&#20803;&#30340;&#37096;&#20998;&#25353;10%&#25552;&#25104;&#65292;&#39640;&#20110;10&#19975;&#20803;&#30340;&#37096;&#20998;&#65292;
    </p>
    <p>
      &#21487;&#21487;&#25552;&#25104;7.5%&#65307;20&#19975;&#21040;40&#19975;&#20043;&#38388;&#26102;&#65292;&#39640;&#20110;20&#19975;&#20803;&#30340;&#37096;&#20998;&#65292;&#21487;&#25552;&#25104;5%&#65307;40&#19975;&#21040;60&#19975;&#20043;&#38388;&#26102;&#39640;&#20110;40&#19975;&#20803;&#30340;&#37096;&#20998;&#65292;
    </p>
    <p>
      &#21487;&#25552;&#25104;3%&#65307;60&#19975;&#21040;100&#19975;&#20043;&#38388;&#26102;&#65292;&#39640;&#20110;60&#19975;&#20803;&#30340;&#37096;&#20998;&#65292;&#21487;&#25552;&#25104;1.5%&#65292;&#39640;&#20110;100&#19975;&#20803;&#26102;&#65292;&#36229;&#36807;100&#19975;&#20803;&#30340;&#37096;&#20998;&#25353;1%&#25552;&#25104;&#65292;
    </p>
    <p>
      &#20174;&#38190;&#30424;&#36755;&#20837;&#24403;&#26376;&#21033;&#28070;I&#65292;&#27714;&#24212;&#21457;&#25918;&#22870;&#37329;&#24635;&#25968;&#65311;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1531652868160" FOLDED="true" ID="ID_91953432" MODIFIED="1532056889098" TEXT="&#x6253;&#x5370;&#x8272;&#x503c;">
<node COLOR="#111111" CREATED="1531652873404" ID="ID_1112516820" MODIFIED="1531652898994">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre style="background-color: #ffffff; color: #000000; font-family: Consolas; font-size: 15.0pt"><font color="#000080"><b>//%x&#29992;&#20110;&#26684;&#24335;&#21270;16&#36827;&#21046;&#25972;&#25968;
for </b></font>(<font color="#000080"><b>int </b></font>i = <font color="#0000ff">0</font>; i &lt;= <font color="#0000ff">255</font>; i++) {<br />&#160;&#160;&#160; <font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>j = <font color="#0000ff">0</font>; j &lt;= <font color="#0000ff">255</font>; j++) {<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160; <font color="#000080"><b>for </b></font>(<font color="#000080"><b>int </b></font>k = <font color="#0000ff">0</font>; k &lt;= <font color="#0000ff">255</font>; k++) {<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;System.<font color="#660e7a"><b><i>out</i></b></font>.println(String.<i>format</i>(<font color="#008000"><b>&quot;#%x%x%x&quot;</b></font>, i, j, k));<br />&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;}<br />&#160;&#160;&#160;&#160;}<br />}</pre>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_223496958" MODIFIED="1472778412267" TEXT="foreach(){}">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_321490408" MODIFIED="1472778412267" TEXT="while(){}">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_571774107" MODIFIED="1472778412267" TEXT="do{}-while()">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_169346159" MODIFIED="1532056889098" TEXT="&#x6ce8;&#x610f;&#x6807;&#x7b7e; &quot;label&quot;&#xff1a; &#x7684;&#x4f7f;&#x7528;  p71">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="bookmark"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1747638415" MODIFIED="1472778412267" TEXT="break &#x548c;continue&#x6807;&#x7b7e;&#x901a;&#x5e38;&#x53ea;&#x662f;&#x4e2d;&#x65ad;&#x5f53;&#x524d;&#x5faa;&#x73af;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1911400287" MODIFIED="1472778412267" TEXT="&#x4f46;&#x5982;&#x679c;&#x548c; &#x6807;&#x7b7e;&#x4e00;&#x8d77;&#x4f7f;&#x7528;&#x5219;&#x4f1a;&#x4e2d;&#x65ad;&#x5faa;&#x73af;&#xff0c;&#x76f4;&#x5230;&#x6807;&#x7b7e;&#x6240;&#x5728;&#x7684;&#x5730;&#x65b9;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1488889628720" FOLDED="true" ID="ID_769963136" MODIFIED="1532056889098" POSITION="left" TEXT="&#x5f02;&#x5e38;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1488889669597" FOLDED="true" ID="ID_370027860" MODIFIED="1532056889098" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488889768571" ID="ID_608656540" MODIFIED="1488889779675" TEXT="&#x7a0b;&#x5e8f;&#x4e2d;&#x7684;&#x9519;&#x8bef;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488889811857" ID="ID_654112" MODIFIED="1488889832935" TEXT="&#x80fd;&#x591f;&#x963b;&#x6b62;&#x7a0b;&#x5e8f;&#x6b63;&#x5e38;&#x8fd0;&#x884c;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488893732041" ID="ID_1147759051" MODIFIED="1488893739965" TEXT="&#x5f02;&#x5e38;&#x4e5f;&#x662f;&#x7c7b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1488890687101" FOLDED="true" ID="ID_1781889652" MODIFIED="1532056889098" TEXT="&#x5f02;&#x5e38;&#x5206;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488890783629" FOLDED="true" ID="ID_1034551523" MODIFIED="1532056889098" TEXT="Throwable">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488890788068" FOLDED="true" ID="ID_24079277" MODIFIED="1532056889098" TEXT="Error">
<node COLOR="#111111" CREATED="1488891547498" ID="ID_1690559088" MODIFIED="1516855640486" TEXT="&#x901a;&#x5e38;&#x662f;&#x7cfb;&#x7edf;&#x9519;&#x8bef;"/>
<node COLOR="#111111" CREATED="1488890837144" ID="ID_263481203" MODIFIED="1488890851722" TEXT="&#x4e25;&#x91cd;&#x7684;&#x9519;&#x8bef;,&#x65e0;&#x6cd5;&#x901a;&#x8fc7;&#x6355;&#x83b7;&#x6765;&#x89e3;&#x51b3;"/>
<node COLOR="#111111" CREATED="1488891573075" ID="ID_598741309" MODIFIED="1488891587018" TEXT="&#x8be5;&#x4e2d;&#x9519;&#x8bef;&#x7a0b;&#x5e8f;&#x5458;&#x4e0d;&#x5fc5;&#x5173;&#x5fc3;"/>
</node>
<node COLOR="#111111" CREATED="1488890791768" FOLDED="true" ID="ID_279220519" MODIFIED="1532056889098" TEXT="Exception">
<node COLOR="#111111" CREATED="1488891068827" FOLDED="true" ID="ID_635592499" MODIFIED="1532056889098" TEXT="&#x7f16;&#x8bd1;&#x65f6;&#x5f02;&#x5e38;(Java.lang.Exception)&#xff1a;">
<node COLOR="#111111" CREATED="1488892016637" ID="ID_545972275" MODIFIED="1488892041861" TEXT="&#x5728;&#x7f16;&#x5199;&#x4ee3;&#x7801;&#x7f16;&#x8f91;&#x5668;&#x4f1a;&#x63d0;&#x793a;&#x62a5;&#x9519;&#x7684;&#x5f02;&#x5e38;"/>
</node>
<node COLOR="#111111" CREATED="1488891305279" FOLDED="true" ID="ID_1894008683" MODIFIED="1532056889098" TEXT="&#x8fd0;&#x884c;&#x671f;&#x5f02;&#x5e38;(Java.lang.RuntimeException)">
<node COLOR="#111111" CREATED="1488891839455" FOLDED="true" ID="ID_418135016" MODIFIED="1532056889098" TEXT="&#x5e38;&#x89c1;&#x5f02;&#x5e38;">
<node COLOR="#111111" CREATED="1488891845747" FOLDED="true" ID="ID_946228402" MODIFIED="1532056889098" TEXT="NullPointerException">
<node COLOR="#111111" CREATED="1488892109508" ID="ID_1007092561" MODIFIED="1488892109508" TEXT="&#x7a7a;&#x6307;&#x9488;&#x5f02;&#x5e38;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1488892091171" FOLDED="true" ID="ID_511513179" MODIFIED="1532056889098" TEXT="NumberFormatException">
<node COLOR="#111111" CREATED="1488892099595" ID="ID_1030058121" MODIFIED="1488892099595" TEXT="&#x5b57;&#x7b26;&#x4e32;&#x8f6c;&#x6362;&#x4e3a;&#x6570;&#x5b57;&#x5f02;&#x5e38;"/>
</node>
<node COLOR="#111111" CREATED="1488891850518" FOLDED="true" ID="ID_561789797" MODIFIED="1532056889098" TEXT="ArrayIndexOutOfBoundsException">
<node COLOR="#111111" CREATED="1488892154366" ID="ID_1271092387" MODIFIED="1488892154366" TEXT="&#x6570;&#x7ec4;&#x4e0b;&#x6807;&#x8d8a;&#x754c;&#x5f02;&#x5e38;"/>
</node>
<node COLOR="#111111" CREATED="1488892115420" FOLDED="true" ID="ID_1407688140" MODIFIED="1532056889098" TEXT="ArithmeticExecption">
<node COLOR="#111111" CREATED="1488892119317" ID="ID_125544346" MODIFIED="1488892121972" TEXT="&#x7b97;&#x672f;&#x5f02;&#x5e38;&#x7c7b;"/>
</node>
<node COLOR="#111111" CREATED="1488891894743" FOLDED="true" ID="ID_1336708122" MODIFIED="1532056889098" TEXT="ClassCastException">
<node COLOR="#111111" CREATED="1488892149163" ID="ID_233703548" MODIFIED="1488892149163" TEXT="&#x7c7b;&#x578b;&#x5f3a;&#x5236;&#x8f6c;&#x6362;&#x5f02;&#x5e38;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1488891341288" ID="ID_1067623352" MODIFIED="1488891341289" TEXT="&#x7a0b;&#x5e8f;&#x5b58;&#x5728;bug&#xff0c;&#x5982;&#x6570;&#x7ec4;&#x8d8a;&#x754c;&#xff0c;0&#x88ab;&#x9664;&#xff0c;&#x5165;&#x53c2;&#x4e0d;&#x6ee1;&#x8db3;&#x89c4;&#x8303;.....&#x8fd9;&#x7c7b;&#x5f02;&#x5e38;&#x9700;&#x8981;&#x66f4;&#x6539;&#x7a0b;&#x5e8f;&#x6765;&#x907f;&#x514d;&#xff0c;Java&#x7f16;&#x8bd1;&#x5668;&#x5f3a;&#x5236;&#x8981;&#x6c42;&#x5904;&#x7406;&#x8fd9;&#x7c7b;&#x5f02;&#x5e38;&#x3002;"/>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1488889881173" FOLDED="true" ID="ID_993248923" MODIFIED="1532056889098" TEXT="&#x6355;&#x83b7;&#x5f02;&#x5e38;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488889961830" FOLDED="true" ID="ID_967696423" MODIFIED="1532056889098" TEXT="&#x8bed;&#x6cd5;&#x7ed3;&#x6784;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488889889993" ID="ID_1447126973" MODIFIED="1493775001738">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      try{&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    </p>
    <p>
      &#160;}catch(Exeption e){&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    </p>
    <p>
      
    </p>
    <p>
      }&#160;&#160;&#26469;&#25429;&#33719;
    </p>
  </body>
</html></richcontent>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1488889970368" ID="ID_1502358312" MODIFIED="1488890026418" TEXT="&#x5f53;&#x7a0b;&#x5e8f;&#x4e2d;&#x51fa;&#x73b0;&#x9519;&#x8bef;&#x65f6;,&#x53ef;&#x4ee5;&#x4f7f;&#x7528;try&#x6765;&#x6355;&#x83b7;&#x5f02;&#x5e38;&#x5e76;&#x4e14;&#x5904;&#x7406;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1488890102055" FOLDED="true" ID="ID_541397710" MODIFIED="1532056889098" TEXT="finally&#x5173;&#x952e;&#x5b57;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488890111791" FOLDED="true" ID="ID_1014624740" MODIFIED="1532056889098" TEXT="?">
<node COLOR="#111111" CREATED="1488890119227" ID="ID_841088902" MODIFIED="1488890161678" TEXT="&#x8868;&#x793a;&#x6700;&#x7ec8;&#x5730;,&#x5728;&#x5f02;&#x5e38;&#x4e2d;&#x4ee3;&#x8868;&#x6700;&#x7ec8;&#x4f1a;&#x88ab;&#x6267;&#x884c;&#x7684;&#x4ee3;&#x7801;&#x533a;&#x57df;"/>
</node>
<node COLOR="#111111" CREATED="1488890164681" FOLDED="true" ID="ID_905594306" MODIFIED="1532056889098" TEXT="&#x4f7f;&#x7528;">
<node COLOR="#111111" CREATED="1488890171845" ID="ID_1779358534" MODIFIED="1488890212811" TEXT="try{          }catch(Exeption e){     }finally{     &#x8fd9;&#x91cc;&#x7684;&#x4ee3;&#x7801;&#x6700;&#x7ec8;&#x4f1a;&#x88ab;&#x6267;&#x884c;}"/>
</node>
<node COLOR="#111111" CREATED="1488890226138" FOLDED="true" ID="ID_1817565175" MODIFIED="1532056889098" TEXT="&#x601d;&#x8003;">
<node COLOR="#111111" CREATED="1488890253301" ID="ID_1261498515" MODIFIED="1488890283208" TEXT="&#x5982;&#x679c;&#x5728;catch&#x5757;&#x4e2d;&#x6267;&#x884c;return &#x4f1a;&#x600e;&#x6837;?"/>
<node COLOR="#111111" CREATED="1488890286108" ID="ID_1892375561" MODIFIED="1495161032366" TEXT="&#x4f8b;&#x5982;: &#xa;public String get(){ &#xa; try{ &#xa;   ....&#x8fd9;&#x91cc;&#x662f;&#x4ee3;&#x7801;  &#xa;    return &quot;haha&quot;;  &#xa;  }catch(Exeption e){ &#xa;    System.out.println(e.getMessage());&#xa; }finally{  &#xa;   System.out.println(&quot;=====haha======&quot;);&#xa; }&#xa;}"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1488892321342" FOLDED="true" ID="ID_1175557247" MODIFIED="1532056889098" TEXT="throw&#x548c;throws&#x5173;&#x952e;&#x5b57;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1488892333920" FOLDED="true" ID="ID_1429276269" MODIFIED="1532056889098" TEXT="throw">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488892427367" ID="ID_320372964" MODIFIED="1488892436842" TEXT="throw&#x603b;&#x662f;&#x51fa;&#x73b0;&#x5728;&#x51fd;&#x6570;&#x4f53;&#x4e2d;&#xff0c;&#x7528;&#x6765;&#x629b;&#x51fa;&#x4e00;&#x4e2a;&#x5f02;&#x5e38;&#x3002;"/>
<node COLOR="#111111" CREATED="1488892438137" ID="ID_1296581399" MODIFIED="1488892485328" TEXT="&#x7a0b;&#x5e8f;&#x4f1a;&#x5728;throw&#x8bed;&#x53e5;&#x540e;&#x7acb;&#x5373;&#x7ec8;&#x6b62;&#xff0c;&#x5b83;&#x540e;&#x9762;&#x7684;&#x8bed;&#x53e5;&#x6267;&#x884c;&#x4e0d;&#x5230;"/>
<node COLOR="#111111" CREATED="1488892695054" FOLDED="true" ID="ID_1703369588" MODIFIED="1532056889098" TEXT="&#x6bd4;&#x5982;:">
<node COLOR="#111111" CREATED="1488892700342" ID="ID_1404315123" MODIFIED="1488892732851" TEXT="throw new NullPointerException(&quot;Error,&#x7a7a;&#x6307;&#x9488;!&quot;);"/>
</node>
</node>
<node COLOR="#990000" CREATED="1488892336019" FOLDED="true" ID="ID_101363279" MODIFIED="1532056889098" TEXT="throws">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488892498844" ID="ID_1081453017" MODIFIED="1488892508508" TEXT="throws&#x603b;&#x662f;&#x51fa;&#x73b0;&#x5728;&#x4e00;&#x4e2a;&#x51fd;&#x6570;&#x5934;&#x4e2d;&#xff0c;&#x7528;&#x6765;&#x6807;&#x660e;&#x8be5;&#x6210;&#x5458;&#x51fd;&#x6570;&#x53ef;&#x80fd;&#x629b;&#x51fa;&#x7684;&#x5404;&#x79cd;&#x5f02;&#x5e38;&#x3002;"/>
<node COLOR="#111111" CREATED="1488892509648" ID="ID_1060880250" MODIFIED="1488892586614" TEXT="&#x4f60;&#x53ef;&#x4ee5;&#x7528;throws&#x8bed;&#x53e5;&#x5728;&#x51fd;&#x6570;&#x540d;&#x540e;&#x9762;&#x6765;&#x58f0;&#x660e;&#x5b83;&#x7684;&#x7c7b;&#x578b;&#x3002;"/>
<node COLOR="#111111" CREATED="1488892590965" FOLDED="true" ID="ID_10968975" MODIFIED="1532056889098" TEXT="&#x6bd4;&#x5982;">
<node COLOR="#111111" CREATED="1488892652620" ID="ID_947047040" MODIFIED="1488892688119" TEXT="protected void doGet(HttpServletRequest request, &#xa;HttpServletResponse response) throws ServletException, IOException { &#x9;&#xa;&#x9;}"/>
</node>
</node>
<node COLOR="#990000" CREATED="1488892979810" FOLDED="true" ID="ID_1759088756" MODIFIED="1532056889098" TEXT="&#x533a;&#x522b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1488893029063" FOLDED="true" ID="ID_1924651514" MODIFIED="1532056889098" TEXT="1.&#x542b;&#x4e49;">
<node COLOR="#111111" CREATED="1488893033054" ID="ID_1021614976" MODIFIED="1488893033054" TEXT="throw &#x662f;&#x8bed;&#x53e5;&#x629b;&#x51fa;&#x4e00;&#x4e2a;&#x5f02;&#x5e38;&#xff1b;throws &#x662f;&#x65b9;&#x6cd5;&#x629b;&#x51fa;&#x4e00;&#x4e2a;&#x5f02;&#x5e38;&#xff1b;"/>
</node>
<node COLOR="#111111" CREATED="1488893205546" FOLDED="true" ID="ID_1338876718" MODIFIED="1532056889098" TEXT="2.&#x8bed;&#x6cd5;&#x4e0d;&#x540c;">
<node COLOR="#111111" CREATED="1488893040828" ID="ID_1631447256" MODIFIED="1488893110263" TEXT="&#x5728;&#x65b9;&#x6cd5;&#x4f53;&#x4e2d;:   throw &lt;&#x5f02;&#x5e38;&#x5bf9;&#x8c61;&gt;"/>
<node COLOR="#111111" CREATED="1488893071003" ID="ID_1954359269" MODIFIED="1488893138284" TEXT="&#x5728;&#x65b9;&#x6cd5;&#x540d;&#x540e;: throws&lt;&#x5f02;&#x5e38;&#x7c7b;&gt;,&#x800c;&#x4e14;&#x662f;&#x53ef;&#x4ee5;&#x662f;&#x591a;&#x4e2a;,&#x7528;&#x9017;&#x53f7;&#x5206;&#x5f00;"/>
</node>
<node COLOR="#111111" CREATED="1488893251425" FOLDED="true" ID="ID_1371801327" MODIFIED="1532056889098" TEXT="3.&#x5f02;&#x5e38;&#x629b;&#x51fa;&#x7684;&#x786e;&#x5b9a;&#x6027;">
<node COLOR="#111111" CREATED="1488893264092" ID="ID_1330514346" MODIFIED="1488893294411" TEXT="throws&#x8868;&#x793a;&#x65b9;&#x6cd5;&#x6709;&#x53ef;&#x80fd;&#x4f1a;&#x629b;&#x51fa;&#x5f02;&#x5e38;,&#x4ee3;&#x8868;&#x4e0d;&#x786e;&#x5b9a;"/>
<node COLOR="#111111" CREATED="1488893294905" ID="ID_1015221369" MODIFIED="1488893308652" TEXT="throw&#x660e;&#x786e;&#x8868;&#x793a;&#x4f1a;&#x629b;&#x51fa;&#x5f02;&#x5e38;"/>
</node>
<node COLOR="#111111" CREATED="1488893486586" FOLDED="true" ID="ID_644705099" MODIFIED="1532056889098" TEXT="4.&#x4ee3;&#x7801;&#x5904;&#x7406;">
<node COLOR="#111111" CREATED="1488893497318" FOLDED="true" ID="ID_1500743379" MODIFIED="1532056889098" TEXT="throws&#x7684;&#x65b9;&#x6cd5;&#x88ab;&#x8c03;&#x7528;&#x65f6;&#x5fc5;&#x987b;&#x88ab;&#x5904;&#x7406;">
<node COLOR="#111111" CREATED="1488893539093" ID="ID_1761407812" MODIFIED="1488893581407" TEXT="&#x8c03;&#x7528;&#x8005;&#x7ee7;&#x7eed;&#x4e0a;&#x629b;&#x9519;&#x8bef;"/>
<node COLOR="#111111" CREATED="1488893583139" ID="ID_154552793" MODIFIED="1488893591887" TEXT="&#x6216;&#x8005;try-catch"/>
</node>
<node COLOR="#111111" CREATED="1488893611385" ID="ID_200488644" MODIFIED="1488893694544" TEXT="throw &#x7684;&#x65b9;&#x6cd5;&#x65e0;&#x9700;&#x5904;&#x7406;"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1513320761376" FOLDED="true" ID="ID_1272321213" MODIFIED="1532056889098" POSITION="left" TEXT="&#x5934;&#x6587;&#x4ef6;import">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1513320771735" ID="ID_1677999927" MODIFIED="1513320790172" TEXT="import java.lang.String">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1513320837224" FOLDED="true" ID="ID_1175114364" MODIFIED="1532056889098" TEXT="&#x8303;&#x4f8b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1513320861048" FOLDED="true" ID="ID_746228630" MODIFIED="1532056889098" TEXT="import org.junit.*;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1513320875736" ID="ID_891684776" MODIFIED="1513320898117" TEXT="&#x5bfc;&#x5165;&#x7684;org.junit &#x5305;&#x4e0b;&#x7684;&#x6240;&#x6709;&#x6587;&#x4ef6;"/>
</node>
<node COLOR="#990000" CREATED="1513320873473" FOLDED="true" ID="ID_801423085" MODIFIED="1532056889098" TEXT="import java.util.Date;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1513320901872" ID="ID_1594724708" MODIFIED="1513320937134">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23548;&#20837;&#20102;Date&#31867;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1513321245856" FOLDED="true" ID="ID_231972988" MODIFIED="1532056889098" TEXT="import&#x4e00;&#x4e2a;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1513321254160" ID="ID_359149264" MODIFIED="1513321317605" TEXT="import &#x7c7b;&#x7684;&#x5168;&#x8def;&#x5f84;;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1513321262848" FOLDED="true" ID="ID_749693447" MODIFIED="1532056889098" TEXT="import &#x540c;&#x4e00;&#x4e2a;&#x5305;&#x4e0b;&#x7684;&#x6240;&#x6709;&#x7c7b;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1513321289336" ID="ID_868385684" MODIFIED="1513321312405" TEXT="import org.junit.*;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1513320843751" FOLDED="true" ID="ID_306562512" MODIFIED="1532056889098" TEXT="&#x9759;&#x6001; import">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1513321169792" FOLDED="true" ID="ID_729483232" MODIFIED="1532056889098" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1513321172168" ID="ID_80491014" MODIFIED="1513321223237" TEXT="&#x5e38;&#x91cf;&#x7684;&#x4f7f;&#x7528;&#x662f;   &#x7c7b;&#x540d;.&#x5e38;&#x91cf;,&#x4f46;&#x662f;&#x5982;&#x679c;&#x4f7f;&#x7528;&#x7684;&#x9759;&#x6001;&#x5bfc;&#x5165;&#x5219;&#x53ef;&#x4ee5;&#x7701;&#x7565;&#x7c7b;&#x540d;"/>
</node>
<node COLOR="#990000" CREATED="1513321225624" FOLDED="true" ID="ID_784283358" MODIFIED="1532056889098" TEXT="&#x8bed;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1513321227929" ID="ID_922395956" MODIFIED="1513321227929" TEXT="import java.util.Date;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1519466810797" FOLDED="true" ID="ID_1669607376" MODIFIED="1532056889098" POSITION="left" TEXT="&#x5173;&#x952e;&#x5b57;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1519467006993" FOLDED="true" ID="ID_405025265" MODIFIED="1532056889098">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27010;&#35272;
    </p>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node BACKGROUND_COLOR="#ccccff" COLOR="#990000" CREATED="1519466851724" ID="ID_847193748" MODIFIED="1519703455154">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <pre><font color="#000000">&#35775;&#38382;&#25511;&#21046;
private    protected    public

&#31867;</font>,<font color="#000000">&#26041;&#27861;&#21644;&#21464;&#37327;&#20462;&#39280;&#31526;
abstract    class    extends    final    implements    interface    native    new
static    strictfp    synchronized    transient    volatile
    
&#31243;&#24207;&#25511;&#21046;
break    continue    return    do    while    if    else    for    instanceof    switch
case    default
    
&#24322;&#24120;&#22788;&#29702;
try    catch    throw    throws

&#21253;&#30456;&#20851;
import    package
    
&#22522;&#26412;&#31867;&#22411;
boolean    byte    char    double    float    int    long    short    null    true    false

&#21464;&#37327;&#24341;&#29992;
super    this    void
    
&#20445;&#30041;&#23383;
goto    const    </font></pre>
  </body>
</html></richcontent>
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1519467024460" FOLDED="true" ID="ID_1971475801" MODIFIED="1532056889098" TEXT="strictfp">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1519467047487" ID="ID_303363843" MODIFIED="1519467047489" TEXT="&#x7cbe;&#x786e;&#x6d6e;&#x70b9;&#x7684;&#x610f;&#x601d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1519467072943" ID="ID_1293254628" MODIFIED="1519467072944" TEXT="&#x4e00;&#x65e6;&#x4f7f;&#x7528;&#x4e86;strictfp&#x6765;&#x58f0;&#x660e;&#x4e00;&#x4e2a; &#x7c7b;&#x3001;&#x63a5;&#x53e3;&#x6216;&#x8005;&#x65b9;&#x6cd5;&#x65f6;&#xff0c;&#x90a3;&#x4e48;&#x6240;&#x58f0;&#x660e;&#x7684;&#x8303;&#x56f4;&#x5185;Java&#x7684;&#x7f16;&#x8bd1;&#x5668;&#x4ee5;&#x53ca;&#x8fd0;&#x884c;&#x73af;&#x5883;&#x4f1a;&#x5b8c;&#x5168;&#x4f9d;&#x7167;&#x6d6e;&#x70b9;&#x89c4;&#x8303;IEEE-754&#x6765;&#x6267;&#x884c;&#x3002;&#x56e0;&#x6b64;&#x5982;&#x679c;&#x4f60;&#x60f3;&#x8ba9;&#x4f60;&#x7684;&#x6d6e;&#x70b9;&#x8fd0;&#x7b97;&#x66f4;&#x52a0;&#x7cbe;&#x786e;&#xff0c; &#x800c;&#x4e14;&#x4e0d;&#x4f1a;&#x56e0;&#x4e3a;&#x4e0d;&#x540c;&#x7684;&#x786c;&#x4ef6;&#x5e73;&#x53f0;&#x6240;&#x6267;&#x884c;&#x7684;&#x7ed3;&#x679c;&#x4e0d;&#x4e00;&#x81f4;&#x7684;&#x8bdd;&#xff0c;&#x90a3;&#x5c31;&#x8bf7;&#x7528;&#x5173;&#x952e;&#x5b57;strictfp&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1519467090545" ID="ID_1595024561" MODIFIED="1519467090546" TEXT="&#x4f60;&#x53ef;&#x4ee5;&#x5c06;&#x4e00;&#x4e2a;&#x7c7b;&#x3001;&#x63a5;&#x53e3;&#x4ee5;&#x53ca;&#x65b9;&#x6cd5;&#x58f0;&#x660e;&#x4e3a;strictfp&#xff0c;&#x4f46;&#x662f;&#x4e0d;&#x5141;&#x8bb8;&#x5bf9;&#x63a5;&#x53e3;&#x4e2d;&#x7684;&#x65b9;&#x6cd5;&#x4ee5;&#x53ca;&#x6784;&#x9020;&#x51fd;&#x6570;&#x58f0;&#x660e;strictfp&#x5173;&#x952e;&#x5b57;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1472387066327" FOLDED="true" ID="7mmm72b4i7eik3dvts2ddoug97" MODIFIED="1532307180394" POSITION="left" TEXT="&#x64cd;&#x4f5c;&#x7b26;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1472387066327" FOLDED="true" ID="ID_1293012932" MODIFIED="1532056889098" TEXT="&#x7b97;&#x672f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_82737106" MODIFIED="1472778412204" TEXT="+">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_1455413026" MODIFIED="1472778412204" TEXT="-">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_1262943105" MODIFIED="1472778412204" TEXT="*">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_98427373" MODIFIED="1472778412204" TEXT="/">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_953828497" MODIFIED="1472778412204" TEXT="%">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_1741951795" MODIFIED="1532056889098" TEXT="&#x81ea;&#x589e;&#x3001;&#x51cf;">
<font NAME="SansSerif" SIZE="14"/>
<icon BUILTIN="flag"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_630532000" MODIFIED="1532056889098" TEXT="++">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_414965595" MODIFIED="1532056889098" TEXT="&#x524d;&#x7f00;++">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1195236123" MODIFIED="1532056889098" TEXT="&#x5148;&#x6267;&#x884c;&#x81ea;&#x52a0;&#x8fd0;&#x7b97;&#xff0c;&#x7136;&#x540e;&#x8d4b;&#x503c;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1613099296" MODIFIED="1472778412204" TEXT="int i = 1; System.out.println(++i)   :  2"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_122904508" MODIFIED="1532056889098" TEXT="&#x540e;&#x7f00;++">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_957084901" MODIFIED="1532056889098" TEXT="&#x5148;&#x8d4b;&#x503c;&#xff0c;&#x540e;&#x518d;&#x6267;&#x884c;&#x81ea;&#x52a0;&#x8fd0;&#x7b97;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_384441390" MODIFIED="1472778412204" TEXT="int i = 1;   System.out.println(i++);    &#xff1a;   1"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_281880703" MODIFIED="1472778412204" TEXT="&#x4e8c;&#x8005; System.out.println(i) &#x7684;&#x7ed3;&#x679c;&#x90fd;&#x662f; 2"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_948158792" MODIFIED="1532056889098" TEXT="--">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1942316836" MODIFIED="1532056889098" TEXT="&#x6267;&#x884c;&#x540c;&#x4e0a;">
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1745713906" MODIFIED="1532056889098" TEXT="int i = 1;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1867536470" MODIFIED="1472778412220" TEXT="System.out.println(i--);  &#x7ed3;&#x679c;&#x662f; 1"/>
</node>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1021011250" MODIFIED="1532056889098" TEXT=" int j = 1;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1114618589" MODIFIED="1472778412220" TEXT=" System.out.println(--j); &#x7ed3;&#x679c;&#x662f; 0"/>
</node>
</node>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066327" FOLDED="true" ID="ID_77560834" MODIFIED="1532056889098" TEXT="&#x8d4b;&#x503c;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_1587028841" MODIFIED="1472778412220" TEXT="=">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066327" FOLDED="true" ID="ID_360113051" MODIFIED="1532056889098" TEXT="&#x903b;&#x8f91;&#x8fd0;&#x7b97;&#x7b26;(&#x9488;&#x5bf9;boolean&#x6570;&#x636e;)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_1053248640" MODIFIED="1532056889098" TEXT="&amp;&amp;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_1073426693" MODIFIED="1532056889098" TEXT="&#x4f1a;&#x77ed;&#x8def;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1559732938" MODIFIED="1472778412220" TEXT="&#x5f53;&#x524d;&#x9762;&#x7684;&#x4e3a;false&#x662f;&#xff0c;&#x77ed;&#x8def;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_1130797636" MODIFIED="1532056889098" TEXT="||">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066327" FOLDED="true" ID="ID_216540878" MODIFIED="1532056889098" TEXT="&#x4f1a;&#x77ed;&#x8def;">
<node COLOR="#111111" CREATED="1472387066327" ID="ID_302478532" MODIFIED="1472778412220" TEXT="&#x5f53;&#x524d;&#x9762;&#x7684;&#x4e3a;true&#x65f6;&#xff0c;&#x77ed;&#x8def;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_1446567291" MODIFIED="1472778412220" TEXT="!">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066327" FOLDED="true" ID="ID_1555155229" MODIFIED="1532056889098" TEXT="&#x5173;&#x7cfb;&#x64cd;&#x4f5c;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_1484839553" MODIFIED="1472778412220" TEXT="&gt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_1969185041" MODIFIED="1472778412220" TEXT="&gt;=">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_165050906" MODIFIED="1472778412220" TEXT="&lt;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_976450064" MODIFIED="1472778412220" TEXT="&lt;=">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_1403630316" MODIFIED="1532056889098" TEXT="==">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1766663589" MODIFIED="1472778412220" TEXT="&#x5bf9;&#x4e8e;&#x5f15;&#x7528;&#x7c7b;&#x578b;&#xff1a; &#x6bd4;&#x8f83;&#x5bf9;&#x8c61;&#x7684;&#x5730;&#x5740;&#xff0c;&#x7528;&#x6765;&#x5224;&#x65ad;&#x662f;&#x4e0d;&#x662f;&#x540c;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;"/>
<node COLOR="#111111" CREATED="1472387066327" ID="ID_1079922208" MODIFIED="1472778412220" TEXT="&#x5bf9;&#x4e8e;&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;&#xff1a; &#x5224;&#x65ad;&#x503c;&#x662f;&#x5426;&#x76f8;&#x540c;"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" ID="ID_178342359" MODIFIED="1472778412220" TEXT="!=">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066327" FOLDED="true" ID="ID_790523029" LINK="http://developer.51cto.com/art/201106/266454.htm" MODIFIED="1532056889098" TEXT="equals">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1893596760" MODIFIED="1472778412220" TEXT="&#x6bd4;&#x8f83;&#x4e24;&#x4e2a;&#x5bf9;&#x8c61;&#x7684;&#x503c;&#x662f;&#x5426;&#x76f8;&#x540c;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_215843693" MODIFIED="1472778412220" TEXT="&#x6bd4;&#x8f83;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x503c;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1434105173" MODIFIED="1532056889098" TEXT="equalsIgnorecase">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1858495955" MODIFIED="1472778412220" TEXT="&#x53ea;&#x9488;&#x5bf9;&#x4e8e;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1431870608" MODIFIED="1532056889098" TEXT="instanceof">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1654558548" MODIFIED="1472778412220" TEXT="&#x5224;&#x65ad;&#x4e00;&#x4e2a;&#x5bf9;&#x8c61;&#x662f;&#x4e0d;&#x662f;&#x67d0;&#x4e2a;&#x7c7b;&#x7684;&#x5bf9;&#x8c61;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_719907485" MODIFIED="1532056889098" TEXT="&#x4e09;&#x5143;&#x64cd;&#x4f5c;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1881145279" MODIFIED="1532056889098" TEXT="&quot; &#xff1f;  &#xff1a; &quot;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_616872692" MODIFIED="1472778412236" TEXT="boolean - expression ? value0 : value 1;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_45022694" MODIFIED="1532056889098" TEXT="&#x5b57;&#x7b26;&#x4e32;&#x64cd;&#x4f5c;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_96932301" MODIFIED="1472778412236" TEXT="+">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_439118331" MODIFIED="1472778412236" TEXT="+=">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_1392401744" MODIFIED="1532056889098" TEXT="&#x7c7b;&#x578b;&#x8f6c;&#x6362;&#x64cd;&#x4f5c;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1310547723" MODIFIED="1532056889098" TEXT="()">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1244392425" MODIFIED="1472778412236" TEXT="long b = 1L"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1507660162" MODIFIED="1472778412236" TEXT="int i = (int)b"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_1661766519" MODIFIED="1532056889098" TEXT="&#x6309;&#x4f4d;&#x64cd;&#x4f5c;&#x7b26;&#xff08;&#x4e0d;&#x4f1a;&#x77ed;&#x8def;&#xff0c;&#x9488;&#x5bf9;&#x5355;&#x4e2a;bit&#xff09;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1528796372" MODIFIED="1532056889098" TEXT="&amp;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_156839223" MODIFIED="1472778412236" TEXT="&#x4e0e;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1157884246" MODIFIED="1532056889098" TEXT="&amp;=">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1410082317" MODIFIED="1472778412236" TEXT="&#x4e0e;&#xff0c;&#x7136;&#x540e;&#x8d4b;&#x503c;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_36493382" MODIFIED="1532056889098" TEXT="|">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1225627697" MODIFIED="1472778412236" TEXT="&#x6216;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_637830185" MODIFIED="1532056889098" TEXT="|=">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_318789200" MODIFIED="1472778412236" TEXT="&#x6216;&#x8fd0;&#x7b97;&#xff0c;&#x7136;&#x540e;&#x8d4b;&#x503c;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_824535645" MODIFIED="1532056889098" TEXT="^">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1896434584" MODIFIED="1472778412236" TEXT="&#x5f02;&#x6216;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_546932391" MODIFIED="1472778412236" TEXT="&#x76f8;&#x540c;&#x5219;0&#xff0c;&#x4e0d;&#x540c;&#x5219; 1"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1410709050" MODIFIED="1532056889098" TEXT="^=">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1769764712" MODIFIED="1472778412236" TEXT="&#x5f02;&#x6216;&#x8fd0;&#x7b97;&#xff0c;&#x7136;&#x540e;&#x8d4b;&#x503c;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_614579643" MODIFIED="1532056889098" TEXT="~">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_81038788" MODIFIED="1472778412236" TEXT="&#x4e00;&#x5143;&#x64cd;&#x4f5c;&#x7b26;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_222471205" MODIFIED="1472778412236" TEXT="&#x53d6;&#x53cd;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_339644565" LINK="http://www.linuxidc.com/Linux/2015-02/113863.htm" MODIFIED="1532056889098" TEXT="&#x6982;&#x5ff5; &#xff1a; &#x7801;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1634300414" MODIFIED="1532056889098" TEXT="&#x539f;&#x7801;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1309118261" MODIFIED="1472778412236" TEXT="&#x4e00;&#x4e2a;&#x6574;&#x6570;&#xff0c;&#x6309;&#x7167;&#x7edd;&#x5bf9;&#x503c;&#x5927;&#x5c0f;&#x8f6c;&#x6362;&#x6210;&#x7684;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#xff0c;&#x79f0;&#x4e3a;&#x539f;&#x7801;"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1316192789" MODIFIED="1532056889098" TEXT="&#x53cd;&#x7801;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_896988650" MODIFIED="1472778412236" TEXT="&#x5c06;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x6309;&#x4f4d;&#x53d6;&#x53cd;&#xff0c;&#x6240;&#x5f97;&#x7684;&#x65b0;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x79f0;&#x4e3a;&#x539f;&#x4e8c;&#x8fdb;&#x5236;&#x6570;&#x7684;&#x53cd;&#x7801;"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1530709142" MODIFIED="1532056889098" TEXT="&#x8865;&#x7801;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1310994856" MODIFIED="1472778412236" TEXT="&#x53cd;&#x7801;&#x52a0;1&#x79f0;&#x4e3a;&#x8865;&#x7801;"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1172949565" MODIFIED="1472778412236" TEXT="&#x8d1f;&#x6570;&#x4ee5;&#x5176;&#x6b63;&#x503c;&#x7684;&#x8865;&#x7801;&#x8868;&#x793a;"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_475677883" MODIFIED="1532056889098" TEXT="&#x79fb;&#x4f4d;&#x64cd;&#x4f5c;&#x7b26;&#xff08;&#x9488;&#x5bf9;&#x4e8e;&#x6574;&#x6570;&#xff09;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_594254909" MODIFIED="1532056889098" TEXT="&lt;&lt;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1484071825" MODIFIED="1532056889098" TEXT="&#x6709;&#x7b26;&#x53f7;&#x5de6;&#x79fb;&#x52a8;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1846051749" MODIFIED="1499215509805" TEXT="a &lt;&lt; b"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_1539633430" MODIFIED="1472778412236" TEXT="&lt;&lt;=">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1111525868" MODIFIED="1532056889098" TEXT="&gt;&gt;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1996963064" MODIFIED="1532056889098" TEXT="&#x6709;&#x7b26;&#x53f7;&#x53f3;&#x79fb;">
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1563320193" MODIFIED="1532056889098" TEXT="a&gt;&gt; b">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1702517409" MODIFIED="1472778412236" TEXT="a* 2 ^-b"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066342" ID="ID_262211288" MODIFIED="1472778412236" TEXT="&gt;&gt;=">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1156932889" MODIFIED="1532056889098" TEXT="&gt;&gt;&gt;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_474752660" MODIFIED="1472778412251" TEXT="&#x65e0;&#x7b26;&#x53f7;&#x53f3;&#x79fb;"/>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1300585975" MODIFIED="1532056889098" TEXT="&#x6ce8;&#x610f;&#xff1a; &#x8d1f;&#x6570;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_757319546" MODIFIED="1532056889098" TEXT="&#x8d1f;&#x6570;&#x5728;&#x8ba1;&#x7b97;&#x673a;&#x4e2d;&#x5c31;&#x662f;&#x4ee5;&#x8865;&#x7801;&#x7684;&#x5f62;&#x5f0f;&#x4fdd;&#x5b58;">
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_3401721" MODIFIED="1532056889098" TEXT="&#x6700;&#x9ad8;&#x4f4d; 1">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1708278668" MODIFIED="1472778412251" TEXT="&#x8d1f;&#x6570;"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1990716877" MODIFIED="1532056889098" TEXT="&#x6700;&#x9ad8;&#x4f4d; 0">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_464953129" MODIFIED="1472778412251" TEXT="&#x6b63;&#x6570;"/>
</node>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1926253010" MODIFIED="1532056889098" TEXT="&#x539f;&#x7801;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_792074275" MODIFIED="1472778412251" TEXT="&#x5c31;&#x662f;&#x5341;&#x8fdb;&#x5236;&#x7684;&#x6570;&#x5b57;&#x8f6c;&#x6362;&#x4e3a;&#x4e8c;&#x8fdb;&#x5236;&#x5728;&#x8ba1;&#x7b97;&#x673a;&#x4e2d;&#x7684;&#x8868;&#x793a;"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_891524292" MODIFIED="1532056889098" TEXT="&#x53cd;&#x7801;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1649436792" MODIFIED="1472778412251" TEXT="&#x6b63;&#x6570;&#x7684;&#x53cd;&#x7801;&#x548c;&#x539f;&#x7801;&#x76f8;&#x540c;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_348076322" MODIFIED="1472778412251" TEXT="&#x8d1f;&#x6570;&#x7684;&#x53cd;&#x7801;&#x5c31;&#x662f;&#x4fdd;&#x6301;&#x539f;&#x6709;&#x7b26;&#x53f7;&#x4f4d;&#x4e0d;&#x53d8;&#xff0c;&#x5176;&#x4ed6;&#x4f4d;&#x53d6;&#x53cd;"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_627932637" MODIFIED="1532056889098" TEXT="&#x8865;&#x7801;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1395690851" MODIFIED="1472778412251" TEXT="&#x6b63;&#x6570;&#x7684;&#x8865;&#x7801;&#x548c;&#x539f;&#x7801;&#x4e00;&#x6837;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1701620623" MODIFIED="1472778412251" TEXT="&#x8d1f;&#x6570;&#x7684;&#x8865;&#x7801;&#x5c31;&#x662f;&#x5176;&#x53cd;&#x7801; + 1"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1472387066342" FOLDED="true" ID="ID_475690253" MODIFIED="1532056889098" TEXT="&#x6ce8;&#x610f;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_997549018" MODIFIED="1532056889098" TEXT="&#x622a;&#x5c3e;&#x548c;&#x820d;&#x5165;&#x95ee;&#x9898;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1466087285" MODIFIED="1532056889098" TEXT="double &#x6216; float&#x8f6c;&#x6362;&#x4e3a;int&#x65f6;&#x4f1a;&#x6267;&#x884c;&#x622a;&#x5c3e;&#xff08;&#x53bb;&#x6389;&#x5c0f;&#x6570;&#x90e8;&#x5206;&#xff09;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1283910418" MODIFIED="1472778412251" TEXT="double a = 1.7"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1019411847" MODIFIED="1472778412251" TEXT="int i = &#xff08;int&#xff09;a &#xff1b; &#x6b64;&#x65f6; a&#x7684;&#x503c;&#x4e3a; 1"/>
</node>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_188446765" MODIFIED="1532056889098" TEXT="&#x6240;&#x4ee5;&#x5e94;&#x8be5;&#x4f7f;&#x7528; Math.round(num);">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1139180953" MODIFIED="1472778412251" TEXT="Math.round(1.5) = 2&#xff1b;"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_1940952809" MODIFIED="1472778412251" TEXT="Math.round(1.45) = 1&#xff1b;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1538427361" MODIFIED="1532056889098" TEXT="&#x63d0;&#x5347;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" FOLDED="true" ID="ID_1785007794" MODIFIED="1532056889098" TEXT="&#x6307;&#x7684;&#x662f;&#x57fa;&#x672c;&#x6570;&#x636e;&#x7c7b;&#x578b;&#x7684;&#x8fd0;&#x7b97;&#x7684;&#x7ed3;&#x679c;&#x7c7b;&#x578b;&#x603b;&#x662f;&#x548c;&#x7c7b;&#x578b;&#x9ad8;&#x7684;&#x76f8;&#x540c;">
<node COLOR="#111111" CREATED="1472387066342" ID="ID_276920399" MODIFIED="1472778412251" TEXT="&#x5982;&#xff1a; int + long = long &#x7c7b;&#x578b;"/>
</node>
</node>
<node COLOR="#990000" CREATED="1472387066342" FOLDED="true" ID="ID_1353841618" MODIFIED="1532056889098" TEXT="&#x4f18;&#x5148;&#x7ea7;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1472387066342" ID="ID_628404511" LINK="images/60t51fs0lu32hge6gd0e2hso1s.png" MODIFIED="1472778412251" TEXT="&#x8fd0;&#x7b97;&#x7b26;&#x4f18;&#x5148;&#x7ea7;.png"/>
</node>
</node>
</node>
</node>
</map>
