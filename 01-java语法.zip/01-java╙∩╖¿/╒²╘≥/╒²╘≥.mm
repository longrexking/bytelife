<map version="1.0.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1491398671195" ID="ID_408007542" LINK="&#x6b63;&#x5219;.mm" MODIFIED="1491617739706" TEXT="&#x6b63;&#x5219;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1491439493841" FOLDED="true" ID="ID_1018307250" MODIFIED="1522139723285" POSITION="right" TEXT="&#x5206;&#x652f;&#x7ed3;&#x6784;&#xff08;Alternation&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491439508928" FOLDED="true" ID="ID_1356209227" MODIFIED="1522108720440" TEXT="?  ">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439546850" ID="ID_341166605" MODIFIED="1491460653430" TEXT="&#x5f53;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x67d0;&#x4e00;&#x5b50;&#x4e32;&#x5177;&#x6709;&#x591a;&#x79cd;&#x53ef;&#x80fd;&#x65f6;&#xff0c;&#x91c7;&#x7528;&#x5206;&#x652f;&#x7ed3;&#x6784;&#x6765;&#x5339;&#x914d;&#xff0c;&#x201c;|&#x201d;&#x8868;&#x793a;&#x591a;&#x4e2a;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x4e4b;&#x95f4;&#x201c;&#x6216;&#x201d;&#x7684;&#x5173;&#x7cfb;&#xff0c;&#x201c;|&#x201d;&#x662f;&#x4ee5;()&#x9650;&#x5b9a;&#x8303;&#x56f4;&#x7684;&#xff0c;&#x5982;&#x679c;&#x5728;&#x201c;|&#x201d;&#x7684;&#x5de6;&#x53f3;&#x4e24;&#x4fa7;&#x6ca1;&#x6709;()&#x6765;&#x9650;&#x5b9a;&#x8303;&#x56f4;&#xff0c;&#x90a3;&#x4e48;&#x5b83;&#x7684;&#x4f5c;&#x7528;&#x8303;&#x56f4;&#x5373;&#x4e3a;&#x201c;|&#x201d;&#x5de6;&#x53f3;&#x4e24;&#x4fa7;&#x6574;&#x4f53;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439532957" ID="ID_1396899369" MODIFIED="1522108896492" TEXT="|">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439532957" ID="ID_1280587161" MODIFIED="1491460653433" TEXT="&#x591a;&#x4e2a;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x4e4b;&#x95f4;&#x53d6;&#x201c;&#x6216;&#x201d;&#x7684;&#x5173;&#x7cfb;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439678357" ID="ID_878769319" MODIFIED="1522108898677" TEXT="&#x8303;&#x4f8b;1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439691426" ID="ID_408744704" MODIFIED="1491460653435" TEXT="&#x201c;^(aa|b)$&#x201d;&#x5728;&#x533a;&#x914d;&#x201c;cccb&#x201d;&#x65f6;&#xff0c;&#x662f;&#x5339;&#x914d;&#x5931;&#x8d25;&#x7684;&#xff0c;&#x56e0;&#x4e3a;&#x8fd9;&#x4e2a;&#x8868;&#x8fbe;&#x5f0f;&#x8868;&#x793a;&#x5728;&#x201c;&#x5f00;&#x59cb;&#x201d;&#x548c;&#x201c;&#x7ed3;&#x675f;&#x201d;&#x4f4d;&#x7f6e;&#x4e4b;&#x95f4;&#x53ea;&#x80fd;&#x662f;&#x201c;aa&#x201d;&#x6216;&#x201c;b&#x201d;&#xff0c;&#x800c;&#x201c;cccb&#x201d;&#x663e;&#x7136;&#x662f;&#x4e0d;&#x6ee1;&#x8db3;&#x7684;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439710129" ID="ID_798752094" MODIFIED="1522108927122" TEXT="&#x8303;&#x4f8b;2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439713135" ID="ID_1768264839" MODIFIED="1491460653440" TEXT="&#x201c;^aa|b$&#x201d;&#x5728;&#x5339;&#x914d;&#x201c;cccb&#x201d;&#x65f6;&#xff0c;&#x662f;&#x53ef;&#x4ee5;&#x5339;&#x914d;&#x6210;&#x529f;&#x7684;&#xff0c;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x662f;&#x201c;b&#x201d;&#xff0c;&#x56e0;&#x4e3a;&#x8fd9;&#x4e2a;&#x8868;&#x8fbe;&#x5f0f;&#x8868;&#x793a;&#x5339;&#x914d;&#x201c;^aa&#x201d;&#x6216;&#x201c;b&#x201d;&#xff0c;&#x800c;&#x201c;b &#x201d;&#x5728;&#x5339;&#x914d;&#x201c;cccb &#x201d;&#x65f6;&#x662f;&#x53ef;&#x4ee5;&#x5339;&#x914d;&#x6210;&#x529f;&#x7684;&#x3002;&#xa;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491396415076" FOLDED="true" ID="ID_993231406" MODIFIED="1491617739704" POSITION="left" TEXT="?">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491396417094" ID="ID_1532675314" MODIFIED="1491460653414" TEXT="&#x5339;&#x914d;&#x6a21;&#x5f0f;&#xff0c;&#x63cf;&#x8ff0;&#x7684;&#x662f;&#x4e00;&#x4e32;&#x6587;&#x672c;&#x7684;&#x7279;&#x5f81;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491396553438" FOLDED="true" ID="ID_488344417" MODIFIED="1522139716353" POSITION="left" TEXT="&#x6784;&#x6210;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491396575427" FOLDED="true" ID="ID_1889718494" MODIFIED="1491617739704" TEXT="&#x6587;&#x672c;&#x5b57;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396579779" ID="ID_1755299901" MODIFIED="1491460653415" TEXT="&#x5982;: &quot;haha&quot;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396558838" FOLDED="true" ID="ID_1502303245" MODIFIED="1491617739704" TEXT="&#x5143;&#x5b57;&#x7b26;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396666999" FOLDED="true" ID="ID_1440679981" MODIFIED="1491617739704" TEXT="? &#x6b63;&#x5219;&#x4e2d;&#x5b9a;&#x4e49;&#x7684;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491396565036" ID="ID_906005552" MODIFIED="1491396616783" TEXT="&#x5982;: &quot;^&quot;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491396699485" FOLDED="true" ID="ID_478437898" MODIFIED="1522139712324" POSITION="left" TEXT=" [&#x2026;] &#x5b57;&#x7b26;&#x7ec4;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491396708633" ID="ID_481393209" MODIFIED="1522139673117" TEXT="[abc]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708633" ID="ID_381326274" MODIFIED="1491460653416" TEXT="&#x8868;&#x793a;&#x201c;a&#x201d;&#x6216;&#x201c;b&#x201d;&#x6216;&#x201c;c&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708634" ID="ID_941851619" MODIFIED="1522139674192" TEXT="[0-9]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708635" ID="ID_1236978224" MODIFIED="1491460653417" TEXT="&#x8868;&#x793a;0~9&#x4e2d;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x6570;&#x5b57;&#xff0c;&#x7b49;&#x4ef7;&#x4e8e;[0123456789]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708636" FOLDED="true" ID="ID_346683656" MODIFIED="1491617739704" TEXT="[\u4e00-\u9fa5]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708637" ID="ID_1433372235" MODIFIED="1491460653419" TEXT="&#x8868;&#x793a;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x6c49;&#x5b57;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708638" FOLDED="true" ID="ID_666088814" MODIFIED="1491617739704" TEXT="[^a1&lt;]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708638" ID="ID_1048344814" MODIFIED="1491460653419" TEXT="&#x8868;&#x793a;&#x9664;&#x201c;a&#x201d;&#x3001;&#x201c;1&#x201d;&#x3001;&#x201c;&lt;&#x201d;&#x5916;&#x7684;&#x5176;&#x5b83;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491396708639" FOLDED="true" ID="ID_772693986" MODIFIED="1491617739704" TEXT="[^a-z]">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491396708640" ID="ID_1814068553" MODIFIED="1491460653420" TEXT="&#x8868;&#x793a;&#x9664;&#x5c0f;&#x5199;&#x5b57;&#x6bcd;&#x5916;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491458652167" FOLDED="true" ID="ID_998536512" MODIFIED="1491617739704" POSITION="left" TEXT="&#x73af;&#x89c6;&#xff08;Look Around&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491458663935" FOLDED="true" ID="ID_518442502" MODIFIED="1491617739703" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458665309" ID="ID_1607815091" MODIFIED="1491460653463" TEXT="&#x53ea;&#x8fdb;&#x884c;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x7684;&#x5339;&#x914d;&#xff0c;&#x5339;&#x914d;&#x5185;&#x5bb9;&#x4e0d;&#x8ba1;&#x5165;&#x6700;&#x7ec8;&#x7684;&#x5339;&#x914d;&#x7ed3;&#x679c;&#xff0c;&#x662f;&#x96f6;&#x5bbd;&#x5ea6;&#x7684;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491458893194" ID="ID_1352711854" MODIFIED="1491460653465" TEXT="&#x73af;&#x89c6;&#x6309;&#x7167;&#x65b9;&#x5411;&#x5212;&#x5206;&#x6709;&#x987a;&#x5e8f;&#x548c;&#x9006;&#x5e8f;&#x4e24;&#x79cd;&#xff0c;&#x6309;&#x7167;&#x662f;&#x5426;&#x5339;&#x914d;&#x6709;&#x80af;&#x5b9a;&#x548c;&#x5426;&#x5b9a;&#x4e24;&#x79cd;&#xff0c;&#x7ec4;&#x5408;&#x8d77;&#x6765;&#x5c31;&#x6709;&#x56db;&#x79cd;&#x73af;&#x89c6;&#x3002;&#x73af;&#x89c6;&#x76f8;&#x5f53;&#x4e8e;&#x5bf9;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x52a0;&#x4e86;&#x4e00;&#x4e2a;&#x9644;&#x52a0;&#x6761;&#x4ef6;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851528" FOLDED="true" ID="ID_1093049995" MODIFIED="1491617739703" TEXT="(?&lt;=Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851531" FOLDED="true" ID="ID_1177854920" MODIFIED="1491617739703" TEXT="&#x9006;&#x5e8f;&#x80af;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x5de6;&#x4fa7;&#x80fd;&#x591f;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491459966704" ID="ID_1692912390" MODIFIED="1491460031214" TEXT="&#x5982;: (?&lt;=haha),&#x8868;&#x793a;&#x5de6;&#x4fa7;&#x5fc5;&#x987b;&#x662f; haha"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851533" FOLDED="true" ID="ID_61312521" MODIFIED="1491617739703" TEXT="(?&lt;!Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851534" FOLDED="true" ID="ID_1443198615" MODIFIED="1491617739703" TEXT="&#x9006;&#x5e8f;&#x5426;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x5de6;&#x4fa7;&#x4e0d;&#x80fd;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491459966704" ID="ID_1359087895" MODIFIED="1491460046402" TEXT="&#x5982;: (?&lt;!haha),&#x8868;&#x793a;&#x5de6;&#x4fa7;&#x4e0d;&#x80fd;&#x662f; haha"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851536" FOLDED="true" ID="ID_99852633" MODIFIED="1491617739704" TEXT="(?=Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851541" FOLDED="true" ID="ID_266929494" MODIFIED="1491617739704" TEXT="&#x987a;&#x5e8f;&#x80af;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x53f3;&#x4fa7;&#x80fd;&#x591f;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491459966704" ID="ID_192254703" MODIFIED="1491460075361" TEXT="&#x5982;: (?=haha),&#x8868;&#x793a;&#x53f3;&#x4fa7;&#x5fc5;&#x987b;&#x662f; haha"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491458851543" FOLDED="true" ID="ID_800677834" MODIFIED="1491617739704" TEXT="(?!Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491458851544" FOLDED="true" ID="ID_1496615786" MODIFIED="1491617739704" TEXT="&#x987a;&#x5e8f;&#x5426;&#x5b9a;&#x73af;&#x89c6;&#xff0c;&#x8868;&#x793a;&#x6240;&#x5728;&#x4f4d;&#x7f6e;&#x53f3;&#x4fa7;&#x4e0d;&#x80fd;&#x5339;&#x914d;Expression">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491459966704" ID="ID_31787755" MODIFIED="1491460091359" TEXT="&#x5982;: (?!=haha),&#x8868;&#x793a;&#x53f3;&#x4fa7;&#x4e0d;&#x80fd;&#x662f; haha"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398236335" ID="ID_260339544" MODIFIED="1522108947359" POSITION="right" TEXT=". &#x5c0f;&#x6570;&#x70b9;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398257526" ID="ID_1360853336" MODIFIED="1522108948452" TEXT=".">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398257528" ID="ID_201577837" MODIFIED="1491460653421" TEXT="&#x5339;&#x914d;&#x9664;&#x4e86;&#x6362;&#x884c;&#x7b26; \n &#x4ee5;&#x5916;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398271553" FOLDED="true" ID="ID_1445213562" MODIFIED="1522141614695" POSITION="right" TEXT="&#x5176;&#x5b83;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398277039" ID="ID_1334881572" MODIFIED="1522108738317" TEXT="^">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398277040" ID="ID_690579978" MODIFIED="1491460653422" TEXT="&#x5339;&#x914d;&#x5b57;&#x7b26;&#x4e32;&#x5f00;&#x59cb;&#x7684;&#x4f4d;&#x7f6e;&#xff0c;&#x4e0d;&#x5339;&#x914d;&#x4efb;&#x4f55;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398277041" ID="ID_822154357" MODIFIED="1522108740108" TEXT="$">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398277042" ID="ID_387189089" MODIFIED="1491460653422" TEXT="&#x5339;&#x914d;&#x5b57;&#x7b26;&#x4e32;&#x7ed3;&#x675f;&#x7684;&#x4f4d;&#x7f6e;&#xff0c;&#x4e0d;&#x5339;&#x914d;&#x4efb;&#x4f55;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398277042" ID="ID_1754807272" MODIFIED="1522140362014" TEXT="\b">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398277043" FOLDED="true" ID="ID_107558793" MODIFIED="1491617739705" TEXT="&#x5339;&#x914d;&#x5355;&#x8bcd;&#x8fb9;&#x754c;&#xff0c;&#x4e0d;&#x5339;&#x914d;&#x4efb;&#x4f55;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491450417436" FOLDED="true" ID="ID_1545535489" MODIFIED="1491617739705" TEXT="&#x4ec0;&#x4e48;&#x662f;&#x5355;&#x8bcd;&#x8fb9;&#x754c;?">
<node COLOR="#111111" CREATED="1491450427522" ID="ID_981066418" MODIFIED="1491450487486" TEXT="&#x7a7a;&#x683c;,&#x6807;&#x70b9;,&#x5176;&#x4ed6;&#x7b26;&#x53f7;&#x628a;&#x5355;&#x8bcd;&#x5206;&#x5f00;,&#x8fd9;&#x4e9b;&#x7b26;&#x53f7;&#x5c31;&#x662f;&#x5355;&#x8bcd;&#x7684;&#x8fb9;&#x754c;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491449308520" ID="ID_394890696" MODIFIED="1522140358378" TEXT="\B">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491449310152" ID="ID_238201559" MODIFIED="1491460653423" TEXT="&#x5339;&#x914d;&#x975e;&#x5b57;&#x7b26;&#x8fb9;&#x754c;,&#x4e0d;&#x5339;&#x914d;&#x4efb;&#x4f55;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398305035" FOLDED="true" ID="ID_666986448" MODIFIED="1522140355902" POSITION="right" TEXT="&#x8f6c;&#x4e49;&#x5b57;&#x7b26;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398311927" ID="ID_681501909" MODIFIED="1522139110766" TEXT="\r">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398311928" ID="ID_1016777100" MODIFIED="1491460653423" TEXT="&#x56de;&#x8f66;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_1320604285" MODIFIED="1491460653423" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\r">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491444181085" ID="ID_1013137062" MODIFIED="1522139093294" TEXT="\n">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491444189400" ID="ID_1182145912" MODIFIED="1491460653423" TEXT="&#x6362;&#x884c;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_1461495928" MODIFIED="1491460653423" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\n">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398311929" ID="ID_1826222344" MODIFIED="1522139127855" TEXT="\\">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398311930" ID="ID_97168570" MODIFIED="1491460653423" TEXT="&#x5339;&#x914d;&#x201c;\&#x201d;&#x672c;&#x8eab;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457255157" ID="ID_1906537214" MODIFIED="1491460653423" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\\\">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457157254" ID="ID_435171575" MODIFIED="1491617144006" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398311931" ID="ID_717596084" MODIFIED="1522139141019" TEXT="\^">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398311931" ID="ID_867441972" MODIFIED="1491460653424" TEXT="&#x5339;&#x914d;&#x201c;^&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_1493005670" MODIFIED="1491460653424" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\^">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491444200871" ID="ID_1265976658" MODIFIED="1522139155902" TEXT="\$">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491444219942" ID="ID_1673309106" MODIFIED="1491460653424" TEXT="&#x5339;&#x914d;&#x201c;$&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_1504671188" MODIFIED="1491460653424" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\$">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491444206598" FOLDED="true" ID="ID_307118181" MODIFIED="1522139006281" TEXT="\.">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491444228311" ID="ID_1667771361" MODIFIED="1491460653424" TEXT="&#x5339;&#x914d;&#x201c;.&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491457212119" ID="ID_1682688315" MODIFIED="1491460653424" TEXT="&#x4f7f;&#x7528;&#x65f6;,&#x7b26;&#x53f7; \ &#x9700;&#x8981;&#x8f6c;&#x4e49;,&#x6545;&#x8981;&#x5199;&#x6210;:  \\.">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398341198" FOLDED="true" ID="ID_763891548" MODIFIED="1522141609045" POSITION="right" TEXT="&#x91cf;&#x8bcd;&#xff08;Quantifier&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398349489" ID="ID_623430369" MODIFIED="1522107407781" TEXT="{m}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349490" ID="ID_1248682665" MODIFIED="1491460653425" TEXT="?  &#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;m&#x6b21;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491398376249" ID="ID_1272624660" MODIFIED="1522107486374" TEXT="&#x8303;&#x4f8b;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491398349490" ID="ID_1988442540" MODIFIED="1491398362864" TEXT="&#x201c;(abc){2}&#x201d;&#x76f8;&#x5f53;&#x4e8e;&#x201c;abcabc&#x201d;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1491398349490" ID="ID_1772610532" MODIFIED="1491398364465" TEXT="&#x201c;\d{3}&#x201d;&#x76f8;&#x5f53;&#x4e8e;&#x201c;\d\d\d &#x201d;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349491" ID="ID_278170573" MODIFIED="1522107529934" TEXT="{m,n}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349492" ID="ID_1055596030" MODIFIED="1491460653425" TEXT="?  &#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;&#x6700;&#x5c11;m&#x6b21;&#xff0c;&#x6700;&#x591a;n&#x6b21;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491398349493" ID="ID_589272374" MODIFIED="1491460653425" TEXT="&#x8303;&#x4f8b;:  &#x201c;\d{2,3}&#x201d;&#x53ef;&#x4ee5;&#x5339;&#x914d;&#x201c;12&#x201d;&#x6216;&#x201c;321&#x201d;&#x7b49;2&#x5230;3&#x4f4d;&#x7684;&#x6570;&#x5b57;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349494" ID="ID_185568312" MODIFIED="1522107777229" TEXT="{m,}">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349495" ID="ID_1197455042" MODIFIED="1491460653425" TEXT="?  &#x8868;&#x8fbe;&#x5f0f;&#x81f3;&#x5c11;&#x5339;&#x914d;m&#x6b21;">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491398349497" ID="ID_810291160" MODIFIED="1491460653425" TEXT="&#x8303;&#x4f8b;:    &#x201c;[a-z]{8,}&#x201d;&#x8868;&#x793a;&#x81f3;&#x5c11;8&#x4f4d;&#x4ee5;&#x4e0a;&#x7684;&#x5b57;&#x6bcd;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349499" ID="ID_1614791631" MODIFIED="1522139199382" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349501" ID="ID_1514570586" MODIFIED="1491460653425" TEXT="  ?  &#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;0&#x6b21;&#x6216;1&#x6b21;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;{0,1}">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491398349503" ID="ID_1787080664" MODIFIED="1491460653425" TEXT="&#x8303;&#x4f8b;:   &#x201c;ab?&#x201d;&#x53ef;&#x4ee5;&#x5339;&#x914d;&#x201c;a&#x201d;&#x6216;&#x201c;ab&#x201d;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349504" ID="ID_948358152" MODIFIED="1522107855579" TEXT="*">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349505" ID="ID_532675029" MODIFIED="1491460653426" TEXT="?    &#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;0&#x6b21;&#x6216;&#x4efb;&#x610f;&#x591a;&#x6b21;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;{0,}">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491398349506" ID="ID_1145058844" MODIFIED="1491460653426" TEXT="&#x8303;&#x4f8b;:   &#x201c;&lt;[^&gt;]*&gt;&#x201d;&#x4e2d;&#x201c;[^&gt;]*&#x201d;&#x8868;&#x793a;0&#x4e2a;&#x6216;&#x4efb;&#x610f;&#x591a;&#x4e2a;&#x4e0d;&#x662f;&#x201c;&gt;&#x201d;&#x7684;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398349510" ID="ID_1305531895" MODIFIED="1522107859590" TEXT="+">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398349511" ID="ID_1617594188" MODIFIED="1491460653426" TEXT="?   &#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;1&#x6b21;&#x6216;&#x4efb;&#x610f;&#x591a;&#x6b21;&#xff0c;&#x81f3;&#x5c11;1&#x6b21;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;{1,}">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1491398349512" ID="ID_352359023" MODIFIED="1491460653426" TEXT="&#x8303;&#x4f8b;:   &#x201c;\d\s+\d&#x201d;&#x8868;&#x793a;&#x4e24;&#x4e2a;&#x6570;&#x5b57;&#x4e2d;&#x95f4;&#xff0c;&#x81f3;&#x5c11;&#x6709;&#x4e00;&#x4e2a;&#x4ee5;&#x4e0a;&#x7684;&#x7a7a;&#x767d;&#x5b57;&#x7b26;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491398082155" FOLDED="true" ID="ID_1274564890" MODIFIED="1522139665377" POSITION="right" TEXT="&#x5e38;&#x89c1;&#x5b57;&#x7b26;&#x8303;&#x56f4;&#x7f29;&#x5199;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491398161174" ID="ID_1708255877" MODIFIED="1522107398033" TEXT="\d">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161175" ID="ID_279739155" MODIFIED="1491460653420" TEXT="&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x6570;&#x5b57;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[0-9]&#xff0c;&#x5373;0~9 &#x4e2d;&#x7684;&#x4efb;&#x610f;&#x4e00;&#x4e2a;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161180" ID="ID_978594169" MODIFIED="1522107392684" TEXT="\D">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161180" ID="ID_692692519" MODIFIED="1491460653420" TEXT="&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x975e;&#x6570;&#x5b57;&#x5b57;&#x7b26;&#xff0c;\d&#x53d6;&#x53cd;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[^0-9]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161177" ID="ID_275010594" MODIFIED="1522107616313" TEXT="\w">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161178" ID="ID_190990591" MODIFIED="1491460653420" TEXT="&#x4efb;&#x610f;&#x4e00;&#x4e2a;&#x5b57;&#x6bcd;&#x6216;&#x6570;&#x5b57;&#x6216;&#x4e0b;&#x5212;&#x7ebf;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[a-zA-Z0-9_]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161181" ID="ID_1658433225" MODIFIED="1522137126031" TEXT="\W">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161182" ID="ID_78020601" MODIFIED="1491460653421" TEXT="\w&#x53d6;&#x53cd;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[^a-zA-Z0-9_]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161179" ID="ID_616037432" MODIFIED="1522107612330" TEXT="\s">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161179" ID="ID_491028297" MODIFIED="1491460653421" TEXT="&#x4efb;&#x610f;&#x7a7a;&#x767d;&#x5b57;&#x7b26;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[ \r\n\f\t\v]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491398161182" ID="ID_248204138" MODIFIED="1522107951138" TEXT="\S">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491398161182" ID="ID_250621755" MODIFIED="1491460653421" TEXT="&#x4efb;&#x610f;&#x975e;&#x7a7a;&#x767d;&#x5b57;&#x7b26;&#xff0c;\s&#x53d6;&#x53cd;&#xff0c;&#x76f8;&#x5f53;&#x4e8e;[^ \r\n\f\t\v]">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491440052447" FOLDED="true" ID="ID_1202514374" MODIFIED="1522108556799" POSITION="left" TEXT="&#x53cd;&#x5411;&#x5f15;&#x7528;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491457673475" ID="ID_735323192" MODIFIED="1491460653459" TEXT="&#x53cd;&#x5411;&#x5f15;&#x7528;&#x7684;&#x4f5c;&#x7528;&#x901a;&#x5e38;&#x662f;&#x7528;&#x6765;&#x67e5;&#x627e;&#x6216;&#x9650;&#x5b9a;&#x91cd;&#x590d;&#x3001;&#x67e5;&#x627e;&#x6216;&#x9650;&#x5b9a;&#x6307;&#x5b9a;&#x6807;&#x8bc6;&#x914d;&#x5bf9;&#x51fa;&#x73b0;&#x7b49;&#x7b49;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1491460143803" FOLDED="true" ID="ID_1433357105" MODIFIED="1491617739702" TEXT="&#x5982;">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491460146163" FOLDED="true" ID="ID_114382253" MODIFIED="1491617739702" TEXT="\1&#xff0c;\2">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491460146164" ID="ID_1362237878" MODIFIED="1491460146164" TEXT="&#x5bf9;&#x5e8f;&#x53f7;&#x4e3a;1&#x548c;2&#x7684;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x53cd;&#x5411;&#x5f15;&#x7528;"/>
</node>
<node COLOR="#990000" CREATED="1491460146164" FOLDED="true" ID="ID_196445043" MODIFIED="1491617739702" TEXT="\k&lt;name&gt;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491460146164" ID="ID_1137694326" MODIFIED="1491460146164" TEXT="&#x5bf9;&#x547d;&#x540d;&#x4e3a;name&#x7684;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x53cd;&#x5411;&#x5f15;&#x7528;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491439975582" FOLDED="true" ID="ID_1604898321" MODIFIED="1522106938222" POSITION="left" TEXT="&#x975e;&#x6355;&#x83b7;&#x7ec4;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491439991544" ID="ID_1407452310" MODIFIED="1522106930406" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439993650" ID="ID_717770299" MODIFIED="1491460653451" TEXT="&#x4e00;&#x4e9b;&#x8868;&#x8fbe;&#x5f0f;&#x4e2d;&#xff0c;&#x4e0d;&#x5f97;&#x4e0d;&#x4f7f;&#x7528;( )&#xff0c;&#x4f46;&#x53c8;&#x4e0d;&#x9700;&#x8981;&#x4fdd;&#x5b58;( )&#x4e2d;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#xff0c;&#x8fd9;&#x65f6;&#x53ef;&#x4ee5;&#x7528;&#x975e;&#x6355;&#x83b7;&#x7ec4;&#x6765;&#x62b5;&#x6d88;&#x4f7f;&#x7528;( )&#x5e26;&#x6765;&#x7684;&#x526f;&#x4f5c;&#x7528;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491440001894" ID="ID_1188949056" MODIFIED="1522106920055" TEXT="(?:Expression) ">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491440015156" ID="ID_862499504" MODIFIED="1491460653456" TEXT="&#x8fdb;&#x884c;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;Expression&#x7684;&#x5339;&#x914d;&#xff0c;&#x5e76;&#x5c06;&#x5339;&#x914d;&#x5185;&#x5bb9;&#x4fdd;&#x5b58;&#x5230;&#x6700;&#x7ec8;&#x7684;&#x6574;&#x4e2a;&#x8868;&#x8fbe;&#x5f0f;&#x7684;&#x533a;&#x914d;&#x7ed3;&#x679c;&#x4e2d;&#xff0c;&#x4f46;Expression&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#x4e0d;&#x5355;&#x72ec;&#x4fdd;&#x5b58;&#x5230;&#x4e00;&#x4e2a;&#x7ec4;&#x5185;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491450674866" FOLDED="true" ID="ID_1468643323" MODIFIED="1522139313979" POSITION="right" TEXT="java&#x4e2d;&#x76f8;&#x5173;&#x7684;&#x7c7b;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491450687764" ID="ID_277913954" MODIFIED="1522106950935" TEXT="Pattern">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491450725351" ID="ID_1902840373" MODIFIED="1522139283132" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491450726737" ID="ID_1944401034" MODIFIED="1491450726737" TEXT="public static boolean matches(String regex, CharSequence input)"/>
<node COLOR="#111111" CREATED="1491450738957" ID="ID_1230087559" MODIFIED="1491450738957" TEXT="public static Pattern compile(String regex)"/>
<node COLOR="#111111" CREATED="1491450758736" FOLDED="true" ID="ID_427236004" MODIFIED="1491617739702" TEXT="public Matcher matcher(CharSequence input)">
<node COLOR="#111111" CREATED="1491450846288" ID="ID_1725267474" MODIFIED="1491450861285" TEXT="&#x901a;&#x8fc7;&#x5339;&#x914d;&#x5f97;&#x5230;Matcher&#x5bf9;&#x8c61;"/>
</node>
<node COLOR="#111111" CREATED="1491450875153" ID="ID_1960056363" MODIFIED="1491450878718" TEXT="public String[] split(CharSequence input)"/>
<node COLOR="#111111" CREATED="1491450811862" FOLDED="true" ID="ID_492903159" MODIFIED="1491617739702" TEXT="public String[] split(CharSequence input, int limit)">
<node COLOR="#111111" CREATED="1491450813696" ID="ID_1221196996" MODIFIED="1491450836771" TEXT="&#x628a;&#x5339;&#x914d;&#x5230;&#x7684;&#x7ed3;&#x679c;&#x653e;&#x5230;&#x6570;&#x7ec4;&#x4e2d;&#x5e76;&#x4e14;&#x8fd4;&#x56de;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491450695039" ID="ID_1243938092" MODIFIED="1522106955457" TEXT="Matcher">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491451297862" FOLDED="true" ID="ID_586470097" MODIFIED="1522139311393" TEXT="&#x65b9;&#x6cd5;">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491451299313" ID="ID_359089138" MODIFIED="1491451299313" TEXT="public Pattern pattern()"/>
<node COLOR="#111111" CREATED="1491451333257" ID="ID_1784279247" MODIFIED="1491451333257" TEXT="public MatchResult toMatchResult()"/>
<node COLOR="#111111" CREATED="1491451364706" FOLDED="true" ID="ID_1795202724" MODIFIED="1491617739702" TEXT="public Matcher reset()">
<node COLOR="#111111" CREATED="1491455584605" ID="ID_1710096626" MODIFIED="1491455673449" TEXT="&#x91cd;&#x7f6e;,&#x8fd8;&#x662f;&#x4e4b;&#x524d;&#x7684;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491455604345" FOLDED="true" ID="ID_1323543375" MODIFIED="1491617739702" TEXT="public Matcher reset(CharSequence input)">
<node COLOR="#111111" CREATED="1491455638655" ID="ID_1066404493" MODIFIED="1491455656216" TEXT="&#x91cd;&#x7f6e;&#x9700;&#x8981;&#x5339;&#x914d;&#x7684;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491451384472" FOLDED="true" ID="ID_1696238088" MODIFIED="1491617739702" TEXT="public Matcher reset(CharSequence input)">
<node COLOR="#111111" CREATED="1491451390377" ID="ID_1841384708" MODIFIED="1491451390377" TEXT="Resets this matcher with a new input sequence."/>
</node>
<node COLOR="#111111" CREATED="1491451404832" FOLDED="true" ID="ID_264230580" MODIFIED="1491617739702" TEXT="public int start()">
<node COLOR="#111111" CREATED="1491451410161" ID="ID_479814931" MODIFIED="1491451410161" TEXT="Returns the start index of the previous match."/>
</node>
<node COLOR="#111111" CREATED="1491451421921" FOLDED="true" ID="ID_755289468" MODIFIED="1491617739703" TEXT="public int start(int group)">
<node COLOR="#111111" CREATED="1491451432884" ID="ID_1015833952" MODIFIED="1491453595032" TEXT="&#x5339;&#x914d;&#x5230;&#x7684;&#x6bcf;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;"/>
<node COLOR="#111111" CREATED="1491453609467" ID="ID_834191824" MODIFIED="1491453652634" TEXT="group :  &#x7ec4;&#x7684;&#x7d22;&#x5f15;"/>
</node>
<node COLOR="#111111" CREATED="1491451453795" FOLDED="true" ID="ID_1316927093" MODIFIED="1491617739703" TEXT="public int start(String name)">
<node COLOR="#111111" CREATED="1491451461800" ID="ID_990194822" MODIFIED="1491453971537" TEXT="name : &#x7ec4;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1491451479987" FOLDED="true" ID="ID_219321137" MODIFIED="1491617739703" TEXT="public int end()">
<node COLOR="#111111" CREATED="1491451432884" ID="ID_1125919896" MODIFIED="1491453605081" TEXT="&#x5339;&#x914d;&#x5230;&#x7684;&#x6bcf;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x7ed3;&#x675f;&#x4f4d;&#x7f6e;"/>
</node>
<node COLOR="#111111" CREATED="1491453562416" FOLDED="true" ID="ID_1838862709" MODIFIED="1491617739703" TEXT="public int end(int group)">
<node COLOR="#111111" CREATED="1491453609467" ID="ID_185150445" MODIFIED="1491453652634" TEXT="group :  &#x7ec4;&#x7684;&#x7d22;&#x5f15;"/>
</node>
<node COLOR="#111111" CREATED="1491453683102" FOLDED="true" ID="ID_706512066" MODIFIED="1491617739703" TEXT="public int end(String name)">
<node COLOR="#111111" CREATED="1491451461800" ID="ID_1033962789" MODIFIED="1491451473386" TEXT="name : &#x7ec4;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1491453787390" FOLDED="true" ID="ID_1970105199" MODIFIED="1491617739703" TEXT="public String group(int group)">
<node COLOR="#111111" CREATED="1491453886767" ID="ID_496435436" MODIFIED="1491453894438" TEXT="&#x8fd4;&#x56de;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491453697212" FOLDED="true" ID="ID_691050981" MODIFIED="1491617739703" TEXT="public String group()">
<node COLOR="#111111" CREATED="1491453793934" FOLDED="true" ID="ID_1208185497" MODIFIED="1491617739703" TEXT="?">
<node COLOR="#111111" CREATED="1491453886767" ID="ID_202105622" MODIFIED="1491453894438" TEXT="&#x8fd4;&#x56de;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491453699138" ID="ID_1645567603" MODIFIED="1491453717860" TEXT="&#x5c31;&#x662f; group(0)"/>
<node COLOR="#111111" CREATED="1491453718278" ID="ID_1908038953" MODIFIED="1491453779261" TEXT="0&#x7ec4;&#x6307;&#x7684;&#x662f;&#x6574;&#x4e2a;&#x6b63;&#x5219;, 1,2&#x7b49;&#x6307;&#x7684;&#x662f;&#x5b50;&#x7ec4;"/>
</node>
<node COLOR="#111111" CREATED="1491453907183" FOLDED="true" ID="ID_1859743703" MODIFIED="1491617739703" TEXT="public String group(String name)">
<node COLOR="#111111" CREATED="1491453911343" ID="ID_571993315" MODIFIED="1491453954265" TEXT="&#x901a;&#x8fc7;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x540d;&#x5b50;&#x6765;&#x83b7;&#x53d6;&#x5339;&#x914d;&#x7684;&#x7ed3;&#x679c;&#x5b57;&#x7b26;&#x4e32;"/>
<node COLOR="#111111" CREATED="1491453936769" ID="ID_1678344104" MODIFIED="1491453943549" TEXT="name: &#x7ec4;&#x7684;&#x540d;&#x5b57;"/>
</node>
<node COLOR="#111111" CREATED="1491453984060" FOLDED="true" ID="ID_1642645667" MODIFIED="1491617739703" TEXT="public int groupCount()">
<node COLOR="#111111" CREATED="1491453993477" ID="ID_308967375" MODIFIED="1491454000597" TEXT="&#x8fd4;&#x56de;&#x6355;&#x83b7;&#x7ec4;&#x7684;&#x6570;&#x91cf;"/>
</node>
<node COLOR="#111111" CREATED="1491454008047" FOLDED="true" ID="ID_1786983020" MODIFIED="1491617739703" TEXT="public boolean matches()">
<node COLOR="#111111" CREATED="1491454019332" ID="ID_183030784" MODIFIED="1491455026467" TEXT="&#x5168;&#x90e8;&#x5339;&#x914d;,&#x5339;&#x914d;&#x6574;&#x4e2a;&#x5b57;&#x7b26;&#x4e32;&#x624d;&#x8fd4;&#x56de;true"/>
</node>
<node COLOR="#111111" CREATED="1491454034153" FOLDED="true" ID="ID_1776675776" MODIFIED="1491617739703" TEXT="public boolean find()">
<node COLOR="#111111" CREATED="1491454259613" ID="ID_1157579865" MODIFIED="1491454691205" TEXT="&#x90e8;&#x5206;&#x5339;&#x914d;"/>
<node COLOR="#111111" CREATED="1491454320058" ID="ID_322399693" MODIFIED="1491455529618" TEXT="&#x4ece;&#x5f53;&#x524d;&#x4f4d;&#x7f6e;(&#x5339;&#x914d;&#x6210;&#x529f;&#x4e4b;&#x540e;&#x7ed3;&#x675f;&#x7684;&#x4f4d;&#x7f6e;)&#x5f00;&#x59cb;&#x5339;&#x914d;&#xff0c;&#x627e;&#x5230;&#x4e00;&#x4e2a;&#x5339;&#x914d;&#x7684;&#x5b50;&#x4e32;&#xff0c;&#x5c06;&#x79fb;&#x52a8;&#x4e0b;&#x6b21;&#x5339;&#x914d;&#x7684;&#x4f4d;&#x7f6e;"/>
<node COLOR="#111111" CREATED="1491455541957" ID="ID_1186971372" MODIFIED="1491455551903" TEXT="&#x901a;&#x5e38;&#x548c; while&#x5faa;&#x73af;&#x914d;&#x5408;&#x4f7f;&#x7528;"/>
</node>
<node COLOR="#111111" CREATED="1491454416758" FOLDED="true" ID="ID_575790806" MODIFIED="1491617739703" TEXT="public boolean find(int start)">
<node COLOR="#111111" CREATED="1491454419253" ID="ID_794899768" MODIFIED="1491454454493" TEXT="start : &#x4ece;&#x6307;&#x5b9a;&#x7684;&#x4f4d;&#x7f6e;&#x5f00;&#x59cb;&#x5339;&#x914d;"/>
</node>
<node COLOR="#111111" CREATED="1491454959326" FOLDED="true" ID="ID_1877941047" MODIFIED="1491617739703" TEXT="public boolean lookingAt()">
<node COLOR="#111111" CREATED="1491455029647" ID="ID_67884926" MODIFIED="1491455459386" TEXT="&#x90e8;&#x5206;&#x5339;&#x914d;"/>
<node COLOR="#111111" CREATED="1491455447846" ID="ID_921714682" MODIFIED="1491455447846" TEXT="&#x603b;&#x662f;&#x4ece;&#x7b2c;&#x4e00;&#x4e2a;&#x5b57;&#x7b26;&#x8fdb;&#x884c;&#x5339;&#x914d;,&#x5339;&#x914d;&#x6210;&#x529f;&#x4e86;&#x4e0d;&#x518d;&#x7ee7;&#x7eed;&#x5339;&#x914d;&#xff0c;&#x5339;&#x914d;&#x5931;&#x8d25;&#x4e86;,&#x4e5f;&#x4e0d;&#x7ee7;&#x7eed;&#x5339;&#x914d;&#x3002;"/>
</node>
<node COLOR="#111111" CREATED="1491455143690" FOLDED="true" ID="ID_1254603870" MODIFIED="1491617739703" TEXT="public String replaceAll(String replacement)">
<node COLOR="#111111" CREATED="1491455155506" ID="ID_120431951" MODIFIED="1491455194802" TEXT="replacement : &#x65b0;&#x7684;&#x5b57;&#x7b26;&#x4e32;"/>
</node>
<node COLOR="#111111" CREATED="1491455207414" ID="ID_323683362" MODIFIED="1491455207414" TEXT="public String replaceFirst(String replacement)"/>
<node COLOR="#111111" CREATED="1491455241168" FOLDED="true" ID="ID_1530203223" MODIFIED="1491617739703" TEXT="public Matcher region(int start, int end)">
<node COLOR="#111111" CREATED="1491455250629" ID="ID_639689810" MODIFIED="1491455261967" TEXT="&#x8bbe;&#x7f6e;&#x9700;&#x8981;&#x5339;&#x914d;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x7684;&#x533a;&#x57df;"/>
<node COLOR="#111111" CREATED="1491455262721" ID="ID_1921149011" MODIFIED="1491455279789" TEXT="start :&#x5f00;&#x59cb;&#x4f4d;&#x7f6e;&#x7684;&#x4e0b;&#x6807;"/>
<node COLOR="#111111" CREATED="1491455269600" ID="ID_1843851289" MODIFIED="1491455282243" TEXT="end: &#x7ed3;&#x675f;&#x4f4d;&#x7f6e;&#x7684;&#x4e0b;&#x6807;"/>
</node>
<node COLOR="#111111" CREATED="1491455296082" FOLDED="true" ID="ID_881787733" MODIFIED="1491617739703" TEXT="public int regionStart()">
<node COLOR="#111111" CREATED="1491455300569" ID="ID_144715092" MODIFIED="1491455321301" TEXT="&#x8fd4;&#x56de;&#x9700;&#x8981;&#x5339;&#x914d;&#x533a;&#x57df;&#x7684;&#x8d77;&#x59cb;&#x4f4d;&#x7f6e;"/>
</node>
<node COLOR="#111111" CREATED="1491455329153" FOLDED="true" ID="ID_863940411" MODIFIED="1491617739703" TEXT="public int regionEnd()">
<node COLOR="#111111" CREATED="1491455300569" ID="ID_1194946187" MODIFIED="1491455340337" TEXT="&#x8fd4;&#x56de;&#x9700;&#x8981;&#x5339;&#x914d;&#x533a;&#x57df;&#x7684;&#x7ed3;&#x675f;&#x4f4d;&#x7f6e;"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1491451315979" FOLDED="true" ID="ID_473398488" MODIFIED="1522139294809" TEXT="MatchResult">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491455848297" FOLDED="true" ID="ID_1964888993" MODIFIED="1491617739703" TEXT="?">
<font NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1491455849995" ID="ID_874819305" MODIFIED="1491455869643" TEXT="&#x4e00;&#x4e2a;&#x63a5;&#x53e3;,Matcher&#x5b9e;&#x73b0;&#x7684;&#x63a5;&#x53e3;"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1491439850074" FOLDED="true" ID="ID_1210190763" MODIFIED="1522139662841" POSITION="right" TEXT="&#x6355;&#x83b7;&#x7ec4;&#xff08;Capture Group&#xff09;">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="SansSerif" SIZE="18"/>
<node COLOR="#00b439" CREATED="1491439859982" FOLDED="true" ID="ID_1082741429" MODIFIED="1491617739702" TEXT="?">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439861931" ID="ID_787304167" MODIFIED="1491460653445" TEXT="&#x6355;&#x83b7;&#x7ec4;&#x5c31;&#x662f;&#x628a;&#x6b63;&#x5219;&#x8868;&#x8fbe;&#x5f0f;&#x4e2d;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#xff0c;&#x4fdd;&#x5b58;&#x5230;&#x5185;&#x5b58;&#x4e2d;&#x4ee5;&#x6570;&#x5b57;&#x7f16;&#x53f7;&#x6216;&#x624b;&#x52a8;&#x547d;&#x540d;&#x7684;&#x7ec4;&#x91cc;&#xff0c;&#x4ee5;&#x4f9b;&#x540e;&#x9762;&#x5f15;&#x7528;&#x3002;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439871425" ID="ID_1350109729" MODIFIED="1522106896661" TEXT="(Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439871425" ID="ID_774314133" MODIFIED="1491460653448" TEXT="&#x666e;&#x901a;&#x6355;&#x83b7;&#x7ec4;&#xff0c;&#x5c06;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;Expression&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#x4fdd;&#x5b58;&#x5230;&#x4ee5;&#x6570;&#x5b57;&#x7f16;&#x53f7;&#x7684;&#x7ec4;&#x91cc;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1491439871503" FOLDED="true" ID="ID_1154760234" MODIFIED="1522139661549" TEXT="(?&lt;name&gt; Expression)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1491439871503" ID="ID_269043368" MODIFIED="1491460653448" TEXT="&#x547d;&#x540d;&#x6355;&#x83b7;&#x7ec4;&#xff0c;&#x5c06;&#x5b50;&#x8868;&#x8fbe;&#x5f0f;Expression&#x5339;&#x914d;&#x7684;&#x5185;&#x5bb9;&#x4fdd;&#x5b58;&#x5230;&#x4ee5;name&#x547d;&#x540d;&#x7684;&#x7ec4;&#x91cc;">
<font NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
