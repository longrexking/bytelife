/**
 * 
 */
package com.zhiyou.js;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author longWH
 *
 */
public class Test {

	public static void main(String[] args) {
		// show("b");
		String text = "<textarea rows=\"20\" cols=\"70\">nexus maven repository index properties updating index central</textarea>";
		String regex = "(?:<textarea.*?>)(?<me>.*?)(?:</textarea>)";
//		String regex2 = "(textarea.*?)";
//		String regex3 = "[\u4e00-\u9fa5]";
//		String email = "^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$";
//		match("hah_-eh@ha.a", email);
		match(text, regex);
		//========���Ե��ʱ߽�======
//		String borderRegex = "\\b";
//		match("i,ama, {ba)- ������}[ ", borderRegex);
				
	}

	static void show(String text) {
		String regex = "[a-c]";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(text);
		boolean ret = matcher.find();
		System.out.println(matcher.matches());
		System.out.println(ret);
	}

	static void match(String text, String regex) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(text);
//		if (!matcher.find()) {
//			System.out.println("������Ч����");
//		}
	
//		String[] array = pattern.split(text);
//		for (String e : array) {
//			System.out.println(e);
//		}
//		
		while (matcher.find()) {
			System.out.println(matcher.group("me"));
			System.out.println(matcher.start() +"  "+matcher.end());
//			System.out.println(matcher.group(2));
//			System.out.println(matcher.group(2));
//			System.out.println(matcher.group(3));
		}
		

	}
}
