/**
 * 
 */
package org.lc;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.crypto.Data;

/**
 * @author longWH
 *
 */
public class TestFormatDate {
	public static void main(String[] args) {
		Date date = new Date();
		// showComposite(date);

		common('B');
		common('b');
		common('A');
		common('C');
		common('Y');
		common('y');
		common('j');
		common('m');
		common('d');

	}

	public static void common(char value) {
		GregorianCalendar calendar = new GregorianCalendar();
//		calendar.set(Calendar.YEAR, 1111);
		Date date = calendar.getTime();
		String ret = String.format("%t" + value, date);
		System.out.println(value + ": " + ret);
	}

	/**
	 * @param date
	 */
	private static void showComposite(Date date) {
		String c = String.format("%tc", date);
		System.out.println("c: " + c);
		String F = String.format("%tF", date);
		System.out.println("F: " + F);

		String D = String.format("%tD", date);
		System.out.println("D: " + D);

		String r = String.format("%tr", date);
		System.out.println("r: " + r);

		String R = String.format("%tR", date);
		System.out.println("R: " + R);

		String T = String.format("%tT", date);
		System.out.println("T: " + T);
	}
}
